var nomappingneededcodes=[];
var needsave=false;
var dxString='00000';
var activerowid='';
var dxsystem='';
var accountType="-1";
var rowcount=0;
var defaultPOS=-100;
var defaultdate='';
var defaultdateset='';
var defaultDoctor=-100;
var defaultBillingDoctor=-100;
var defaultProviderId=-1;
var defaultPOSId=-1;
var CPTPickerLoaded=0;
var codeSplitter=":#:";
var isDxPickerLoaded=0;
var savedIdArray	=new Array();
var selectedCPT		=new Array();
var combotd			='';
var tmprowid		=0;
var currentRowId;
var serviceCPT 		= new Array();
var selectedCPT		=new Array();
var removedRow		=new Array();
var selectedDxDesc 	=new Array();
var selectedDx	   	= new Array();
var deletedDx 	   	= new Array();
var deletedDxIndex 	= 0;
var SE_SCROLL_TOP=0,SE_SCROLL_LEFT=0;
var SE_showing=0;
var idString='';
var mouseClickedAt=-1;
var localPID;
var S_ID=-1;
var cptPickerPage=-1;
var dxPickerPage=-1;
var isFreqCpt=1;
var isFreqDx=1;
var cptReceived=0;
var dxReceived=0;
var sr_fullcontextpath='';
var doctorCombinationCheck=0;
var allowSBDoctorCombination=0;
var sr_practicename='';
var newSPFVisible =1;
var editDOS='';
var comingforedit=0;
var downloadApplet=1;
var isValidating=0;
var patientLoaded=0;
var dosOrDop=1;
var editCPT="";
var dirtybit=0;
var refreshScreen=0;
var AR_ACTION=-1;
var setPQRIload=0;
var dosage_a="";
var defaultBReason=-1;
var defaultNoOfLines=15;
var paymentGroup=0;
var autoLoadCPTPicker=0;
var selectedIndividualDx='';
var isReferringPicker=0;
var dataString="";
var savedServiceIDArray=null;
var ENCOUNTER_TYPE=2;
var PATIENT_DOB="01/01/1900";
var currentRef="";
var loadingLastVisit=0;
var prevCptData;
var z=100;
var defCodeSys;
var prevCptDataDxDesc;
var authAlertOverriden=0;
var ruleenginealert=0; 		
var foottableObj="";		
var medicalNecessityDesc="",medicalNecessityType="",medicalNecessityDx="",moreDateAppend="",totalCount;		
var mNDos="-1";		
var mNSDXAry=[];		
var mNSDXLoadedAry=[];		
var selectedDxInfo=[];		
var medicalNeeded="";		
var currentlySelectedRow="";		
var splitString;		
var choosenValue="",choosenDescValue="";		
var multibodytableObj = document.createElement("table"); //for rule engine		
var multifoottableObj1 = document.createElement("div");		
var problemService=null;		
var saveTypeInfo="";
var savetypechk=0;
var signBitChk=0;
var patientID='';
/*var serviceOrder_msg='';
var serviceOrder_sdoc='';
var serviceOrder_pos='';
var serviceOrder_dos-'';*/
function getSelectedDosage(){return dosage_a;}
function setSelectedDosage(val){dosage_a=val;}
function signBitChk1(){signBitChk=1;}
function reSignBitChk(){signBitChk=0;}
function getSignBitChk(){return signBitChk;}
function getARAction(){return AR_ACTION;}
function setARAction(){AR_ACTION=SR_FROM_AR;}
function doRefreshScreen(){
if( refreshScreen==1) 
return true;
else
 return false;
}
function validatingStatus()
{return isValidating;}
function savetypechkbit()
{return savetypechk;}
function setRefreshScreen(){refreshScreen=1;}
function reSetRefreshScreen(){refreshScreen=0;}
function getDirty(){return dirtybit;}
function setDirty(){dirtybit=1;makeDirty();}
function reSetDirty(){dirtybit=0;}
function getDosOrDop(){return dosOrDop;}
function setDosOrDop(x){dosOrDop=x;}
function setCptReceived(x){cptReceived=x;}
function getCptReceived(){return cptReceived;}
function setDxReceived(x){dxReceived=x;}
function getDxReceived(){return dxReceived;}
function getCptFreq(){return isFreqCpt;}
function setCptFreq(x){isFreqCpt=x;}
function getDxFreq(){return isFreqDx;}
function setDxFreq(x){isFreqDx=x;}
function setCptPickerPage(x){cptPickerPage=x;}
function getCptPickerPage(){return cptPickerPage;}
function setDxPickerPage(x){dxPickerPage=x;}
function getDxPickerPage(){return dxPickerPage;}
function onloadServiceActions(){
	if(navigator.userAgent.toLowerCase().indexOf('chrome')>-1){
		try{ resetData();
	    rowcount=0;
	    clearProcessedCPTArray();
	    setServiceId(-1);
	    savedIdArray	=new Array();
	    savedIdString="";
	    editDOS='';
	    AR_ACTION=-1;
	    setDefaults();
	    selectedDx=new Array();
		}catch(e){}
		}
		else{
			rowcount=0;
			editDOS='';
			setServiceId(-1);
			savedIdArray	=new Array();
			savedIdString="";
			setDefaults();
		}
	YAHOO.glace.servicepanel = new YAHOO.widget.Panel("service_ywin", { effect:{effect:YAHOO.widget.ContainerEffect.FADE , duration:0.25} , width:"30em", fixedcenter: true, constraintoviewport: true, underlay:"none", close:true, visible:false, draggable:true, modal:false } );
	YAHOO.glace.servicepanel.render();
	reSetDirty();
	pqri_LoadMainPanel();
	if(PATIENT_ID >0)
	{
	//showRequestDivStatus(false,tabDetails.SERVICE,0,false,'Loading ...');
	loadService(1);
	loadPQRINeedDiv();
	}
}

function editService(s_id)
{
//clickedTab(tabDetails.SERVICE);
try{ resetData();}catch(e){}
setServiceId(s_id);
savedIdArray	=new Array();
savedIdString="";
rowcount=0;
editDOS='';
AR_ACTION=-1;
setDefaults();
selectedDx=new Array();
reSetDirty();
if(s_id>0)
drawEditService();
}

function editServiceByDos(dos)
{
editDOS=dos;
try{ resetData();}catch(e){}
setServiceId(-2);
savedIdArray	=new Array();
rowcount=0;
setDefaults();
idString='';
AR_ACTION=-1;
document.getElementById('CommonDiv').style.display='none';
selectedDx=new Array();
savedIdString="";
editCPT="";
comingforedit=1;
reSetDirty();
if(dos!='')
drawEditServiceByDos();
}
function goEntry()
{
	multibodytableObj.innerHTML="";		
	multifoottableObj1.innerHTML="";		
	currentlySelectedRow="";
if(patientLoaded==0)
{
document.getElementById('sr_modediv').style.display='none';
document.getElementById('sr_modelink').style.display='none';
try{ resetData();}catch(e){}
     rowcount=0;
     clearProcessedCPTArray();
     setServiceId(-1);
     savedIdArray	=new Array();
     mNSDXAry=[];		
     mNSDXLoadedAry=[];		
     selectedDxInfo=[];
     savedIdString="";
     editDOS='';
     AR_ACTION=-1;
     setDefaults();
     selectedDx=new Array();
     reSetDirty();
     if(PATIENT_ID >0)
     {patientLoaded=1;
     drawHiddenForEdit(PATIENT_ID);
     loadService(2);
     }
}
}
function loadServiceForCart(pId,isUpdated)  //setAllToUpdated() to call after saving to set the status as false
{
if(patientLoaded == 0)
 {
 document.getElementById('sr_modediv').style.display='none';
 document.getElementById('sr_modelink').style.display='none';
 if (localPID != pId)
  {
  	patientLoaded=1;
    try{ resetData();}catch(e){}
    rowcount=0;
     AR_ACTION=-1;
     setDefaults();
     setServiceId(-1);
     savedIdArray	=new Array();
     selectedDx=new Array();
     savedIdString="";
 	 editDOS='';
 	 reSetDirty();
 	 if(pId > 0 )
 	 {
 	 drawHiddenForEdit(pId);
     loadService(1);
     }
   }
 else if(isUpdated)
 {
   AR_ACTION=-1;
    setRefreshScreen();
   if(getServiceid() >0 ){patientLoaded=1;
     editService(getServiceid())}
    else if(editDOS != ''){patientLoaded=1;
     editServiceByDos(editDOS);}
    else
      goEntry();
 }
 
  }
 
}

function editServiceFromAR(s_id)
{
//clickedTab(tabDetails.SERVICE);
try{ resetData();}catch(e){}
setServiceId(s_id);
savedIdArray	=new Array();
savedIdString="";
rowcount=0;
editDOS='';
setDefaults();
selectedDx=new Array();
reSetDirty();
if(s_id>0)
{setARAction();
drawEditService();}
}
var selectPool = {
	set : function(id, options) {this[id] = options;},
	get : function(id) {return this[id];}
}
function addCase(){
	var win = window.open( "../../../jsp/billing/superbill/CaseDetail.jsp?patientId=" + PATIENT_ID,"AddCase","left=400,top=250, width=400, height=200, scrollbar=no, resizable=no");
}
function setSavedId(ids){
	savedIdString=ids;
	var id=ids.split(':');
	for(var i=0;i<id.length;i++)
	    {
		savedIdArray[i]=id[i].split('~')[1];
	
		}
}
function setRemovedRow(ids){
	removedRow[ids]=ids;
}
function delRemovedRow(ids){
	removedRow[ids]=-1;		
}
function getRemovedRow(pos){
	return removedRow[pos];
}
function HideDiv(divId){
	document.getElementById(divId).style.display="none";
}

function ShowDiv(divId){
	document.getElementById(divId).style.display="block";
}
function getCptPickerLoaded(){return CPTPickerLoaded;}
function setCptPickerAsLoaded(){CPTPickerLoaded=1;}
function getDxPickerLoaded(){return isDxPickerLoaded;}
function setDxPickerAsLoaded(){isDxPickerLoaded=1;}
function textNode(txt){var node=document.createTextNode(txt);return node;}
function setContextpath(val){contextpath=val;}
function setAccountId(val){accountid=val;}
function setDefCodeSys(val){defCodeSys=val;}
function setEnableFlag(val){ enableflag=val;}
function getCurrentRowId(){return currentRowId;}
function setCurrentRowId(x){currentRowId=x;}
function loadCptData(cpt) {
	//createTextBox('CPTtxt_'+getCurrentRowId(),'psblinetextbox1');
	var cptEle=document.getElementById('CPTtxt_'+getCurrentRowId());	
	if(cptEle){
		cptEle.value=cpt;
		cptEle.focus();
		cptEle.blur();
	}
}
function deleteCPTRow(cpt){
	var row=getCurrentRowId();
	var patId=row.substr(0,row.indexOf('_'));
	var totRow=row.substr(row.indexOf('_')+1,row.length);
	var tot=parseInt(totRow);
	var cptEle;
	var delSer;
	for(var i=0;i<=tot;i++){
		try{
			cptEle=document.getElementById('CPTtxt_'+patId+'_'+i);
			delSer=document.getElementById('deleteservice_'+patId+'_'+i);
			if(cptEle.getAttribute('value')==cpt){
				delSer.focus();
				if(document.all)
					delSer.click();
			    else{
					var evt = document.createEvent("MouseEvents");
					evt.initMouseEvent("click", true, true, window,0, 0, 0, 0, 0, false, false, false, false, 0, null);
					delSer.dispatchEvent(evt);
				} 
			}
		}catch(e){}
	}
}
var currentModelService;
var currentModelEdit;
function loadService(x){
if(document.getElementById('CommonDiv').style.display=='none')
	 document.getElementById('CommonDiv').style.display='block';
	try{
	document.getElementById('sr_modediv').style.display='none';
	document.getElementById('sr_modelink').style.display='none';
	document.getElementById('entrytype').innerHTML="&nbsp;Charges Entry";
	document.getElementById('datacontainer').style.height="250px";
	 }catch(e){}
	var fdd=addHiddenField(document.serviceinformation,"doctor");
	fdd=addHiddenField(document.serviceinformation,"entrydate");
	fdd=addHiddenField(document.serviceinformation,"dos");	
	fdd=addHiddenField(document.serviceinformation,"serviceId");
	fdd=addHiddenField(document.serviceinformation,"screen");
	fdd=addHiddenField(document.serviceinformation,"encDate");
	fdd=addHiddenField(document.serviceinformation,"servicedata");
	fdd=addHiddenField(document.serviceinformation,"actionType");
	fdd=addHiddenField(document.serviceinformation,"templateName");
	fdd=addHiddenField(document.serviceinformation,"templateDesc");
	fdd=addHiddenField(document.serviceinformation,"logdata") ;
	fdd=addHiddenField(document.serviceinformation,"dataCollection");
	fdd=addHiddenField(document.serviceinformation,"savedIds");
	localPID=PATIENT_ID;
	fetchSelectFromServer(6,10,11,12,13,14,18,20,21,30,31,32,33,41,50,55,56,201);

	var det=fetchDefaults();
	var model=new ServiceDetail();
	var dataobj=eval(det)[0];
	model.posId=dataobj.pos;
	model.sdoctorId=dataobj.sdoc;
	model.bdoctorId=dataobj.bdoc;
	//model.patientinfo=dataobj.lname+' '+dataobj.fname+","+dataobj.mi;
	model.patientinfo="";
	model.primaryInsId=dataobj.pins;  
	model.secInsId=dataobj.sins;
	defCodeSys=dataobj.defaultDxCodeSystem;
	model.patientId=PATIENT_ID;
	model.refdoctorId=dataobj.rdoc;
	model.rdoctorId="-1";
	model.thirdInsId=dataobj.thirdinsid;
	//setAccountType(dataobj.accType);
	model.typeOfService=1;
	model.accType=dataobj.group_id;
	PATIENT_DOB=dataobj.ptdob;
	ENCOUNTER_TYPE=dataobj.group_id;
	setContextpath(dataobj.contextpath);
	setAccountId(dataobj.accountID);
	setEnableFlag(dataobj.allowLocalValidation);
	doctorCombinationCheck=dataobj.allowDoctorCombination;
	allowSBDoctorCombination=dataobj.allowSBDoctorCombination;
	isReferringPicker=dataobj.isReferringPicker;
	model.submitStatus='0';
		model.date_of_posting=defaultdate;
	defaultdate=dataobj.dop;
	defaultBReason=dataobj.defaultBillingReason;
	defaultNoOfLines=dataobj.defaultNoOfLines;
	paymentGroup=dataobj.paymentGroupOption;
	autoLoadCPTPicker=dataobj.loadCPTPickerAtStartUp;
	fetchOldService('39,40',model.sdoctorId,model.posId,defaultdate);
	var tempbdoc=dataobj.bdoc;
	savedIdString="";
	var result=eval("("+selectPool.get(39)+")");
	savedServiceIDArray = new Array();
	for(var i=0;i<result.length;i++)
	{
	savedServiceIDArray[i]=result[i].serviceid;
	model.rowid=model.patientId+"_"+rowcount;
	tempbdoc=result[i].bdoctorid;
	if(i!=0)
	  {
       model.headersRequired=false;
       savedIdString+=":"+model.rowid+"~"+result[i].serviceid;
       }
      else 
     savedIdString+=model.rowid+"~"+result[i].serviceid;  
	var fieldData=eval("("+selectPool.get(55)+")");
	 createServiceStripMain(model,fieldData,result[i],null);
	 if(result[i].submit_status=='X'){
		 disableFieldsForFullySetteledServices(model.rowid); 
	 }
	 setDxDescription(model.rowid,890);
	document.getElementById('CPTtxt_'+model.rowid).setAttribute("serviceid",result[i].serviceid);
	document.getElementById('VisitTypecmb_'+model.rowid).value=getValueFromPool(result[i].visittype, 10);
	document.getElementById('VisitTypecmb_'+model.rowid).setAttribute("comboval",result[i].visittype);
	document.getElementById('VisitTypecmb_'+model.rowid).setAttribute("orival",result[i].visittype);
	document.getElementById('cmbStatus_'+model.rowid).value=result[i].submit_status;
	
	document.getElementById('billingReasoncmb_'+model.rowid).value=getValueFromPool(result[i].billingreason, 14);
	document.getElementById('billingReasoncmb_'+model.rowid).setAttribute("comboval",result[i].billingreason);
	document.getElementById('billingReasoncmb_'+model.rowid).setAttribute("orival",result[i].billingreason);
	
	document.getElementById('CostPlancmb_'+model.rowid).value=getValueFromPool(result[i].costplanid, 12);
	document.getElementById('CostPlancmb_'+model.rowid).setAttribute("comboval",result[i].costplanid);
	document.getElementById('CostPlancmb_'+model.rowid).setAttribute("orival",result[i].costplanid);
	
	document.getElementById('HowPaidcmb_'+model.rowid).value=getValueFromPool(result[i].howpaidid, 13);
	document.getElementById('HowPaidcmb_'+model.rowid).setAttribute("comboval",result[i].howpaidid);
	document.getElementById('HowPaidcmb_'+model.rowid).setAttribute("orival",result[i].howpaidid);
	
	document.getElementById('Authcmb_'+model.rowid).value=getValueFromPool(result[i].authid, 6);
	document.getElementById('Authcmb_'+model.rowid).setAttribute("comboval",result[i].authid);
	document.getElementById('Authcmb_'+model.rowid).setAttribute("orival",result[i].authid);

	document.getElementById('Statuscmb_'+model.rowid).value=getValueFromPool(result[i].submit_status, 11);
	document.getElementById('Statuscmb_'+model.rowid).setAttribute("comboval",result[i].submit_status);
	document.getElementById('Statuscmb_'+model.rowid).setAttribute("orival",result[i].submit_status);
	
	 if(paymentGroup==1){
	 	document.getElementById('PaymentGroupcmb_'+model.rowid).value=getValueFromPool(result[i].paymentgroup, 41);
		document.getElementById('PaymentGroupcmb_'+model.rowid).setAttribute("comboval",result[i].paymentgroup);
		document.getElementById('PaymentGroupcmb_'+model.rowid).setAttribute("orival",result[i].paymentgroup);
	 }
	 
	 rowcount++;
	}
	if(result.length ==1)
	  model.headersRequired=false;
	document.serviceinformation.savedIds.value=savedIdString;
	var dopObj=document.getElementById('DOPtxt_');
	if(dopObj == null)
	 document.getElementById('CommonDiv').appendChild(createCommonStrip(model));
	 
	model.bdoctorId=tempbdoc;
	model.rowid=model.patientId+"_"+rowcount;		
	rowcount++;
	var fieldData=eval("("+selectPool.get(55)+")");
    var defaultAddFieldData=eval("("+selectPool.get(56)+")");
	createServiceStripMain(model,fieldData,null,defaultAddFieldData);
	currentModelService=model;
	if(selectPool.get(7)==null)
	{
	  fetchComboDataByAjax("4,6,7,8,9,10,12,13,14,15,16,171,51,52,53,200",1);
	  clearProcessedCPTArray();
	 // clearsavedServiceIDArray();
	  }
	else if( doRefreshScreen())
	{
	  reSetRefreshScreen();
	 fetchComboDataByAjax("4,6,7,8,9,10,12,13,14,15,16,171,51,52,53,200",1);
	 clearProcessedCPTArray();
	 clearsavedServiceIDArray();
	 }
	else
	  {
	  setDefaultValuesToCommonStrip(model);
	  setValueForService(model);
	  checkForInsurance();
	  }
    var chdpInsurance=selectPool.get(8);	
	var wcInsurance=selectPool.get(9);
	chdpInsurance=eval(chdpInsurance);
	wcInsurance=eval(wcInsurance);
	try{
		model.chdpInsId=eval(chdpInsurance[0]).hsp001;
		model.wcInsId=eval(wcInsurance[0]).hsp001;
	}catch(e){}		    
	//checkForInsurance();
if(autoLoadCPTPicker==1 && x==1)	
  createCptPicker();	
//dummy('39,40',model.sdoctorId,model.posId,defaultdate);
}
/*function dummy(msg,sdoc,pos,dos){
	//serviceOrder_msg=msg;
	
	alert("===== in dummy =[==== "+msg+""+sdoc+"fggrf"+pos+"dafgdfg"+dos);
}*/
function openCptPicker()
{
if(autoLoadCPTPicker==1 && Common_Picker_obj.style.display=='block')
 {
 close_Common_Picker();
 createCptPicker();
 autoLoadCPTPicker=0;
 }
}

/*function closeLoadingDiv(){
	document.getElementById('LoadingServiceDiv').style.display='none';
}*/
function loadAgain()
{
sr_showEditServices(getServiceid());
}
function drawEditService(){
showRequestDivStatus(false,tabDetails.SERVICE,0,false,'Loading ...');
try{
	document.getElementById('sr_modediv').style.display='block';
	document.getElementById('sr_modelink').style.display='block';
	document.getElementById('defaultValue').style.display='none';
	if(getARAction() == 1 && getServiceid() >0)
	{
	
	addHiddenField(document.serviceinformation,'moduleid');
	addHiddenField(document.serviceinformation,'ad_actionid');
	addHiddenField(document.serviceinformation,'ar_servicedata');
	addHiddenField(document.serviceinformation,'patientid');
	addHiddenField(document.serviceinformation,'actionComments');
	addHiddenField(document.serviceinformation,'ac_nextfollowupaction');
	addHiddenField(document.serviceinformation,'ac_problem');
	addHiddenField(document.serviceinformation,'ac_nextfollowupdate');
	addHiddenField(document.serviceinformation,'ac_notes');
	
	eval("document.serviceinformation.moduleid").value =ar_action_moduleid;
	eval("document.serviceinformation.ad_actionid").value ="8";
	eval("document.serviceinformation.ar_servicedata").value =ar_ConstructServiceData();
	eval("document.serviceinformation.patientid").value =PATIENT_ID;
	eval("document.serviceinformation.actionComments").value =ar_constructActionComments();
	}
	document.getElementById('entrytype').innerHTML="&nbsp;Edit Charges";
	document.getElementById('datacontainer').style.height=((screen.height/3)-10)+"px";
	}catch(e){
	//setTimeout("loadAgain()",500);
	}
	if(document.getElementById('CommonDiv').style.display=='none')
	 document.getElementById('CommonDiv').style.display='block';
	var fdd=addHiddenField(document.serviceinformation,"doctor");
	fdd=addHiddenField(document.serviceinformation,"entrydate");
	fdd=addHiddenField(document.serviceinformation,"dos");	
	fdd=addHiddenField(document.serviceinformation,"serviceId");
	fdd=addHiddenField(document.serviceinformation,"screen");
	fdd=addHiddenField(document.serviceinformation,"encDate");
	fdd=addHiddenField(document.serviceinformation,"servicedata");
	fdd=addHiddenField(document.serviceinformation,"actionType");
	fdd=addHiddenField(document.serviceinformation,"templateName");
	fdd=addHiddenField(document.serviceinformation,"templateDesc");
	fdd=addHiddenField(document.serviceinformation,"logdata") ;
	fdd=addHiddenField(document.serviceinformation,"dataCollection");
	fdd=addHiddenField(document.serviceinformation,"savedIds");
	localPID=PATIENT_ID;
	/*if(selectPool.get(11)==null)
			fetchSelectFromServer(6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,23);
	else*/
	if(sr_fullcontextpath!='')
	fetchSelectFromServer(23,55)
	else
		fetchSelectFromServer(25,23,55,57);
	
	var result=eval("("+selectPool.get(23)+")");
	if(sr_fullcontextpath=='')
	{
	        var dataobj=eval("("+selectPool.get(25)+")");
	        setContextpath(dataobj.contextpath);
			setAccountId(dataobj.accountID);
			setEnableFlag(dataobj.allowLocalValidation);
			sr_fullcontextpath=dataobj.fullcontextpath;
			sr_practicename=dataobj.practicename;
		}	
	for(var i=0;i<result.length;i++)
			{
			var model=new ServiceDetail();
			model.dxsystem=result[i].dxsystem;
			model.posId=result[i].posid;
			model.sdoctorId=result[i].sdoctorid;
			model.bdoctorId=result[i].bdoctorid;
			model.rdoctorId=result[i].rdoctorid;
			model.patientinfo="";
			model. primaryInsId=result[i].priinsid;
			model.secInsId=result[i].secinsid;
			model.patientId=result[i].serviceid;
			model.date_of_posting=result[i].dop;
			model.refdoctorId=result[i].referralid;
			model.caseId=result[i].patientcase;
			model.typeOfService=result[i].typeofservice;
			model.submitStatus=result[i].submit_status;
			model.accType=result[i].enctype;
			model.rowid=getServiceid();
			model.ratePlan=result[i].costplanid;
			model.howPaid=result[i].howpaidid;
			model.hospadmittimehrs=result[i].hospadmittimehrs;
			model.hospadmittimemins=result[i].hospadmittimemins;
			model.hospadmittimesecs=result[i].hospadmittimesecs;
			
			model.hosdistimehrs=result[i].hospdistimehrs;
			model.hospdistimemins=result[i].hospdistimemins;
			model.hospdistimesecs=result[i].hospdistimesecs;
			
			model.billingReason=result[i].billingreason;
			model.authorizationId=result[i].authid;
			model.dos=result[i].dosfrom;
			model.dosto=result[i].dosto;
			model.submitStatus=result[i].submit_status;
			
			//document.getElementById('maintable').style.visibility='visible';
			/*try{
			var d=eval("document.serviceinformation.txtDOP_"+getServiceid()).value;
			}
			catch(e){
			     
				 drawHiddenForEdit(getServiceid());
			 }*/
			 var dopObj=document.getElementById('DOPtxt_');
			if(dopObj == null)
	         document.serviceinformation.appendChild(createCommonStrip(model));
	         else
	           drawHiddenForEdit(getServiceid());
		//	 document.serviceinformation.appendChild(createPatientWiseSelects(model));
			var fieldData=eval("("+selectPool.get(55)+")");
						createServiceStripMain(model,fieldData,result[i],null);
			if(selectPool.get(11)==null){
			  currentModelEdit=model;
			  fetchComboDataByAjax("6,7,8,9,10,11,12,13,14,15,16,171,18,20,21,200",2);
	          }
	         else if( doRefreshScreen())
	         {
	         reSetRefreshScreen();
	          currentModelEdit=model;
			  fetchComboDataByAjax("6,7,8,9,10,11,12,13,14,15,16,171,18,20,21,200",2);
	         }
	         else
	         {
	          setDefaultValuesToCommonStripEdit(model)
	          setValueForEditing(model);
	          }
			}
}

function drawEditServiceByDos()
{
showRequestDivStatus(false,tabDetails.SERVICE,0,false,'Loading ...');
localPID=PATIENT_ID;
try{
	document.getElementById('sr_modediv').style.display='block';
	document.getElementById('sr_modelink').style.display='block';
	document.getElementById('defaultValue').style.display='none';
	document.getElementById('entrytype').innerHTML="&nbsp;Edit Charges";
	document.getElementById('datacontainer').style.height="500px";
	}catch(e){
	//setTimeout("loadAgain()",500);
	}
addHiddenField(document.serviceinformation,'servicedata');
addHiddenField(document.serviceinformation,'actionType');
addHiddenField(document.serviceinformation,'patientId');
addHiddenField(document.serviceinformation,'takeARAction');
addHiddenField(document.serviceinformation,"logdata") ;
if(sr_fullcontextpath=='')
{
fetchSelectFromServer(25);
var con_info=eval("("+selectPool.get(25)+")");
setContextpath(con_info.contextpath);
setAccountId(con_info.accountID);
setEnableFlag(con_info.allowLocalValidation);
allowSBDoctorCombination=con_info.allowSBDoctorCombination;
sr_fullcontextpath=con_info.fullcontextpath;
sr_practicename=con_info.practicename;
}
fetchSelectFromServer(24,55,58,201);
var result=eval("("+selectPool.get(24)+")");
var fieldData=eval("("+selectPool.get(55)+")");
for(var i=0;i<result.length;i++)
{
  editCPT=editCPT+","+result[i].cptcode;
  createServiceForEditByDos(result[i],i,fieldData);
}
if(selectPool.get(11)==null){
fetchComboDataByAjax("6,7,8,9,10,11,12,13,14,15,16,171,18,20,21,200",3);
}
else if(doRefreshScreen())
{
reSetRefreshScreen();
fetchComboDataByAjax("6,7,8,9,10,11,12,13,14,15,16,171,18,20,21,200",3);
}
else
setValuesForEditingByDos();
}

function setValuesForEditingByDos()
{
var result=eval("("+selectPool.get(24)+")");
var uniqueKey;
var model;
for(var i=0;i<result.length;i++)
{
uniqueKey=result[i].serviceid;
model=result[i];
document.getElementById('XSDoctorcmb_'+uniqueKey).value=getValueFromPool(model.sdoctorid, 16);
document.getElementById('XSDoctorcmb_'+uniqueKey).setAttribute("comboval",model.sdoctorid);
document.getElementById('XSDoctorcmb_'+uniqueKey).setAttribute("orival",model.sdoctorid);
document.getElementById('XPOScmb_'+uniqueKey).value=getValueFromPool(model.posid, 171);
document.getElementById('XPOScmb_'+uniqueKey).setAttribute("comboval",model.posid);
document.getElementById('XPOScmb_'+uniqueKey).setAttribute("orival",model.posid);
document.getElementById('XServiceTypecmb_'+uniqueKey).value=getValueFromPool(model.enctype, 10);
document.getElementById('XServiceTypecmb_'+uniqueKey).setAttribute("comboval",model.enctype);
document.getElementById('XServiceTypecmb_'+uniqueKey).setAttribute("orival",model.enctype);
document.getElementById('XBDoctorcmb_'+uniqueKey).value=getValueFromPool(model.bdoctorid, 16);
document.getElementById('XBDoctorcmb_'+uniqueKey).setAttribute("comboval",model.bdoctorid);
document.getElementById('XBDoctorcmb_'+uniqueKey).setAttribute("orival",model.bdoctorid);
document.getElementById('XPrimarycmb_'+uniqueKey).value=getValueFromPool(model.priinsid, 20);
document.getElementById('XPrimarycmb_'+uniqueKey).setAttribute("comboval",model.priinsid);
document.getElementById('XPrimarycmb_'+uniqueKey).setAttribute("orival",model.priinsid);
document.getElementById('XCasecmb_'+uniqueKey).value=getValueFromPool(model.patientcase, 7);
document.getElementById('XCasecmb_'+uniqueKey).setAttribute("comboval",model.patientcase);
document.getElementById('XCasecmb_'+uniqueKey).setAttribute("orival",model.patientcase);
document.getElementById('XReferralcmb_'+uniqueKey).value=getValueFromPool(model.referralid, 18);
document.getElementById('XReferralcmb_'+uniqueKey).setAttribute("comboval",model.referralid);
document.getElementById('XReferralcmb_'+uniqueKey).setAttribute("orival",model.referralid);
document.getElementById('XSecondcmb_'+uniqueKey).value=getValueFromPool(model.secinsid, 21);
document.getElementById('XSecondcmb_'+uniqueKey).setAttribute("comboval",model.secinsid);
document.getElementById('XSecondcmb_'+uniqueKey).setAttribute("orival",model.secinsid);
document.getElementById('XThirdcmb_'+uniqueKey).value=getValueFromPool(model.otherinsid, 30);
document.getElementById('XThirdcmb_'+uniqueKey).setAttribute("comboval",model.otherinsid);
document.getElementById('XThirdcmb_'+uniqueKey).setAttribute("orival",model.otherinsid);
document.getElementById('XOrDoctorcmb_'+uniqueKey).value=getValueFromPool(model.rdoctorid, 16);
document.getElementById('XOrDoctorcmb_'+uniqueKey).setAttribute("comboval",model.rdoctorid);
document.getElementById('XOrDoctorcmb_'+uniqueKey).setAttribute("orival",model.rdoctorid);
document.getElementById('XtypeOfServicecmb_'+uniqueKey).value=getValueFromPool(model.typeofservice, 15);
document.getElementById('XtypeOfServicecmb_'+uniqueKey).setAttribute("comboval",model.typeofservice);
document.getElementById('XtypeOfServicecmb_'+uniqueKey).setAttribute("orival",model.typeofservice);
document.getElementById('XStatuscmb_'+uniqueKey).value=getValueFromPool(model.submit_status, 11);
document.getElementById('XStatuscmb_'+uniqueKey).setAttribute("comboval",model.submit_status);
document.getElementById('XStatuscmb_'+uniqueKey).setAttribute("orival",model.submit_status);
document.getElementById('XCostPlancmb_'+uniqueKey).value=getValueFromPool(model.costplanid, 12);
document.getElementById('XCostPlancmb_'+uniqueKey).setAttribute("comboval",model.costplanid, 12);
document.getElementById('XCostPlancmb_'+uniqueKey).setAttribute("orival",model.costplanid, 12);
document.getElementById('XHowPaidcmb_'+uniqueKey).value=getValueFromPool(model.howpaidid, 13);
document.getElementById('XHowPaidcmb_'+uniqueKey).setAttribute("comboval",model.howpaidid);
document.getElementById('XHowPaidcmb_'+uniqueKey).setAttribute("orival",model.howpaidid);
document.getElementById('XbillingReasoncmb_'+uniqueKey).value=getValueFromPool(model.billingreason, 14);
document.getElementById('XbillingReasoncmb_'+uniqueKey).setAttribute("comboval",model.billingreason);
document.getElementById('XbillingReasoncmb_'+uniqueKey).setAttribute("orival",model.billingreason);
document.getElementById('XAuthcmb_'+uniqueKey).value=getValueFromPool(model.authid, 6);
document.getElementById('XAuthcmb_'+uniqueKey).setAttribute("comboval",model.authid);
document.getElementById('XAuthcmb_'+uniqueKey).setAttribute("orival",model.authid);

document.getElementById('XSpDxcmb_'+uniqueKey).value=getValueFromPool(model.spdx, 200);
document.getElementById('XSpDxcmb_'+uniqueKey).setAttribute("comboval",model.spdx);
document.getElementById('XSpDxcmb_'+uniqueKey).setAttribute("orival",model.spdx);
/*var fieldData=eval("("+selectPool.get(55)+")");
if(fieldData!=null)
{
	for(var k=0;k<fieldData.length;k++)
	{
		if(fieldData[k].chargetabdispname=='NDC')
			{
document.getElementById('ndc_'+uniqueKey).value=getValueFromPool(model.ndc, uniqueKey);
document.getElementById('ndc_'+uniqueKey).setAttribute("comboval",model.ndc);
document.getElementById('ndc_'+uniqueKey).setAttribute("orival",model.ndc);
		}
	  }
	}*/
}
patientLoaded=0;
//hideRequestDivStatus(tabDetails.SERVICE,0);
}
function createServiceForEditByDos(model,n,fieldData)
{
var rowid=model.serviceid;
var dontShowCharges = (CAN_NOT_VIEW_CHARGES && CAN_NOT_VIEW_CHARGES!=-1);
 if(idString=='')
	 idString=rowid;
	else
	 idString=idString+"~||~"+rowid;
	 
	 if(document.getElementById('servicegrid')==null){
		var testtable=document.createElement('table');		
		testtable.id='servicegrid';
	}
	else
		var testtable=document.getElementById('servicegrid');
	testtable.id='servicegrid';
	testtable.border='1px';
	testtable.cellPadding="0px";
	testtable.cellSpacing="0px";
	testtable.width='100%';
	//testtable.onfocus=function(event){locateCell(event,this);}
	testtable.className='editableGridService';
	var testbody1=document.createElement('tbody');		
		testbody1.id=rowid+'_main';	
	if(n==0){
		var rowObj=document.createElement('tr');
		rowObj.style.height='19px';
		rowObj.className='tableColHeaderService';
		rowObj.noWrap=true;
		rowObj.appendChild(insertCell('', 'emlbl',1,0,'doclist-col-normal','2%'));
		rowObj.appendChild(insertCell('DOS', 'doslbl',1,0,'doclist-col-normal','7%'));
		rowObj.appendChild(insertCell('DOP', 'doslbl',1,0,'doclist-col-normal','7%'));
		rowObj.appendChild(insertCell('CPT', 'cptlbl',1,0,'doclist-col-normal','5%'));
		rowObj.appendChild(insertCell('Mod1', 'mod1lbl',1,0,'doclist-col-normal','4%'));
		rowObj.appendChild(insertCell('Units', 'unitslbl',1,0,'doclist-col-normal','4%'));
		var ttd = insertCell('Charges', 'chargeslbl',1,0,'doclist-col-normal','6%');
		if(dontShowCharges)
			ttd.style.display = "none";
		rowObj.appendChild(ttd);
		rowObj.appendChild(insertCell('Copay', 'copaylbl',1,0,'doclist-col-normal',((dontShowCharges)?'6%':'5%')));
		rowObj.appendChild(insertCell('CopayPmt', 'copmtlbl',1,0,'doclist-col-normal',((dontShowCharges)?'7%':'6%')));
		rowObj.appendChild(insertCell('', 'emlbl',1,0,'doclist-col-normal','2%')); 
		rowObj.appendChild(insertCell('Dx1', 'dx1lbl',1,0,'doclist-col-normal','4%'));
		rowObj.appendChild(insertCell('Dx2', 'dx2lbl',1,0,'doclist-col-normal','4%'));
		rowObj.appendChild(insertCell('Dx3', 'dx3lbl',1,0,'doclist-col-normal','4%'));
		rowObj.appendChild(insertCell('Dx4', 'dx4lbl',1,0,'doclist-col-normal','4%'));
		rowObj.appendChild(insertCell('Mod2', 'dx4lbl',1,0,'doclist-col-normal','4%'));
		rowObj.appendChild(insertCell('Mod3', 'dx4lbl',1,0,'doclist-col-normal','4%'));
		rowObj.appendChild(insertCell('Mod4', 'dx4lbl',1,0,'doclist-col-normal','4%'));
		//rowObj.appendChild(insertCell('Sp.Dx.', 'dx4lbl',1,0,'doclist-col-normal','35px'));
		rowObj.appendChild(insertCell('Status', 'stslbl',1,0,'doclist-col-normal',((dontShowCharges)?'12%':'10%')));
		rowObj.appendChild(insertCell('Reference', 'reflbl',1,0,'doclist-col-normal',((dontShowCharges)?'12%':'10%')));
		testbody1.appendChild(rowObj);
	}	
		var rowObj=document.createElement('tr');
rowObj.style.height="24px";
rowObj.appendChild(sr_createCell('txtDOS_'+rowid,9,'generaltextbox',model.dosfrom,'bottomsidebordertd','text',model.dosfrom,-1,'',1));
rowObj.appendChild(sr_createCell('txtDOP_'+rowid,9,'generaltextbox',model.dop,'bottomsidebordertd','text',model.dop,-1,'',1));
var cptCell=sr_createCell('txtCPT_'+rowid,5,'generaltextbox',model.cptcode,'bottomsidebordertd','text',model.cptcode,-1,'',1);
//cptCell.firstChild.setAttribute("cpttype",model.cpttype);
cptCell.firstChild.title=model.cptdesc;
rowObj.appendChild(cptCell);
rowObj.appendChild(sr_createCell('txtMod1_'+rowid,3,'generaltextbox',model.mod1,'bottomsidebordertd','text',model.mod1,-1,'',1));
rowObj.appendChild(sr_createCell('txtUnits_'+rowid,3,'generaltextbox',model.units,'bottomsidebordertd','text',model.units,-1,'',1));
var ttd = sr_createCell('txtCharges_'+rowid,7,'generaltextboxrightaligned',setFormattedCurrency(model.charges,CURR_SYM),'bottomsidebordertd','text',model.charges,-1,'',1)
if(dontShowCharges)
ttd.style.display = "none";
rowObj.appendChild(ttd);
addHiddenField(document.serviceinformation,'hdnCharges_'+rowid);
eval("document.serviceinformation.hdnCharges_"+rowid).value=model.charges;
rowObj.appendChild(sr_createCell('txtCopay_'+rowid,5,'generaltextboxrightaligned',setFormattedCurrency(model.copay,CURR_SYM),'bottomsidebordertd','text',model.copay,-1,'',1));
rowObj.appendChild(sr_createCell('txtPayments_'+rowid,11,'generaltextboxrightaligned',setFormattedCurrency(model.payments,CURR_SYM),'bottomsidebordertd','text',model.payments,-1,'',1));
var dxloader=document.createElement("img" );
dxloader.src="../../../images/pointer.gif";
dxloader.title="Dx Picker";
dxloader.onclick=function(){
createDxPicker(model.serviceid);
}
var dx=document.createElement('td');
dx.nowrap=true;
dx.className="bottomsidebordertd";
dx.style.width='10px';
dx.appendChild(dxloader);
rowObj.appendChild(dx);
rowObj.appendChild(sr_createCell('txtDX1_'+rowid,5,'generaltextbox',model.dx1,'bottomsidebordertd','text',model.dx1,-1,'',1));
rowObj.appendChild(sr_createCell('txtDX2_'+rowid,5,'generaltextbox',model.dx2,'bottomsidebordertd','text',model.dx2,-1,'',1));
rowObj.appendChild(sr_createCell('txtDX3_'+rowid,5,'generaltextbox',model.dx3,'bottomsidebordertd','text',model.dx3,-1,'',1));
rowObj.appendChild(sr_createCell('txtDX4_'+rowid,5,'generaltextbox',model.dx4,'bottomsidebordertd','text',model.dx4,-1,'',1));
rowObj.appendChild(sr_createCell('txtMod2_'+rowid,2,'generaltextbox',model.mod2,'bottomsidebordertd','text',model.mod2,-1,'',1));
rowObj.appendChild(sr_createCell('txtMod3_'+rowid,2,'generaltextbox',model.mod3,'bottomsidebordertd','text',model.mod3,-1,'',1));
rowObj.appendChild(sr_createCell('txtMod4_'+rowid,2,'generaltextbox',model.mod4,'bottomsidebordertd','text',model.mod4,-1,'',1));
//rowObj.appendChild(sr_createCell('txtSpDxtxt_'+rowid,2,'generaltextbox',model.spdx,'bottomsidebordertd','text',model.spdx,-1,'5px',1));
rowObj.appendChild(sr_createCell('XStatuscmb_'+rowid,15,'dropdn generaltextbox','Submit Status','bottomsidebordertd','combo','-1',11,'',1));
rowObj.appendChild(sr_createCell('txtTifRef_'+rowid,11,'generaltextbox',model.tif_ref,'bottomsidebordertd','text',model.tif_ref,-1,'',1));
var downpointer=document.createElement("img" );
downpointer.tabIndex=1;
downpointer.src="../../../images/down1.gif"
downpointer.border=0;
downpointer.title='Detail';
var lin=document.createElement("a");
lin.setAttribute("href","javascript:showTable('"+rowid+"');");
lin.appendChild(downpointer);
var td=document.createElement('td');
td.className='bottomsidebordertd';
td.style.width='10px';
td.appendChild(lin);
rowObj.appendChild(td);
testbody1.appendChild(rowObj);
testtable.appendChild(testbody1);		

//******************
var othertable=document.createElement('table');
othertable.className='tableStyleNoBorder';
othertable.setAttribute("name","tableStyleNoBorder");
var otherbody=document.createElement('tbody');
othertable.appendChild(otherbody);
othertable.style.display='none';
othertable.style.width="99%";
othertable.id='others_'+rowid;
var otherrow = document.createElement('tr');
otherrow.style.height='5px';
var totcell=document.createElement('td');
totcell.colSpan="10";
otherrow.appendChild(totcell);
otherbody.appendChild(otherrow);
var widthperCellA;
var widthperCellB;
if(document.implementation)
{
widthperCellA=(screen.width/8)+"px";
widthperCellB=(screen.width/12)+"px";
}
else
{
widthperCellA=(screen.width/10)+"px";
widthperCellB=(screen.width/13)+"px";
}
otherrow = document.createElement('tr');
otherrow.style.height='25px';
otherrow.appendChild(insertCellSpl('Service Doctor','costplanlbl_'+rowid,1,0,'othertddata','5%',1));
otherrow.appendChild(sr_createCell('XSDoctorcmb_'+rowid,-100,'dropdn generaltextbox','None','databordertd','combo','-1',16,widthperCellA,'1'));
otherrow.appendChild(insertCellSpl('Billing Doctor','costplanlbl_'+rowid,1,0,'othertddata','5%',1));
otherrow.appendChild(sr_createCell('XBDoctorcmb_'+rowid,-100,'dropdn generaltextbox','None','databordertd','combo','-1',16,widthperCellA,'1'));
otherrow.appendChild(insertCellSpl('Referring Doctor','costplanlbl_'+rowid,1,0,'othertddata','5%',1));
otherrow.appendChild(sr_createCell('XReferralcmb_'+rowid,-100,'dropdn generaltextbox','None','databordertd','combo','-1',18,widthperCellA,'1'));
otherrow.appendChild(insertCellSpl('R Doctor','costplanlbl_'+rowid,1,0,'othertddata','5%',1));
otherrow.appendChild(sr_createCell('XOrDoctorcmb_'+rowid,-100,'dropdn generaltextbox','None','databordertd','combo','-1',16,widthperCellB,'1'));
otherrow.appendChild(insertCellSpl('TOS','costplanlbl_'+rowid,1,0,'othertddata','5%',1));
otherrow.appendChild(sr_createCell('XtypeOfServicecmb_'+rowid,-100,'dropdn generaltextbox','None','databordertd','combo','-1',15,widthperCellB,'1'));
otherbody.appendChild(otherrow);

otherrow = document.createElement('tr');
otherrow.style.height='5px';
totcell=document.createElement('td');
totcell.colSpan="10";
otherrow.appendChild(totcell);
otherbody.appendChild(otherrow);

otherrow = document.createElement('tr');
otherrow.style.height='25px';
otherrow.appendChild(insertCellSpl('POS','costplanlbl_'+rowid,1,0,'othertddata','5%',1));
otherrow.appendChild(sr_createCell('XPOScmb_'+rowid,-100,'dropdn generaltextbox','None','databordertd','combo','-1',171,widthperCellA,'1'));
otherrow.appendChild(insertCellSpl('Pri Ins','costplanlbl_'+rowid,1,0,'othertddata','5%',1));
otherrow.appendChild(sr_createCell('XPrimarycmb_'+rowid,-100,'dropdn generaltextbox','None','databordertd','combo','-1',20,widthperCellA,'1'));
otherrow.appendChild(insertCellSpl('Sec Ins','costplanlbl_'+rowid,1,0,'othertddata','5%',1));
otherrow.appendChild(sr_createCell('XSecondcmb_'+rowid,-100,'dropdn generaltextbox','None','databordertd','combo','-1',21,widthperCellA,'1'));
otherrow.appendChild(insertCellSpl('How Paid','costplanlbl_'+rowid,1,0,'othertddata','5%',1));
otherrow.appendChild(sr_createCell('XHowPaidcmb_'+rowid,-100,'dropdn generaltextbox','None','databordertd','combo','-1',13,widthperCellB,'1'));
otherrow.appendChild(insertCellSpl('Chk No','costplanlbl_'+rowid,1,0,'othertddata','5%',1));
otherrow.appendChild(sr_createCell('txtCheck_'+rowid,4,'generaltextboxwhite',model.checkno,'databordertd','text',model.checkno,-1,'10%','1'));
otherbody.appendChild(otherrow);

otherrow = document.createElement('tr');
otherrow.style.height='5px';
totcell=document.createElement('td');
totcell.colSpan="10";
otherrow.appendChild(totcell);
otherbody.appendChild(otherrow);

otherrow = document.createElement('tr');
otherrow.style.height='25px';
	otherrow.appendChild(insertCellSpl('Rate Plan','costplanlbl_'+rowid,1,0,'othertddata','5%',1));
	otherrow.appendChild(sr_createCell('XCostPlancmb_'+rowid,-100,'dropdn generaltextbox','None','databordertd','combo','-1',12,widthperCellA,'1'));
	otherrow.appendChild(insertCellSpl('Type','costplanlbl_'+rowid,1,0,'othertddata','5%',1));
	otherrow.appendChild(sr_createCell('XServiceTypecmb_'+rowid,-100,'dropdn generaltextbox','None','databordertd','combo','-1',10,widthperCellA,'1'));
	otherrow.appendChild(insertCellSpl('Case','costplanlbl_'+rowid,1,0,'othertddata','5%',1));
	otherrow.appendChild(sr_createCell('XCasecmb_'+rowid,-100,'dropdn generaltextbox','None','databordertd','combo','-1',7,widthperCellA,'1'));
	//otherrow.appendChild(insertCellSpl('Authorization','costplanlbl_'+rowid,1,0,'othertddata','80px',1,'','1'));
	//otherrow.appendChild(sr_createCell('XAuthcmb_'+rowid,35,'dropdn generaltextbox','None','databordertd','combo',model.authid,6,'150px','3'));
	otherrow.appendChild(insertCellSpl('Comment','costplanlbl_'+rowid,1,0,'othertddata','5%',1));
	otherrow.appendChild(sr_createCell('txtComments_'+rowid,30,'generaltextboxwhite',model.scomments,'databordertd','text',model.scomments,-1,'30%','3'));
otherbody.appendChild(otherrow);


otherrow = document.createElement('tr');
otherrow.style.height='5px';
totcell=document.createElement('td');
totcell.colSpan="10";
otherrow.appendChild(totcell);
otherbody.appendChild(otherrow);

otherrow = document.createElement('tr');
otherrow.style.height='25px';
	
	
	otherrow.appendChild(insertCellSpl('Authorization','costplanlbl_'+rowid,1,0,'othertddata','5%',1));
	otherrow.appendChild(sr_createCell('XAuthcmb_'+rowid,-100,'dropdn generaltextbox','None','databordertd','combo',model.authid,6,widthperCellA,'1'));
	/*var medNoteLink=document.createElement("a");
	medNoteLink.setAttribute("href","javascript:uploadMedNotes("+getPatientId()+",1,'"+rowid+"');");
	var medNote=textNode('Upload Med Notes');
	medNoteLink.appendChild(medNote);
	var td=document.createElement('td');
	td.noWrap=true;
	td.className='othertddata';
	td.appendChild(medNoteLink);
	otherrow.appendChild(td);
	
	var medNoteViewLink=document.createElement("a");
	medNoteViewLink.setAttribute("href","javascript:viewMedNotes('"+model.mednotes+"');");
	var medNoteVies=textNode('View Med Notes');
	medNoteViewLink.appendChild(medNoteVies);
	var td1=document.createElement('td');
	td1.noWrap=true;
	td1.className='othertddata';
	td1.appendChild(medNoteViewLink);
	otherrow.appendChild(td1);*/
	//Commented as per Vasanth
	var commentLink=document.createElement("a");
	commentLink.setAttribute("href","javascript:newServicePayment("+model.serviceid+");");
	var commentLabel=textNode('Enter Comment');
	commentLink.appendChild(commentLabel);
	var td2=document.createElement('td');
	td2.noWrap='true';
	td2.className='othertddata';
	td2.appendChild(commentLink);
	otherrow.appendChild(td2);
//otherrow.appendChild(insertCellSpl('','emptylbl_'+rowid,1,0,'othertddata','15%',1));	
otherrow.appendChild(insertCellSpl('RLU','billrealbl_'+rowid,1,0,'othertddata','5%',1));
otherrow.appendChild(sr_createCell('txtRlu_'+rowid,30,'generaltextboxwhite',model.rlu_claim,'databordertd','text',model.rlu_claim,-1,'30%','3'));
otherbody.appendChild(otherrow);

otherrow = document.createElement('tr');
otherrow.style.height='5px';
totcell=document.createElement('td');
totcell.colSpan="13";
otherrow.appendChild(totcell);
otherbody.appendChild(otherrow);
var otherrow = document.createElement('tr');
otherrow.style.height='20px';	

otherrow.appendChild(insertCellSpl('Hosp Admission Time','hospadmtime_'+rowid,1,0,'othertddata','5%',1));
otherrow.appendChild(createEditCombo('txtadmTimehrs_'+rowid,'4%','othertddata',model.hospadmittimehrs));
otherrow.appendChild(createEditCombo('txtadmTimemins_'+rowid,'4%','othertddata',model.hospadmittimemins));
otherrow.appendChild(createEditCombo('txtadmTimesecs_'+rowid,'4%','othertddata',model.hospadmittimesecs));
otherrow.appendChild(insertCellSpl('Hosp Discharge Time','hospadmtime_'+rowid,1,0,'othertddata','5%',1));
otherrow.appendChild(createEditCombo('txtdisTimehrs_'+rowid,'4%','othertddata',model.hospdistimehrs));
otherrow.appendChild(createEditCombo('txtdisTimemins_'+rowid,'4%','othertddata',model.hospdistimemins));
otherrow.appendChild(createEditCombo('txtdisTimesecs_'+rowid,'4%','othertddata',model.hospdistimesecs));

otherbody.appendChild(otherrow);
otherrow = document.createElement('tr');
otherrow.style.height='5px';
totcell=document.createElement('td');
totcell.colSpan="10";
otherrow.appendChild(totcell);
otherbody.appendChild(otherrow);

otherrow = document.createElement('tr');
otherrow.style.height='25px';
otherrow.appendChild(insertCellSpl('Billing Reason','billrealbl_'+rowid,1,0,'othertddata','5%',1));
otherrow.appendChild(sr_createCell('XbillingReasoncmb_'+rowid,-100,'dropdn generaltextbox','None','databordertd','combo','-1',14,widthperCellA,'1'));
//otherrow.appendChild(insertCellSpl('','billrealbl_'+rowid,1,0,'othertddata','5%',1));
otherrow.appendChild(insertCellSpl('Corrected Claim','billrealbl_'+rowid,1,0,'othertddata','5%',1));
otherrow.appendChild(sr_createCell('XSpDxcmb_'+rowid,12,'dropdn generaltextbox','None','databordertd','combo','-1',200,'15%','1'));
//otherrow.appendChild(sr_createCell('txtSpDxtxt_'+rowid,12,'generaltextboxwhite',model.spdx,'databordertd','text',model.spdx,-1,'15%','1'));
otherrow.appendChild(insertCellSpl('Third Insurance','billrealbl_'+rowid,1,0,'othertddata','5%',1));
otherrow.appendChild(sr_createCell('XThirdcmb_'+rowid,-100,'dropdn generaltextbox','None','databordertd','combo','-1',30,widthperCellA,'1'));
otherbody.appendChild(otherrow);

//Aditional Data
otherrow = document.createElement('tr');
otherrow.style.height='5px';
otherbody.appendChild(otherrow);

if(fieldData!=null)
{
	for(var i=0;i<fieldData.length;i++)
	{
		var tempvar='';
		var tempvar=eval('model.'+fieldData[i].chargetabname);
    if(i%5==0)
    	{
    	otherrow = document.createElement('tr');
    	otherrow.style.height='25px';
    	}
	otherrow.appendChild(insertCellSpl(fieldData[i].chargetabdispname,'fielddata_'+rowid,1,0,'othertddata','2%',1));
	//otherrow.appendChild(sr_createCell(fieldData[i].chargetabname+"_"+rowid,5,'generaltextboxwhite',model.dx8,'databordertd','text',model.dx8,-1,'	',1));
/*if(fieldData[i].chargetabfieldtype=="combo")
	{
		otherrow.appendChild(sr_createCell(fieldData[i].chargetabname+"_"+rowid,'','dropdn generaltextbox',tempvar,'databordertd','combo','-1',rowid,'8%',1));
	}
	else if(fieldData[i].chargetabfieldtype=="date")*/
	if(fieldData[i].chargetabfieldtype=="date")
	{
		var popupcalen=document.createElement("img" );
		popupcalen.tabIndex=0;
		popupcalen.src="../../../images/blue14x14/Calendar.png"
		popupcalen.border=0;
		popupcalen.title='Select Date';
		popupcalen.setAttribute("onclick","popUpCalendar(this,document.getElementById(\""+fieldData[i].chargetabname+"_"+rowid+"\"),\"mm/dd/yyyy\");");
		//Anch.setAttribute("href","javascript:popUpCalendar(this,document.getElementById(\""+fieldData[i].chargetabname+"_"+rowid+"\"),\"mm/dd/yyyy\");");

		var newtd=sr_createCell(fieldData[i].chargetabname+"_"+rowid,-99,'generaltextboxwhite',tempvar,'databordertd','text',tempvar,-1,'7%',1);
		newtd.appendChild(popupcalen);
		otherrow.appendChild(newtd);
		//otherrow.appendChild(sr_createCell(fieldData[i].chargetabname+"_"+rowid,5,'generaltextboxwhite',model.dx8,'databordertd','text',model.dx8,-1,'	',1));	
	}
	else
		otherrow.appendChild(sr_createCell(fieldData[i].chargetabname+"_"+rowid,5,'generaltextboxwhite',tempvar,'databordertd','text',tempvar,-1,'7%',1));
	
	if(i%5==4)
	{
	otherbody.appendChild(otherrow);
	otherrow = document.createElement('tr');
	otherrow.style.height='5px';
	otherbody.appendChild(otherrow);
	}
	}
	otherbody.appendChild(otherrow);	
	otherrow = document.createElement('tr');
	otherrow.style.height='5px';
	otherbody.appendChild(otherrow);
}
addHiddenField(document.serviceinformation,'medNotes_'+rowid);
eval("document.serviceinformation.medNotes_"+rowid).value=model.mednotes;
var rowObj=document.createElement('tr');
rowObj.id='othersContainer_'+rowid;
rowObj.style.height='0px';
var celObj=document.createElement('td');
celObj.colSpan='19';
celObj.width="100%";
celObj.appendChild(othertable);
rowObj.appendChild(celObj);
testbody1.appendChild(rowObj);
//*******
document.serviceinformation.appendChild(testtable);	
} /// END OF THE FUNCTION

function setValueForEditing(model)
{
var uniqueKey=getServiceid();
/*document.getElementById('Statuscmb_'+uniqueKey).value=getValueFromPool(model.submitStatus, 11);
document.getElementById('Statuscmb_'+uniqueKey).setAttribute("comboval",model.submitStatus);
document.getElementById('CostPlancmb_'+uniqueKey).value=getValueFromPool(model.costplanid, 12);
document.getElementById('CostPlancmb_'+uniqueKey).setAttribute("comboval",model.costplanid);
document.getElementById('HowPaidcmb_'+uniqueKey).value=getValueFromPool(model.howpaidid, 13);
document.getElementById('HowPaidcmb_'+uniqueKey).setAttribute("comboval",model.howpaidid);
document.getElementById('billingReasoncmb_'+uniqueKey).value=getValueFromPool(model.billingreason, 14);
document.getElementById('billingReasoncmb_'+uniqueKey).setAttribute("comboval",model.billingreason);
document.getElementById('Authcmb_'+uniqueKey).value=getValueFromPool(model.authid, 6);
document.getElementById('Authcmb_'+uniqueKey).setAttribute("comboval",model.authid);*/
if(getARAction()==1)
{
document.getElementById('Statuscmb_'+uniqueKey).value='EMR Service';
document.getElementById('Statuscmb_'+uniqueKey).setAttribute("comboval","0");
document.getElementById('Statuscmb_'+uniqueKey).setAttribute("orival",model.submitStatus);
}
else
{
document.getElementById('Statuscmb_'+uniqueKey).value=getValueFromPool(model.submitStatus, 11);
document.getElementById('Statuscmb_'+uniqueKey).setAttribute("comboval",model.submitStatus);
document.getElementById('Statuscmb_'+uniqueKey).setAttribute("orival",model.submitStatus);
}
document.getElementById('CostPlancmb_'+uniqueKey).value=getValueFromPool(model.ratePlan, 12);
document.getElementById('CostPlancmb_'+uniqueKey).setAttribute("comboval",model.ratePlan);
document.getElementById('CostPlancmb_'+uniqueKey).setAttribute("orival",model.ratePlan);
document.getElementById('HowPaidcmb_'+uniqueKey).value=getValueFromPool(model.howPaid, 13);
document.getElementById('HowPaidcmb_'+uniqueKey).setAttribute("comboval",model.howPaid);
document.getElementById('HowPaidcmb_'+uniqueKey).setAttribute("orival",model.howPaid);
document.getElementById('billingReasoncmb_'+uniqueKey).value=getValueFromPool(model.billingReason, 14);
document.getElementById('billingReasoncmb_'+uniqueKey).setAttribute("comboval",model.billingReason);
document.getElementById('billingReasoncmb_'+uniqueKey).setAttribute("orival",model.billingReason);
document.getElementById('Authcmb_'+uniqueKey).value=getValueFromPool(model.authorizationId, 6);
document.getElementById('Authcmb_'+uniqueKey).setAttribute("comboval",model.authorizationId);
document.getElementById('Authcmb_'+uniqueKey).setAttribute("orival",model.authorizationId);
/*var fieldData=eval("("+selectPool.get(55)+")");
if(fieldData!=null)
{
	for(var k=0;k<fieldData.length;k++)
	{
		if(fieldData[k].chargetabdispname=='NDC')
			{
document.getElementById('ndc_'+uniqueKey).value=getValueFromPool(model.ndc, model.sId);
document.getElementById('ndc_'+uniqueKey).setAttribute("comboval",model.ndc);
document.getElementById('ndc_'+uniqueKey).setAttribute("orival",model.ndc);
			}
	     }
	}*/
document.getElementById('SpDxcmb_'+uniqueKey).value=getValueFromPool(model.spdx, 200);
document.getElementById('SpDxcmb_'+uniqueKey).setAttribute("comboval",model.spdx);
document.getElementById('SpDxcmb_'+uniqueKey).setAttribute("orival",model.spdx);

patientLoaded=0;
//hideRequestDivStatus(tabDetails.SERVICE,0);
}

function setValueForService(model)
{
var uniqueKey=PATIENT_ID;
if(getServiceid() == -1){
var ins_name=document.getElementById('Primarycmb_').value;
if(ins_name.indexOf('self pay')>-1 ||ins_name.indexOf('selfpay')>-1 || ins_name.indexOf('SELF PAY')>-1 || ins_name.indexOf('SELFPAY')>-1 || ins_name.indexOf('Self Pay')>-1 || ins_name.indexOf('SelfPay')>-1)  
{
	document.getElementById('Statuscmb_'+model.rowid).value='Ready for Patient Billing';
	document.getElementById('Statuscmb_'+model.rowid).setAttribute("comboval","T");
	document.getElementById('Statuscmb_'+model.rowid).setAttribute("orival","T");
	
	document.getElementById('VisitTypecmb_'+model.rowid).value='6-Self Pay';
	document.getElementById('VisitTypecmb_'+model.rowid).setAttribute("comboval","9");
	document.getElementById('VisitTypecmb_'+model.rowid).setAttribute("orival","9");
	document.getElementById('cmbStatus_'+model.rowid).value='T';
}
else if(model.accType==3){
	document.getElementById('VisitTypecmb_'+model.rowid).value='7-CHDP';
	document.getElementById('VisitTypecmb_'+model.rowid).setAttribute("comboval","3");
	document.getElementById('VisitTypecmb_'+model.rowid).setAttribute("orival","3");
	document.getElementById('cmbStatus_'+model.rowid).value='0';
}
else if(model.accType==4){
	document.getElementById('VisitTypecmb_'+model.rowid).value='8 - Workman Compensation';
	document.getElementById('VisitTypecmb_'+model.rowid).setAttribute("comboval","4");
	document.getElementById('VisitTypecmb_'+model.rowid).setAttribute("orival","5");
	document.getElementById('cmbStatus_'+model.rowid).value='0';
}
else
{
	document.getElementById('Statuscmb_'+model.rowid).value='EMR Service';
	document.getElementById('Statuscmb_'+model.rowid).setAttribute("comboval","0");
	document.getElementById('Statuscmb_'+model.rowid).setAttribute("orival","0");
	
	document.getElementById('VisitTypecmb_'+model.rowid).value='5-Private';
	document.getElementById('VisitTypecmb_'+model.rowid).setAttribute("comboval","2");
	document.getElementById('VisitTypecmb_'+model.rowid).setAttribute("orival","2");
	document.getElementById('cmbStatus_'+model.rowid).value='0';
}
//var plan=document.getElementById("ServiceTypecmb_");
var plan=document.getElementById("VisitTypecmb_"+model.rowid);
var accType=getValueFromPool(plan.getAttribute("comboval"), 10);
	if(accType=='None')
 	 accType=-1;
 	else
	 accType= parseInt(accType.substring(0,accType.indexOf('-')));
if(accType >0){	 
document.getElementById('CostPlancmb_'+model.rowid).value=getValueFromPool(accType, 12);
document.getElementById('CostPlancmb_'+model.rowid).setAttribute("comboval",accType);
document.getElementById('CostPlancmb_'+model.rowid).setAttribute("orival",accType);
}
}
patientLoaded=0;
//hideRequestDivStatus(tabDetails.SERVICE,0);
	if(parseInt(isQuickCPTRequired)==1){//to hide quick cpt div
		drawQuickCPT();
	}
	var t=document.getElementById('QuickCPT_Combo');	
	constructGrp(t,-1);
	if(isQuickCPTGrpRequired==1){
		drawQuickCPTGroup();
	}else{
		constructShortCutConfigDiv(x);
		constructQuickCptCombo(x);
	}
}
var constructGrp=function(t,setValue){
	
	var ele=eval(selectPool.get(52));
	var data="<select title='Select Shortcut' style='width:100%;font-size:8pt' onchange='javascript:loadSelectedGroup(this.value);'>";
			data+="<option value='-1'>None</option>";
			setValue=(setValue)?setValue:-1;
		for(var i=0;i<ele.length;i++){
			data+="<option value='"+ele[i].hsp001;
			if(setValue == ele[i].qcgid){
				data+="' selected=selected >"+ele[i].hsp002;
				loadSelectedGroup(ele[i].hsp001);
			}else{
				data+="'>"+ele[i].hsp002;
			}
			data+="</option>";
			}
			data+="</select>";
		
	t.innerHTML=data;
	return t;
}
function checkForInsurance(){
  if(getServiceid() == -1 && editDOS =='')
  {	
	var priText=getValueFromPool(document.getElementById('Primarycmb_').getAttribute('comboval'),20);
	//var secText=document.getElementById('Secondcmb_').innerHTML;
	//var typeText=getValueFromPool(document.getElementById('ServiceTypecmb_').getAttribute('comboval'),10) ;
	var typeText="";
	if(typeText.indexOf('CHDP') > -1){
	//alert("You are about to put a CHDP service ...");
		/*if(priText.indexOf("Type-4") < 0 )
			alert("Please register a CHDP insurance for this patient ....");*/
	}
	if(typeText.indexOf('Work') > -1){
	//alert("You are about to put a Workmen Compensation service ...");
		/*if(priText.indexOf("Type-5") < 0 )
      		alert("Please register a Workmen Compensation insurance for this patient ....");*/
	}
}	
}

function getValueFromPool(value,id){
	if(value==-1)
		return 'None';
	/*else if(!selectPool.get(id)){
		var a=selectPool.get(id);
		fetchSelectFromServer(id);
	}	*/
	else
		var a=selectPool.get(id);
	if(id==18 && isReferringPicker==1){
		var data=eval(getResponseData("../ServiceEntry.Action?isfromEditService=1&group="+id+"&refDocId="+value+"&patientId="+PATIENT_ID+"&rand="+Math.random()))[0];
		var a=eval(data.valu);	
	}
	var val=eval(a);
	for(var i=0;i<val.length;i++)
		if(val[i].hsp001==value|| val[i].hsp002==value)
			return(val[i].hsp002);
	return 'None';			
}
function appendSelectOptions(name,id,evt)
{
var  tarEvt=getTarget(evt);
var width=(tarEvt.offsetWidth-1)+"px";
var na=getTarget(evt).name;
var celObj=document.getElementById(na);
celObj.className='databordertd';
var init_val=celObj.getAttribute('value');
celObj.innerHTML="";
var combo=document.createElement('select');
combo.name=name;
combo.id='commonCombo';
combo.style.width=width;
combo.onblur=function(event){
if(!event)event=window.event;
celObj.innerHTML="";
celObj.innerHTML=getValueFromPool(document.getElementById(current).getAttribute('value'), id);
celObj.className="dropdn databordertd";
}
combo.onchange=function(){
document.getElementById(prevName).setAttribute('value',this.value);
celObj.innerHTML="";
celObj.innerHTML=getValueFromPool(document.getElementById(prevName).getAttribute('value'), id);
celObj.className="dropdn databordertd";
if(na=='defaultDoctor' )
{
if(!document.all)
{
document.getElementById('SDoctorcmb_').value=getValueFromPool(this.value,16);
document.getElementById('SDoctorcmb_').setAttribute('comboval',this.value);
defaultDoctor=this.value;
}
else
{
var v=document.getElementById('defaultDoctor').value;
document.getElementById('SDoctorcmb_').value=getValueFromPool(v,16);
document.getElementById('SDoctorcmb_').setAttribute('comboval',v);
defaultDoctor=v;
}
}
else if(na=='defaultBillingDoctor' )
{
if(!document.all)
{
document.getElementById('BDoctorcmb_').value=getValueFromPool(this.value,16);
document.getElementById('BDoctorcmb_').setAttribute('comboval',this.value);
defaultBillingDoctor=this.value;
}
else
{
var v=document.getElementById('defaultBillingDoctor').value;
document.getElementById('BDoctorcmb_').value=getValueFromPool(v,16);
document.getElementById('BDoctorcmb_').setAttribute('comboval',v);
defaultBillingDoctor=v;
}
}
else if(na=='defaultPOS' )
{
if(!document.all)
{
document.getElementById('POScmb_').value=getValueFromPool(this.value,171);
document.getElementById('POScmb_').setAttribute('comboval',this.value);
defaultPOS=this.value;
}
else
{
var v=document.getElementById('defaultPOS').value;
document.getElementById('POScmb_').value=getValueFromPool(v,171);
document.getElementById('POScmb_').setAttribute('comboval',v);
defaultPOS=v;
}
}
}
combo.onblur=function(event){
//document.getElementById('SDoctorcmb_').setAttribute('value',this.value);
celObj.innerHTML="";
celObj.innerHTML=getValueFromPool(document.getElementById(current).getAttribute('value'), id);
celObj.className="dropdn databordertd";
isClicked=0;
//selectSecond();
}
var a=selectPool.get(id);
a=eval(a);
try
{
var opt=document.createElement('option');
 opt.value='-1';
 opt.appendChild(textNode('None'));
 combo.appendChild(opt);
for(i=0;i<a.length;i++)
{
opt=document.createElement('option');
opt.value=eval(a[i]).hsp001;
opt.appendChild(textNode(eval(a[i]).hsp002));
combo.appendChild(opt);

}
}
catch(e){}
combo.name=name;
combo.value=init_val;
celObj.appendChild(combo);
combo.focus();
}
function createCommonStrip(model)
{
populateDefaultValueDiv();
var rowid=model.patientId;
var commontable=document.createElement('table');
commontable.id='commontable';
//document.focus=function(){alert('hi');}
commontable.width='100%';commontable.cellSpacing='0px';commontable.cellPadding='0px';commontable.className='tableStyle';
var commontbody=document.createElement('tbody');commontable.appendChild(commontbody);
var rowObj=document.createElement('tr');
var emptytd=document.createElement('td');
emptytd.colSpan="12";rowObj.style.height='5px';rowObj.appendChild(emptytd);commontbody.appendChild(rowObj);
rowObj=document.createElement('tr');rowObj.style.height='23px';
rowObj.appendChild(insertCell("Date Of Posting", 'doplbl_'+rowid,1,0,'othertddata','10%'));
rowObj.appendChild(sr_createCell('DOPtxt_',16,'generaltextboxwhite','DOS','databordertd','text',model.date_of_posting,-1,'10%',1));
//rowObj.appendChild(insertCell("", 'poslbl_'+rowid,1,0,'othertddata','5%'));
rowObj.appendChild(insertCell("Service Doctor", 'sdlbl_'+rowid,1,0,'othertddata','12%'));
rowObj.appendChild(sr_createCell('SDoctorcmb_',20,'dropdn generaltextboxwhite','Service Doctor','databordertd','combo',model.sdoctorId,16,'15%',1));
rowObj.appendChild(insertCell("POS", 'poslbl_'+rowid,1,0,'othertddata','7%'));	
rowObj.appendChild(sr_createCell('POScmb_',33,'dropdn generaltextboxwhite','Place Of Service','databordertd','combo',model.posId,171,'19%',1));
rowObj.appendChild(insertCell("R Doctor", 'refdoclbl_'+rowid,1,0,'othertddata','10%'));
if(doctorCombinationCheck==1)
 rowObj.appendChild(sr_createCell('OrDoctorcmb_',20,'dropdn generaltextboxwhite','R Doctor','databordertd','combo',model.rdoctorId,32,'15%',1));
else
 rowObj.appendChild(sr_createCell('OrDoctorcmb_',20,'dropdn generaltextboxwhite','R Doctor','databordertd','combo',model.rdoctorId,16,'15%',1));
rowObj.appendChild(insertCell("", 'poslbl_'+rowid,1,0,'othertddata','2%'));
rowObj.appendChild(insertCell("", 'poslbl_'+rowid,1,0,'othertddata','2%'));
rowObj.appendChild(insertCell("", 'poslbl_'+rowid,1,0,'othertddata','2%'));
rowObj.appendChild(insertCell("", 'poslbl_'+rowid,1,0,'othertddata','2%'));

commontbody.appendChild(rowObj);rowObj=document.createElement('tr');emptytd=document.createElement('td');emptytd.colSpan="12";
rowObj.appendChild(emptytd);rowObj.style.height='5px';commontbody.appendChild(rowObj);
rowObj=document.createElement('tr');rowObj.style.height='23px';

//rowObj.appendChild(insertCell("Type", 'typelbl_'+rowid,1,0,'othertddata','10%'));
//rowObj.appendChild(sr_createCell('ServiceTypecmb_',13,'dropdn generaltextboxwhite','Type','databordertd','combo',model.posId,10,'10%',1));

rowObj.appendChild(insertCell("Type Of Service", 'typelbl_'+rowid,1,0,'othertddata','10%'));
rowObj.appendChild(sr_createCell('typeOfServicecmb_',13,'dropdn generaltextboxwhite','Type Of Service','databordertd','combo',-1,15,'10%',1));

rowObj.appendChild(insertCell("Billing Doctor", 'poslbl_'+rowid,1,0,'othertddata','12%'));
if(doctorCombinationCheck==1)
 rowObj.appendChild(sr_createCell('BDoctorcmb_',20,'dropdn generaltextboxwhite','Billing Doctor','databordertd','combo',model.bdoctorId,31,'15%',1));
else
 rowObj.appendChild(sr_createCell('BDoctorcmb_',20,'dropdn generaltextboxwhite','Billing Doctor','databordertd','combo',model.bdoctorId,16,'15%',1));
if(model.accType==3)
	rowObj.appendChild(insertCell("CHDP Ins", 'pinslbl_'+rowid,1,0,'othertddata','7%'));
else if(model.accType==4)
	rowObj.appendChild(insertCell("Workman Ins", 'pinslbl_'+rowid,1,0,'othertddata','7%'));
else
rowObj.appendChild(insertCell("Pri Ins", 'pinslbl_'+rowid,1,0,'othertddata','7%'));
rowObj.appendChild(sr_createCell('Primarycmb_',33,'dropdn generaltextboxwhite','Primary Insurance','databordertd','combo',model.primaryInsId,20,'19%',1));

//rowObj.appendChild(insertCell("Type Of Service", 'toslbl_'+rowid,1,0,'othertddata','10%'));
//rowObj.appendChild(sr_createCell('typeOfServicecmb_',20,'dropdn generaltextboxwhite','Type Of Service','databordertd','combo',-1,15,'15%',1));

rowObj.appendChild(insertCell("Third Ins", 'toslbl_'+rowid,1,0,'othertddata','10%'));
rowObj.appendChild(sr_createCell('Thirdcmb_',20,'dropdn generaltextboxwhite','Third Insurance','databordertd','combo',model.thirdInsId,15,'15%',1));

rowObj.appendChild(insertCell("", 'poslbl_'+rowid,1,0,'othertddata','2%'));
rowObj.appendChild(insertCell("", 'poslbl_'+rowid,1,0,'othertddata','2%'));
rowObj.appendChild(insertCell("", 'poslbl_'+rowid,1,0,'othertddata','2%'));
rowObj.appendChild(insertCell("", 'poslbl_'+rowid,1,0,'othertddata','2%'));

commontbody.appendChild(rowObj);rowObj=document.createElement('tr');emptytd=document.createElement('td');emptytd.colSpan="12";
rowObj.appendChild(emptytd);rowObj.style.height='5px';commontbody.appendChild(rowObj);commontbody.appendChild(rowObj);
rowObj=document.createElement('tr');rowObj.style.height='23px';
rowObj.appendChild(insertCell("Case", 'caselbl_'+rowid,1,0,'othertddata','10%'));
rowObj.appendChild(sr_createCell('Casecmb_',13,'dropdn generaltextboxwhite','None','databordertd','combo',model.caseId,7,'10%',1));
rowObj.appendChild(insertCell("Referring Doctor", 'rdlbl_'+rowid,1,0,'othertddata','12%'));
if(isReferringPicker==1)
rowObj.appendChild(sr_createCell('Referralcmb_',20,'generaltextboxwhite','Refering Doctor','databordertd','text',model.refdoctorId,-1,'15%',1));
else
rowObj.appendChild(sr_createCell('Referralcmb_',20,'dropdn generaltextboxwhite','Refering Doctor','databordertd','combo',model.refdoctorId,18,'15%',1));
rowObj.appendChild(insertCell("Sec Ins", 'sinslbl_'+rowid,1,0,'othertddata','7%'));
rowObj.appendChild(sr_createCell('Secondcmb_',33,'dropdn generaltextboxwhite','Secondary Insurnce','databordertd','combo',model.secInsId,21,'20%',1));

rowObj.appendChild(insertCell('Quick CPT', 'QuickCPTGrpLbl',1,0,'othertddata','7%'));
rowObj.appendChild(insertCell('QuickCPTCombo','QuickCPT_Combo','text',-1,'databordertd','15%','None'));

var td=document.createElement("td");
td.innerHTML="<a href='javascript:showHideQShortcuts(true);' > <font size='1'><u>Add/Edit</u></font></a>";
rowObj.appendChild(td);

//rowObj.appendChild(insertCell("Third Ins", 'thirdinslbl_'+rowid,1,0,'othertddata','10%'));
//rowObj.appendChild(sr_createCell('Thirdcmb_',20,'dropdn generaltextboxwhite','Third Insurance','databordertd','combo',model.thirdInsId,30,'15%',1));
//rowObj.appendChild(insertCell("CPT Groups", 'sinslbl_'+rowid,1,0,'othertddata','10%'));
//rowObj.appendChild(sr_createCell('CPTGroupcmb_',20,'dropdn generaltextboxwhite','None','databordertd','combo',-1,4,'15%',1));
rowObj.appendChild(insertCell("", 'poslbl_'+rowid,1,0,'othertddata','2%'));
rowObj.appendChild(insertCell("", 'poslbl_'+rowid,1,0,'othertddata','2%'));
rowObj.appendChild(insertCell("", 'poslbl_'+rowid,1,0,'othertddata','2%'));
commontbody.appendChild(rowObj);rowObj=document.createElement('tr');emptytd=document.createElement('td');
emptytd.colSpan="12";rowObj.appendChild(emptytd);
rowObj.style.height='5px';commontbody.appendChild(rowObj);
var ele=document.getElementById('txtDOP_'+rowid);
if(!ele)
{
addHiddenField(document.serviceinformation,'patientId');
addHiddenField(document.serviceinformation,'takeARAction');
addHiddenField(document.serviceinformation,"txtDOP_"+rowid);
addHiddenField(document.serviceinformation,"cmbSDoctor_"+rowid);
addHiddenField(document.serviceinformation,"cmbPOS_"+rowid);
addHiddenField(document.serviceinformation,'cmbServiceType_'+rowid);
addHiddenField(document.serviceinformation,"cmbBDoctor_"+rowid);
addHiddenField(document.serviceinformation,"cmbPrimary_"+rowid);
addHiddenField(document.serviceinformation,"cmbCase_"+rowid);
addHiddenField(document.serviceinformation,"cmbReferral_"+rowid);
addHiddenField(document.serviceinformation,"cmbSecond_"+rowid);
addHiddenField(document.serviceinformation,"cmbThird_"+rowid);
addHiddenField(document.serviceinformation,"cmbOrDoctor_"+rowid);
addHiddenField(document.serviceinformation,"cmbTypeOfService_"+rowid);
document.serviceinformation.patientId.value=PATIENT_ID;
}
return commontable;
}

function drawHiddenForEdit(row)
{
var ele=document.getElementById('txtDOP_'+row);
if(!ele)
{
addHiddenField(document.serviceinformation,'patientId');
addHiddenField(document.serviceinformation,'takeARAction');
addHiddenField(document.serviceinformation,"txtDOP_"+row);
addHiddenField(document.serviceinformation,"cmbSDoctor_"+row);
addHiddenField(document.serviceinformation,"cmbPOS_"+row);
addHiddenField(document.serviceinformation,'cmbServiceType_'+row);
addHiddenField(document.serviceinformation,"cmbBDoctor_"+row);
addHiddenField(document.serviceinformation,"cmbPrimary_"+row);
addHiddenField(document.serviceinformation,"cmbCase_"+row);
addHiddenField(document.serviceinformation,"cmbReferral_"+row);
addHiddenField(document.serviceinformation,"cmbSecond_"+row);
addHiddenField(document.serviceinformation,"cmbThird_"+row);
addHiddenField(document.serviceinformation,"cmbOrDoctor_"+row);
addHiddenField(document.serviceinformation,"cmbTypeOfService_"+row);
document.serviceinformation.patientId.value=PATIENT_ID;
}
}
function setDefaultValuesToCommonStrip(model)
{
var uniqueKey=PATIENT_ID;
if(getServiceid() == -1){
document.getElementById('DOPtxt_').value=model.date_of_posting;
document.getElementById('SDoctorcmb_').value=getValueFromPool(model.sdoctorId, 16);
document.getElementById('SDoctorcmb_').setAttribute('comboval',model.sdoctorId);
document.getElementById('POScmb_').value=getValueFromPool(model.posId, 171);
document.getElementById('POScmb_').setAttribute('comboval',model.posId);
//document.getElementById('ServiceTypecmb_').value=getValueFromPool(model.accType, 10);
//document.getElementById('ServiceTypecmb_').setAttribute('comboval',model.accType);
if(doctorCombinationCheck==1)
{
document.getElementById('BDoctorcmb_').value='None';
document.getElementById('BDoctorcmb_').setAttribute('comboval',-1);
}
else
{
document.getElementById('BDoctorcmb_').value=getValueFromPool(model.bdoctorId, 16);
document.getElementById('BDoctorcmb_').setAttribute('comboval',model.bdoctorId);
}
document.getElementById('Primarycmb_').value=getValueFromPool(model.primaryInsId, 20);
document.getElementById('Primarycmb_').setAttribute('comboval',model.primaryInsId);
document.getElementById('Casecmb_').value=getValueFromPool(model.caseId, 7);
document.getElementById('Casecmb_').setAttribute('comboval',model.caseId);
document.getElementById('Referralcmb_').value=getValueFromPool(model.refdoctorId, 18);
document.getElementById('Referralcmb_').setAttribute('comboval',model.refdoctorId);
document.getElementById('Secondcmb_').value=getValueFromPool(model.secInsId, 21);
document.getElementById('Secondcmb_').setAttribute('comboval',model.secInsId);
document.getElementById('Thirdcmb_').value=getValueFromPool(model.thirdInsId, 30);
document.getElementById('Thirdcmb_').setAttribute('comboval',model.thirdInsId);
if(doctorCombinationCheck==1)
{
document.getElementById('OrDoctorcmb_').value='None';
document.getElementById('OrDoctorcmb_').setAttribute('comboval',-1);
}
else
{
document.getElementById('OrDoctorcmb_').value=getValueFromPool(model.rdoctorId, 16);
document.getElementById('OrDoctorcmb_').setAttribute('comboval',model.rdoctorId);
}
document.getElementById('typeOfServicecmb_').value=getValueFromPool(model.typeOfService, 15);
document.getElementById('typeOfServicecmb_').setAttribute('comboval',model.typeOfService);
}
}


function setDefaultValuesToCommonStripEdit(model)
{
var uniqueKey=getServiceid();
document.getElementById('DOPtxt_').value=model.date_of_posting;
document.getElementById('DOPtxt_').setAttribute("orival",model.date_of_posting);
document.getElementById('SDoctorcmb_').value=getValueFromPool(model.sdoctorId, 16);
document.getElementById('SDoctorcmb_').setAttribute('comboval',model.sdoctorId);
document.getElementById('SDoctorcmb_').setAttribute("orival",model.sdoctorId);
document.getElementById('POScmb_').value=getValueFromPool(model.posId, 171);
document.getElementById('POScmb_').setAttribute('comboval',model.posId);
document.getElementById('POScmb_').setAttribute("orival",model.posId);
document.getElementById('ServiceTypecmb_').value=getValueFromPool(model.accType, 10);
document.getElementById('ServiceTypecmb_').setAttribute('comboval',model.accType);
document.getElementById('ServiceTypecmb_').setAttribute("orival",model.accType);
document.getElementById('BDoctorcmb_').value=getValueFromPool(model.bdoctorId, 16);
document.getElementById('BDoctorcmb_').setAttribute('comboval',model.bdoctorId);
document.getElementById('BDoctorcmb_').setAttribute("orival",model.bdoctorId);
document.getElementById('Primarycmb_').value=getValueFromPool(model.primaryInsId, 20);
document.getElementById('Primarycmb_').setAttribute('comboval',model.primaryInsId);
document.getElementById('Primarycmb_').setAttribute("orival",model.primaryInsId);
document.getElementById('Casecmb_').value=getValueFromPool(model.caseId, 7);
document.getElementById('Casecmb_').setAttribute('comboval',model.caseId);
document.getElementById('Casecmb_').setAttribute("orival",model.caseId);
document.getElementById('Referralcmb_').value=getValueFromPool(model.refdoctorId, 18);
document.getElementById('Referralcmb_').setAttribute('comboval',model.refdoctorId);
document.getElementById('Referralcmb_').setAttribute("orival",model.refdoctorId);
document.getElementById('Secondcmb_').value=getValueFromPool(model.secInsId, 21);
document.getElementById('Secondcmb_').setAttribute('comboval',model.secInsId);
document.getElementById('Secondcmb_').setAttribute("orival",model.secInsId);
document.getElementById('Thirdcmb_').value=getValueFromPool(model.thirdInsId, 30);
document.getElementById('Thirdcmb_').setAttribute('comboval',model.thirdInsId);
document.getElementById('Thirdcmb_').setAttribute("orival",model.thirdInsId);
document.getElementById('OrDoctorcmb_').value=getValueFromPool(model.rdoctorId, 16);
document.getElementById('OrDoctorcmb_').setAttribute('comboval',model.rdoctorId);
document.getElementById('OrDoctorcmb_').setAttribute("orival",model.rdoctorId);
document.getElementById('typeOfServicecmb_').value=getValueFromPool(model.typeOfService, 15);
document.getElementById('typeOfServicecmb_').setAttribute('comboval',model.typeOfService);
document.getElementById('typeOfServicecmb_').setAttribute("orival",model.typeOfService);
}

function createPatientWiseSelects(model){
	var rowid=model.patientId;
	var commontable=document.createElement('table');
	commontable.width='100%';
	//commontable.style.height='60px';
	commontable.cellSpacing='0px';
	commontable.cellPadding='0px';
	commontable.className='tableStyle';
		
	var commontbody=document.createElement('tbody');
	commontable.appendChild(commontbody);
	
	var rowObj=document.createElement('tr');
	var emptytd=document.createElement('td');
	emptytd.colspan=6;
	rowObj.style.height='5px';
	rowObj.appendChild(emptytd);
	commontbody.appendChild(rowObj);
		
	rowObj=document.createElement('tr');
	rowObj.style.height='20px';
	rowObj.appendChild(insertCell("Date Of Posting", 'doplbl_'+rowid,1,0,'othertddata','10%'));
	rowObj.appendChild(insertCell(model.date_of_posting, 'DOPtxt_'+rowid,2,0,'databordertd','100px',model.date_of_posting));	
	rowObj.appendChild(insertCell("&nbsp;&nbsp;&nbsp;Service Doctor", 'sdlbl_'+rowid,1,0,'othertddata','12%'));
	rowObj.appendChild(insertCell(getValueFromPool(model.sdoctorId, 16), 'SDoctorcmb_'+rowid,3,16,'databordertd','15%',model.sdoctorId));
	rowObj.appendChild(insertCell("&nbsp;&nbsp;&nbsp;POS", 'poslbl_'+rowid,1,0,'othertddata','7%'));	
	rowObj.appendChild(insertCell(getValueFromPool(model.posId, 171), 'POScmb_'+rowid,3,171,'databordertd','15%',model.posId));
	rowObj.appendChild(insertCell("&nbsp;&nbsp;&nbsp;", 'poslbl_'+rowid,1,0,'othertddata','2%'));
	var dxtd=document.createElement('td');	
	var dxdiv=document.createElement('div');
	dxdiv.name='dxContainer';
	dxdiv.id='dxContainer';	
	dxdiv.style.border='2px outset white';
	dxdiv.style.borderCollapse='collapse';
	dxdiv.style.height='100px';
	dxdiv.style.backgroundcolor='rgb(231,232,237)';
	var dxtable=document.createElement('table');
	var dxbody=document.createElement('tbody');
	dxtable.appendChild(dxbody);
	dxtable.cellSpacing=0;
	var dxrow=document.createElement('tr');	
	var dxcel=document.createElement('td');
	dxcel.className='dxtable';
	dxcel.noWrap=true;
	dxcel.innerHTML='Current Dx';
	dxrow.appendChild(dxcel);
	var dxcel=document.createElement('td');
	dxcel.className='dxtable';
	var dximg=document.createElement('img');
	dximg.src='../../../images/pinocular.gif';
	dximg.title='Dx Picker';
	//addEvent(dximg, 'click', Dxpicker);
	addEvent(dximg, 'click', createDxPicker);
	dxcel.appendChild(dximg);	
	dxrow.appendChild(dxcel);
	dxbody.appendChild(dxrow);
	var dxrow=document.createElement('tr');
	dxrow.id='servicedxlistRow';
	dxrow.name='servicedxlistRow';
	var dxcel=document.createElement('td');
	dxcel.id='servicedxlist';
	dxcel.name='servicedxlist';
	dxcel.colSpan=2;
	dxrow.appendChild(dxcel);
	dxbody.appendChild(dxrow);
	dxdiv.appendChild(dxtable);	
	dxtd.appendChild(dxdiv);
	dxtd.rowSpan=8;
	dxtd.vAlign='top';
	rowObj.appendChild(dxtd);	
	commontbody.appendChild(rowObj);
	
	rowObj=document.createElement('tr');
	emptytd=document.createElement('td');
	emptytd.colspan=6;
	rowObj.style.height='5px';
	rowObj.appendChild(emptytd);
	commontbody.appendChild(rowObj);
	
	rowObj=document.createElement('tr');
	rowObj.appendChild(insertCell("Type", 'typelbl_'+rowid,1,0,'othertddata','10%'));
	rowObj.appendChild(insertCell(getValueFromPool(model.accType, 10), 'ServiceTypecm_'+rowid,3,10,'databordertd','15%',model.accType));
	rowObj.appendChild(insertCell("&nbsp;&nbsp;&nbsp;Billing Doctor", 'poslbl_'+rowid,1,0,'othertddata','12%'));
	rowObj.appendChild(insertCell(getValueFromPool(model.bdoctorId, 16), 'BDoctorcmb_'+rowid,3,16,'databordertd','15%',model.bdoctorId));
	rowObj.appendChild(insertCell("&nbsp;&nbsp;&nbsp;Pri Ins", 'pinslbl_'+rowid,1,0,'othertddata','7%'));
	rowObj.appendChild(insertCell(getValueFromPool(model.primaryInsId, 20), 'Primarycmb_'+rowid,3,20,'databordertd','15%',model.primaryInsId));
	rowObj.appendChild(insertCell("&nbsp;&nbsp;&nbsp;", 'poslbl_'+rowid,1,0,'othertddata','2%'));
	commontbody.appendChild(rowObj);
	
	rowObj=document.createElement('tr');
	emptytd=document.createElement('td');
	emptytd.colspan=6;
	rowObj.style.height='5px';
	rowObj.appendChild(emptytd);
	commontbody.appendChild(rowObj);
	
	rowObj=document.createElement('tr');
	rowObj.appendChild(insertCell("Case", 'caselbl_'+rowid,1,0,'othertddata','10%'));
	rowObj.appendChild(insertCell("None", 'Casecmb_'+rowid,3,7,'databordertd','15%', '-1'));
	rowObj.appendChild(insertCell("&nbsp;&nbsp;&nbsp;Referring Doctor", 'rdlbl_'+rowid,1,0,'othertddata','12%'));
	rowObj.appendChild(insertCell(getValueFromPool(model.refdoctorId, 18), 'Referralcmb_'+rowid,3,18,'databordertd','15%',model.refdoctorId));
	rowObj.appendChild(insertCell("&nbsp;&nbsp;&nbsp;Sec Ins", 'sinslbl_'+rowid,1,0,'othertddata','7%'));
	rowObj.appendChild(insertCell(getValueFromPool(model.secInsId, 21), 'Secondcmb_'+rowid,3,21,'databordertd','15%',model.secInsId));
	rowObj.appendChild(insertCell("&nbsp;&nbsp;&nbsp;", 'poslbl_'+rowid,1,0,'othertddata','2%'));
	commontbody.appendChild(rowObj);
	
	rowObj=document.createElement('tr');
	emptytd=document.createElement('td');
	emptytd.colspan=6;
	rowObj.style.height='5px';
	rowObj.appendChild(emptytd);
	commontbody.appendChild(rowObj);
	
	rowObj=document.createElement('tr');	
	rowObj.appendChild(insertCell("R Doctor", 'refdoclbl_'+rowid,1,0,'othertddata','10%'));
	rowObj.appendChild(insertCell(getValueFromPool(model.rdoctorId, 16), 'OrDoctorcmb_'+rowid,3,16,'databordertd','16%',model.rdoctorId));	
	commontbody.appendChild(rowObj);
	
	rowObj=document.createElement('tr');
	emptytd=document.createElement('td');
	emptytd.colspan=6;
	rowObj.style.height='5px';
	rowObj.appendChild(emptytd);
	commontbody.appendChild(rowObj);
		
	addHiddenField(document.serviceinformation,'patientId');
	addHiddenField(document.serviceinformation,'takeARAction');
	addHiddenField(document.serviceinformation,"txtDOP_"+rowid);
	addHiddenField(document.serviceinformation,"cmbSDoctor_"+rowid);
	addHiddenField(document.serviceinformation,"cmbPOS_"+rowid);
	//addHiddenField(document.serviceinformation,'cmbServiceType_'+rowid);
	addHiddenField(document.serviceinformation,"cmbBDoctor_"+rowid);
	addHiddenField(document.serviceinformation,"cmbPrimary_"+rowid);
	addHiddenField(document.serviceinformation,"cmbCase_"+rowid);
	addHiddenField(document.serviceinformation,"cmbReferral_"+rowid);
	addHiddenField(document.serviceinformation,"cmbSecond_"+rowid);
	addHiddenField(document.serviceinformation,"cmbThird_"+rowid);
	addHiddenField(document.serviceinformation,"cmbOrDoctor_"+rowid);
	document.serviceinformation.patientId.value=PATIENT_ID;
	return commontable;
}
function round(number, x){
	return number.toFixed(x);
}
function deletePreviouslySelectedDx(dxinfo)	{
	var DxClassId=dxinfo;
	var dxList=getSelectedDx(1);
	var currentPointer = dxList.length;
	var dxDesc="";
	try{		
		var dxFrame=document.getElementById('servicedxpicker').contentWindow;
		if (dxFrame.document.getElementById("dxtblrowtd_pair" + DxClassId).className == "formdatared"){
			dxFrame.document.getElementById("dxtblrowtd_pair" + DxClassId).className = "formdatablue";
			dxFrame.document.getElementById("dxtblrowtd" + DxClassId).className = "formdatablue";
		}			
	}catch(e){}
	if (currentPointer > 0){
		for (var i=0; i < dxList.length; i++)
			if (dxList[i] == dxinfo)
				dxList.splice(i,1);				
		currentPointer--;
		setSelectedDx(dxList);
		try{	
			setDxInfo();
		}catch(Exception){}					
	}
	else if (currentPointer == 0){
		dxList.splice(0,1);
	}		
}

function mapCrossWalk(currentid){
	var mappingneededcodes=[];
	var mappingneedcount=0;
	if(currentid.split("_").length>2)
		currentid=currentid.split("_")[1]+"_"+currentid.split("_")[2];
	else
		currentid=currentid.split("_")[1];
	var dos;
	if(document.getElementById('DOStxt_'+currentid)!=undefined)
		dos=document.getElementById('DOStxt_'+currentid).value;
	else if(document.getElementById('txtDOS_'+currentid)!=undefined)
		dos=document.getElementById('txtDOS_'+currentid).value;
	for(var mappingref=1;mappingref<=20;mappingref++){

		
		if( (document.getElementById('txtDX'+mappingref+'_'+currentid) !=undefined && document.getElementById('txtDX'+mappingref+'_'+currentid).value!='')|| document.getElementById('DX'+mappingref+'txt_'+currentid) !=undefined && document.getElementById('DX'+mappingref+'txt_'+currentid).value!=''){
			if(document.getElementById('txtDXCodeSystemId_'+currentid).value=='2.16.840.1.113883.6.90'){
				
				if(document.getElementById('DX'+mappingref+'txt_'+currentid)!=undefined && document.getElementById('DX'+mappingref+'txt_'+currentid).value!=''){
					var hh=document.getElementById('DX'+mappingref+'txt_'+currentid).value.charCodeAt(0);
				if((hh > 64 && hh<91) || (hh > 96 && hh<123)){
					var dataarr = new Array();
					dataarr[0]	= 'txtDX'+mappingref+'_'+currentid;
					dataarr[1]=Trim(document.getElementById('DX'+mappingref+'txt_'+currentid).value);
					dataarr[2]='icd10toicd9';
					mappingneededcodes[mappingneedcount++] = dataarr;
					 }}else if(document.getElementById('txtDX'+mappingref+'_'+currentid)!=undefined && document.getElementById('txtDX'+mappingref+'_'+currentid).value!=''){
						 var hh=document.getElementById('txtDX'+mappingref+'_'+currentid).value.charCodeAt(0);
						 if((hh > 64 && hh<91) || (hh > 96 && hh<123)){
							 var dataarr = new Array();
						 dataarr[0]	= 'txtDX'+mappingref+'_'+currentid;
						 dataarr[1]=Trim(document.getElementById('txtDX'+mappingref+'_'+currentid).value);
						 dataarr[2]='icd10toicd9';
						 mappingneededcodes[mappingneedcount++] = dataarr;		 
					 }}
				
				}else if(document.getElementById('txtDXCodeSystemId_'+currentid).value=='2.16.840.1.113883.6.104'){
					if(document.getElementById('DX'+mappingref+'txt_'+currentid)!=undefined && document.getElementById('DX'+mappingref+'txt_'+currentid).value!=''){
					var hh=document.getElementById('DX'+mappingref+'txt_'+currentid).value.charCodeAt(0);
						if((hh > 47 && hh<58) || (hh==86 || hh==118)){
							var dataarr = new Array();
							dataarr[0]	= 'txtDX'+mappingref+'_'+currentid;
							dataarr[1]=Trim(document.getElementById('DX'+mappingref+'txt_'+currentid).value);
							dataarr[2]='icd9toicd10';
							mappingneededcodes[mappingneedcount++] = dataarr;
							 }}else if(document.getElementById('txtDX'+mappingref+'_'+currentid)!=undefined && document.getElementById('txtDX'+mappingref+'_'+currentid).value!=''){
								 var dataarr = new Array();
								 var hh=document.getElementById('txtDX'+mappingref+'_'+currentid).value.charCodeAt(0);
								 if((hh > 47 && hh<58) || (hh==86 || hh==118)){
								 dataarr[0]	= 'txtDX'+mappingref+'_'+currentid;
								 dataarr[1]=Trim(document.getElementById('txtDX'+mappingref+'_'+currentid).value);
								 dataarr[2]='icd9toicd10';
								 mappingneededcodes[mappingneedcount++] = dataarr;
								 }
							 }
					 
				}
			}		
	}
	if(document.getElementById('DOStxt_'+currentid)!=undefined && document.getElementById('DOStxt_'+currentid).value !='')
		drawMappingsPicker(mappingneededcodes,'setMappingCodes',document.getElementById('DOStxt_'+currentid).value);
	else
		drawMappingsPicker(mappingneededcodes,'setMappingCodes');

}


function getSaveFlag(){return 1;}
function getShow(){return SE_showing;}
function getServiceid(){return S_ID;}
function setServiceId(id){S_ID=id;}
var commonStr="";
var detailStr="";
function saveServices(moduleref){
		
	if(moduleref!="mappingdone"){
		var commonId= "";
		var mappingneededcodes=[];
		var mappingneedcount=0;
		var rowreference=document.getElementsByName('tableStyleNoBorder');
		for(var ref=0;ref<rowreference.length;ref++){
			if(rowreference[ref].id!=undefined){
				var currentid=rowreference[ref].id;
				if(currentid.split("_").length>2)
					currentid=currentid.split("_")[1]+"_"+currentid.split("_")[2];
				else
					currentid=currentid.split("_")[1];
				commonId=currentid;
				if(isMappingsNeeded(document.getElementById('DOStxt_'+currentid).value,document.getElementById('txtDXCodeSystemId_'+currentid).value,'Enter Service With',1)){
					for(var mappingref=1;mappingref<=20;mappingref++){
						if((document.getElementById('DX'+mappingref+'txt_'+currentid)!=undefined && document.getElementById('DX'+mappingref+'txt_'+currentid).value!='') || (document.getElementById('txtDX'+mappingref+'_'+currentid)!=undefined && document.getElementById('txtDX'+mappingref+'_'+currentid).value!='')){	if(document.getElementById('txtDXCodeSystemId_'+currentid).value=='2.16.840.1.113883.6.90'){
							if(document.getElementById('DX'+mappingref+'txt_'+currentid)!=undefined && document.getElementById('DX'+mappingref+'txt_'+currentid).value!=''){
								var hh=document.getElementById('DX'+mappingref+'txt_'+currentid).value.charCodeAt(0);
							if((hh > 64 && hh<91) || (hh > 96 && hh<123)){
								var dataarr = new Array();
								dataarr[0]	= 'txtDX'+mappingref+'_'+currentid;
								dataarr[1]=Trim(document.getElementById('DX'+mappingref+'txt_'+currentid).value);
								dataarr[2]='icd10toicd9';
								mappingneededcodes[mappingneedcount++] = dataarr;
								 }}else if(document.getElementById('txtDX'+mappingref+'_'+currentid)!=undefined && document.getElementById('txtDX'+mappingref+'_'+currentid).value!=''){
									 var hh=document.getElementById('txtDX'+mappingref+'_'+currentid).value.charCodeAt(0);
									 if((hh > 64 && hh<91) || (hh > 96 && hh<123)){
									 var dataarr = new Array();
									 dataarr[0]	= 'txtDX'+mappingref+'_'+currentid;
									 dataarr[1]=Trim(document.getElementById('txtDX'+mappingref+'_'+currentid).value);
									 dataarr[2]='icd10toicd9';
									 mappingneededcodes[mappingneedcount++] = dataarr;		 
								 }}
							
							}else if(document.getElementById('txtDXCodeSystemId_'+currentid).value=='2.16.840.1.113883.6.104'){
								if(document.getElementById('DX'+mappingref+'txt_'+currentid)!=undefined && document.getElementById('DX'+mappingref+'txt_'+currentid).value!=''){
								var hh=document.getElementById('DX'+mappingref+'txt_'+currentid).value.charCodeAt(0);
									if((hh > 47 && hh<58) || (hh==86 || hh==118)){
										var dataarr = new Array();
										dataarr[0]	= 'txtDX'+mappingref+'_'+currentid;
										dataarr[1]=Trim(document.getElementById('DX'+mappingref+'txt_'+currentid).value);
										dataarr[2]='icd9toicd10';
										mappingneededcodes[mappingneedcount++] = dataarr;
										 }}else if(document.getElementById('txtDX'+mappingref+'_'+currentid)!=undefined && document.getElementById('txtDX'+mappingref+'_'+currentid).value!=''){
											 var hh=document.getElementById('txtDX'+mappingref+'_'+currentid).value.charCodeAt(0);
											 if(hh > 47 && hh<58){
											 var dataarr = new Array();
											 dataarr[0]	= 'txtDX'+mappingref+'_'+currentid;
											 dataarr[1]=Trim(document.getElementById('txtDX'+mappingref+'_'+currentid).value);
											 dataarr[2]='icd9toicd10';
											 mappingneededcodes[mappingneedcount++] = dataarr;
											 }
										 }
								 
							}}
					}
				
				}
			}
		}
		for(var alertref=0;alertref<rowreference.length;alertref++){
			if(rowreference[alertref].id!=undefined){
				var currentid=rowreference[alertref].id;
				if(currentid.split("_").length>2)
					currentid=currentid.split("_")[1]+"_"+currentid.split("_")[2];
				else
					currentid=currentid.split("_")[1];
				if(isMappingsNeeded(document.getElementById('DOStxt_'+currentid).value,document.getElementById('txtDXCodeSystemId_'+currentid).value,'Enter Service With',2))
					break;
			}
		}
		if(mappingneedcount==0 && moduleref!="domapppings"){
			saveServices("mappingdone");
			return true;
		}
		else{
			if(moduleref=="domapppings")
				needsave=false;
			else
				needsave=true;
			
			if(document.getElementById('DOStxt_'+commonId) != undefined && document.getElementById('DOStxt_'+commonId).value != '')
				drawMappingsPicker(mappingneededcodes,'setMappingCodes',document.getElementById('DOStxt_'+commonId).value);
			else
				drawMappingsPicker(mappingneededcodes,'setMappingCodes');
			return false;
		}
		
	}else{	
	
if(getDirty() == 0)
{
 //alert("No changes identified !");
 return(1);
} 
if(editDOS!='')
 {
   saveSavedServiecs();
   return;
 }
if(processForSaving() == 0)
 return(0);
if(getServiceid() > 0 && getARAction()==1)
{
 showARDiv();
 return;
 }


//showRequestDivStatus(false,tabDetails.SERVICE,0,false,'Saving ...');
var frm = eval("document.serviceinformation");
		if(getSaveFlag() == 1){
		    if(getServiceid()==-1)
		    {
		    frm.actionType.value = "UPDATEINSERT";
		    eval("document.serviceinformation.takeARAction").value=-1;
		    eval("document.serviceinformation.screen").value=1;
		    document.serviceinformation.logdata.value="Services Entered";
		    }
			else
			{
			frm.actionType.value = "UPDATE_SERVICE";
			eval("document.serviceinformation.takeARAction").value=getARAction();
			eval("document.serviceinformation.screen").value=1;
			document.serviceinformation.logdata.value=prepareLogData(getServiceid());
			}
			
			frm.servicedata.value='';
			var uniqueIDSec;
			for (var j=0; j <  removedRow.length-1; j++){
				i=getRemovedRow(j);
				if(i==-1)
					continue;
					if(getServiceid()==-1)
					 uniqueIDSec=PATIENT_ID+"_"+i;
					 else
					 uniqueIDSec=getServiceid();
			if (document.getElementById('CPTtxt_'+uniqueIDSec).getAttribute('cpttype')!=0  && document.getElementById('CPTtxt_'+uniqueIDSec) !='' && document.getElementById('cmbStatus_'+uniqueIDSec).value!='X')
				frm.servicedata.value += uniqueIDSec + "~";
			}
			addOnHoldHiddenData();
			document.serviceinformation.submit();
			dataString="";
			//alert("Last Transactions was saved");
		}
		else{
			alert("No data to save");
			return(0);
			}
return(1);
}
}
function processForSaving()
{
	problemService=new Array();
	var uniqueKey;
	if(getServiceid()==-1)
	uniqueKey=PATIENT_ID;
	else
	uniqueKey=getServiceid();
	commonStr="";
	detailStr="";
var pText=getValueFromPool(parseInt(document.getElementById('Primarycmb_').getAttribute('comboval')), 20);
var sText=getValueFromPool(parseInt(document.getElementById('SDoctorcmb_').getAttribute('comboval')), 16);
var placeText=getValueFromPool(parseInt(document.getElementById('POScmb_').getAttribute('comboval')), 171);
if(parseInt(document.getElementById('SDoctorcmb_').getAttribute('comboval')) <1 || document.getElementById('SDoctorcmb_').value=="" ||sText=="None"){
				alert("Select Service Doctor !");
				savetypechk=1;
				throw "Select Service Doctor !";
				return(0);
				}
if(parseInt(document.getElementById('POScmb_').getAttribute('comboval')) <1 || document.getElementById('POScmb_').value=="" ||placeText=="None"){
				alert("Select Place Of Service !");
				savetypechk=1;
				throw "Select Place Of Service !";
				return(0);
				}
if(parseInt(document.getElementById('Primarycmb_').getAttribute('comboval')) <1 || document.getElementById('Primarycmb_').value=="" ||pText=="None"){
			if(parseInt(document.getElementById('Primarycmb_').getAttribute('comboval')) != -99){
				alert("Select Primary Insurance !");
				savetypechk=1;
				throw "Select Primary Insurance !";
				return(0);
				}
		}
/*if(parseInt(document.getElementById('ServiceTypecmb_').getAttribute('comboval')) == 3 )
{
	if(pText.indexOf('Type-CHDP') <0){
	alert("No CHDP Insurance registered for this patient !");
	return(0);}
}*/

/*if(parseInt(document.getElementById('ServiceTypecmb_').getAttribute('comboval'))==4)
{
	if(pText.indexOf('Type-WC') <0){
	alert("No WC Insurance registered for this patient !");
	return(0);}
} */												

if(parseInt(document.getElementById('typeOfServicecmb_').getAttribute('comboval'))==2)
{
	if(parseInt(document.getElementById('Casecmb_').getAttribute('comboval'))==-1)
	{
		alert("Select a case for Surgery service(s) !");
		savetypechk=1;
		throw "Select a case for Surgery service(s) !";
		return(0);
	}
}
if(doctorCombinationCheck==1)
{
if(checkDoctorCombination()==0)
 {
 alert("Service doctor, Billing doctor and R Doctor combination is not valid !");
 savetypechk=1;
 throw "Service doctor, Billing doctor and R Doctor combination is not valid !";
 return(0);
 }
}

if(navigator.userAgent.toLowerCase().indexOf('chrome')>-1){
	var ele=document.getElementById('txtDOP_'+uniqueKey);
	if(!ele)
	{
	addHiddenField(document.serviceinformation,'patientId');
	addHiddenField(document.serviceinformation,'takeARAction');
	addHiddenField(document.serviceinformation,"txtDOP_"+uniqueKey);
	addHiddenField(document.serviceinformation,"cmbSDoctor_"+uniqueKey);
	addHiddenField(document.serviceinformation,"cmbPOS_"+uniqueKey);
	addHiddenField(document.serviceinformation,'cmbServiceType_'+uniqueKey);
	addHiddenField(document.serviceinformation,"cmbBDoctor_"+uniqueKey);
	addHiddenField(document.serviceinformation,"cmbPrimary_"+uniqueKey);
	addHiddenField(document.serviceinformation,"cmbCase_"+uniqueKey);
	addHiddenField(document.serviceinformation,"cmbReferral_"+uniqueKey);
	addHiddenField(document.serviceinformation,"cmbSecond_"+uniqueKey);
	addHiddenField(document.serviceinformation,"cmbThird_"+uniqueKey);
	addHiddenField(document.serviceinformation,"cmbOrDoctor_"+uniqueKey);
	addHiddenField(document.serviceinformation,"cmbTypeOfService_"+uniqueKey);
	document.serviceinformation.patientId.value=PATIENT_ID;
	}
	}

	eval("document.serviceinformation.serviceId").value=getServiceid();
	eval("document.serviceinformation.txtDOP_"+uniqueKey).value=document.getElementById('DOPtxt_').value;
	eval("document.serviceinformation.cmbSDoctor_"+uniqueKey).value=document.getElementById('SDoctorcmb_').getAttribute('comboval');
	eval("document.serviceinformation.cmbPOS_"+uniqueKey).value=document.getElementById('POScmb_').getAttribute('comboval');
	//eval("document.serviceinformation.cmbServiceType_"+uniqueKey).value=document.getElementById('ServiceTypecmb_').getAttribute('comboval');
	eval("document.serviceinformation.cmbBDoctor_"+uniqueKey).value=document.getElementById('BDoctorcmb_').getAttribute('comboval');
	eval("document.serviceinformation.cmbPrimary_"+uniqueKey).value=document.getElementById('Primarycmb_').getAttribute('comboval');
	eval("document.serviceinformation.cmbCase_"+uniqueKey).value=document.getElementById('Casecmb_').getAttribute('comboval');
	eval("document.serviceinformation.cmbReferral_"+uniqueKey).value=document.getElementById('Referralcmb_').getAttribute('comboval');
	eval("document.serviceinformation.cmbSecond_"+uniqueKey).value=document.getElementById('Secondcmb_').getAttribute('comboval');
	eval("document.serviceinformation.cmbThird_"+uniqueKey).value=document.getElementById('Thirdcmb_').getAttribute('comboval');
	eval("document.serviceinformation.cmbOrDoctor_"+uniqueKey).value=document.getElementById('OrDoctorcmb_').getAttribute('comboval');
	eval("document.serviceinformation.cmbTypeOfService_"+uniqueKey).value=document.getElementById('typeOfServicecmb_').getAttribute('comboval');
	if(getServiceid() == -1)
	{
	commonStr=PATIENT_ID;
	commonStr+="~"+convertDateToSqliteFormat(eval("document.serviceinformation.txtDOP_"+uniqueKey).value);
	commonStr+="~"+eval("document.serviceinformation.cmbSDoctor_"+uniqueKey).value;
	commonStr+="~"+eval("document.serviceinformation.cmbBDoctor_"+uniqueKey).value;
	commonStr+="~"+eval("document.serviceinformation.cmbPOS_"+uniqueKey).value;
	commonStr+="~"+eval("document.serviceinformation.cmbPrimary_"+uniqueKey).value;
	commonStr+="~"+eval("document.serviceinformation.cmbSecond_"+uniqueKey).value;
	commonStr+="~"+eval("document.serviceinformation.cmbThird_"+uniqueKey).value;
	}
	var fullySetteledFlag =false;
	dxString='00000';
	for (var j=0; j <  removedRow.length-1; j++){
	if(getServiceid()==-1)
	uniqueKey=PATIENT_ID;
	i=getRemovedRow(j);
		if(i==-1)
			continue;
			if(getServiceid()==-1)
			 uniqueKey=uniqueKey+"_"+i;
		 var resultCheck=""; 
		 resultCheck=eval("("+selectPool.get(40)+")");
		 if(getSavedServiceIDArray(uniqueKey)==-1){
	     for(var i=0;i<resultCheck.length;i++)
	     {
	     if(resultCheck[i].cptcode==document.getElementById('CPTtxt_'+uniqueKey).value  && resultCheck[i].dosfrom==document.getElementById('DOStxt_'+uniqueKey).value  && resultCheck[i].sdoctorid==parseInt(document.getElementById('SDoctorcmb_').getAttribute('comboval')) &&  resultCheck[i].mod1==document.getElementById('Mod1txt_'+uniqueKey).value  && resultCheck[i].mod2==document.getElementById('Mod2txt_'+uniqueKey).value)
			{	     
             alert("Service with CPT: "+resultCheck[i].cptcode+" is already present with different status. Remove or change the CPT before saving.");
             savetypechk=1;
             throw "Service with CPT: "+resultCheck[i].cptcode+" is already present with different status. Remove or change the CPT before saving.";
             return(0);
           }	     
	     }
		 }
	     //skip if the service is fully setteled 
		if(document.getElementById('cmbStatus_'+uniqueKey).value=='X'){
			fullySetteledFlag = true;
			continue;
		}
		//if(document.getElementById('Statuscmb_'+uniqueKey).getAttribute('comboval')=='T' )
		if(getSavedServiceIDArray(uniqueKey)==-1){ //alert('Statuscmb_'+uniqueKey);  //recheck
			//alert('in---'+getSavedServiceIDArray(uniqueKey)+'----uniqueKey_---'+uniqueKey);
			var sub=document.getElementById('Statuscmb_'+uniqueKey).getAttribute('comboval');
			if(sub=='-1' || sub==''){
			  alert("Invalid Submit Status !");
			  savetypechk=1;
			  throw "Invalid Submit Status !";
			  return(0);
			}
			if(sub == 'Y' || sub =='B' || sub == 'C'){
				  alert("New Service Submit Status can be EMR Service, Ready for Patient Billing or On Hold only !");
				  savetypechk=1;
				  throw "New Service Submit Status can be EMR Service, Ready for Patient Billing or On Hold only !";
				  return(0);
			}
			/*if(sub!='0' && sub!='T' && sub!='A'){
			   alert("Submit Status can be EMR Service, Ready for Patient Billing or On Hold only !");
			  return(0);
			}*/
		}
			if(getSavedServiceIDArray(uniqueKey)> 0){
				var sub=document.getElementById('Statuscmb_'+uniqueKey).getAttribute('comboval');
				if(sub=='-1' || sub==''){
				  alert("Invalid Submit Status !");
				  savetypechk=1;
				  throw "Invalid Submit Status !";
				  return(0);
				}
				if(!checkSubmitStatus(document.getElementById('Statuscmb_'+uniqueKey),document.getElementById('CPTtxt_'+uniqueKey),1)){
					savetypechk=1;
				return(0);
				}
			}		

		if(document.getElementById('cmbStatus_'+uniqueKey).value=='T' )
		 {
		    if(parseInt(document.getElementById('billingReasoncmb_'+uniqueKey).getAttribute('comboval')) <1 || document.getElementById('billingReasoncmb_'+uniqueKey).value=="" ||document.getElementById('billingReasoncmb_'+uniqueKey).value=="None"){
				alert("Select billing reason for ready for patient bill service !");
				savetypechk=1;
				throw "Select billing reason for ready for patient bill service !";
				return(0);
				}
		 }	 
	 	if(parseInt(getFormattedCurrency(document.getElementById('Paymentstxt_'+uniqueKey).value,CURR_SYM)) > 0)
		 {
		    if(parseInt(document.getElementById('HowPaidcmb_'+uniqueKey).getAttribute('comboval')) <1 || document.getElementById('HowPaidcmb_'+uniqueKey).value=="" ||document.getElementById('HowPaidcmb_'+uniqueKey).value=="None"){
				alert("Select payment mode for patient copay payment !");
				savetypechk=1;
				throw "Select payment mode for patient copay payment !";
				return(0);
				}
		 }
	 	if(parseInt(document.getElementById('HowPaidcmb_'+uniqueKey).getAttribute('comboval'))==2)
	 	{
	 	  if(document.getElementById('Checktxt_'+uniqueKey).value==''){
	 	    alert("Enter check number for check payment !");
	 	   savetypechk=1;
	 	    throw "Enter check number for check payment !";
	 	    return(0);
	 	    }
	 	}
	 	if(parseInt(document.getElementById('CPTtxt_'+uniqueKey).getAttribute('cpttype'))==1)
	 	{
	 	  if(document.getElementById('DX1txt_'+uniqueKey).value==''){
	 		 alert("Enter diagnosis code for CPT "+document.getElementById('CPTtxt_'+uniqueKey).getAttribute('prev_val')+" !");
			   savetypechk=1;
	 	   throw "Enter diagnosis code !";
	 	   return(0);
	 	  }
	 	}
	 	if(parseInt(getFormattedCurrency(document.getElementById('Chargestxt_'+uniqueKey).value,CURR_SYM)) < 0)
		 {
		    	alert("Charges can't be negative !");
		    	savetypechk=1;
		    	throw "Charges can't be negative !";
				return(0);
	     }
	 	
	 	//alert(document.getElementById("POScmb_").value.indexOf('(11)')+"===="+document.getElementById('hospadm_date_'+uniqueKey).value);
	    
	     if(document.getElementById('hospadm_date_'+uniqueKey)!= null){
		     if((document.getElementById("POScmb_").value.indexOf('(21)')>-1) && (Trim(document.getElementById('hospadm_date_'+uniqueKey).value)=="" || Trim(document.getElementById('hospadm_date_'+uniqueKey).value)== null)){
		    	 alert('Enter hospital admission date !');
		    	 savetypechk=1;
		    	 throw "Enter hospital admission date !";
		    	 return(0);
		     }
	     }
	 	
	     /*if(parseInt(getFormattedCurrency(document.getElementById('Chargestxt_'+uniqueKey).value,CURR_SYM)) < parseInt(getFormattedCurrency(document.getElementById('Copaytxt_'+uniqueKey).value,CURR_SYM)))
		 {
		    	alert("Copay can't be greater than charges !");
				return(0);
	     }
	     if(parseInt(getFormattedCurrency(document.getElementById('Copaytxt_'+uniqueKey).value,CURR_SYM)) < parseInt(getFormattedCurrency(document.getElementById('Paymentstxt_'+uniqueKey).value,CURR_SYM)))
		 {
		    	alert("Copay payment can't be greater than copay !");
				return(0);
	     }*/
	     if(getServiceid() == -1){
	     if(document.getElementById('Authcmb_'+uniqueKey).getAttribute('comboval')!=-1 )
	     {
	     	//if(!checkAuth(document.getElementById('Authcmb_'+uniqueKey).getAttribute('comboval')))
	     	 //return(0);
	     }}
	     
	 	eval("document.serviceinformation.txtDOS_"+uniqueKey).value=document.getElementById('DOStxt_'+uniqueKey).value;	
	 	eval("document.serviceinformation.txtdosto_"+uniqueKey).value=document.getElementById('dosto_'+uniqueKey).value;
	 	eval("document.serviceinformation.txtCPT_"+uniqueKey).value=document.getElementById('CPTtxt_'+uniqueKey).value;
		eval("document.serviceinformation.txtMod1_"+uniqueKey).value=document.getElementById('Mod1txt_'+uniqueKey).value;	
		eval("document.serviceinformation.txtUnits_"+uniqueKey).value=document.getElementById('Unitstxt_'+uniqueKey).value;	
		eval("document.serviceinformation.txtCharges_"+uniqueKey).value=getFormattedCurrency(document.getElementById('Chargestxt_'+uniqueKey).value,CURR_SYM);	
		eval("document.serviceinformation.txtCopay_"+uniqueKey).value=getFormattedCurrency(document.getElementById('Copaytxt_'+uniqueKey).value,CURR_SYM);	
		eval("document.serviceinformation.txtPayments_"+uniqueKey).value=getFormattedCurrency(document.getElementById('Paymentstxt_'+uniqueKey).value,CURR_SYM);	
		eval("document.serviceinformation.txtDX1_"+uniqueKey).value=document.getElementById('DX1txt_'+uniqueKey).value;	
		eval("document.serviceinformation.txtDX2_"+uniqueKey).value=document.getElementById('DX2txt_'+uniqueKey).value;	
		eval("document.serviceinformation.txtDX3_"+uniqueKey).value=document.getElementById('DX3txt_'+uniqueKey).value;	
		eval("document.serviceinformation.txtDX4_"+uniqueKey).value=document.getElementById('DX4txt_'+uniqueKey).value;
		/*eval("document.serviceinformation.txtDX5_"+uniqueKey).value=document.getElementById('D-X5txt_'+uniqueKey).value;	
		eval("document.serviceinformation.txtDX6_"+uniqueKey).value=document.getElementById('D-X6txt_'+uniqueKey).value;	
		eval("document.serviceinformation.txtDX7_"+uniqueKey).value=document.getElementById('D-X7txt_'+uniqueKey).value;	
		eval("document.serviceinformation.txtDX8_"+uniqueKey).value=document.getElementById('D-X8txt_'+uniqueKey).value;*/
		
		var dx5to20Data=document.getElementById('D-X5-20txt_'+uniqueKey).value;
		var dxValues=dx5to20Data.split(",");
		
		if(dx5to20Data.lastIndexOf(',') >= 0 && dx5to20Data.length-1 == dx5to20Data.lastIndexOf(','))
			{
			dx5to20Data=dx5to20Data.split(",").slice(0, -1).join(',');
			dxValues=dx5to20Data.split(",");
			}		
		
		if(dxValues.length >16){
			alert('You have entered more than 16 Diagnosis codes !');
			savetypechk=1;
			throw "You have entered more than 16 Diagnosis codes !";
			return(0);
		}
		for(var i=0;i<dxValues.length;i++){
			if((dxValues[i] == "" &&(dx5to20Data.lastIndexOf(',') >= 0 && dx5to20Data.length-1 != dx5to20Data.lastIndexOf(','))) || dxValues[i].indexOf('.') == 0){
				alert('Invalid Dx !');
				savetypechk=1;
				throw "Invalid Dx !";
				document.getElementById('D-X5-20txt_'+uniqueKey).style.backgroundColor="yellow";
				return(0);
			}
			else{
				var idValue=i+5;
					eval("document.serviceinformation.txtDX"+idValue+"_"+uniqueKey).value=dxValues[i];
				if(dxValues[i])
					dxString+="~"+Trim(dxValues[i]);
				}
		}
		for(var k=dxValues.length+5;k<=16;k++){
				eval("document.serviceinformation.txtDX"+k+"_"+uniqueKey).value="";
		}
		
		eval("document.serviceinformation.txtMod2_"+uniqueKey).value=document.getElementById('Mod2txt_'+uniqueKey).value;	
		eval("document.serviceinformation.txtMod3_"+uniqueKey).value=document.getElementById('Mod3txt_'+uniqueKey).value;	
		eval("document.serviceinformation.txtMod4_"+uniqueKey).value=document.getElementById('Mod4txt_'+uniqueKey).value;
		eval("document.serviceinformation.txtHospAdmTimehrs_"+uniqueKey).value=document.getElementById('admTimehrs_'+uniqueKey).value;
		eval("document.serviceinformation.txtHospAdmTimemins_"+uniqueKey).value=document.getElementById('admTimemins_'+uniqueKey).value;
		eval("document.serviceinformation.txtHospAdmTimesecs_"+uniqueKey).value=document.getElementById('admTimesecs_'+uniqueKey).value;
		eval("document.serviceinformation.txtHospDisTimehrs_"+uniqueKey).value=document.getElementById('disTimehrs_'+uniqueKey).value;
		eval("document.serviceinformation.txtHospDisTimemins_"+uniqueKey).value=document.getElementById('disTimemins_'+uniqueKey).value;
		eval("document.serviceinformation.txtHospDisTimesecs_"+uniqueKey).value=document.getElementById('disTimesecs_'+uniqueKey).value;
		eval("document.serviceinformation.cmbStatus_"+uniqueKey).value=document.getElementById('Statuscmb_'+uniqueKey).getAttribute('comboval');
		eval("document.serviceinformation.cmbOldStatus_"+uniqueKey).value=document.getElementById('Statuscmb_'+uniqueKey).getAttribute('orival');
		eval("document.serviceinformation.cmbServiceType_"+uniqueKey).value=document.getElementById('VisitTypecmb_'+uniqueKey).getAttribute('comboval');
		eval("document.serviceinformation.txtTifRef_"+uniqueKey).value=document.getElementById('TifReftxt_'+uniqueKey).value;			
		eval("document.serviceinformation.cmbCostPlan_"+uniqueKey).value=document.getElementById('CostPlancmb_'+uniqueKey).getAttribute('comboval');
		eval("document.serviceinformation.cmbHowPaid_"+uniqueKey).value=document.getElementById('HowPaidcmb_'+uniqueKey).getAttribute('comboval');
		eval("document.serviceinformation.txtCheck_"+uniqueKey).value=document.getElementById('Checktxt_'+uniqueKey).value;
		eval("document.serviceinformation.cmbAuth_"+uniqueKey).value=document.getElementById('Authcmb_'+uniqueKey).getAttribute('comboval');
		//eval("document.serviceinformation.typeOfService_"+uniqueKey).value=document.getElementById('typeOfServicecmb_'+uniqueKey).getAttribute('comboval');			
		eval("document.serviceinformation.txtComments_"+uniqueKey).value=document.getElementById('Commentstxt_'+uniqueKey).value;			
		eval("document.serviceinformation.billingReason_"+uniqueKey).value=document.getElementById('billingReasoncmb_'+uniqueKey).getAttribute('comboval');			
		if(paymentGroup==1)
		 eval("document.serviceinformation.paymentGroup_"+uniqueKey).value=document.getElementById('PaymentGroupcmb_'+uniqueKey).getAttribute('comboval');
		eval("document.serviceinformation.txtRlu_"+uniqueKey).value=document.getElementById('Rlutxt_'+uniqueKey).value;		
		eval("document.serviceinformation.cmbSpDx_"+uniqueKey).value=document.getElementById('SpDxcmb_'+uniqueKey).getAttribute('comboval');
		//eval("document.serviceinformation.txtSpDxtxt_"+uniqueKey).value=document.getElementById('SpDxtxt_'+uniqueKey).value;
		
		//Aditional Data
		var fieldValue=eval("("+selectPool.get(55)+")");
		if(fieldValue!=null)
			{
			var starttime='';
			var endtime='';
			var nTotalDiff='';
			
		
		for (var i=0; i<fieldValue.length; i++)
			{
	if(starttime==''&& endtime=='')
			{
				for (var k=0; k<fieldValue.length; k++)
				{	
					if(fieldValue[k].chargetabname=='anes_starttime')
						starttime=document.getElementById(fieldValue[k].chargetabname+"_"+uniqueKey).value;
					if(fieldValue[k].chargetabname=='anes_endtime')
						endtime=document.getElementById(fieldValue[k].chargetabname+"_"+uniqueKey).value;
				}
				if(starttime!=''&& endtime=='')
				{
					alert("Please Enter Anesthesia EndTime!!!");
					savetypechk=1;
					throw "Please Enter Anesthesia EndTime!!!";
					return(0);
				}
				if(starttime==''&& endtime!='')
				{
					alert("Please Enter Anesthesia StartTime!!!");
					savetypechk=1;
					throw "Please Enter Anesthesia StartTime!!!";
					return(0);
				}
				if(starttime!=''&& endtime!='')
				{
		var xhour=starttime.split(".");
		var yhour=endtime.split(".");
		var meanhour=parseInt(yhour[0]-xhour[0]);
		var meanmin=yhour[1]-xhour[1];
		var totmin=parseInt(meanhour*60)+meanmin;
		starttime=starttime.replace(".", "");
		endtime=endtime.replace(".", "");
		if(starttime.length==2)
			starttime="00"+starttime;
		if(starttime.length==3)
			starttime="0"+starttime;
		if(endtime.length==2)
			endtime="00"+endtime;
		if(endtime.length==3)
			endtime="0"+endtime;
		
		nTotalDiff +="7 BEGIN "+starttime+" END "+endtime+" "+totmin+" MINUTES"; 
		eval("document.serviceinformation.txtanesthesia_timeline_"+uniqueKey).value=nTotalDiff;
				}
			}
			var tempval = fieldValue[i].chargetabname;

			var testid = "txt"+tempval+"_"+uniqueKey;
			eval("document.serviceinformation."+testid).value=document.getElementById(fieldValue[i].chargetabname+'_'+uniqueKey).value;
			//alert("value>>>>"+document.getElementById(fieldValue[i].chargetabname+"_"+uniqueKey).value);
			//alert("testid>>>"+testid);
		  }
	    }
		
		
		if(getServiceid() == -1)
		{
		if(detailStr!="")
		 detailStr+="#"
		if(detailStr=="")
		 detailStr=eval("document.serviceinformation.cmbStatus_"+uniqueKey).value;
		else
		 detailStr+=eval("document.serviceinformation.cmbStatus_"+uniqueKey).value;
		detailStr+="~"+convertDateToSqliteFormat(eval("document.serviceinformation.txtDOS_"+uniqueKey).value);
		//detailStr+="~"+convertDateToSqliteFormat(eval("document.serviceinformation.txtdosto_"+uniqueKey).value);
		detailStr+="~"+eval("document.serviceinformation.txtCPT_"+uniqueKey).value;
		detailStr+="~"+eval("document.serviceinformation.txtMod1_"+uniqueKey).value;
		detailStr+="~"+eval("document.serviceinformation.txtMod2_"+uniqueKey).value;	
		detailStr+="~"+eval("document.serviceinformation.txtUnits_"+uniqueKey).value;	
		detailStr+="~"+eval("document.serviceinformation.txtCharges_"+uniqueKey).value;	
		detailStr+="~"+eval("document.serviceinformation.txtCopay_"+uniqueKey).value;
		
		var dx1Data=eval("document.serviceinformation.txtDX1_"+uniqueKey).value;
		var dx2Data=eval("document.serviceinformation.txtDX2_"+uniqueKey).value;
		var dx3Data=eval("document.serviceinformation.txtDX3_"+uniqueKey).value;
		var dx4Data=eval("document.serviceinformation.txtDX4_"+uniqueKey).value;
		
		if(	dx1Data =='')
		detailStr+="~NIL"
		else
		detailStr+="~"+dx1Data;
		if(dx2Data =='')
		detailStr+="~NIL"
		else	
		detailStr+="~"+dx2Data;
		if(	dx3Data =='')
		detailStr+="~NIL"
		else
		detailStr+="~"+dx3Data;
		if(	dx4Data =='')
		detailStr+="~NIL"
		else
		detailStr+="~"+dx4Data;
		
		if(Trim(dx1Data) !='')
			 dxString+="~"+Trim(dx1Data);
		if(Trim(dx2Data) !='')
			 dxString+="~"+Trim(dx2Data);
		if(Trim(dx3Data) !='')
			 dxString+="~"+Trim(dx3Data);
		if(Trim(dx4Data) !='')
			 dxString+="~"+Trim(dx4Data);
		}
	}
	
	if(validateDx()==0){
		savetypechk=1;
		return(0);
	}
		var b_reason=0;
		var b_reason_ok=1;
		var b_reason_desc="";
		var billing_code="",billing_desc="",billing_status="";
		var pos_valid="",ins_valid="",doctor_valid="",past_serviceid="";
		var frm = eval("document.serviceinformation");
		var serviceid=getServiceid();
		var dxValues='';
		var uniqueID;
		if(getServiceid()==-1)
		 uniqueID=frm.patientId.value;
		 else
		 uniqueID=getServiceid();
				
		if(removedRow.length-1<=0){
			if(getSignBitChk()==1){
				if(!confirm(" Do you want to continue without entering services?")){
					savetypechk=1;
					throw "Enter Service details !";
					return(0);
				}
			}
		}
		for (var j=0;j<removedRow.length-1;j++){
			i=getRemovedRow(j);
			if(i==-1)
				continue;
			if(getServiceid() == -1)
			{
			uniqueID=frm.patientId.value;
			 uniqueID=uniqueID+"_"+j;
			 }	
			if(document.getElementById('cmbStatus_'+uniqueID).value=='X'){
				continue;
			}
			if (document.getElementById('CPTtxt_'+uniqueID).getAttribute('cpttype')!=0 ){			
				var dos = eval("document.serviceinformation.txtDOS_" + uniqueID).value ;
				var dx1 = eval("document.serviceinformation.txtDX1_" + uniqueID).value ;
				var dx2 = eval("document.serviceinformation.txtDX2_" + uniqueID).value ;
				var dx3 = eval("document.serviceinformation.txtDX3_" + uniqueID).value ;
				var dx4 = eval("document.serviceinformation.txtDX4_" + uniqueID).value ;
				var dxValue ='';
//				document.getElementById('inputText').value=dx1+' ' + dx2+' ' + dx3 +' ' + dos +' ' + dx4 ;
				var submit_status=eval("document.serviceinformation.cmbStatus_" + uniqueID).value ;
				if(submit_status=="T"){
					b_reason=eval("document.serviceinformation.billingReason_" + uniqueID).value ;
					b_reason_desc=eval("document.serviceinformation.billingReason_" + uniqueID) ;
					if(b_reason < 0)
						b_reason_ok=-1;
				}				
				if(!(Trim(dx1)=='')){
					if(dxValues.indexOf(dx1)==-1)
						dxValue = dx1+"~~~";
				}
				else if(!(dx2=='')){
					alert("Dx1 missing !");
					savetypechk=1;
					throw "Dx1 missing !";
					return(0);
				}
				if(!(dx2=='')){
					if(dxValues.indexOf(dx2)==-1)
						dxValue = dxValue + dx2+"~~~";
				}
				else if(!(dx3=='')){
					alert("Dx2 missing !");
					savetypechk=1;
					throw "Dx2 missing !";
					return(0);
				}
				if(!(dx3=='')){
					if(dxValues.indexOf(dx3)==-1)
						dxValue = dxValue + dx3+"~~~";
				}
				else if(!(dx4=='')){
					alert("Dx3 missing !");
					savetypechk=1;
					throw "Dx3 missing !";
					return(0);
				}
				if(!(dx4=='')){
					if(dxValues.indexOf(dx1)==-1)
						dxValue = dxValue + dx4+"~~~";
				}
				dxValues = dxValues + dxValue;
		 		if(dos==""){
					alert("Enter date of service !");
					savetypechk=1;
					throw "Enter date of service !";
					return(0);
				}
			}
		}  
		
		if(b_reason_ok==-1){
			alert("Select billing reason for ready for patient bill service !");
			savetypechk=1;
			throw "Select billing reason for ready for patient bill service !";
			return(0);
		}
/*		if(fullySetteledFlag){
			alert("Note: Modification done for fully setteled services will not be saved.");
		}*/
		savetypechk=2;
return(1);
}

function saveSavedServiecs()
{
var ids=idString.split('~||~');
var uniqueKey;
/*if(!eval("document.serviceinformation.servicedata"))
{
addHiddenField(document.serviceinformation,'servicedata');
addHiddenField(document.serviceinformation,'actionType');
addHiddenField(document.serviceinformation,'patientId');
}
*/
showRequestDivStatus(false,tabDetails.SERVICE,0,false,'Gathering information ...');
var fieldValue=eval("("+selectPool.get(55)+")");

for(var i=0;i<ids.length;i++)
{
uniqueKey=ids[i];
if(!eval("document.serviceinformation.cmbSDoctor_"+uniqueKey) || comingforedit==1)
{
addHiddenField(document.serviceinformation,'cmbSDoctor_'+uniqueKey);
addHiddenField(document.serviceinformation,'cmbPOS_'+uniqueKey);
addHiddenField(document.serviceinformation,'cmbServiceType_'+uniqueKey);
addHiddenField(document.serviceinformation,'cmbBDoctor_'+uniqueKey);
addHiddenField(document.serviceinformation,'cmbPrimary_'+uniqueKey);
addHiddenField(document.serviceinformation,'cmbCase_'+uniqueKey);
addHiddenField(document.serviceinformation,'cmbReferral_'+uniqueKey);
addHiddenField(document.serviceinformation,'cmbSecond_'+uniqueKey);
addHiddenField(document.serviceinformation,'cmbThird_'+uniqueKey);
addHiddenField(document.serviceinformation,'cmbOrDoctor_'+uniqueKey);
addHiddenField(document.serviceinformation,'cmbTypeOfService_'+uniqueKey);
addHiddenField(document.serviceinformation,'cmbStatus_'+uniqueKey);
addHiddenField(document.serviceinformation,'cmbOldStatus_'+uniqueKey);
addHiddenField(document.serviceinformation,'cmbCostPlan_'+uniqueKey);
addHiddenField(document.serviceinformation,'cmbHowPaid_'+uniqueKey);
addHiddenField(document.serviceinformation,'cmbAuth_'+uniqueKey);
addHiddenField(document.serviceinformation,'billingReason_'+uniqueKey);
addHiddenField(document.serviceinformation,'paymentGroup_'+uniqueKey);
addHiddenField(document.serviceinformation,'cmbSpDx_'+uniqueKey);

}
if(fieldValue!=null)
{
	addHiddenField(document.serviceinformation,'txtanesthesia_timeline_'+uniqueKey);
	for(var j=0;j<fieldValue.length;j++)
	addHiddenField(document.serviceinformation,'txt'+fieldValue[j].chargetabname+"_"+uniqueKey);
}

if(parseInt(document.getElementById('XSDoctorcmb_'+uniqueKey).getAttribute('comboval')) <1 || document.getElementById('XSDoctorcmb_'+uniqueKey).value=="" ||document.getElementById('XSDoctorcmb_'+uniqueKey).value=="None"){
				alert("Select Service Doctor !");//hideRequestDivStatus(tabDetails.SERVICE,0);
				throw "Select Service Doctor !";
				return;
				}
if(parseInt(document.getElementById('XPOScmb_'+uniqueKey).getAttribute('comboval')) <1 || document.getElementById('XPOScmb_'+uniqueKey).value=="" ||document.getElementById('XPOScmb_'+uniqueKey).value=="None"){
				alert("Select Place Of Service !");//hideRequestDivStatus(tabDetails.SERVICE,0);
				throw "Select Place Of Service !";			
				return;
				}
if(parseInt(document.getElementById('XPrimarycmb_'+uniqueKey).getAttribute('comboval')) <1 || document.getElementById('XPrimarycmb_'+uniqueKey).value=="" ||document.getElementById('XPrimarycmb_'+uniqueKey).value=="None"){
				alert("Select Primary Insurance !");//hideRequestDivStatus(tabDetails.SERVICE,0);
				throw "Select Primary Insurance !";
				return;
				}

if(document.getElementById('XStatuscmb_'+uniqueKey).getAttribute('comboval')=='T' )
		 {
		    if(parseInt(document.getElementById('XbillingReasoncmb_'+uniqueKey).getAttribute('comboval')) <1 || document.getElementById('XbillingReasoncmb_'+uniqueKey).value=="" ||document.getElementById('XbillingReasoncmb_'+uniqueKey).value=="None"){
				alert("Select billing reason for ready for patient bill service !");//hideRequestDivStatus(tabDetails.SERVICE,0);
				throw "Select billing reason for ready for patient bill service !";
				return;
				}
		 }	 
	 	if(parseInt(getFormattedCurrency(document.getElementById('txtPayments_'+uniqueKey).value,CURR_SYM)) > 0)
		 {
		    if(parseInt(document.getElementById('XHowPaidcmb_'+uniqueKey).getAttribute('comboval')) <1 || document.getElementById('XHowPaidcmb_'+uniqueKey).value=="" ||document.getElementById('XHowPaidcmb_'+uniqueKey).value=="None"){
				alert("Select payment mode for patient copay payment !");//hideRequestDivStatus(tabDetails.SERVICE,0);
				throw "Select payment mode for patient copay payment !";
				return;
				}
		 }
	 	if(parseInt(document.getElementById('XHowPaidcmb_'+uniqueKey).getAttribute('comboval'))==2)
	 	{
	 	  if(document.getElementById('txtCheck_'+uniqueKey).value==''){
	 	    alert("Enter check number for check payment !");//hideRequestDivStatus(tabDetails.SERVICE,0);
	 	    throw "Enter check number for check payment !";
	 	    return;
	 	    }
	 	}
	 	if(parseInt(document.getElementById('txtCPT_'+uniqueKey).getAttribute('cpttype'))==1)
	 	{
	 	  if(document.getElementById('txtDX1_'+uniqueKey).value==''){
	 	   alert("Please enter diagnosis code ...");//hideRequestDivStatus(tabDetails.SERVICE,0);
	 	   throw "Please enter diagnosis code ...";
	 	   return;
	 	  }
	 	}
	 	if(parseInt(getFormattedCurrency(document.getElementById('txtCharges_'+uniqueKey).value,CURR_SYM)) < 0)
		 {
		    	alert("Charges can't be negative !");//hideRequestDivStatus(tabDetails.SERVICE,0);
		    	throw "Charges can't be negative !";
				return;
	     }
	     if(parseInt(getFormattedCurrency(document.getElementById('txtCharges_'+uniqueKey).value,CURR_SYM)) < parseInt(getFormattedCurrency(document.getElementById('txtCopay_'+uniqueKey).value,CURR_SYM)))
		 {
		    	alert("Copay can't be greater than charges !");//hideRequestDivStatus(tabDetails.SERVICE,0);
		    	throw "Copay can't be greater than charges !";
				return;
	     }
	     /*if(parseInt(getFormattedCurrency(document.getElementById('txtCopay_'+uniqueKey).value,CURR_SYM)) < parseInt(getFormattedCurrency(document.getElementById('txtPayments_'+uniqueKey).value,CURR_SYM)))
		 {
		    	alert("Copay payment can't be greater than copay !");
				return;
	     }*/

eval("document.serviceinformation.txtCharges_"+uniqueKey).value=getFormattedCurrency(eval("document.serviceinformation.txtCharges_"+uniqueKey).value,CURR_SYM);
eval("document.serviceinformation.txtCopay_"+uniqueKey).value=getFormattedCurrency(eval("document.serviceinformation.txtCopay_"+uniqueKey).value,CURR_SYM);
eval("document.serviceinformation.txtPayments_"+uniqueKey).value=getFormattedCurrency(eval("document.serviceinformation.txtPayments_"+uniqueKey).value,CURR_SYM);

eval("document.serviceinformation.cmbSDoctor_"+uniqueKey).value=document.getElementById('XSDoctorcmb_'+uniqueKey).getAttribute('comboval');
eval("document.serviceinformation.cmbPOS_"+uniqueKey).value=document.getElementById('XPOScmb_'+uniqueKey).getAttribute('comboval');
eval("document.serviceinformation.cmbServiceType_"+uniqueKey).value=document.getElementById('XServiceTypecmb_'+uniqueKey).getAttribute('comboval');
eval("document.serviceinformation.cmbBDoctor_"+uniqueKey).value=document.getElementById('XBDoctorcmb_'+uniqueKey).getAttribute('comboval');	
eval("document.serviceinformation.cmbPrimary_"+uniqueKey).value=document.getElementById('XPrimarycmb_'+uniqueKey).getAttribute('comboval');
eval("document.serviceinformation.cmbCase_"+uniqueKey).value=document.getElementById('XCasecmb_'+uniqueKey).getAttribute('comboval');
eval("document.serviceinformation.cmbReferral_"+uniqueKey).value=document.getElementById('XReferralcmb_'+uniqueKey).getAttribute('comboval');	
eval("document.serviceinformation.cmbSecond_"+uniqueKey).value=document.getElementById('XSecondcmb_'+uniqueKey).getAttribute('comboval');	
eval("document.serviceinformation.cmbThird_"+uniqueKey).value=document.getElementById('XThirdcmb_'+uniqueKey).getAttribute('comboval');
eval("document.serviceinformation.cmbOrDoctor_"+uniqueKey).value=document.getElementById('XOrDoctorcmb_'+uniqueKey).getAttribute('comboval');
eval("document.serviceinformation.cmbTypeOfService_"+uniqueKey).value=document.getElementById('XtypeOfServicecmb_'+uniqueKey).getAttribute('comboval');

eval("document.serviceinformation.cmbStatus_"+uniqueKey).value=document.getElementById('XStatuscmb_'+uniqueKey).getAttribute('comboval');
eval("document.serviceinformation.cmbCostPlan_"+uniqueKey).value=document.getElementById('XCostPlancmb_'+uniqueKey).getAttribute('comboval');
eval("document.serviceinformation.cmbHowPaid_"+uniqueKey).value=document.getElementById('XHowPaidcmb_'+uniqueKey).getAttribute('comboval');
eval("document.serviceinformation.cmbAuth_"+uniqueKey).value=document.getElementById('XAuthcmb_'+uniqueKey).getAttribute('comboval');
eval("document.serviceinformation.billingReason_"+uniqueKey).value=document.getElementById('XbillingReasoncmb_'+uniqueKey).getAttribute('comboval');

if(fieldValue!=null)
{
var starttime='';
var endtime='';
var nTotalDiff='';

for (var k=0; k<fieldValue.length; k++)
{
	if(starttime==''&& endtime=='')
		{
		for (var z=0; z<fieldValue.length; z++)
		{	
			if(fieldValue[z].chargetabname=='anes_starttime')
				starttime=document.getElementById(fieldValue[z].chargetabname+"_"+uniqueKey).value;
			if(fieldValue[z].chargetabname=='anes_endtime')
				endtime=document.getElementById(fieldValue[z].chargetabname+"_"+uniqueKey).value;
		}
		if(starttime!=''&& endtime=='')
		{
			alert("Please Enter Anesthesia EndTime!!!");
			throw "Please Enter Anesthesia EndTime!!!";
			return(0);
		}
		if(starttime==''&& endtime!='')
		{
			alert("Please Enter Anesthesia StartTime!!!");
			throw "Please Enter Anesthesia StartTime!!!";
			return(0);
		}
		if(starttime!=''&& endtime!='')
		{
		var xhour=starttime.split(".");
		var yhour=endtime.split(".");
		var meanhour=parseInt(yhour[0]-xhour[0]);
		var meanmin=yhour[1]-xhour[1];
		var totmin=parseInt(meanhour*60)+meanmin;
		starttime=starttime.replace(".", "");
		endtime=endtime.replace(".", "");
		if(starttime.length==2)
			starttime="00"+starttime;
		if(starttime.length==3)
			starttime="0"+starttime;
		if(endtime.length==2)
			endtime="00"+endtime;
		if(endtime.length==3)
			endtime="0"+endtime;
		
		nTotalDiff +="7 BEGIN "+starttime+" END "+endtime+" "+totmin+" MINUTES"; 
		eval("document.serviceinformation.txtanesthesia_timeline_"+uniqueKey).value=nTotalDiff;
		}
		}
		var tempval = fieldValue[k].chargetabname;
		var testid = "txt"+tempval+"_"+uniqueKey;
		eval("document.serviceinformation."+testid).value=document.getElementById(fieldValue[k].chargetabname+"_"+uniqueKey).value;
		//alert("testid>>>"+testid);
		//alert("value>>"+document.getElementById(fieldValue[k].chargetabname+"_"+uniqueKey).value);
		
		}
	}
eval("document.serviceinformation.cmbSpDx_"+uniqueKey).value=document.getElementById('XSpDxcmb_'+uniqueKey).getAttribute('comboval');
eval("document.serviceinformation.servicedata").value+=uniqueKey+"~";
}
comingforedit=0;
//hideRequestDivStatus(tabDetails.SERVICE,0);
eval("document.serviceinformation.actionType").value = "UPDATE_SERVICE";
eval("document.serviceinformation.patientId").value = PATIENT_ID;
eval("document.serviceinformation.takeARAction").value=-1;
document.serviceinformation.logdata.value="Services Updated";
showRequestDivStatus(false,tabDetails.SERVICE,0,false,'Saving ...');
document.serviceinformation.submit();
}

function Trim(str){
  return RTrim(LTrim(str));
}
function LTrim(str)
{
        var whitespace = new String(" \t\n\r");
        var s = new String(str);
        if (whitespace.indexOf(s.charAt(0)) != -1) {
            var j=0, i = s.length;
            while (j < i && whitespace.indexOf(s.charAt(j)) != -1)
                j++;
            s = s.substring(j, i);
        }
        return s;
}

function RTrim(str)
{
        var whitespace = new String(" \t\n\r");
        var s = new String(str);
        if (whitespace.indexOf(s.charAt(s.length-1)) != -1) {
            var i = s.length - 1;
            while (i >= 0 && whitespace.indexOf(s.charAt(i)) != -1)
                i--;
            s = s.substring(0, i+1);
        }
        return s;
}

function inStr(strSearch, charSearchFor){
	for (i=0; i < strSearch.length; i++)
		if (charSearchFor == Mid(strSearch, i, 1))
			return i;      
	return -1;
}
function Mid(str, start, len){
// Make sure start and len are within proper bounds
    if (start < 0 || len < 0) return "";
    var iEnd, iLen = String(str).length;
    if (start + len > iLen)
          iEnd = iLen;
    else
          iEnd = start + len;
    return String(str).substring(start,iEnd);
}

function setAccountType(str) {
	if(str.indexOf("Work") > -1 )
		accountType="4";
	else if(str.indexOf("CHDP") > -1)
		accountType="3";
	else if(str.indexOf("General") > -1)
		accountType="2";
	else
		accountType="-1";
}

function getAccountType(){return accountType;}

function fetchComboDataByAjax(msg,x)
{
/*var msg='';
	for(i=0;i<arguments.length;i++){
		msg=msg+arguments[i];
		if(i!=arguments[i].length-1)
		msg=msg+",";
	}*/
	var callback={
	success:sr_callSuccess,
	failure:sr_callFailure,
	progress:sr_callProgress
	}
	var callback1={
	success:sr_callSuccessEdit,
	failure:sr_callFailureEdit,
	progress:sr_callProgressEdit
	}
	var callback2={
	success:sr_callSuccessEditByDOS,
	failure:sr_callFailureEditByDOS,
	progress:sr_callProgressEditByDOS
	}
if(x==1)	
getAjaxDataFromServer("../ServiceEntry.Action","patientId="+PATIENT_ID+"&group="+msg,false,callback);
else if(x==2)
getAjaxDataFromServer("../ServiceEntry.Action","patientId="+PATIENT_ID+"&group="+msg,false,callback1);
else if (x==3)
getAjaxDataFromServer("../ServiceEntry.Action","patientId="+PATIENT_ID+"&group="+msg,false,callback2);
}

var sr_callFailure=function(responseObject){} 
var sr_callProgress=function(responseObject){}
var sr_callFailureEdit=function(responseObject){} 
var sr_callProgressEdit=function(responseObject){}
var sr_callFailureEditByDOS=function(responseObject){} 
var sr_callProgressEditByDOS=function(responseObject){}
var sr_callSuccess=function(responseObject)
{
var res=eval(responseObject.responseText);
for(j=0;j<res.length;j++){ 		
		var t=eval(res[j]);
		selectPool.set(t.key,t.valu);
	}
setDefaultValuesToCommonStrip(currentModelService);
setValueForService(currentModelService);
checkForInsurance();
}

var sr_callSuccessEdit=function(responseObject)
{
var res=eval(responseObject.responseText);
for(j=0;j<res.length;j++){ 		
		var t=eval(res[j]);
		selectPool.set(t.key,t.valu);
	}
setDefaultValuesToCommonStripEdit(currentModelEdit);
setValueForEditing(currentModelEdit);
checkForInsurance();
}

var sr_callSuccessEditByDOS=function(responseObject)
{
var res=eval(responseObject.responseText);
for(j=0;j<res.length;j++){ 		
		var t=eval(res[j]);
		selectPool.set(t.key,t.valu);
	}
setValuesForEditingByDos();
}

function fetchOldService(msg,sdoc,pos,dos)
{
	alert("==== in fetch old services"+msg+"....sdoc"+sdoc+"-------pos+"+pos+"-----dsos"+dos);
var a;
a=eval(getResponseData("../ServiceEntry.Action?group="+msg+"&patientId="+PATIENT_ID+"&dos="+dos+"&sdoc="+sdoc+"&pos="+pos+"&rand="+Math.floor(Math.random()*1121)));
for(j=0;j<a.length;j++){ 		
		var t=eval(a[j]);
		selectPool.set(t.key,t.valu);
	}
}
function fetchSelectFromServer(){
	var msg='';
	for(i=0;i<arguments.length;i++){
		msg=msg+arguments[i];
		if(i!=arguments[i].length-1)
		msg=msg+",";
	}
	var a;
	if(getServiceid()==-1)
	  a=eval(getResponseData("../ServiceEntry.Action?group="+msg+"&patientId="+PATIENT_ID+"&encounterId="+ENCOUNTER_ID+"&rand="+Math.floor(Math.random()*1121)));
	else if(getServiceid() >0)
	  a	=eval(getResponseData("../ServiceEntry.Action?group="+msg+"&patientId="+PATIENT_ID+"&serviceId="+getServiceid()+"&rand="+Math.floor(Math.random()*1121)));
	else if(editDOS !='')
	  a	=eval(getResponseData("../ServiceEntry.Action?group="+msg+"&patientId="+PATIENT_ID+"&editDOS="+editDOS+"&rand="+Math.floor(Math.random()*1121)));
	for(j=0;j<a.length;j++){ 		
		var t=eval(a[j]);
		selectPool.set(t.key,t.valu);
	}	
}
function fetchDefaults()
{
var a=eval(getResponseData("../ServiceEntry.Action?action=4&patientId="+PATIENT_ID+"&encounterId="+ENCOUNTER_ID+"&rand="+Math.floor(Math.random()*1121)));
return a;
}

function createServiceStripMain(model,fieldData,serviceData,defaultAddFieldData){
	var rowid=model.rowid;
	var dontShowCharges = (CAN_NOT_VIEW_CHARGES && CAN_NOT_VIEW_CHARGES!=-1);
	var isFullysetteledService = false;
	if(serviceData!=null && serviceData.submit_status=='X')
	{
		isFullysetteledService = true;
	}
	if(idString=='')
	 idString=rowid;
	else
	 idString=idString+"~||~"+rowid;
	if(document.getElementById('servicegrid')==null){
		var testtable=document.createElement('table');		
		testtable.id='servicegrid';
	}
	else
		var testtable=document.getElementById('servicegrid');
	testtable.border='1px';
	testtable.cellPadding="0px";
	testtable.cellSpacing="0px";
	testtable.width='100%';
	//testtable.onfocus=function(event){locateCell(event,this);}
	testtable.className='editableGridService';	
	if(model.headersRequired){
		var rowObj=document.createElement('tr');
		rowObj.style.heigth='19px';
		rowObj.className='tableColHeaderService';
		rowObj.noWrap=true;
		rowObj.appendChild(insertCell('', 'emlbl',1,0,'doclist-col-normal',((dontShowCharges)?'3%':'2%')));
		rowObj.appendChild(insertCell('DOS', 'doslbl',1,0,'doclist-col-normal',((dontShowCharges)?'8.5%':'7.5%')));//Inscreased Width for Ipod 
		//rowObj.appendChild(insertCell('DOS To','dostolbl',1,0,'doclist-col-normal',((dontShowCharges)?'8%':'7%')));
		rowObj.appendChild(insertCell('CPT', 'cptlbl',1,0,'doclist-col-normal',((dontShowCharges)?'7%':'6%')));
		rowObj.appendChild(insertCell('Mod1', 'mod1lbl',1,0,'doclist-col-normal',((dontShowCharges)?'5%':'4%')));
		rowObj.appendChild(insertCell('Units', 'unitslbl',1,0,'doclist-col-normal','4%'));
		var ttd = insertCell('Charges', 'chargeslbl',1,0,'doclist-col-normal','6%');
		if(dontShowCharges)
			ttd.style.display = "none";
		rowObj.appendChild(ttd);
		rowObj.appendChild(insertCell('Copay', 'copaylbl',1,0,'doclist-col-normal',((dontShowCharges)?'6%':'5%')));
		rowObj.appendChild(insertCell('CopayPmt', 'copmtlbl',1,0,'doclist-col-normal',((dontShowCharges)?'7%':'6%')));
		rowObj.appendChild(insertCell('', 'emlbl',1,0,'doclist-col-normal','13%')); //Dx picker got hiden in Ipod so increased the Width 
		rowObj.appendChild(insertCell('Dx1', 'dx1lbl',1,0,'doclist-col-normal','6%'));
		//rowObj.appendChild(insertCell('', 'emlbl35',1,0,'doclist-col-normal','10px'));
		rowObj.appendChild(insertCell('Dx2', 'dx2lbl',1,0,'doclist-col-normal','6%'));
		//rowObj.appendChild(insertCell('', 'emlbl4',1,0,'doclist-col-normal','10px'));
		rowObj.appendChild(insertCell('Dx3', 'dx3lbl',1,0,'doclist-col-normal','6%'));
		//rowObj.appendChild(insertCell('', 'emlbl5',1,0,'doclist-col-normal','10px'));
		rowObj.appendChild(insertCell('Dx4', 'dx4lbl',1,0,'doclist-col-normal','6%'));
		rowObj.appendChild(insertCell('Visit Type', 'stslbl',1,0,'doclist-col-normal',((dontShowCharges)?'12%':'10%')));
		rowObj.appendChild(insertCell('Reference', 'reflbl',1,0,'doclist-col-normal',((dontShowCharges)?'13%':'10%')));
		rowObj.appendChild(insertCell('', 'emlbl',1,0,'doclist-col-normal','2%'));
		var testbody1=document.createElement('tbody');		
		testbody1.id=rowid+'_main';
		testbody1.appendChild(rowObj);
		testtable.appendChild(testbody1);		
	}
	if(getServiceid()==-1)
	setRemovedRow(rowid.substring(rowid.indexOf('_')+1, rowid.length));
	else
	setRemovedRow(1);
	var rowObj=document.createElement('tr');
	rowObj.style.height="30px";
	var dxloader=document.createElement("img" );
	dxloader.src="../../../images/pointer.gif";
	dxloader.title="Load dx from assessment";
	dxloader.style.cursor='pointer';
	if(!isFullysetteledService){
		dxloader.onclick=function(){
			loadDXInfo(rowid);
		}
	}
	var serviceDxLoader=document.createElement("img" );
	serviceDxLoader.src="../../../images/arrow_blue.gif";
	serviceDxLoader.title="Load previous visit dx code";
	serviceDxLoader.style.cursor='pointer';
	if(!isFullysetteledService){
		serviceDxLoader.onclick=function(){
			loadDXInfoFromService(rowid);
		}
	}
	
	var deleteservice=document.createElement("img" );
	deleteservice.src="../../../images/close.gif"
	deleteservice.id='deleteservice_'+rowid;
	deleteservice.style.cursor='pointer';
	deleteservice.title='Delete';
	if(!isFullysetteledService){
	 	deleteservice.onclick=function(){
			var cpt=document.getElementById('CPTtxt_'+rowid).value;
			var isSaved=document.getElementById('CPTtxt_'+rowid).getAttribute("issaved");
			if(getServiceid()==-1 && isSaved=='0')
			{
			if(isSaved=='0'){
			delRemovedRow(rowid.substring(rowid.indexOf('_')+1, rowid.length));
	 		if(cpt!=-1 && Trim(cpt)!='' && cpt!='&nbsp;'){ 		
			 	document.getElementById('servicegrid').removeChild(document.getElementById(rowid));
			 	}
			 	}
			 else
			    alert("This service can't be removed as it is already saved >>>>>>>>  !");	
			}
			
			if(isSaved=='1')
			  deleteService(rowid);
			 //alert("This service can't be removed as it is already saved !");
			 	
		}	
	}
	openMultipleService();
	 var tempTab=document.createElement('table');
	    var tempTabBody= document.createElement('tbody');
	    var tempTr= document.createElement('tr');
	    var tempTd= document.createElement('td');
	    tempTd.height='10px';
	    tempTd.width='10px';
	    tempTd.bgColor='#000000';
        tempTd.title='Fully Settled Service';
        tempTr.appendChild(tempTd);
        tempTabBody.appendChild(tempTr);  
        tempTab.appendChild(tempTabBody);
	
	var td=document.createElement('td');
	td.className='bottomsidebordertd';
	//td.style.width='10px';
	if(!isFullysetteledService)
		td.appendChild(deleteservice);
	else{
		td.appendChild(tempTab);
		/*		td.bgColor='#000000';
		td.title='Fully Settled Service';*/
	}
		
	rowObj.appendChild(td);
	rowObj.style.height='25px';	
	
	if(getServiceid()==-1)
	rowObj.appendChild(sr_createCell('DOStxt_'+rowid,9,'generaltextbox',getCurrentDate(rowid),'bottomsidebordertd','text',getCurrentDate(rowid),-1,'',1));
	else
	rowObj.appendChild(sr_createCell('DOStxt_'+rowid,9,'generaltextbox',model.dos,'bottomsidebordertd','text',model.dos,-1,'',1));
	
	var cptData='',mod1Data='',mod2Data='',mod3Data='',mod4Data='',hospAdmitTimehrs='',hospAdmitTimemins='',hospAdmitTimesecs='',hospDisTimehrs='',hospDisTimemins='',hospDisTimesecs='',unitData='',chargeData='',copayData='',paymentData='';
	var dx1Data='',dx2Data='',dx3Data='',dx4Data='',refData='',chekNoData='',comData='',rluData='',spDx='',medN="",dosagestring="";
	var dx5Data='',dx6Data='',dx7Data='',dx8Data='',dx9Data='',dx10Data='',dx11Data='',dx12Data='',dostoData='',cptdesc='',dxSys='';
	var dx5to20Data='',dx1Desc='',dx2Desc='',dx3Desc='',dx4Desc='',dx5Desc='',dx6Desc='',dx7Desc='',dx8Desc='',dx9Desc='',dx10Desc='';
	var dx11Desc='',dx12Desc='',dx13Desc='',dx14Desc='',dx15Desc='',dx16Desc='',dx17Desc='',dx18Desc='',dx19Desc='',dx20Desc='',invalidstatusreason='';
	var startingIndex=0;		
	var endingIndex=0;		
	var serviceStatus = 1;//for rule engine;
	if(serviceData!=null)
	 {
	 dostoData=serviceData.dosto;
	 cptData=serviceData.cptcode;
	 mod1Data=serviceData.mod1;
	 unitData=serviceData.units;
	 mNDos=serviceData.dosto;
	 chargeData=setFormattedCurrency(serviceData.charges,CURR_SYM);
	 copayData=setFormattedCurrency(serviceData.copay,CURR_SYM);
	 paymentData=setFormattedCurrency(serviceData.payments,CURR_SYM);
	 dx1Data=serviceData.dx1;
	 dx2Data=serviceData.dx2;
	 dx3Data=serviceData.dx3;
	 dx4Data=serviceData.dx4;
	 dx5Data=serviceData.dx5;
	 dx6Data=serviceData.dx6;
	 dx7Data=serviceData.dx7;
	 dx8Data=serviceData.dx8;
	 dx9Data=serviceData.dx9;
	 dx10Data=serviceData.dx10;
	 dx11Data=serviceData.dx11;
	 dx12Data=serviceData.dx12;
	 dxSys=serviceData.dxsystem;
	 hospAdmitTimehrs=serviceData.hospadmittimehrs;
	 hospAdmitTimemins=serviceData.hospadmittimemins;
	 hospAdmitTimesecs=serviceData.hospadmittimesecs;
	 hospDisTimehrs=serviceData.hospdistimehrs;
	 hospDisTimemins=serviceData.hospdistimemins;
	 hospDisTimesecs=serviceData.hospdistimesecs;
	 dx1Desc=serviceData.dx1desc;dx2Desc=serviceData.dx2desc;dx3Desc=serviceData.dx3desc;dx4Desc=serviceData.dx4desc;dx5Desc=serviceData.dx5desc;dx6Desc=serviceData.dx6desc;dx7Desc=serviceData.dx7desc;
	 dx8Desc=serviceData.dx8desc;dx9Desc=serviceData.dx9desc;dx10Desc=serviceData.dx10desc;dx11Desc=serviceData.dx11desc;dx12Desc=serviceData.dx12desc;dx13Desc=serviceData.dx13desc;dx14Desc=serviceData.dx14desc;
	 dx15Desc=serviceData.dx15desc;dx16Desc=serviceData.dx16desc;dx17Desc=serviceData.dx17desc;dx18Desc=serviceData.dx18desc;dx19Desc=serviceData.dx19desc;dx20Desc=serviceData.dx20desc;

	 dx5to20Data=serviceData.dx5+','+serviceData.dx6+','+serviceData.dx7+','+serviceData.dx8+','+serviceData.dx9+','+serviceData.dx10+','+serviceData.dx11+','+serviceData.dx12+','+serviceData.dx13+','+serviceData.dx14+','+serviceData.dx15+','+serviceData.dx16+','+serviceData.dx17+','+serviceData.dx18+','+serviceData.dx19+','+serviceData.dx20;
	 serviceStatus = serviceData.servicestatus; //for rule engine		
	 invalidstatusreason=serviceData.invalidstatusreason; //for rule engine		
	 /*medicalNecessityDesc=serviceData.medicaldesc;		
		medicalNecessityType=serviceData.medicaltype		
		medicalNecessityDx=serviceData.medicaldiagnosis;*/
	 var tempDxData=dx5to20Data.split(',');
	 for(var i=0;i<tempDxData.length;i++)
		 {
		 	if(tempDxData[i]=="" && tempDxData[i+1]==""){
		 		dx5to20Data=dx5to20Data.split(',',i);
		 		i=tempDxData.length;
		 	}
		 }
	 mod2Data=serviceData.mod2;
	 mod3Data=serviceData.mod3;
	 mod4Data=serviceData.mod4;
	 refData=serviceData.tif_ref;
	 chekNoData=serviceData.checkno;
	 comData=serviceData.scomments;
	 cptdesc = serviceData.cptdesc;
	 rluData=serviceData.rlu_claim;
	 spDx=serviceData.spdx;
	 medN=serviceData.mednotes;
	 dosagestring=serviceData.dosage;
	 }
	var validservice = document.createElement("img");    //for rule engine		
	validservice.style.marginLeft='-16px';		
	validservice.id = 'validservice_' + rowid;		
	validservice.style.cursor = 'pointer';		
	validservice.style.display = 'none';		
	validservice.title = 'Status';		
	/*var ststd = document.createElement('td');		
	ststd.className = 'bottomsidebordertd';		
	ststd.appendChild(validservice);		
	rowObj.appendChild(ststd);*/   //for rule engine
	//rowObj.appendChild(sr_createCell('dosto_'+rowid,2,'generaltextbox',dostoData,'bottomsidebordertd','text',dostoData,-1,'',1));
	var cptCell=sr_createCell('CPTtxt_'+rowid,6,'generaltextbox',cptData,'bottomsidebordertd','text',cptData,-1,'',1);
	 /*if(getServiceid()!=-1)
	  cptCell.firstChild.setAttribute("cpttype",serviceData.cpttype);*/
	//----------------For Multiple services----------------------		
	var multiEachPanel = document.createElement("div");		
	multiEachPanel.id = 'multivalidservice_' + rowid;			
	multiEachPanel.className="multipleServiceEachPanel";		
	multiEachPanel.setAttribute("style","margin-top: 5px;");		
	var informationHolderDiv=document.createElement("div");		
	informationHolderDiv.className="informationShowingDiv";		
//	var mnlId="medical_necessity_link_"+rowid;		
	var dataTable=document.createElement("table");		
	dataTable.style.height="100%";		
	dataTable.style.width="100%";		
	var dataTableRow1=document.createElement("tr");		
	var dataTableCol1=document.createElement("td");		
	var dataTableCol2=document.createElement("td");		
	var dataTableCol3=document.createElement("td");		
	var dataTableCol4=document.createElement("td");		
	dataTableCol4.style.width="5%";		
	dataTableCol3.style.width="22%";		
	var dataTableSpan1=document.createElement("span");		
	dataTableSpan1.className="eachMultiPanelLabel";		
	dataTableSpan1.innerHTML=cptCell.firstChild.value+" - Service Invalid Reason"; 		
	var selectedDxLabel=document.createElement("label");		
	selectedDxLabel.id="selected_Dx_value_"+rowid;		
	selectedDxLabel.className="eachMultiPanelLabel selectedCodeLbl";		
	var dataTableUTag=document.createElement("u");		
	dataTableUTag.id="medical_necessity_link_"+rowid;		
	dataTableUTag.className="eachPanemMedicalNecessity";		
	dataTableUTag.innerHTML="View Medical Necessity";		
	dataTableUTag.style.display="none";		
	dataTableUTag.setAttribute("isDxLoaded_"+rowid,"false");		
	var dataTableSpan2=document.createElement("span");		
	dataTableSpan2.className="eachMultiPanelLabel minusContent";		
	dataTableSpan2.innerHTML="_";		
	dataTableCol1.appendChild(dataTableSpan1);		
	dataTableCol2.appendChild(selectedDxLabel);		
	dataTableCol3.appendChild(dataTableUTag);		
	dataTableCol4.appendChild(dataTableSpan2);		
	dataTableRow1.appendChild(dataTableCol1);		
	dataTableRow1.appendChild(dataTableCol2);		
	dataTableRow1.appendChild(dataTableCol3);		
	dataTableRow1.appendChild(dataTableCol4);		
	var dataTable2Col1=document.createElement("td");		
	dataTable2Col1.colSpan="4";		
	dataTable2Col1.appendChild(informationHolderDiv);		
	var dataTableRow2=document.createElement("tr");		
	dataTableRow2.id="inormationRow_"+rowid;		
	dataTableRow2.style.display="table-row";		
//	dataTableRow2.style.width="99%";		
	dataTableRow2.appendChild(dataTable2Col1);		
	dataTable.appendChild(dataTableRow1);		
	dataTable.appendChild(dataTableRow2);		
	dataTableSpan2.onclick=function(){		
		if(dataTableSpan2.innerHTML=="+"){		
			dataTableSpan2.innerHTML="_";		
			dataTableSpan2.className="eachMultiPanelLabel minusContent";		
			document.getElementById("inormationRow_"+rowid).style.display="table-row";		
		}else{		
			dataTableSpan2.innerHTML="+";		
			document.getElementById("inormationRow_"+rowid).style.display="none";		
			dataTableSpan2.className="eachMultiPanelLabel expandFont";		
		}		
	}		
//	var problemInfo="<table style='width:100%;height:100%;'><tr><td><span class='eachMultiPanelLabel'>"+cptCell.firstChild.value+" - Service Invalid Reason </span></td><td><u id='"+mnlId+"' class='eachPanemMedicalNecessity' style='display:none;'>View Medical Necessity</u></td><td><span id=expandBtn"+rowid+" class='eachMultiPanelLabel expandFont'>+</span></td></tr><tr colspan='3'></tr></table>"		
	multiEachPanel.appendChild(dataTable);		
	var multipanelRow=document.createElement('tr');		
	var multipanelColumn=document.createElement('td');		
	multipanelColumn.appendChild(multiEachPanel);		
	multipanelRow.appendChild(multipanelColumn);		
	//----------------For Multiple services----------------------
	  if(serviceData!=null){
		  if(getServiceid()!=-1)
			  cptCell.firstChild.setAttribute("cpttype",serviceData.cpttype);
		  
	   cptCell.firstChild.setAttribute("issaved",'1');
	   cptCell.firstChild.title=cptdesc;
	   ruleenginealert=0; //for rule engine		
		if (serviceStatus == 0) { //for rule engine		
			ruleenginealert=1; //for rule engine		
//			document.getElementById("valcpt").style.display="block";		
			cptCell.firstChild.style.color = "red"; //for rule engine		
			validservice.style.display = 'none';		
			validservice.src = "../../../images/Alert.gif"; //for rule engine		
			validservice.setAttribute("reason",invalidstatusreason) //for rule engine		
					
			validservice.onclick = function() { //for rule engine		
				medicalNecessityDesc=serviceData.medicaldesc;		
				medicalNecessityType=serviceData.medicaltype;		
				medicalNecessityDx=serviceData.medicaldiagnosis;		
				showHideEvents(true);				//for rule engine		
				var  bodytableObj; //for rule engine		
				bodytableObj = document.createElement("table"); //for rule engine		
				foottableObj = document.createElement("div"); //for rule engine		
				foottableObj.style.display="none";		
				foottableObj.id="diagnosisCodesShowing";		
				/*var serviceDiv = document.createElement("div"); //for rule engine		
				var iframe = document.getElementById('serviceStatusIFrame');		
				var divElement="<div id='serviceStatusDiv' style='display: none;width:100%;height:100%'></div>";		
				alert(">>>>>>>>>document.getElementById>>>>>>>>>>>>>>>"+window.frames['serviceStatusIFrame']);		
				var innerDoc = (iframe.contentDocument) ? iframe.contentDocument : iframe.contentWindow.document;		
				alert(">>>>>>>>>>>innerDoc>>>>>>>>>"+innerDoc);*/		
//				innerDoc.body.innerHTML=divElement;		
				var mainSCDiv= document.getElementById("serviceStatusDiv"); //for rule engine		
//				var mainSCDiv =innerDoc.getElementById("serviceStatusDiv")		
//				var mainSCDiv = iframe1.document.getElementById("serviceStatusDiv");  //for rule engine		
				var headerBar=createHeadger(cptCell.firstChild.value,rowid);		
				gen_newPopUpAttachment(mainSCDiv,headerBar, bodytableObj,foottableObj); //for rule engine		
				mainSCDiv.className="mainDivStyles";		
				var dDiv = mainSCDiv.firstChild; //for rule engine		
				bodytableObj.cellSpacing = "3px"; //for rule engine		
				bodytableObj.cellPadding = "3px"; //for rule engine		
				bodytableObj.id="resonInfoShowing";		
				var statusrowObj = bodytableObj.insertRow(-1); //for rule engine		
				tmpSchild = document.createElement("div"); //for rule engine		
				tmpSchild.id = "shortcut_operations";  //for rule engine		
				temptable = document.createElement("table");  //for rule engine		
				temptable.id = "operations_table";  //for rule engine		
				var res = this.getAttribute("reason");   //for rule engine		
				var res1=res.substring(1,res.length-1).split(",");		
				for(var z=0;z<res1.length;z++)  //for rule engine		
					{   //for rule engine		
					temptr = temptable.insertRow(-1);		
					tempspan = document.createElement("span");  //for rule engine		
					tempspan.className = "label-class";  //for rule engine		
					var tr=document.createElement("tr");  //for rule engine		
					tr.innerHTML= (z+1)+'. '+res1[z];  //for rule engine		
					tr.className="checkboxLabelStyles";		
					tempspan.appendChild(tr) ;  //for rule engine		
					appendTdItem(tempspan, temptr, -1); 		
					//alert(">>>"+res1[z]);		
					 //for rule engine		
					}   //for rule engine		
				tmpSchild.appendChild(temptable);  //for rule engine		
				cellObj = appendTdItem(tmpSchild, statusrowObj, -1);   //for rule engine		
				foottableObj.style.display = "inline-block";   //for rule engine		
//				statusrowObj = foottableObj.insertRow(-1);  //for rule engine		
				foottableObj.style.width="100%";		
				/*foottableObj.style.backgroundColor = "#CCCCCC";		
				foottableObj.style.height = "400px";		
				foottableObj.style.overflowX = "hidden";		
				foottableObj.style.overflowY = "scroll";		
				foottableObj.style.textAlign="center";*/		
//				var diagnosisInfo=createInformationData(medicalNecessityDesc,medicalNecessityType,medicalNecessityDx);		
				startingIndex=0;		
				if(medicalNecessityDx.length==0){		
					document.getElementById("medical_necessity_link").style.display="none";		
					document.getElementById("processingTable").style.display="none";		
//					foottableObj.innerHTML=headerBar;		
				}else{		
					document.getElementById("medical_necessity_link").style.display="block";		
					foottableObj.innerHTML="";		
					splitString=medicalNecessityDx.split(",");		
					totalCount=splitString.length;		
					if(totalCount>20){		
						endingIndex=20;							
					}else{		
						endingIndex=totalCount;		
					}		
					document.getElementById("medical_necessity_link").setAttribute("onclick","requestToGetDxDescription("+startingIndex+","+endingIndex+","+mNDos+")");		
				}		
//				cellObj = insertTdItem(diagnosisInfo,foottableObj.insertRow(0),0);		
//				mainSCDiv.setAttribute("style","height:90%;width:90%;left:5%;top:5%;background-color:#F7F7F7;");		
				showStatusPopup(true);   //for rule engine		
						
			
			}   //for rule engine		
			//---------For Multiple Services-------------------------		
			multibodytableObj.appendChild(multipanelRow);		
			medicalNecessityDesc=serviceData.medicaldesc;		
			medicalNecessityType=serviceData.medicaltype;		
			medicalNecessityDx=serviceData.medicaldiagnosis;		
			var temptableToload = document.createElement("table");  //for rule engine		
			temptableToload.id = "operations_table";  //for rule engine		
			var res1=invalidstatusreason.substring(1,invalidstatusreason.length-1).split(",");		
			for(var z=0;z<res1.length;z++)  //for rule engine		
			{   //for rule engine		
				temptr = temptableToload.insertRow(-1);		
				tempspan = document.createElement("span");  //for rule engine		
				tempspan.className = "label-class";  //for rule engine		
				var tr=document.createElement("tr");  //for rule engine		
				tr.innerHTML= (z+1)+'. '+res1[z];  //for rule engine		
				tr.className="checkboxLabelStyles infLblStyle";		
				tempspan.appendChild(tr) ;  //for rule engine		
				appendTdItem(tempspan, temptr, -1); 		
			}		
			informationHolderDiv.appendChild(temptableToload);		
			if(medicalNecessityDx.length==0){		
				document.getElementById("medical_necessity_link_"+rowid).style.display="none";		
			}else{		
				document.getElementById("medical_necessity_link_"+rowid).style.display="block";		
				if(medicalNeeded.length==0){		
					medicalNeeded=rowid;		
				}else{		
					medicalNeeded=medicalNeeded+","+rowid;		
				}		
				dataTableUTag.onclick=function(){		
					document.getElementById("multiPanelFirstScroller").style.display="none";		
					multifoottableObj1.style.display="block";		
					document.getElementById("LMRPPopLabel").innerHTML=serviceData.medicaldesc;		
					multiDxProcess(true);		
					currentlySelectedRow=rowid;		
					if(dataTableUTag.getAttribute("isDxLoaded_"+rowid)=="true"){		
						document.getElementById("multipleProcessDiv").style.display="none";		
						var rowidSplit=rowid.split("_");		
						var endIndx=document.getElementById("medical_necessity_link_"+rowid).getAttribute("e_location_"+rowid);		
						var totIndx=document.getElementById("medical_necessity_link_"+rowid).getAttribute("t_location_"+rowid);		
						document.getElementById("mutilpnaelDxinfo").innerHTML=mNSDXLoadedAry[rowidSplit[1]].value;		
						if(selectedDxInfo[rowidSplit[1]]!=undefined || selectedDxInfo[rowidSplit[1]]!=null){		
							document.getElementById(selectedDxInfo[rowidSplit[1]].dxCode+"_"+rowid).checked = true;		
						}		
						if((parseInt(endIndx)==(parseInt(totIndx)-1))||(parseInt(endIndx)==parseInt(totIndx))){		
							document.getElementById("multiDxMore").style.display="none";		
						}else{		
							document.getElementById("multiDxMore").style.display="block";		
						}		
					}else{		
						dataTableUTag.setAttribute("isDxLoaded_"+rowid,"true");		
						document.getElementById("mutilpnaelDxinfo").innerHTML="";		
						getMedicalDxCodes(serviceData.serviceid,rowid,mNDos,serviceData.medicaldiagnosis);		
					}		
				}		
			}		
			//---------For Multiple Services-------------------------		
		} else {   //for rule engine		
			validservice.remove();   //for rule engine		
		}		
	   
	   cptCell.firstChild.setAttribute("serviceid",serviceData.serviceid);
	   }
	   else{
	   cptCell.firstChild.setAttribute("issaved",'0');
	   cptCell.firstChild.title="XXX";
	   cptCell.firstChild.setAttribute("serviceid",'-1');
	   }
	 rowObj.appendChild(cptCell);
	rowObj.appendChild(sr_createCell('Mod1txt_'+rowid,3,'generaltextbox',mod1Data,'bottomsidebordertd','text',mod1Data,-1,'',1));
	rowObj.appendChild(sr_createCell('Unitstxt_'+rowid,3,'generaltextbox',unitData,'bottomsidebordertd','text',unitData,-1,'',1));
	ttd = sr_createCell('Chargestxt_'+rowid,11,'generaltextboxrightaligned',chargeData,'bottomsidebordertd','text',chargeData,-1,'',1)
	if(dontShowCharges)
		ttd.style.display = "none";
	rowObj.appendChild(ttd);
	rowObj.appendChild(sr_createCell('Copaytxt_'+rowid,7,'generaltextboxrightaligned',copayData,'bottomsidebordertd','text',copayData,-1,'',1));
	rowObj.appendChild(sr_createCell('Paymentstxt_'+rowid,11,'generaltextboxrightaligned',paymentData,'bottomsidebordertd','text',paymentData,-1,'',1));	
	var dx=document.createElement('td');
	dx.nowrap=true;
	dx.style.width='10px';
	var dxtab=document.createElement('table');
	var dxtabbody=document.createElement('tbody');
	var dxtrow=document.createElement('tr');
	var loadprev=document.createElement("img" );
	loadprev.title="Load previous row dx code";
	loadprev.style.cursor='pointer';
	loadprev.src="../../../images/next4.gif";
	if(!isFullysetteledService){
		loadprev.onclick=function(){
			loadDXFromPreviousRow(rowid);   //model.rowid   
		}
	}
	var loaddxpicker=document.createElement("img" );
	loaddxpicker.src="../../../images/icd9.png";
	loaddxpicker.title="Load dx picker";
	loaddxpicker.style.width="18";
	loaddxpicker.style.cursor='pointer';
	var id23=model.rowid;
	if(!isFullysetteledService){
		loaddxpicker.onclick=function(){
			createDxPicker(id23);
		}
	}
	
	var loaddx10picker=document.createElement("img" );
	loaddx10picker.src="../../../images/icd10.png";
	loaddx10picker.title="Load dx 10 picker";
	loaddx10picker.style.width="18";
	loaddx10picker.id=model.rowid;
	loaddx10picker.style.cursor='pointer';
	loaddx10picker.onclick=function(){
		createICD10Picker(id23,1);
	}
	
	var loaddsmpicker=document.createElement("img" );
	loaddsmpicker.src="../../../images/blue14x14/Picker.png";
	loaddsmpicker.title="Load DSM5 picker";
	loaddsmpicker.style.width="18";
	loaddsmpicker.id=model.rowid;
	loaddsmpicker.style.cursor='pointer';
	loaddsmpicker.onclick=function(){
		createICD10Picker(id23,2);
	}
	var tu6=document.createElement('td');
	tu6.appendChild(loaddsmpicker);
	var tu=document.createElement('td');
	tu.appendChild(serviceDxLoader);
	dxtrow.appendChild(tu);	
	tu=document.createElement('td');
	tu.appendChild(dxloader);
	dxtrow.appendChild(tu);
	var tu1=document.createElement('td');
	tu1.appendChild(loadprev);
	dxtrow.appendChild(tu1);
	var tu3=document.createElement('td');
	tu3.appendChild(loaddxpicker);
	var tu4=document.createElement('td');
	tu4.appendChild(loaddx10picker);
	var tu5=document.createElement('td');
	var mapLabel=document.createElement('a');
	var textMap=textNode('Map');
	mapLabel.setAttribute("href","javascript:mapCrossWalk('map_"+model.rowid+"');");
	mapLabel.id='map_'+model.rowid;
	tu5.style.fontSize = "12px";
	mapLabel.appendChild(textMap);
	tu5.appendChild(mapLabel);
	dxtrow.appendChild(tu3);
	dxtrow.appendChild(tu4);
	if(defCodeSys=='2.16.840.1.113883.6.90.5')
	  dxtrow.appendChild(tu6);
	dxtrow.appendChild(tu5);
	dxtabbody.appendChild(dxtrow);
	dxtab.appendChild(dxtabbody);
	dx.appendChild(dxtab);
	
	dx.className='bottomsidebordertd';
	rowObj.appendChild(dx);
	
	rowObj.appendChild(sr_createCell('DX1txt_'+rowid,5,'generaltextbox',dx1Data,'bottomsidebordertd','text',dx1Data,model.rowid+'~1','',1));
	
	var dxmove1=document.createElement("img" );
	dxmove1.src="../../../images/rotate.gif";
	if(!isFullysetteledService){
		dxmove1.onclick=function(){
			swapDx(model.rowid,1);
		}
	}
	var dxmovetd1=document.createElement('td');
	dxmovetd1.style.width='10px';
	dxmovetd1.appendChild(dxmove1);
	dxmovetd1.className='bottomsidebordertd';
	//rowObj.appendChild(dxmovetd1);
	//rowObj.appendChild(insertCell(dx2Data, 'DX2txt_'+rowid,2,0,'bottomsidebordertd','35px',dx2Data));
	rowObj.appendChild(sr_createCell('DX2txt_'+rowid,5,'generaltextbox',dx2Data,'bottomsidebordertd','text',dx2Data,model.rowid+'~2','',1));
	var dxmove2=document.createElement("img" );
	dxmove2.src="../../../images/rotate.gif";
	if(!isFullysetteledService){
		dxmove2.onclick=function(){
			swapDx(model.rowid,2);
		}
	}
	var dxmovetd2=document.createElement('td');
	dxmovetd2.style.width='10px';
	dxmovetd2.appendChild(dxmove2);
	dxmovetd2.className='bottomsidebordertd';
	//rowObj.appendChild(dxmovetd2);
	
	//rowObj.appendChild(insertCell(dx3Data, 'DX3txt_'+rowid,2,0,'bottomsidebordertd','35px',dx3Data));
	rowObj.appendChild(sr_createCell('DX3txt_'+rowid,5,'generaltextbox',dx3Data,'bottomsidebordertd','text',dx3Data,model.rowid+'~3','',1));
	
	var dxmove3=document.createElement("img" );
	dxmove3.src="../../../images/rotate.gif";
	if(!isFullysetteledService){
		dxmove3.onclick=function(){
			swapDx(model.rowid,3);
		}
	}
	var dxmovetd3=document.createElement('td');
	dxmovetd3.style.width='10px';
	dxmovetd3.appendChild(dxmove3);
	dxmovetd3.className='bottomsidebordertd';
	//rowObj.appendChild(dxmovetd3);
	rowObj.appendChild(sr_createCell('DX4txt_'+rowid,5,'generaltextbox',dx4Data,'bottomsidebordertd','text',dx4Data,model.rowid+'~4','',1));
	
	/*if(selectPool.get(11)==null)
	rowObj.appendChild(sr_createCell('Statuscmb_'+rowid,15,'dropdn generaltextbox','Submit Status','bottomsidebordertd','combo','-1',11,'',1));
	else
	rowObj.appendChild(sr_createCell('Statuscmb_'+rowid,15,'dropdn generaltextbox',getValueFromPool(model.submitStatus, 11),'bottomsidebordertd','combo',model.submitStatus,11,'',1));
*/
	if(selectPool.get(10)==null) 
	rowObj.appendChild(sr_createCell('VisitTypecmb_'+rowid,15,'dropdn generaltextbox','None','bottomsidebordertd','combo',-1,10,'',1));
	else
	rowObj.appendChild(sr_createCell('VisitTypecmb_'+rowid,15,'dropdn generaltextbox',getValueFromPool(model.visittype, 10),'bottomsidebordertd','combo',model.visittype,10,'',1));
	
	rowObj.appendChild(sr_createCell('TifReftxt_'+rowid,11,'generaltextbox',refData,'bottomsidebordertd','text',refData,-1,'',1));
	var downpointer=document.createElement("img" );
	downpointer.tabIndex=1;
	downpointer.src="../../../images/down1.gif"
	downpointer.border=0;
	downpointer.title='Detail';
	var lin=document.createElement("a");
	lin.id='downlink_'+rowid;
	lin.setAttribute("href","javascript:showTable('"+rowid+"');");
	lin.appendChild(downpointer);
	var td=document.createElement('td');
	if(serviceData!=null)
	 td.className='bottomsidebordertdbackground';
	else
	 td.className='bottomsidebordertd';
	td.style.width='10px';
	td.appendChild(lin);
	rowObj.appendChild(td);
	
	var testbody=document.createElement('tbody');		
	testbody.id=rowid;			
	testbody.name="activerow";
	testbody.onclick=function(){
		activerowid=this.id;
	}
	testbody.appendChild(rowObj);		
	var othertable=document.createElement('table');
	othertable.className='tableStyleNoBorder';
	var otherbody=document.createElement('tbody');
	othertable.appendChild(otherbody);
	othertable.style.display='none';
	othertable.style.width="99%";
	othertable.setAttribute("name","tableStyleNoBorder");
	othertable.id='others_'+rowid;
	var otherrow = document.createElement('tr');
	otherrow.style.height='5px';
	var totcell=document.createElement('td');
	totcell.colSpan="12";
	otherrow.appendChild(totcell);
	otherbody.appendChild(otherrow);
	otherrow = document.createElement('tr');
    otherrow.style.height='25px';		
	//otherrow.appendChild(insertCellSpl('','emptylbl_'+rowid,1,0,'othertddata','2%',1));
	otherrow.appendChild(insertCellSpl('Rate Plan','costplanlbl_'+rowid,1,0,'othertddata','10%',1));
	otherrow.appendChild(sr_createCell('CostPlancmb_'+rowid,12,'dropdn generaltextboxwhite','None','databordertd','combo','-1',12,'8%',1));
	if(paymentGroup==1){
	otherrow.appendChild(insertCellSpl('Pmt.Grp.','costplanlbl_'+rowid,1,0,'othertddata','5%',1));
	otherrow.appendChild(sr_createCell('PaymentGroupcmb_'+rowid,10,'dropdn generaltextbox','None','databordertd','combo','-1',41,'8%',1));
	}
	/*else{
	otherrow.appendChild(insertCellSpl('','emptylbl_'+rowid,1,0,'othertddata','2%',1));
	}*/
	otherrow.appendChild(insertCellSpl('How Paid','costplanlbl_'+rowid,1,0,'othertddata','10%','1',1));
	otherrow.appendChild(sr_createCell('HowPaidcmb_'+rowid,10,'dropdn generaltextboxwhite','None','databordertd','combo','-1',13,'8%',1));
	//if(paymentGroup==0)
	// otherrow.appendChild(insertCellSpl('','emptylbl_'+rowid,1,0,'othertddata','2%',1));
	otherrow.appendChild(insertCellSpl('Check No.','costplanlbl_'+rowid,1,0,'othertddata','4%',1));
	otherrow.appendChild(sr_createCell('Checktxt_'+rowid,4,'generaltextboxwhite',chekNoData,'databordertd','text',chekNoData,-1,'4%','1'));
	//otherrow.appendChild(insertCellSpl('','emptylbl_'+rowid,1,0,'othertddata','3%',1));
	otherrow.appendChild(insertCellSpl('Authorization','costplanlbl_'+rowid,1,0,'othertddata','80px',1,'10%','1'));
	if(getServiceid()==-1)
	otherrow.appendChild(sr_createCell('Authcmb_'+rowid,33,'dropdn generaltextboxwhite','None','databordertd','combo','-1',-1,'9%','1'));
	else
	otherrow.appendChild(sr_createCell('Authcmb_'+rowid,33,'dropdn generaltextbox','None','databordertd','combo',model.authorizationId,6,'9%','1'));
	//otherrow.appendChild(insertCellSpl('','emptylbl_'+rowid,1,0,'othertddata','2%',1));
	otherbody.appendChild(otherrow);
	otherrow = document.createElement('tr');
	otherrow.style.height='5px';
	totcell=document.createElement('td');
	totcell.colSpan="12";
	otherrow.appendChild(totcell);
	otherbody.appendChild(otherrow);
	
	var otherrow = document.createElement('tr');
	otherrow.className='select-tr';
	otherrow.style.height='25px';		
	//otherrow.appendChild(insertCellSpl('','emptylbl_'+rowid,1,0,'othertddata','2%',1));
	var commentLink=document.createElement("a");
	if(!isFullysetteledService){
		commentLink.setAttribute("href","javascript:newServicePayment(-1);");
	}
	var commentLabel=textNode('Enter Comment');
	commentLink.appendChild(commentLabel);
	var td2=document.createElement('td');
	td2.noWrap='true';
	td2.className='othertddata';
	td2.appendChild(commentLink);
	otherrow.appendChild(td2);
	otherrow.appendChild(insertCellSpl('Corrected Claim','emptylbl_'+rowid,1,0,'othertddata','4%',1));
	otherrow.appendChild(sr_createCell('SpDxcmb_'+rowid,12,'dropdn generaltextbox','None','databordertd','combo','-1',200,'9%','1'));
	//otherrow.appendChild(sr_createCell('SpDxtxt_'+rowid,2,'generaltextboxwhite',spDx,'databordertd','text',spDx,-1,'4%',1));
	otherrow.appendChild(insertCellSpl('Comments','commentslbl_'+rowid,1,0,'othertddata','10%','1',1));
	otherrow.appendChild(sr_createCell('Commentstxt_'+rowid,40,'generaltextboxwhite',comData,'databordertd','text',comData,-1,'10%','1'));
	//otherrow.appendChild(insertCellSpl('','emptylbl_'+rowid,1,0,'othertddata','3%',1));
	otherrow.appendChild(insertCellSpl('Billing Reason','billrealbl_'+rowid,1,0,'othertddata','9%',1));
	otherrow.appendChild(sr_createCell('billingReasoncmb_'+rowid,33,'dropdn generaltextboxwhite','None','databordertd','combo','-1',14,'10%','1'));
	//otherrow.appendChild(insertCellSpl('','emptylbl_'+rowid,1,0,'othertddata','2%',1));
	otherbody.appendChild(otherrow);

	otherrow = document.createElement('tr');
	otherrow.style.height='5px';
	totcell=document.createElement('td');
	totcell.colSpan="12";
	otherrow.appendChild(totcell);
	otherbody.appendChild(otherrow);
	
	var otherrow = document.createElement('tr');
	otherrow.style.height='20px';	
	//otherrow.appendChild(insertCellSpl('','emptylbl_'+rowid,1,0,'','2%',1));
	
	/*var medNoteLink=document.createElement("a");
	if(!isFullysetteledService)
		medNoteLink.setAttribute("href","javascript:uploadMedNotes("+getPatientId()+",1,'"+rowid+"');");
	var medNote=textNode('Upload Med Notes');
	medNoteLink.appendChild(medNote);
	var td=document.createElement('td');
	td.noWrap=true;
	td.className='othertddata';
	td.appendChild(medNoteLink);
	otherrow.appendChild(td);
	
	var medNoteViewLink=document.createElement("a");
	if(serviceData != null)
	 medNoteViewLink.setAttribute("href","javascript:viewMedNotes('"+serviceData.mednotes+"');");
	else
	medNoteViewLink.setAttribute("href","javascript:viewMedNotes('');");
	var medNoteVies=textNode('View Med Notes');
	medNoteViewLink.appendChild(medNoteVies);
	var td1=document.createElement('td');
	td1.noWrap=true;
	td1.colSpan="1";
	td1.className='othertddata';
	td1.appendChild(medNoteViewLink);
	otherrow.appendChild(td1);*/
	//Commented as per Vasanth
	//otherrow.appendChild(insertCellSpl('','emptylbl_'+rowid,1,0,'othertddata','2%',1));
	otherrow.appendChild(insertCellSpl('Status','commentslbl_'+rowid,1,0,'othertddata','5%',1));
	if(selectPool.get(11)==null)
		otherrow.appendChild(sr_createCell('Statuscmb_'+rowid,15,'dropdn generaltextbox','Submit Status','databordertd','combo','-1',11,'',1));
	else
		otherrow.appendChild(sr_createCell('Statuscmb_'+rowid,15,'dropdn generaltextbox',getValueFromPool(model.submitStatus, 11),'databordertd','combo',model.submitStatus,11,'',1));
	
	otherrow.appendChild(insertCellSpl('Mod2-Mod4','commentslbl_'+rowid,1,0,'othertddata','5%',1));
	otherrow.appendChild(sr_createCell('Mod2txt_'+rowid,2,'generaltextboxwhite',mod2Data,'databordertd','text',mod2Data,-1,'4%',1));
	//otherrow.appendChild(insertCellSpl('Mod3','commentslbl_'+rowid,1,0,'othertddata','4%',1));
	otherrow.appendChild(sr_createCell('Mod3txt_'+rowid,2,'generaltextboxwhite',mod3Data,'databordertd','text',mod3Data,-1,'4%',1));
	//otherrow.appendChild(insertCellSpl('Mod4','commentslbl_'+rowid,1,0,'othertddata','4%',1));
	otherrow.appendChild(sr_createCell('Mod4txt_'+rowid,2,'generaltextboxwhite',mod4Data,'databordertd','text',mod4Data,-1,'4%',1));
	//otherrow.appendChild(insertCellSpl('','emptylbl_'+rowid,1,0,'othertddata','3%',1));
	otherrow.appendChild(insertCellSpl('RLU','rlulbl_'+rowid,1,0,'othertddata','10%',1));
	otherrow.appendChild(sr_createCell('Rlutxt_'+rowid,35,'generaltextboxwhite',rluData,'databordertd','text',rluData,-1,'9%','1'));
	//otherrow.appendChild(insertCellSpl('','emptylbl_'+rowid,1,0,'othertddata','2%',1));
	otherbody.appendChild(otherrow);
	
	otherrow = document.createElement('tr');
	otherrow.style.height='5px';
	totcell=document.createElement('td');
	totcell.colSpan="13";
	otherrow.appendChild(totcell);
	otherbody.appendChild(otherrow);
	var otherrow = document.createElement('tr');
	otherrow.style.height='20px';	
	
	otherrow.appendChild(insertCellSpl('Hosp Admission Time','hospadmtime_'+rowid,1,0,'othertddata','5%',1));
	otherrow.appendChild(createEditCombo('admTimehrs_'+rowid,'4%','othertddata',hospAdmitTimehrs,rowid));
	otherrow.appendChild(createEditCombo('admTimemins_'+rowid,'4%','othertddata',hospAdmitTimemins));
	otherrow.appendChild(createEditCombo('admTimesecs_'+rowid,'4%','othertddata',hospAdmitTimesecs));
	otherrow.appendChild(insertCellSpl('Hosp Discharge Time','hospadmtime_'+rowid,1,0,'othertddata','5%',1));
	otherrow.appendChild(createEditCombo('disTimehrs_'+rowid,'4%','othertddata',hospDisTimehrs));
	otherrow.appendChild(createEditCombo('disTimemins_'+rowid,'4%','othertddata',hospDisTimemins));
	otherrow.appendChild(createEditCombo('disTimesecs_'+rowid,'4%','othertddata',hospDisTimesecs));
	
	otherbody.appendChild(otherrow);
	otherrow = document.createElement('tr');
	otherrow.style.height='5px';
	totcell=document.createElement('td');
	totcell.colSpan="12";
	otherrow.appendChild(totcell);
	otherbody.appendChild(otherrow);
	
	var otherrow = document.createElement('tr');
	otherrow.style.height='20px';	
	//otherrow.appendChild(insertCellSpl('','emptylbl_'+rowid,1,0,'','2%',1));
	//otherrow.appendChild(insertCellSpl('','emptylbl_'+rowid,1,0,'othertddata','2%',1));
	otherrow.appendChild(insertCellSpl('DOS TO','dostolbl'+rowid,1,0,'othertddata','5%',1));
	if(serviceData==null){	
		otherrow.appendChild(sr_createCell('dosto_'+rowid,2,'generaltextboxwhite',dostoData,'databordertd','text',dostoData,-1,'4%',1));
	}else{
		var dosToCell = sr_createCell('dosto_'+rowid,2,'generaltextboxwhite',dostoData,'databordertd','text',dostoData,-1,'4%',1);
		dosToCell.firstChild.title=model.scomments;
		dosToCell.firstChild.setAttribute("readonly","true");
		dosToCell.firstChild.style.color = "#996666";
		dosToCell.firstChild.onfocus = function(){
			this.blur();
		}
		otherrow.appendChild(dosToCell);
	}
/*
	otherrow.appendChild(insertCellSpl('Visit Type','commentslbl_'+rowid,1,0,'othertddata','5%',1));
	if(selectPool.get(10)==null) 
	otherrow.appendChild(sr_createCell('VisitTypecmb_'+rowid,15,'dropdn generaltextboxwhite','None','databordertd','combo',-1,10,'',1));
	else
	otherrow.appendChild(sr_createCell('VisitTypecmb_'+rowid,15,'dropdn generaltextboxwhite',getValueFromPool(model.visittype, 10),'databordertd','combo',model.visittype,10,'',1));
*/
	/*otherrow.appendChild(insertCellSpl('','emptylbl_'+rowid,1,0,'othertddata','2%',1));
	otherrow.appendChild(insertCellSpl('','emptylbl_'+rowid,1,0,'othertddata','2%',1));*/
	//otherrow.appendChild(insertCellSpl('','emptylbl_'+rowid,1,0,'othertddata','2%',1));
	/*otherrow.appendChild(insertCellSpl('Dx5-Dx8','commentslbl_'+rowid,1,0,'othertddata','5%',1));
	otherrow.appendChild(sr_createCell('D-X5txt_'+rowid,2,'generaltextboxwhite',dx5Data,'databordertd','text',dx5Data,-1,'4%',1));
	otherrow.appendChild(sr_createCell('D-X6txt_'+rowid,2,'generaltextboxwhite',dx6Data,'databordertd','text',dx6Data,-1,'4%',1));
	otherrow.appendChild(sr_createCell('D-X7txt_'+rowid,2,'generaltextboxwhite',dx7Data,'databordertd','text',dx7Data,-1,'4%',1));
	otherrow.appendChild(sr_createCell('D-X8txt_'+rowid,2,'generaltextboxwhite',dx8Data,'databordertd','text',dx8Data,-1,'4%',1));
	otherrow.appendChild(insertCellSpl('','emptylbl_'+rowid,1,0,'othertddata','2%',1));
	otherrow.appendChild(insertCellSpl('','emptylbl_'+rowid,1,0,'othertddata','2%',1));*/
		
	var tdDX=document.createElement("td");
	var tdx=document.createElement("table");
	var tdxr=document.createElement("tr");
	var tdxd1=insertCellSpl('Dx5-Dx20','commentslbl_'+rowid,1,0,'othertddata','5%',1);
	
	var loaddxpicker=document.createElement("img" );
	loaddxpicker.src="../../../images/pinocular.gif";
	loaddxpicker.title="Load dx picker";
	loaddxpicker.style.cursor='pointer';
	loaddxpicker.onclick=function(){
		createDxPickerNew(rowid);    
	}
	var tuas=document.createElement('td');
	tuas.appendChild(loaddxpicker);
	tdxr.appendChild(tdxd1);
	tdxr.appendChild(tuas);
	tdx.appendChild(tdxr);
	tdDX.appendChild(tdx);
	
	otherrow.appendChild(tdDX);

	
	otherrow.appendChild(sr_createCell('D-X5-20txt_'+rowid,2,'generaltextboxwhite',dx5to20Data,'databordertd','text',dx5to20Data,-1,'4%',7));
	otherbody.appendChild(otherrow);
	
	var otherrow = document.createElement('tr');
	otherrow.style.height='5px';
	otherbody.appendChild(otherrow);
    var count=0;
    
	if(fieldData!=null)
	{
		for(var i=0;i<fieldData.length;i++)
		{
			count++;
			var tempvar='';
	       if(defaultAddFieldData!=null)
			{
				try{
				var fieldDefaultval=eval('defaultAddFieldData[0].'+fieldData[i].chargetabname);
				if (fieldDefaultval==undefined)
					tempvar='';
				else 
					tempvar=fieldDefaultval;
				}
				catch (E)
				{
					alert(E);
				}
			}
			else if(serviceData!=null)
			{
			var tempvar=eval('serviceData.'+fieldData[i].chargetabname);
			}
		if(i%5==0)
	    	{
	    	otherrow = document.createElement('tr');
	    	otherrow.style.height='25px';
	    	}
 if(fieldData[i].chargetabfieldtype=="combo")
		{
			var NdcLink=document.createElement("a");
			NdcLink.setAttribute("href","javascript:EditCPTLink();");
			//NdcLink.setAttribute("href","javascript:uploadMedNotes("+getPatientId()+",1,'"+rowid+"');");
			var NdcNote=textNode('NDC');
			NdcLink.appendChild(NdcNote);
			var td=document.createElement('td');
			td.noWrap=true;
			td.className='othertddata';
			td.appendChild(NdcLink);
			otherrow.appendChild(td);
		}
		else
		otherrow.appendChild(insertCellSpl(fieldData[i].chargetabdispname,'fielddata_'+rowid,1,0,'othertddata','4%',1));
		//otherrow.appendChild(sr_createCell(fieldData[i].chargetabname+"_"+rowid,5,'generaltextboxwhite',"",'databordertd','text',"",-1,'',1));
		/*if(fieldData[i].chargetabfieldtype=="combo")
		{
			otherrow.appendChild(sr_createCell(fieldData[i].chargetabname+"_"+rowid,2,'dropdn generaltextbox',tempvar,'databordertd','combo','-1',rowid,'8%',1));
		}
		else*/
		if(fieldData[i].chargetabfieldtype=="date")

		{
			var popupcalen=document.createElement("img" );
			popupcalen.tabIndex=0;
			popupcalen.src="../../../images/blue14x14/Calendar.png"
			popupcalen.border=0;
			popupcalen.title='Select Date';
			popupcalen.setAttribute("onclick","popUpCalendar(this,document.getElementById(\""+fieldData[i].chargetabname+"_"+rowid+"\"),\"mm/dd/yyyy\");");
		
			//otherrow.appendChild(fieddataTD);
		    if(count%5==0)
			var newtd=sr_createCell(fieldData[i].chargetabname+"_"+rowid,-99,'generaltextboxwhite',tempvar,'databordertd','text',tempvar,-1,'10%',1);
		    else
			
			var newtd=sr_createCell(fieldData[i].chargetabname+"_"+rowid,-99,'generaltextboxwhite',tempvar,'databordertd','text',tempvar,-1,'7%',1);
			newtd.appendChild(popupcalen);
			otherrow.appendChild(newtd);
			//otherrow.appendChild(sr_createCell(fieldData[i].chargetabname+"_"+rowid,5,'generaltextboxwhite',model.dx8,'databordertd','text',model.dx8,-1,'	',1));	
		}
else{
		    if(count%5==0)
		    	otherrow.appendChild(sr_createCell(fieldData[i].chargetabname+"_"+rowid,5,'generaltextboxwhite',tempvar,'databordertd','text',tempvar,-1,'10%',1));
		  else
			otherrow.appendChild(sr_createCell(fieldData[i].chargetabname+"_"+rowid,5,'generaltextboxwhite',tempvar,'databordertd','text',tempvar,-1,'7%',1));
			}
		
		if(i%5==4)
		{
		otherbody.appendChild(otherrow);
		otherrow = document.createElement('tr');
		otherrow.style.height='5px';
		otherbody.appendChild(otherrow);
		}
		}
		otherbody.appendChild(otherrow);
		otherrow = document.createElement('tr');
		otherrow.style.height='5px';
		otherbody.appendChild(otherrow);
	}
	//*************
	
	var rowObj=document.createElement('tr');
	rowObj.id='othersContainer_'+rowid;
	rowObj.style.height='0px';
	var celObj=document.createElement('td');
	celObj.colSpan='16';
	celObj.appendChild(othertable);
	rowObj.appendChild(celObj);
	testbody.appendChild(rowObj);	
	testtable.appendChild(testbody);
	setCurrentRowId(rowid);
	
	document.serviceinformation.appendChild(testtable);
	if(serviceStatus == 0){		
		document.getElementById("LMRPValidationAlert").style.display="block";		
	}
	addHiddenField(document.serviceinformation,'txtCPT_'+rowid);
	addHiddenField(document.serviceinformation,'txtDOS_'+rowid);
	addHiddenField(document.serviceinformation,'txtdosto_'+rowid);
	addHiddenField(document.serviceinformation,'txtMod1_'+rowid);
	addHiddenField(document.serviceinformation,'txtUnits_'+rowid);
	addHiddenField(document.serviceinformation,'txtCharges_'+rowid);
	addHiddenField(document.serviceinformation,'txtCopay_'+rowid);
	addHiddenField(document.serviceinformation,'txtPayments_'+rowid);
	addHiddenField(document.serviceinformation,'txtDX1_'+rowid);
	addHiddenField(document.serviceinformation,'txtDX2_'+rowid);
	addHiddenField(document.serviceinformation,'txtDX3_'+rowid);
	addHiddenField(document.serviceinformation,'txtDX4_'+rowid);
	addHiddenField(document.serviceinformation,'cmbStatus_'+rowid);
	addHiddenField(document.serviceinformation,'cmbOldStatus_'+rowid);
	addHiddenField(document.serviceinformation,'cmbServiceType_'+rowid);
	addHiddenField(document.serviceinformation,'txtTifRef_'+rowid);
	addHiddenField(document.serviceinformation,'txtMod2_'+rowid);
	addHiddenField(document.serviceinformation,'txtMod3_'+rowid);
	addHiddenField(document.serviceinformation,'txtMod4_'+rowid);
	addHiddenField(document.serviceinformation,'txtHospAdmTimehrs_'+rowid);
	addHiddenField(document.serviceinformation,'txtHospAdmTimemins_'+rowid);
	addHiddenField(document.serviceinformation,'txtHospAdmTimesecs_'+rowid);
	addHiddenField(document.serviceinformation,'txtHospDisTimehrs_'+rowid);
	addHiddenField(document.serviceinformation,'txtHospDisTimemins_'+rowid);
	addHiddenField(document.serviceinformation,'txtHospDisTimesecs_'+rowid);
	addHiddenFieldWithValue(document.serviceinformation,'txtDX5_'+rowid,dx5Data);
	addHiddenFieldWithValue(document.serviceinformation,'txtDX6_'+rowid,dx6Data);
	addHiddenFieldWithValue(document.serviceinformation,'txtDX7_'+rowid,dx7Data);
	addHiddenFieldWithValue(document.serviceinformation,'txtDX8_'+rowid,dx8Data);
	addHiddenFieldWithValue(document.serviceinformation,'txtDX9_'+rowid,dx9Data);
	addHiddenFieldWithValue(document.serviceinformation,'txtDX10_'+rowid,dx10Data);
	addHiddenFieldWithValue(document.serviceinformation,'txtDX11_'+rowid,dx11Data);
	addHiddenFieldWithValue(document.serviceinformation,'txtDX12_'+rowid,dx12Data);
	addHiddenField(document.serviceinformation,'txtDX13_'+rowid);
	addHiddenField(document.serviceinformation,'txtDX14_'+rowid);
	addHiddenField(document.serviceinformation,'txtDX15_'+rowid);
	addHiddenField(document.serviceinformation,'txtDX16_'+rowid);
	addHiddenField(document.serviceinformation,'txtDX17_'+rowid);
	addHiddenField(document.serviceinformation,'txtDX18_'+rowid);
	addHiddenField(document.serviceinformation,'txtDX19_'+rowid);
	addHiddenField(document.serviceinformation,'txtDX20_'+rowid);
	addHiddenFieldWithValue(document.serviceinformation,'txtDX1Desc_'+rowid,dx1Desc);
	addHiddenFieldWithValue(document.serviceinformation,'txtDX2Desc_'+rowid,dx2Desc);
	addHiddenFieldWithValue(document.serviceinformation,'txtDX3Desc_'+rowid,dx3Desc);
	addHiddenFieldWithValue(document.serviceinformation,'txtDX4Desc_'+rowid,dx4Desc);
	addHiddenFieldWithValue(document.serviceinformation,'txtDX5Desc_'+rowid,dx5Desc);
	addHiddenFieldWithValue(document.serviceinformation,'txtDX6Desc_'+rowid,dx6Desc);
	addHiddenFieldWithValue(document.serviceinformation,'txtDX7Desc_'+rowid,dx7Desc);
	addHiddenFieldWithValue(document.serviceinformation,'txtDX8Desc_'+rowid,dx8Desc);
	addHiddenFieldWithValue(document.serviceinformation,'txtDX9Desc_'+rowid,dx9Desc);
	addHiddenFieldWithValue(document.serviceinformation,'txtDX10Desc_'+rowid,dx10Desc);
	addHiddenFieldWithValue(document.serviceinformation,'txtDX11Desc_'+rowid,dx11Desc);
	addHiddenFieldWithValue(document.serviceinformation,'txtDX12Desc_'+rowid,dx12Desc);
	addHiddenFieldWithValue(document.serviceinformation,'txtDX13Desc_'+rowid,dx13Desc);
	addHiddenFieldWithValue(document.serviceinformation,'txtDX14Desc_'+rowid,dx14Desc);
	addHiddenFieldWithValue(document.serviceinformation,'txtDX15Desc_'+rowid,dx15Desc);
	addHiddenFieldWithValue(document.serviceinformation,'txtDX16Desc_'+rowid,dx16Desc);
	addHiddenFieldWithValue(document.serviceinformation,'txtDX17Desc_'+rowid,dx17Desc);
	addHiddenFieldWithValue(document.serviceinformation,'txtDX18Desc_'+rowid,dx18Desc);
	addHiddenFieldWithValue(document.serviceinformation,'txtDX19Desc_'+rowid,dx19Desc);
	addHiddenFieldWithValue(document.serviceinformation,'txtDX20Desc_'+rowid,dx20Desc);
	addHiddenFieldWithValue(document.serviceinformation,'txtDXCodeSystemId_'+rowid,dxSys);
	addHiddenField(document.serviceinformation,'cmbCostPlan_'+rowid);
	addHiddenField(document.serviceinformation,'cmbHowPaid_'+rowid);
	addHiddenField(document.serviceinformation,'txtCheck_'+rowid);
	addHiddenField(document.serviceinformation,'txtComments_'+rowid);
	addHiddenField(document.serviceinformation,'billingReason_'+rowid);
	addHiddenField(document.serviceinformation,'paymentGroup_'+rowid);
	addHiddenField(document.serviceinformation,'cmbAuth_'+rowid);
	addHiddenField(document.serviceinformation,'typeOfService_'+rowid);
	addHiddenField(document.serviceinformation,'txtRlu_'+rowid);
	addHiddenField(document.serviceinformation,'cmbSpDx_'+rowid);
	//addHiddenField(document.serviceinformation,'txtSpDxtxt_'+rowid);
	addHiddenField(document.serviceinformation,'medNotes_'+rowid);
	eval("document.serviceinformation.medNotes_"+rowid).value=medN;
	addHiddenField(document.serviceinformation,"txtDosageAmt_"+rowid);
	addHiddenField(document.serviceinformation,"txtDosageUnits_"+rowid);
	addHiddenField(document.serviceinformation,"txtDosage_"+rowid);
	addHiddenField(document.serviceinformation,"hdnCharges_"+rowid);

	if(fieldData!=null)
	{
		addHiddenField(document.serviceinformation,'txtanesthesia_timeline_'+rowid);
		for(var i=0;i<fieldData.length;i++)
		addHiddenField(document.serviceinformation,'txt'+fieldData[i].chargetabname+"_"+rowid);
	}

	//if(getServiceid() != -1)//getFormattedCurrency(chargeData,CURR_SYM)
	//{
	eval("document.serviceinformation.hdnCharges_" + rowid).value=(parseFloat(getFormattedCurrency(chargeData,CURR_SYM))+parseFloat(getFormattedCurrency(copayData,CURR_SYM)))/parseFloat(unitData);
	if(dosagestring!='')
	 {
	    var t1=dosagestring.substring(0,dosagestring.indexOf('~||~'));
		var t2=dosagestring.substring(dosagestring.indexOf('~||~')+4,dosagestring.length);
		var t3=t2.substring(0,t2.indexOf("-"));
		var t4=t2.substring(t2.indexOf("-")+1,t2.length);
		eval("document.serviceinformation.txtDosageAmt_" + rowid).value=t3;
		eval("document.serviceinformation.txtDosageUnits_" + rowid).value=t4;
		eval("document.serviceinformation.txtDosage_" + rowid).value=t1;
		}
	//}
	//document.getElementById('DOStxt_'+rowid).setAttribute('value', defaultdate);
if(serviceData == null)
	adjustLinkDiv();
}
function close(){
	document.getElementById('addNewCase').style.display='none';
	fetchSelectFromServer(7);
}
function createSpace(width){
	var space=document.createElement('div');
	space.style.width=width;
	return space;
}

function setDxList(dxinfo){
	var dxdata = dxinfo.split("^^~~^^");
	var addflg = 0;
	for (var i=0; i<dxdata.length; i++){
		addflg = 0;
		if (dxdata[i] != ""){
			for (var j=0; j<selectedDx.length; j++){
				if (dxdata[i] == selectedDx[j])
					addflg = 1;
			}
			if (addflg == 0)
				selectedDx[selectedDx.length] = dxdata[i];
		}
	}
	//parent.frames['servicedxlist'].loadDxInfo();
}
var currentSerid;
function loadDXInfo(serid){
/*if(dxReceived==0)
{
fetchSelectFromServer(5);
var dx=eval("("+selectPool.get(5)+")");
try{
if(dx[0].hsp001 !='')
 selectedDx[0]=dx[0].hsp001;
if(dx[0].hsp002 !='')
 selectedDx[1]=dx[0].hsp002;
if(dx[0].hsp003 !='')
 selectedDx[2]=dx[0].hsp003;
if(dx[0].hsp004 !='')
 selectedDx[3]=dx[0].hsp004;
}catch(e){}   
dxReceived=1;
}
*/
/* amiya*/
var callback={
	success:sr_callSuccess45,
	failure:sr_callFailure45,
	progress:sr_callProgress45
	}
currentSerid=serid;
if (document.getElementById('CPTtxt_'+ serid).value != ''){
	//if(selectedDx.length==0)
	 //{
           getAjaxDataFromServer("../GetDxAction.Action","patientId="+getPatientId()+"&encounterId="+ENCOUNTER_ID+"&fromSuperbill=1",false,callback);  
	  /*}
	  else {
	    for(var k=1;k<=4;k++)
	  	document.getElementById('DX'+k+'txt_'+serid).value='';
	    for (var i=0; i<selectedDx.length; i++){
			switch(i){
				case 0:
					document.getElementById('DX1txt_'+serid).value=selectedDx[i];
					break;
				case 1:
					document.getElementById('DX2txt_'+serid).value=selectedDx[i];
					break;
				case 2:
					document.getElementById('DX3txt_'+serid).value=selectedDx[i];
					break;
				case 3:
					document.getElementById('DX4txt_'+serid).value=selectedDx[i];
				break;
				default:
					break;
			}
		}
	  }	*/
		}
	else{
		alert("Please select a CPT !");
	}
}
function loadDXInfoFromService(serid){
if(dxReceived==0)
{
dxReceived=1;
fetchSelectFromServer(5);
var dx=eval("("+selectPool.get(5)+")");
try{
var obj=dx[0];
var dxCount=dx[1].dxcount;
dxsystem=dx[1].dxsystem;
if(dxCount<=4){
var n=0;
for(var i=0;n<4 && i<dxCount ;i++){
  if(dx[0][i]!=''){
    selectedDx[n++]=dx[0][i];
	  setDirty();
  }
} 
setDx(serid);
}else{
	if(document.getElementById('CPTtxt_'+ serid).value != '')
		drawPreviousVisitDxCode(dxCount,dx,serid);
	else{
		alert("Please select a CPT !");
	}
}
}catch(e){}
}
dxReceived=0;
}
function setDx(serid){
	if (document.getElementById('CPTtxt_'+ serid).value != ''){
	if(selectedDx.length==0)
	   alert("No previous visit dx code found !");
	  else {
		clearDxFields(serid);
		document.getElementById('txtDXCodeSystemId_'+serid).value=dxsystem;
		dxsystem='';
	    for(var k=1;k<=4;k++)
	  	document.getElementById('DX'+k+'txt_'+serid).value='';
	    for (var i=0; i<selectedDx.length; i++){
			switch(i){
				case 0:
					document.getElementById('DX1txt_'+serid).value=selectedDx[i];
					break;
				case 1:
					document.getElementById('DX2txt_'+serid).value=selectedDx[i];
					break;
				case 2:
					document.getElementById('DX3txt_'+serid).value=selectedDx[i];
					break;
				case 3:
					document.getElementById('DX4txt_'+serid).value=selectedDx[i];
				break;
				default:
					break;
			}
		}
		setDxDescription(serid,891);
	  }	
		}
	else{
		alert("Please select a CPT !");
	}
}
function drawPreviousVisitDxCode(no,data,serid){
selectedPrevDxCount=0;
selectedPrevDx="";
var inH="<table class='othertddata' cellspacing=0 cellpadding=0 border=0 width='100%' style='padding-left:0px;'>";
inH+="<tr><td colspan=2>";
inH+="<div style='overflow:auto;height:170px;'>";
inH+="<table class='generaltextbox' cellspacing=0 cellpadding=0 border=0 width='100%' style='padding-left:0px;'>";
inH+="<tr align=center><td><b>Dx</b></td><td><b>Description</b></td></tr>";
for(var i=0;i<no;i++){
 inH+="<tr onmouseover='javascript:changeColor(this,1);' onmouseout='javascript:changeColor(this,2);' onclick='javascript:changeColor(this,3);'><td>"+data[0][i]+"</td><td>"+getDxDescription(data[0][i],891)+"</td></tr>";
}
inH+="</table></div></td></tr>";
inH+="<tr><td width='43%'>&nbsp;</td><td>";
inH+="<a onclick='this.blur();' class='btn onbtn' href=\"javascript:sr_loadPreviousVisitFormPrompt('"+serid+"');\"  title='Loads selected diagnosis codes'><b><b><b>OK</b></b></b></a>";
inH+="</td></tr></table>";

var obj1=new DialogBox("div2","Setting Page",300,100,400,200);
obj1.setContentBackgroundColor("#F1F0F1");
	obj1.setContentForegroundColor("black");
	obj1.setTitleBackgroundColor("#c3d9ff");
	obj1.setTitleForegroundColor("white");
	obj1.setPosition("15%","50%","35%","220px");
	obj1.setInnerHeight("200px");
	obj1.setContent(inH);
	obj1.setTitle("Previous Visit Dx &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;");
	obj1.setBorderSize(5);
	obj1.setZindex(9);
	obj1.dialogBox();

var preVisitdx = document.getElementById("dragableDivNew");
	document.getElementById("div2").setAttribute("isdragable","1");
	preVisitdx.onmouseover=function(){
		preVisitdx.style.cursor="move";
	}

	preVisitdx.onmousedown=function(e){
		down('div2',e);
	}
	preVisitdx.onmouseup=function(){
		preVisitdx.style.cursor="auto";
		preVisitdx.style.zIndex = (z)?z:0;
		document.onmousemove = null;
	}
	
}


function changeColor(obj,x){
	if(x==1){
	 if(obj.style.backgroundColor!='red')
	   obj.style.backgroundColor="#c3d9ff";
	}
	else if(x==2){
	  if(obj.style.backgroundColor!='red')
		obj.style.backgroundColor="rgb(241, 240, 241)";
	}

	else if(x==3){
	 if(obj.style.backgroundColor=='red'){
	   obj.style.backgroundColor="rgb(241, 240, 241)";
	   removeSelectedDx(Trim(obj.firstChild.innerHTML));   
		}else{
		if(selectedPrevDx.split(',').length < 4){
		  obj.style.backgroundColor="red";
		  recordSelectedDx(Trim(obj.firstChild.innerHTML));
		 } 
		else
		  alert("Maximum four dx !");  
	   }
	}
}

function recordSelectedDx(dx){
	if(selectedPrevDx.indexOf(dx) == -1){
	 if(selectedPrevDx=='')
	  selectedPrevDx=dx;
	   else
	     selectedPrevDx+=','+dx;
	}   
}
function removeSelectedDx(dx){
	if(selectedPrevDx.indexOf(dx) > -1){
	var dxArray=selectedPrevDx.split(',');
	selectedPrevDx="";
	for(var i=0;i<dxArray.length;i++){
	   if(dxArray[i]!=dx){
	    if(selectedPrevDx=='')
	      selectedPrevDx=dxArray[i];
	       else
	          selectedPrevDx+=','+dxArray[i];
	  }
	}
	}
}
function sr_loadPreviousVisitFormPrompt(serid){
	if(Trim(selectedPrevDx)!=''){
	var dxSelected=selectedPrevDx.split(',');
	var n=0;
	selectedDx=new Array();
	for(var i=0;n<4 && i<dxSelected.length ;i++){
	  if(dxSelected[i]!='')
	    selectedDx[n++]=dxSelected[i];
	}
	setDx(serid);
	closeDialog('div2',false,0);
	}else{
		alert("Please select atleast one DX");
	}
}


var sr_callSuccess45=function(responseObject)
{
var res=eval(responseObject.responseText);
var tempdx5to20Data="";
/*selectedDx[0]=parent.getDxForSuperBill(0);
selectedDx[1]=parent.getDxForSuperBill(1);
selectedDx[2]=parent.getDxForSuperBill(2);
selectedDx[3]=parent.getDxForSuperBill(3);*/
res=eval(res);

selectedDx[0]="";
selectedDx[1]="";
selectedDx[2]="";
selectedDx[3]="";
selectedDx[4]="";
selectedDx[5]="";
selectedDx[6]="";
selectedDx[7]="";
selectedDxDesc[0]="";
selectedDxDesc[1]="";
selectedDxDesc[2]="";
selectedDxDesc[3]="";
selectedDxDesc[4]="";
selectedDxDesc[5]="";
selectedDxDesc[6]="";
selectedDxDesc[7]="";
var dxCount=0;
var isdifferentdx=false;
var index=0;
for(var i=0;i<res.length ;i++)
{
if(res[i].dxcode!=''){
 var dos=new Date(document.getElementById('DOStxt_'+currentSerid).value);
 var icd10StartDate=new Date('10/01/2015');
 if(dos<icd10StartDate && res[i].dxcodesystem=='2.16.840.1.113883.6.90'){
	 dxsystem=res[i].dxcodesystem;
 }
 else if(dos>=icd10StartDate && res[i].dxcodesystem=='2.16.840.1.113883.6.104'){
		dxsystem=res[i].dxcodesystem;
 }else if(dos>=icd10StartDate && res[i].dxcodesystem=='2.16.840.1.113883.6.90'){
	 var tempdata=new Array();
	 tempdata=res[i].dxcode;
	 nomappingneededcodes[index++]=tempdata;
 }else if(dos<icd10StartDate && res[i].dxcodesystem!='2.16.840.1.113883.6.90'){
	 var tempdata=new Array();
	 tempdata=res[i].dxcode;
	 nomappingneededcodes[index++]=tempdata;
 }
 selectedDx[dxCount]=res[i].dxcode;
 selectedDxDesc[dxCount]=res[i].dxdesc;
 dxCount++;
}
 /*if(i==0)
   selectedDx[0]=res[0].dxcode;
  else if(i==1) 
   selectedDx[1]=res[1].dxcode;
   else if(i==2) 
   selectedDx[2]=res[2].dxcode;
   else if(i==3) 
   selectedDx[3]=res[3].dxcode;*/
}
if(selectedDx.length==0)
	   alert("No dx in assessment available !");
	  else {
		  clearDxFields(currentSerid);
		  document.getElementById('txtDXCodeSystemId_'+currentSerid).value=dxsystem;
		  dxsystem='';
		  for(var k=1;k<=8;k++){
	    	if(k<5)
	    	document.getElementById('DX'+k+'txt_'+currentSerid).value='';
	    	else
			document.getElementById('D-X5-20txt_'+currentSerid).value='';
	    }

	  	for (var i=0; i<selectedDx.length; i++){
	  		switch(i){
				case 0:
					document.getElementById('DX1txt_'+currentSerid).value=selectedDx[i];
					document.getElementById('DX1txt_'+currentSerid).title=selectedDxDesc[i];
					document.getElementById('txtDX1Desc_'+currentSerid).value=selectedDxDesc[i];
					break;
				case 1:
					document.getElementById('DX2txt_'+currentSerid).value=selectedDx[i];
					document.getElementById('DX2txt_'+currentSerid).title=selectedDxDesc[i];
					document.getElementById('txtDX2Desc_'+currentSerid).value=selectedDxDesc[i];
					break;
				case 2:
					document.getElementById('DX3txt_'+currentSerid).value=selectedDx[i];
					document.getElementById('DX4txt_'+currentSerid).title=selectedDxDesc[i];
					document.getElementById('txtDX3Desc_'+currentSerid).value=selectedDxDesc[i];
					break;
				case 3:
					document.getElementById('DX4txt_'+currentSerid).value=selectedDx[i];
					document.getElementById('DX4txt_'+currentSerid).title=selectedDxDesc[i];
					document.getElementById('txtDX4Desc_'+currentSerid).value=selectedDxDesc[i];
					break;
				case 4:
					tempdx5to20Data=tempdx5to20Data+selectedDx[i]+',';
					document.getElementById('txtDX5_'+currentSerid).value=selectedDx[i];
					document.getElementById('txtDX5Desc_'+currentSerid).value=selectedDxDesc[i];
					break;
				case 5:
					tempdx5to20Data=tempdx5to20Data+selectedDx[i]+',';
					document.getElementById('txtDX6_'+currentSerid).value=selectedDx[i];
					document.getElementById('txtDX6Desc_'+currentSerid).value=selectedDxDesc[i];
					break;
				case 6:
					tempdx5to20Data=tempdx5to20Data+selectedDx[i]+',';
					document.getElementById('txtDX7_'+currentSerid).value=selectedDx[i];
					document.getElementById('txtDX7Desc_'+currentSerid).value=selectedDxDesc[i];
					break;
				case 7:
					tempdx5to20Data=tempdx5to20Data+selectedDx[i]+',';
					document.getElementById('txtDX8_'+currentSerid).value=selectedDx[i];
					document.getElementById('txtDX8Desc_'+currentSerid).value=selectedDxDesc[i];
					break;
				case 8:
					tempdx5to20Data=tempdx5to20Data+selectedDx[i]+',';
					document.getElementById('txtDX9_'+currentSerid).value=selectedDx[i];
					document.getElementById('txtDX9Desc_'+currentSerid).value=selectedDxDesc[i];
					break;
				case 9:
					tempdx5to20Data=tempdx5to20Data+selectedDx[i]+',';
					document.getElementById('txtDX10_'+currentSerid).value=selectedDx[i];
					document.getElementById('txtDX10Desc_'+currentSerid).value=selectedDxDesc[i];
					break;
				case 10:
					tempdx5to20Data=tempdx5to20Data+selectedDx[i]+',';
					document.getElementById('txtDX11_'+currentSerid).value=selectedDx[i];
					document.getElementById('txtDX11Desc_'+currentSerid).value=selectedDxDesc[i];
					break;
				case 11:
					tempdx5to20Data=tempdx5to20Data+selectedDx[i]+',';
					document.getElementById('txtDX12_'+currentSerid).value=selectedDx[i];
					document.getElementById('txtDX12Desc_'+currentSerid).value=selectedDxDesc[i];
					break;
				case 12:
					tempdx5to20Data=tempdx5to20Data+selectedDx[i]+',';
					document.getElementById('txtDX13_'+currentSerid).value=selectedDx[i];
					document.getElementById('txtDX13Desc_'+currentSerid).value=selectedDxDesc[i];
					break;
				case 13:
					tempdx5to20Data=tempdx5to20Data+selectedDx[i]+',';
					document.getElementById('txtDX14_'+currentSerid).value=selectedDx[i];
					document.getElementById('txtDX14Desc_'+currentSerid).value=selectedDxDesc[i];
					break;
				case 14:
					tempdx5to20Data=tempdx5to20Data+selectedDx[i]+',';
					document.getElementById('txtDX15_'+currentSerid).value=selectedDx[i];
					document.getElementById('txtDX15Desc_'+currentSerid).value=selectedDxDesc[i];
					break;
				case 15:
					tempdx5to20Data=tempdx5to20Data+selectedDx[i]+',';
					document.getElementById('txtDX16_'+currentSerid).value=selectedDx[i];
					document.getElementById('txtDX16Desc_'+currentSerid).value=selectedDxDesc[i];
					break;	
				case 16:
					tempdx5to20Data=tempdx5to20Data+selectedDx[i]+',';
					document.getElementById('txtDX17_'+currentSerid).value=selectedDx[i];
					document.getElementById('txtDX17Desc_'+currentSerid).value=selectedDxDesc[i];
					break;
				case 17:
					tempdx5to20Data=tempdx5to20Data+selectedDx[i]+',';
					document.getElementById('txtDX18_'+currentSerid).value=selectedDx[i];
					document.getElementById('txtDX18Desc_'+currentSerid).value=selectedDxDesc[i];
					break;
				case 18:
					tempdx5to20Data=tempdx5to20Data+selectedDx[i]+',';
					document.getElementById('txtDX19_'+currentSerid).value=selectedDx[i];
					document.getElementById('txtDX19Desc_'+currentSerid).value=selectedDxDesc[i];
					break;
				case 19:
					tempdx5to20Data=tempdx5to20Data+selectedDx[i];
					document.getElementById('txtDX20_'+currentSerid).value=selectedDx[i];
					document.getElementById('txtDX20Desc_'+currentSerid).value=selectedDxDesc[i];
					break;
				
				default:
					break;
			}
		}
	  	document.getElementById('D-X5-20txt_'+currentSerid).value=tempdx5to20Data;
		setDirty();
		var dos=new Date(document.getElementById('DOStxt_'+currentSerid).value);
		var icd10StartDate=new Date('10/01/2015')
		if((dos<icd10StartDate && document.getElementById('txtDXCodeSystemId_'+currentSerid).value=='2.16.840.1.113883.6.90' ) || (dos>=icd10StartDate && document.getElementById('txtDXCodeSystemId_'+currentSerid).value=='2.16.840.1.113883.6.104' ))
			setTimeout("saveServices('domapppings')",0);
	    /*for (var i=0; i<selectedDx.length; i++){
	     if(document.getElementById('DX1txt_'+currentSerid).value=='')
	       document.getElementById('DX1txt_'+currentSerid).value=selectedDx[i];
	      else if (document.getElementById('DX2txt_'+currentSerid).value=='')
	        document.getElementById('DX2txt_'+currentSerid).value=selectedDx[i];
	        else if (document.getElementById('DX3txt_'+currentSerid).value=='')
	          document.getElementById('DX3txt_'+currentSerid).value=selectedDx[i];
	          else if (document.getElementById('DX4txt_'+currentSerid).value=='')
	           document.getElementById('DX4txt_'+currentSerid).value=selectedDx[i];
		}*/
	  }	

}
var sr_callFailure45=function(responseObject){}
var sr_callProgress45=function(responseObject){}

function swapDx(serid,n){
var dx1,dx2,dx1Desc,dx2Desc;
setDirty();
switch(n){
case 1:
dx1=document.getElementById('DX1txt_'+serid).value;dx2=document.getElementById('DX2txt_'+serid).value;document.getElementById('DX1txt_'+serid).value=dx2;document.getElementById('DX2txt_'+serid).value=dx1;
dx1Desc=document.getElementById('DX1txt_'+serid).title;dx2Desc=document.getElementById('DX2txt_'+serid).title;document.getElementById('DX1txt_'+serid).title=dx2Desc;document.getElementById('DX2txt_'+serid).title=dx1Desc;
break;
case 2:
dx1=document.getElementById('DX2txt_'+serid).value;dx2=document.getElementById('DX3txt_'+serid).value;document.getElementById('DX2txt_'+serid).value=dx2;document.getElementById('DX3txt_'+serid).value=dx1;
dx1Desc=document.getElementById('DX2txt_'+serid).title;dx2Desc=document.getElementById('DX3txt_'+serid).title;document.getElementById('DX2txt_'+serid).title=dx2Desc;document.getElementById('DX3txt_'+serid).title=dx1Desc;
break;
case 3:
dx1=document.getElementById('DX3txt_'+serid).value;dx2=document.getElementById('DX4txt_'+serid).value;document.getElementById('DX3txt_'+serid).value=dx2;document.getElementById('DX4txt_'+serid).value=dx1;
dx1Desc=document.getElementById('DX3txt_'+serid).title;dx2Desc=document.getElementById('DX4txt_'+serid).title;document.getElementById('DX3txt_'+serid).title=dx2Desc;document.getElementById('DX4txt_'+serid).title=dx1Desc;
break;
}
}
	
function setChangeFlag(serid){
	setSaveFlag(1);
	if (serid == -100)
		frm.servicedata.value = serviceid;
	else{
		var serdata = (frm.servicedata.value).split("~");
		var addFlg = 0;
		for (var i=0; i < serdata.length; i++)
			if (serdata[i] == serid)
				addFlg = 1;
		if (addFlg == 0)
			frm.servicedata.value += serid + "~";
	}
}

function SE_hideDiv(evt){
	evt=getTarget(evt);
	if(evt.getAttribute('type')!=3)		
		document.getElementById('SE_garbageDiv').innerHTML='';
}

function insertComboCell(dataval,name,type,qryid,style,wdth,value){
var tdobj=document.createElement('td');
	tdobj.noWrap=true;
	tdobj.className=style;	
	if(inStr(name,'_')== -1)
		tdobj.align='center';
	if(wdth=='16%')
		tdobj.colSpan='2';
	tdobj.id=name;
	tdobj.name=name;	
	tdobj.style.width=wdth;
	tdobj.setAttribute('qryid', qryid);
	tdobj.setAttribute('type',type);
	if(type==3 || type==2)
		tdobj.tabIndex=1;
	tdobj.setAttribute('value',value);
	addEvent(tdobj,'focus',drawFromObj);
	
	var tBox=document.createElement('input');
	tBox.className="dropdn billingTextbox";
	tBox.value=dataval;
	tdobj.appendChild(tBox);
	return tdobj; 
}	

function createEditCombo(name,cellwidth,styleclassfortd,data){
	var values='[{"id":"-1","value":""},';
	if (name.indexOf('Timehrs') != -1) {
		for ( var i = 0; i <=24; i++) {
            if(i>9){
			var hrsData = '{"id":"' + i + 'hrs","value":"' + i+ '"},';
			values = values + hrsData;
            }else{
            	var hrsData = '{"id":"' + i + 'hrs","value":"0' + i+ '"},';
		        values = values + hrsData;

            }
		}
	} else if (name.indexOf('Timemins') != -1) {
		for ( var i = 0; i <=60; i++) {
			 if(i>9){
			var hrsData = '{"id":"' + i  + ',mins","value":"' + i + '"},';
			values = values + hrsData;
			 }else{
				 var hrsData = '{"id":"' + i  + ',mins","value":"0' + i + '"},';
					values = values + hrsData;
					 
			 }
		}
	} else if (name.indexOf('Timesecs') != -1) {
		for ( var i = 0; i <= 60; i++) {
            if(i>9){
			var hrsData = '{"id":"' + i  + ',secs","value":"' + i +  '"},';
			values = values + hrsData;
		}else{
			var hrsData = '{"id":"' + i  + ',secs","value":"0' + i + '"},';
			values = values + hrsData;
			
		}
		}
	}

	
    values=values+"]";
    //SCROLL_TOP='othersContainer_'+x.scrollTop;
    //document.getElementById('othersContainer_'+x)
    var ele="<input tabindex=1 class='dropdn billingTextbox' type='text' maxlength=10 size=9  id="+name+" optionvalue='-1' name="+name+" DivData="+values+" disableAutocomplete='true' autocomplete='off' onblur='cm_textOnBlur(this,event);' onclick='cm_newshowOrHideCommonCombo(this,event);setDirty();' onkeydown='cm_newshowcommoncombo(this,event);cm_getFocusedItemToDiv(this,event);' value='"+data+"'/>";
	 
	var tdObj=document.createElement('td');
	tdObj.style.width=cellwidth;
	tdObj.noWrap=true;
	tdObj.className=styleclassfortd;
	tdObj.style.paddingLeft="0";
	//tdObj.style.
	tdObj.innerHTML=ele;
	return tdObj
}


function insertCell(dataval,name,type,qryid,style,wdth,value){
    var tdobj=document.createElement('td');
	tdobj.noWrap=true;
	tdobj.className=style;	
	if(inStr(name,'_')== -1)
		tdobj.align='center';
	if(wdth=='16%')
		tdobj.colSpan='2';
	tdobj.id=name;
	tdobj.name=name;	
	tdobj.style.width=wdth;
	tdobj.setAttribute('qryid', qryid);
	tdobj.setAttribute('type',type);
	if(type==3 || type==2)
		tdobj.tabIndex=1;
	tdobj.setAttribute('value',value);
	//addEvent(tdobj,'click',setClickedCell);
	addEvent(tdobj,'focus',drawFromObj);
	var label=document.createTextNode(dataval);
	tdobj.appendChild(label);
	if(dataval=='CPT' && editDOS=='')
	{
	var dximg1=document.createElement('img');
	dximg1.src='../../../images/pinocular.gif';
	dximg1.title='CPT Picker';
	dximg1.style.cursor='pointer';
	addEvent(dximg1, 'click', createCptPicker);
	tdobj.appendChild(document.createTextNode(' '));
	tdobj.appendChild(dximg1);
	
	var dximg2=document.createElement('img');
	dximg2.src='../../../images/pinocular_red.gif';
	dximg2.title='CPT Picker to load multiple cpt';
	dximg2.style.cursor='pointer';
	addEvent(dximg2, 'click', createCptPicker_multiple);
	tdobj.appendChild(document.createTextNode(' '));
	tdobj.appendChild(dximg2);
	}
	if(name=='valcpt' && editDOS==''){		
		var validservice = document.createElement("img"); 		
		validservice.style.marginLeft='-16px';		
		validservice.id = 'validservice_head';		
		validservice.style.cursor = 'pointer';		
		validservice.style.display = 'none';		
		validservice.title = 'Status';		
		validservice.src = "../../../images/Validations/errors.gif";		
		validservice.onclick = function() {		
			onEventSetup();		
		}		
		addEvent(validservice, 'onclick',openMultipleService());		
		tdobj.appendChild(validservice);		
	}
	//tdobj.innerHTML=dataval;
		
	return tdobj; 
}
function insertCellSpl(dataval,name,type,qryid,style,wdth,merge,value){
	var tdobj=document.createElement('td');
	tdobj.noWrap='true';
	tdobj.className=style;
	tdobj.id=name;
	tdobj.name=name;	
	tdobj.colSpan=merge;
	if(type==3 || type==2)
		tdobj.tabIndex=2;
	tdobj.setAttribute('qryid', qryid);
	tdobj.setAttribute('type',type);
	tdobj.setAttribute('value',value);
	addEvent(tdobj,'focus',drawFromObj);		
	if(dataval=='' && type==2){
		tdobj.style.width=wdth;	
	}
	else if(dataval=='' && type==1 && wdth!='')
			tdobj.appendChild(createSpace(wdth));
	else{
		tdobj.innerHTML=dataval;	
		tdobj.style.width=wdth;	
	}	
	
	return tdobj; 
}
function showTable(x){
	var obj=document.getElementById('others_'+x);
	if (obj.style.display == 'none')
	{
		if(editDOS=='')
		document.getElementById('othersContainer_'+x).style.height=((document.all)?'130px':'90px');
		else
		document.getElementById('othersContainer_'+x).style.height=((document.all)?'170px':'150px');
		//document.getElementById('servicegrid').style.height='100%';
		obj.style.display = 'block';
		}
	else
	{
		obj.style.display = 'none';
		document.getElementById('othersContainer_'+x).style.height='0px';
		//document.getElementById('servicegrid').style.height='0px';
		}
}

function getResponseData(fileurl){
	if (window.ActiveXObject){
		var xmlhttpobj =  new ActiveXObject("Microsoft.XMLHTTP");
		xmlhttpobj.open( "GET", fileurl , false);
		try{
			xmlhttpobj.send(null);
		}catch(e){}	
		if(xmlhttpobj.readyState==4)
			return xmlhttpobj.responseText;
	}else if(document.implementation){
		var oXML=new XMLHttpRequest();
		oXML.open("GET",fileurl,false);
		try{	
			oXML.send(null);
		}catch(e){}		
		return oXML.responseText;
	}
}

function setDefaults(){
	var d = new Date();
	var curr_date = d.getDate();
	var curr_month = d.getMonth();
	curr_month++;
	var curr_year = d.getFullYear();
	if(defaultdate=='')
		defaultdate=curr_month + "/" + curr_date + "/" + curr_year;
}

function addHiddenField(formhandle,fieldname){
	var field1=document.createElement('input');
	field1.name=fieldname;
	field1.id=fieldname;
	field1.type='hidden';
	field1.value='';
	formhandle.appendChild(field1);
}

function addHiddenFieldWithValue(formhandle,fieldname,val){
	var field1=document.createElement('input');
	field1.name=fieldname;
	field1.id=fieldname;
	field1.type='hidden';
	field1.value=val;
	formhandle.appendChild(field1);
}
function addEvent(evtobj,evt,myFunction){
	if (evtobj.addEventListener) {
		evtobj.addEventListener (evt,myFunction ,false);
	} else if (evtobj.attachEvent) {
		evtobj.attachEvent ("on"+evt,myFunction);
	}
}
var prevName="";
var current="";
function drawFromObj(evt){
var t=evt;
	if(getTarget(evt).nodeName=="TD"){
	var name=getTarget(evt).name;
	//alert(name);
		//alert(checkForClickEvent(prevName,name));
	current=name;
	if(prevName!=name)
	{
	prevName=name;
	var id=getTarget(evt).getAttribute('qryid');
	if(getTarget(evt).getAttribute('type')==2)
		createTextBox(name,'psblinetextbox1');			
	if(getTarget(evt).getAttribute('type')==3 && id!=0)
		appendSelectOptions(name,id,evt);
		//getSelectBox(name,id,evt);
		
	}
}
}

function checkForClickEvent(prev,cur)
{
//var name=getTarget(evt).name.substr(0,getTarget(evt).name.length-2);
if(prev!='')
{
var cOBj1=document.getElementById(prev);
var cOBj2=document.getElementById(cur);
if(cOBj1.parentNode.rowIndex != cOBj2.parentNode.rowIndex)
 return false;
else if ( cOBj1.cellIndex+1 != cOBj2.cellIndex)
 return false;
else 
 return true; 
}
else
return true;
}
function getSelectBox(name,id,evt){	
	if(!selectPool.get(id)){
		//fetchSelectFromServer(id);
		var a=selectPool.get(id);
	}	
	else
		var a=selectPool.get(id);
	createSlectBox(a,name,evt);
}

function handleKeys(e){
	evt=getTarget(e);
	
	try{
		var KeyID = (window.event) ? event.keyCode : e.which;
		if(KeyID==83 &&e.altKey )
			{//saveServices();
			}			
		}
	catch(e){}
}
	function findPosX(obj,isScroll)
    {
		var curleft = 0;
		if(obj.offsetParent)
			while(1) 
			{
			  curleft += obj.offsetLeft;
			  if(!obj.offsetParent)
				break;
			  obj = obj.offsetParent;
			}
		else if(obj.x)
			curleft += obj.x;
		return ((isScroll)?(curleft-SE_SCROLL_LEFT):(curleft));
    }
 //Return y position of object
    function findPosY(obj,isScroll)
    {
		var curtop = 0;
		if(obj.offsetParent)
			while(1)
			{
			  curtop += obj.offsetTop;
			  if(!obj.offsetParent)
				break;
			  obj = obj.offsetParent;
			}
		else if(obj.y)
			curtop += obj.y;
		return ((isScroll)?(curtop-SE_SCROLL_TOP):(curtop));
	 }
	 
function focusDiv(obj,evt,isFocus,isEvent){
	if(isEvent){
		evt=(!evt)?event:evt;
		obj=getTarget(evt);
	}
	if(obj.className.indexOf("menuitem")!=-1){
		obj.className=(isFocus)?("menuitem menuitem-highlight"):("menuitem");
	}
}
function SE_clickedDiv(evt){
		evt=(!evt)?event:evt;
		evt=getTarget(evt);
		if(evt.className.indexOf("menuitem")!=-1){
			setData(evt,false);
		}
}
function createTableHeader(){
	var row=document.createElement('tr');
	for (var i = 0, j = arguments.length; i < j; i++) {
		var rowelement=document.createElement('th');
		rowelement.setAttribute("class",'tabheaddata');
		rowelement.setAttribute("className",'tabheaddata');
		rowelement.appendChild(textNode(arguments[i]));
		row.appendChild(rowelement);
	}
	return row;
}
function setServiceCPT(x,pos){serviceCPT[pos]=x;}
function getServiceCPT(type,pos){
	if(type==1)
		return serviceCPT;
	else
	return serviceCPT[pos];
}
function checkMoney( name, rowId, x){
	if (!name.value.match(/^\d*.{0,1}\d+$/)){
		alert("Invalid money data!");
		name.value="";
		name.focus();
		return;
	}
	//changeCharges(name, rowId, x);
}
function checkInteger( name, rowId, x){
	if (!name.value.match(/^\d+$/)){
		alert("Invalid integer data!");
		name.value="1";
		name.focus();
		return false;
	}
	
	// changeCharges(name, rowId, x);
}

function resetData(){
	//gstyle='';
	//PATIENT_ID="-1";
	rowcount=0;
	cnt=0;
	serviceCPT  = new Array();
	selectedCPT = new Array();
	var cell= document.serviceinformation;
	if ( cell.hasChildNodes() )	{
		while ( cell.childNodes.length >= 1 ){	cell.removeChild( cell.firstChild );}
	}
}
function createTextBox(name,styleclass){
	var txtbox=null, obj=null;
	txtbox=document.createElement('input');	
	obj=document.getElementById(name);
	var x=obj.innerHTML;
	if (x.indexOf('<input') == -1 )
	{
	obj.innerHTML='';	
	txtbox.tabIndex=1;
	txtbox.setAttribute('type','text');
	txtbox.setAttribute('name',name+'_t');
	txtbox.setAttribute('id',name+'_t');
	txtbox.style.width=obj.style.width;
	txtbox.style.height='18px';
	txtbox.className =styleclass;
	if(name.indexOf('Charge')>-1 || name.indexOf('Copay')>-1 || name.indexOf('Payment')>-1)
	{
	x=getFormattedCurrency(x,CURR_SYM);
	if(x=='')
	x='0';
	txtbox.setAttribute('value',parseFloat(x).toFixed(2));
	}
	  else
	txtbox.setAttribute('value',x);	
	tmprowid=parseInt(name.substring(name.length-1,name.length));	
	if(name.indexOf('CPT')>-1){					
		if(tmprowid>=rowcount-1 && getServiceid() == -1){			
			addEvent(txtbox, 'blur', createNextRow);
			//addEvent(txtbox, 'change', setValue);
			//addEvent(txtbox, 'keydown', moveNextCell);
			
		}
	else
	{
	    if(!document.all )
		addEvent(txtbox, 'keydown', setValToCell);
		else
		addEvent(txtbox, 'blur', setValToCellIE);
		
		//addEvent(txtbox, 'keydown', moveNextCell);
	}	
	}
	else if(name.indexOf('Charge')>-1 || name.indexOf('Copay')>-1 || name.indexOf('Payment')>-1){
		//addEvent(txtbox, 'change', function(event){changeChargeOnCopayChange(event);checkMoney( txtbox,name.substring(name.indexOf('_')+1,name.length),2);});	 	
		//addEvent(txtbox, 'keydown', moveNextCell);	 	
		//if(!document.all )
		//addEvent(txtbox, 'keydown', setValToCellIE);
		//else
		addEvent(txtbox, 'blur', setValToCellIE);
		//addEvent(txtbox, 'change', setValue);
	}
	else if(name.indexOf('Unit')>-1){
		//addEvent(txtbox, 'change', function(event){changeChargeOnCopayChange(event);checkInteger(txtbox,name.substring(name.indexOf('_')+1,name.length),0);});
	 	//if(!document.all )
	 	//{
	 	//addEvent(txtbox, 'change', setValue);
		//addEvent(txtbox, 'keydown', setValToCellIE);
		//}
		//else
		addEvent(txtbox, 'blur', setValToCellIE);
	 	
		//addEvent(txtbox, 'keydown', moveNextCell);
	}
	else if(name.indexOf('DOS') > -1 || name.indexOf('DOP') > -1)
	{
	    //addEvent(txtbox, 'keyup',formatDate);
	    addEvent(txtbox, 'keyup',formatDateLocal);
	    if(name.indexOf('defaultDOP') == 0 && !document.all)
	         addEvent(txtbox, 'blur',setDefaultDate);
	    if(name.indexOf('defaultDOP') == 0 && document.all)
	         addEvent(txtbox, 'blur',setDefaultDateIE);
	    /*if(name.indexOf('DOS') == 0 && !document.all)
	      addEvent(txtbox, 'keydown', setValToCell);
	    if(  name.indexOf('DOS') == 0 && document.all)*/
	      addEvent(txtbox, 'blur', setValToCellIE);
	}
	else{
	 	//if(!document.all ){
		//addEvent(txtbox, 'keydown', setValToCellIE);
		//addEvent(txtbox, 'change', setValue);
		//}
		//else
		addEvent(txtbox, 'blur', setValToCellIE);
	 	//addEvent(txtbox, 'keydown', moveNextCell);
	}
	obj.appendChild(txtbox);
	document.getElementById(name+'_t').focus();
 	//document.getElementById('SE_garbageDiv').focus();
	//document.getElementById(name+'_t').focus();
}	
}
var isClicked=0;
var clickedObj="";
function setClickedCell(evt)
{
try{
evt=getTarget(evt);
var clickedObj=(evt.name).substring(0,(evt.name).length-2);
isClicked=1;}catch(e){}
}

function changeChargeOnCopayChange(evt)
{
if(!document.all)
 setValue(evt);
evt=getTarget(evt);
var objname=(evt.name).substring(0,(evt.name).length-2);
if(objname.indexOf('Copaytxt') == 0)
{
var chargeObj=objname.substring(8,objname.length);
var obj=eval("document.serviceinformation.hdnCharges" + chargeObj);
var objNH=document.getElementById('Chargestxt'+chargeObj);
var objUnit=document.getElementById('Unitstxt'+chargeObj);
var unitVal=objUnit.getAttribute('value');
if(unitVal=='' || unitVal==' ')
unitVal='1';
var copay=getFormattedCurrency(evt.value,CURR_SYM);
if(copay=='' || copay==' ')
copay='0.00';
var val=(parseFloat(obj.value)*parseFloat(unitVal))-parseFloat(copay);
objNH.setAttribute('value',val);
objNH.innerHTML=setFormattedCurrency(parseFloat(val).toFixed(2),CURR_SYM);
}
else if(objname.indexOf('Unitstxt') == 0)
{
var chargeObj=objname.substring(8,objname.length);
var obj=eval("document.serviceinformation.hdnCharges" + chargeObj);
var objNH=document.getElementById('Chargestxt'+chargeObj);
var objCopay=document.getElementById('Copaytxt'+chargeObj);
var copay=getFormattedCurrency(objCopay.getAttribute('value'),CURR_SYM);
if(copay=='' || copay==' ')
copay='0.00';
var unitVal=evt.value;
if(unitVal=='' || unitVal==' ')
unitVal='1';
var val=(parseFloat(obj.value)*parseFloat(unitVal))-parseFloat(copay);
objNH.setAttribute('value',val);
objNH.innerHTML=setFormattedCurrency(parseFloat(val).toFixed(2),CURR_SYM);
}
}
var EvtFlag=false;
function setValToCell(evt){
if(evt.keyCode==9)
{
    var tmpEvt=evt;
	evt=getTarget(evt);	
	var objname=(evt.name).substring(0,(evt.name).length-2);
	var val=evt.value;
	var obj=document.getElementById(objname);
	if ( obj.hasChildNodes() )	{
		while ( obj.childNodes.length >= 1 ){obj.removeChild( obj.firstChild );}
	}
	if(objname.indexOf('Charge')>-1 || objname.indexOf('Copay')>-1 || objname.indexOf('Payment')>-1)
	{
	if(val=='')
	 val='0';
	 obj.innerHTML=setFormattedCurrency(parseFloat(val).toFixed(2),CURR_SYM);
	}
	else
	 obj.innerHTML=val;
	obj.setAttribute('value',val);
	selectNextCell(tmpEvt);
}	
}

function setValToCellIE(evt){
    var tmpEvt=evt;
	evt=getTarget(evt);	
	var objname=(evt.name).substring(0,(evt.name).length-2);	
	var val=evt.value;
	var obj=document.getElementById(objname);
	if ( obj.hasChildNodes() )	{
		while ( obj.childNodes.length >= 1 ){	obj.removeChild( obj.firstChild );}
	}
	if(objname.indexOf('Charge')>-1 || objname.indexOf('Copay')>-1 || objname.indexOf('Payment')>-1)
	{
	if(val=='')
	val='0';	
	var tnode=document.createTextNode(setFormattedCurrency(parseFloat(val).toFixed(2),CURR_SYM));
	obj.appendChild(tnode);
	//obj.innerHTML=setFormattedCurrency(parseFloat(val).toFixed(2),CURR_SYM);
	}
	else
	{
	var tnode=document.createTextNode(val);
	obj.appendChild(tnode);
	}
	//obj.innerHTML=val;
	obj.setAttribute('value',val);
	addEvent(obj,'focus',drawFromObj);
    selectNextCell(tmpEvt);
}


function setValue(evt)
{
var tmpEvt=evt;
	evt=getTarget(evt);	
	var objname=(evt.name).substring(0,(evt.name).length-2);	
	var val=evt.value;
	var obj=document.getElementById(objname);	
	if(objname.indexOf('Charge')>-1 || objname.indexOf('Copay')>-1 || objname.indexOf('Payment')>-1)
	{
	if(val=='')
	val='0';	
	obj.innerHTML=setFormattedCurrency(parseFloat(val).toFixed(2),CURR_SYM);
	}
	else
	obj.innerHTML=val;
	obj.setAttribute('value',val);
}

function selectSecond()
{
var obj=null;
var Pobj=document.getElementById(current);
var colNo=Pobj.cellIndex;
var rowobj=Pobj.parentNode;	
var rowNo=rowobj.rowIndex;
var tabobj=Pobj.parentNode.parentNode.parentNode;

while(obj==null || obj.tabIndex < 1 )
 {
 
if(colNo <20)
colNo++;
else
{colNo=0;rowNo++;
}
 if(document.all )
 obj=tabobj.rows[rowNo].cells[colNo];
 if(!document.all )
obj=tabobj.rows[rowNo].cells[colNo];
}
obj.focus();
}

function selectNextCell(evt)
{
if(!document.all )
{
//changeChargeOnCopayChange(evt);
var obj=null;
evt=getTarget(evt);
var objname=(evt.name).substring(0,(evt.name).length-2);
var Pobj=document.getElementById(objname);
var colNo=Pobj.cellIndex;
var rowobj=Pobj.parentNode;	
var rowNo=rowobj.rowIndex;
var tabobj=rowobj.parentNode.parentNode;
while(obj==null || obj.tabIndex < 1 )
 {
 if(!document.all )
obj=tabobj.rows[rowNo].cells[colNo];
if(colNo <20)
colNo++;
else
{colNo=0;rowNo++;
}
 if(document.all )
 obj=tabobj.rows[rowNo].cells[colNo];
}

obj.focus();
}
}


function setSelectedDx(dx){ selectedDx=dx;}
function getSelectedDx(type,pos){
	if(type==1)
		return selectedDx;
	else 
		return selectedDx[pos];
} 
var trt=0;


var currentCptObj;
function createNextRow(obj)
{
if(Trim(obj.value)!=''){
var prev_cpt;
var plan_no=-1;
var rowid=obj.name.substring(obj.name.indexOf('_')+1,obj.name.length);
var dos ="";
var fetchCopay = true;
if(obj.getAttribute('prev_val'))
 prev_cpt=obj.getAttribute('prev_val');
else
 prev_cpt="uiiedfnveirpoemr"; 
if((obj.value!='' && obj.value!=prev_cpt) || fromCptPicker==1)
{
obj.setAttribute('prev_val',obj.value);
currentCptObj=obj;
var callback={
	success:sr_callSuccess1,
	failure:sr_callFailure1,
	progress:sr_callProgress1
	}
if(getServiceid() == -1){
var plan=document.getElementById("VisitTypecmb_"+rowid);
dos =document.getElementById("DOStxt_"+rowid).value;
plan_no=getValueFromPool(plan.getAttribute("comboval"), 10);
if(plan_no=='None')
 plan_no=-1;
 else
plan_no= parseInt(plan_no.substring(0,plan_no.indexOf('-')));

var rowCount = rowid.substring(rowid.indexOf('_')+1,rowid.length);
var tempId = rowid.substring(0,rowid.indexOf('_'));
if(parseInt(rowCount)>0){
	for(var i=parseInt(rowCount)-1;i>=0;i--){
		tempCPTObj = document.getElementById("Copaytxt_"+tempId+"_"+i);
		tempDOSObj = document.getElementById("DOStxt_"+tempId+"_"+parseInt(rowCount));
		tempDOSPreviousEntryObj = document.getElementById("DOStxt_"+tempId+"_"+(i));
		if(tempCPTObj){
			var tempValue  = tempCPTObj.value.replace(CURR_SYM,'');
			if(parseFloat(tempValue)>0.00){
				if(tempDOSObj && tempDOSPreviousEntryObj){
					var dos1 =  tempDOSObj.value;
					var dos2 =  tempDOSPreviousEntryObj.value;
					if(dos1==dos2){
						fetchCopay = false;
						break;
					}else{
						continue;
					}
				}
				fetchCopay = true;
				break;
			}
		}
	}
}
}else{
	dos = document.getElementById('DOStxt_'+getServiceid()).value;
}
getAjaxDataFromServer("../ServiceEntry.Action","patientId="+PATIENT_ID+"&action=1&cptCode="+obj.value+"&cptPlan="+plan_no+"&dos="+dos+"&fetchCopay="+fetchCopay+"&randNo="+Math.floor(Math.random()*1121),false,callback);
}
}
}
var sr_callFailure1=function(responseObject){} 
var sr_callProgress1=function(responseObject){}
var sr_callSuccess1=function(responseObject)
{
var res=eval(responseObject.responseText);
var s=eval(eval(res)[0]);
var copay=eval(eval(res)[1]).copay;
var cptdata=s.cptdat;
var cptmodel=eval(cptdata)[0];
if(cptmodel == 'undefined' || cptmodel == undefined){
	if(!(loadCount>0)){
		alert("Sorry, CPT not found !");
	}
}else
{
setProcessedCPT(currentCptObj,cptmodel);
createCPT(currentCptObj,cptmodel,copay,(loadCount+1>0));
setTimeout("setCF()",100);
if(loadCount+1>0){
	activeModifier=(activeModifier!='')?activeModifier:cptmodel.mod1;
	setQuickModifierUnits(currentCptObj);
}
}
if(loadCount>=0){
	testLoadGroup();
}
sr_xx_hideCptLoadingDiv();
}
function setCF()
{
var obj=currentCptObj;
var name=obj.name;
var comrowid=name.substring(name.indexOf('_')+1,name.length);
if(!(loadCount>0)){
	if(editDOS=='')
	document.getElementById('Mod1txt_'+comrowid).focus();
	else
	document.getElementById('txtMod1_'+comrowid).focus();
}
cptInd++;
if(loadingLastVisit==1){
if(prevCptData.length>cptInd)
   load_prevcpt();
  else{
  loadingLastVisit=0;
  sr_xx_hideCptLoadingDiv();
  }
}else{
if(cptSelected.length>cptInd)
 load_xxx(cptSelected)
 else
  sr_xx_hideCptLoadingDiv();
}
}
function sr_xx_hideCptLoadingDiv()
{
var d=document.getElementById('showOnlyPopUp');
d.style.display='none';
}
function createCPT(obj,cptmodel,cpay,donotLoadLastVisitDx){
var name=obj.name;
var comrowid=name.substring(name.indexOf('_')+1,name.length);
var rowNo=name.substring(name.lastIndexOf('_')+1,name.length);
	var model=new ServiceDetail();
	model.headersRequired=false;	
	var authcmb;
	if(editDOS=='')
	{
	authcmb=document.getElementById('Authcmb_'+comrowid);
	var cDate,sDate,eDate;
	var remainAuth=0;
	authcmb.setAttribute('controlvalue',6);
	authcmb.setAttribute('comboval',-1);
	}
	if(getServiceid()==-1 && editDOS=='')
	{
	//var plan=document.getElementById("ServiceTypecmb_");
	var plan=document.getElementById("VisitTypecmb_"+comrowid);
	var accType=getValueFromPool(plan.getAttribute("comboval"), 10);
	if(accType=='None')
 		accType=-1;
 	else
		accType= parseInt(accType.substring(0,accType.indexOf('-')));
	document.getElementById('CostPlancmb_'+comrowid).value=getValueFromPool(accType, 12);
	document.getElementById('CostPlancmb_'+comrowid).setAttribute("comboval",accType);
	}
	if(cptmodel!=undefined){
	setDirty();
	if(editDOS=='')
	{
		var changingcpt=false;
		try{
			if(obj.getAttribute('cpttype')==-1)
				changingcpt=true;	
		}catch(e){}		
		obj.setAttribute('cpttype',cptmodel.type);
		obj.setAttribute('qty',cptmodel.qty);
		obj.setAttribute('dunits',cptmodel.dunits);
		
		var sStatus="0";
		try{
		var ins_name=getValueFromPool(parseInt(document.getElementById('Primarycmb_').getAttribute('comboval')), 20);
		if(ins_name.indexOf('self pay') > -1 || ins_name.indexOf('selfpay') >-1 || ins_name.indexOf('SELF PAY') > -1 || ins_name.indexOf('SELFPAY') > -1 || ins_name.indexOf('Self Pay') >-1 || ins_name.indexOf('SelfPay')>-1 || ins_name.indexOf('Self Pay')>-1 )
		  sStatus="T";
		}catch(e){}
		if(parseInt(cpay)>0)
		  document.getElementById('Copaytxt_'+comrowid).value=cpay;

		var cop=getFormattedCurrency(document.getElementById('Copaytxt_'+comrowid).value,CURR_SYM);
		var pay=getFormattedCurrency(document.getElementById('Paymentstxt_'+comrowid).value,CURR_SYM);
		var uni=document.getElementById('Unitstxt_'+comrowid).value;
		if(cop=='' || cop=='0')
		 cop="0.00"
		 if(pay=='' || pay=='0')
		 pay="0.00"
		 if(uni=='' || uni=='0')
		  uni="1"
		document.getElementById('txtDosageAmt_'+comrowid).value=cptmodel.qty;
		document.getElementById('txtDosageUnits_'+comrowid).value=cptmodel.dunits;
		document.getElementById('Chargestxt_'+comrowid).value=setFormattedCurrency(parseFloat(cptmodel.rate)*parseInt(uni)-parseFloat(cop),CURR_SYM);
		//document.getElementById('Chargestxt_'+comrowid).setAttribute('value',parseFloat(cptmodel.rate)*parseInt(uni)-parseFloat(cop));
		document.getElementById('Chargestxt_'+comrowid).setAttribute('value',setFormattedCurrency(parseFloat(cptmodel.rate)*parseInt(uni)-parseFloat(cop),CURR_SYM));
		document.getElementById('Mod1txt_'+comrowid).value=cptmodel.mod1;
		document.getElementById('Mod2txt_'+comrowid).value=cptmodel.mod2;
		document.getElementById('Mod3txt_'+comrowid).value=cptmodel.mod3;
		document.getElementById('Mod4txt_'+comrowid).value=cptmodel.mod4;
		document.getElementById('hdnCharges_'+comrowid).value=cptmodel.rate;					
		document.getElementById('Unitstxt_'+comrowid).value=uni;
		document.getElementById('CPTtxt_'+comrowid).title=cptmodel.shortdesc;
		document.getElementById('Commentstxt_'+comrowid).value=cptmodel.shortdesc;
		document.getElementById('Copaytxt_'+comrowid).value=setFormattedCurrency(cop,CURR_SYM);
		document.getElementById('Paymentstxt_'+comrowid).value=setFormattedCurrency(pay,CURR_SYM);
		//document.getElementById('Rlutxt_'+comrowid).value=cptmodel.ndcno;
		if(loadingLastVisit==1){
			  document.getElementById('DX1txt_'+comrowid).value=prevCptData[cptInd].dx1;
			  document.getElementById('DX2txt_'+comrowid).value=prevCptData[cptInd].dx2;
			  document.getElementById('DX3txt_'+comrowid).value=prevCptData[cptInd].dx3;
			  document.getElementById('DX4txt_'+comrowid).value=prevCptData[cptInd].dx4;
			  setDxDescription(comrowid,895);
		 } 
		 
		if(document.getElementById('hospadm_date_'+comrowid)!= null){
			   if((document.getElementById("POScmb_").value.indexOf('(21)')>-1) && (Trim(document.getElementById('hospadm_date_'+comrowid).value)=="" || Trim(document.getElementById('hospadm_date_'+comrowid).value)== null)){
			    	 var dos = new Date(document.getElementById('DOStxt_'+comrowid).value); 
			    	 var hspAdmDateText = selectPool.get(201);
			    	 var hspAdmDate = new Date(hspAdmDateText);
			    	 if(!(dos < hspAdmDate || dos > hspAdmDate)){
			    		if(hspAdmDate != '01/01/1900')
			    			document.getElementById('hospadm_date_'+comrowid).value = hspAdmDateText;
			    	 }
			     }
			 }
		if(document.getElementById('ndc_'+comrowid)!= null){
			 document.getElementById('ndc_'+comrowid).value = cptmodel.ndcno;
		} 
		
		var ndccmb=new Array();
		if(cptmodel.ndcno.indexOf(';')!=-1)
		ndccmb=cptmodel.ndcno.split(';');
		else if(cptmodel.ndcno.indexOf(',')!=-1)
		ndccmb=cptmodel.ndcno.split(',');
		else 
			ndccmb=cptmodel.ndcno.split(' ');
		
		try{
		var str1Json="[";
		for(var i=0;i<ndccmb.length;i++)
		{
			if(i==(ndccmb.length-1))
				{
				str1Json=str1Json+'{"hsp001":"'+i+'","hsp002":"'+ndccmb[i]+'"}';
				}
			else
				{
				str1Json=str1Json+'{"hsp001":"'+i+'","hsp002":"'+ndccmb[i]+'"},';
				}
		}
		str1Json=str1Json+"]";
		selectPool.set(comrowid,str1Json);
		}
		catch (E)
		{
			//alert(E);
		}

		if(getServiceid() == -1)
		{
		if(sStatus=="T")
		 {
		    document.getElementById('Statuscmb_'+comrowid).value="Ready for Patient Billing";
		 	document.getElementById('Statuscmb_'+comrowid).setAttribute("comboval","T");
		 	document.getElementById('VisitTypecmb_'+comrowid).value='6-Self Pay';
			document.getElementById('VisitTypecmb_'+comrowid).setAttribute("comboval","9");
		 
		 	document.getElementById('cmbStatus_'+comrowid).value='T';
		 	document.getElementById('billingReasoncmb_'+comrowid).value=getValueFromPool(defaultBReason, 14);
			document.getElementById('billingReasoncmb_'+comrowid).setAttribute('comboval',defaultBReason)
		 }
		 else
		 {
			document.getElementById('Statuscmb_'+comrowid).value="EMR Service";
			document.getElementById('Statuscmb_'+comrowid).setAttribute("comboval","0")
			/*document.getElementById('VisitTypecmb_'+comrowid).value='5-Private';
			document.getElementById('VisitTypecmb_'+comrowid).setAttribute("comboval","2");*/
			document.getElementById('cmbStatus_'+comrowid).value='0';
		 }
		}
		if(isAuthPresent(comrowid)){
			var obj=document.getElementById('others_'+comrowid);
		     if (obj.style.display == 'none')
			     obj.style.display='block';
			 document.getElementById('Authcmb_'+comrowid).parentNode.style.border="2px solid red";
			}
			else	
			document.getElementById('Authcmb_'+comrowid).parentNode.style.border="1px solid #9CB8C6";
		model=new ServiceDetail();
		model.headersRequired=false;
		if(changingcpt){
			model.headersRequired=false;
			model.patientId=PATIENT_ID;
			model.submitStatus='0';
			var temp123=rowcount;					
						
		}
		if(parseInt(rowNo)+1==parseInt(rowcount))
		{
		 model.rowid=PATIENT_ID+"_"+(rowcount++);
		 model.submitStatus=sStatus;
		 if(sStatus=="T")
		 model.visittype='9';
		 else if(ENCOUNTER_TYPE==3)
		 model.visittype='3';
		 else
		 model.visittype='2';
		
		 var fieldData=eval("("+selectPool.get(55)+")");
		  var defaultAddFieldData=eval("("+selectPool.get(56)+")");
		 createServiceStripMain(model,fieldData,null,defaultAddFieldData);
		}										
		setServiceCPT(this.value,rowcount);
		con=1;
		fromCptPicker=0;
		setDirty();
		if((loadingLastVisit!=1) && (! donotLoadLastVisitDx))
		  loadDXInfo(comrowid);
		}
	else if(editDOS!='')
	{
		obj.setAttribute('cpttype',cptmodel.type);
		obj.setAttribute('qty',cptmodel.qty);
		obj.setAttribute('dunits',cptmodel.dunits);
		var cop=getFormattedCurrency(document.getElementById('txtCopay_'+comrowid).value,CURR_SYM);
		var pay=getFormattedCurrency(document.getElementById('txtPayments_'+comrowid).value,CURR_SYM);
		var uni=document.getElementById('txtUnits_'+comrowid).value;
		if(cop=='' || cop=='0')
		 cop="0.00"
		 if(pay=='' || pay=='0')
		 pay="0.00"
		 if(uni=='' || uni=='0')
		  uni="1"
		//document.getElementById('txtDosageAmt_'+comrowid).value=cptmodel.qty;
		//document.getElementById('txtDosageUnits_'+comrowid).value=cptmodel.dunits;
		document.getElementById('hdnCharges_'+comrowid).value=cptmodel.rate;
		document.getElementById('txtCharges_'+comrowid).value=setFormattedCurrency(parseFloat(cptmodel.rate)*parseInt(uni)-parseFloat(cop),CURR_SYM);
		//document.getElementById('txtCharges_'+comrowid).setAttribute('value', setFormattedCurrency(parseFloat(cptmodel.rate)*parseInt(uni)-parseFloat(cop),CURR_SYM));
		document.getElementById('txtCharges_'+comrowid).setAttribute('value',setFormattedCurrency(parseFloat(cptmodel.rate)*parseInt(uni)-parseFloat(cop),CURR_SYM));
		document.getElementById('txtMod1_'+comrowid).value=cptmodel.mod1;
		document.getElementById('txtMod2_'+comrowid).value=cptmodel.mod2;
		document.getElementById('txtMod3_'+comrowid).value=cptmodel.mod3;
		document.getElementById('txtMod4_'+comrowid).value=cptmodel.mod4;
		document.getElementById('txtUnits_'+comrowid).value=uni;
		document.getElementById('txtComments_'+comrowid).value=cptmodel.shortdesc;
		document.getElementById('txtCopay_'+comrowid).value=setFormattedCurrency(cop,CURR_SYM);
		document.getElementById('txtPayments_'+comrowid).value=setFormattedCurrency(pay,CURR_SYM);
		document.getElementById('txtRlu_'+comrowid).value=cptmodel.ndcno;
		 if(document.getElementById('ndc_'+comrowid)!= null){
			 document.getElementById('ndc_'+comrowid).value = cptmodel.ndcno;
		}
	}
	setBillingReason(comrowid);
	}
	else{
		alert('Sorry, CPT not found !');
		this.focus();
	}		
			
}

function changeCharges(obj, rowId, id){
	switch(id){
		case 0: //On Change of Units update Charges
			if (parseInt(obj.value) == 0){
				alert("Units cannot be Zero !");
				obj.value = 1;
				obj.focus();
				return;
			}
			if(Trim(obj.value) == ''){
				alert("Units Cannot be null !");
				obj.value=1;
				}
			var val=document.getElementById('Copaytxt_'+ rowId).getAttribute('value');
			if(val=='')
			 val='0';
			document.getElementById('Chargestxt_' + rowId).innerHTML = round((eval("document.serviceinformation.hdnCharges_" + rowId).value * obj.value) - parseFloat(val),2);
			document.getElementById('Chargestxt_' + rowId).setAttribute('value', round((eval("document.serviceinformation.hdnCharges_" + rowId).value * obj.value) - parseFloat(val),2));
			break;
		case 1: //On Change of Copay update Charges
			document.getElementById('Unitstxt_'+rowId).innerHTML =1 ;
			if(Trim(eval("document.getElementById.hdnCharges_" + rowId).value)=='Infinity')
				eval("document.serviceinformation.hdnCharges_" + rowId).value=document.getElementById('Chargestxt_'+rowId).innerHTML ;
			document.getElementById('Chargestxt_'+rowId).innerHTML = round((eval("document.serviceinformation.hdnCharges_" + rowId).value * parseFloat(document.getElementById('Unitstxt_' + rowId).innerHTML) - obj.value),2);
			document.getElementById('Chargestxt_'+rowId).setAttribute('value', round((eval("document.serviceinformation.hdnCharges_" + rowId).value * parseFloat(document.getElementById('Unitstxt_' + rowId).innerHTML) - obj.value),2));
			obj.value = round(parseFloat(obj.value),2);
			break;
		case 2: //Change of Charges update hidden Charges Variable
			var copay = 0;
			if ((document.getElementById('Copaytxt_' + rowId).innerHTML).length > 0)
				copay = document.getElementById('Copaytxt_' + rowId).innerHMTL;
			eval("document.serviceinformation.hdnCharges_" + rowId).value = (parseFloat(obj.value) + parseFloat(copay))/parseInt(document.getElementById('Unitstxt_' + rowId).innerHTML);
			//alert("The Total Charge for this service is: $ " + round((parseFloat(obj.value) + parseFloat(copay)),2));
			obj.value = round(parseFloat(obj.value),2);
			break;
		case 3: //Payments must be less than copay or charges+copay
			if ((document.getElementById('Copay_' + rowId).innerHTML).length < 1){
				alert("Patient copay payment is greater than copay !");
				obj.value = 0.00;
				document.getElementById('Copaytxt_' + rowId).innerHTML = 0.00;
				document.getElementById('Copaytxt_' + rowId).focus();
			}
			else if (parseFloat(obj.value) > parseFloat(document.getElementById('Copaytxt_' + rowId).innerHTML)){
				alert("Patient copay payment is greater than copay !");
				obj.value = 0.00;
				obj.focus();
			}
			else if (parseFloat(obj.value) > (parseFloat(document.getElementById('Copaytxt_' + rowId).innerHTML)+parseFloat(document.getElementById('Chargestxt_' + rowId).innerHTML))){
				alert("Patient copay payment is greater than charge !");
				obj.value = 0.00;
				obj.focus();
			}
			obj.value = round(parseFloat(obj.value),2);
			showOtherInfo(rowId);
			break;
		case 4: //Pt Payments must be less than charges+copay
			if (parseFloat(obj.value) > (parseFloat(document.getElementById('Copaytxt_' + rowId).innerHTML)+parseFloat(document.getElementById('Chargestxt_' + rowId).innerHTML))){
				alert("Patient payment is greater than charge !");
				obj.value = 0.00;
				obj.focus();
			}
			else if((parseFloat(document.getElementById('Copaytxt_' + rowId).innerHTML)+parseFloat(document.getElementById('Chargestxt_' + rowId).innerHTML) - parseFloat(document.getElementById('Paymentstxt_' + rowId).innerHTML)) == parseFloat(obj.value)){
				document.getElementById('Statuscmb_' + rowId).innerHTML = "X";
				document.getElementById('Statuscmb_' + rowId).setAttribute('value',"X");
			}
			obj.value = round(parseFloat(obj.value),2);
			showOtherInfo(rowId);
			break;
		default:
			break;
	}
}

function setValueToCell(evt){
	evt=getTarget(evt);	
	x=document.getElementById(evt.name);
	if(x!=null){
		tmp=x.options[x.selectedIndex].text;
		evt.parentNode.innerHTML=tmp;
	}
}
function getCommonString(){return commonStr;}
function getDetailString(){return detailStr;}

function validateService(){
if(isValidating == 0)
{
    
    if(getServiceid()==-1 && editDOS=='' && getCPTString()=='')
     alert("No servie to validate !");
    else
    {
    if(getServiceid()==-1 && editDOS==''){
    if(processForSaving()==0)
	 {
	  isValidating = 0;
	  return;
	 }
	} 
    isValidating=1;
    window.top.setCallfromapplet();
	showValidationProgress(); 
	if(downloadApplet==1)
	{
	downloadApplet=0;
	var appletDiv=document.getElementById('appletDiv');
	appletDiv.innerHTML="<APPLET CODE=core.CodeExpert  height=10px width=10px  ARCHIVE='json.jar,sqlitejdbc-v037-nested.jar,offlinevalidator_fat.jar'   name='cdeapplet' MAYSCRIPT='MAYSCRIPT'     codebase='../../../applets/offlinevalidator/'></APPLET>";
	}
	//setPopUpHeightWidth(100,200);
	//getCrossObj();
	if(editDOS=='')
	{
	if(getServiceid()==-1)
	{
	setDosOrDop(1);
	addToQueue(PATIENT_ID,getDistinctDos());
	}
	else
	{
	setDosOrDop(3);
	addToQueue(PATIENT_ID,document.getElementById('DOStxt_'+getServiceid()).value);
	}
	}
	else
	{
	 setDosOrDop(2);
	 addToQueue(PATIENT_ID,editDOS);
	}
	checkQueue();
 }	
}
}

function getPatientId(){
	return PATIENT_ID;
}
function getPId(){
	return PATIENT_ID;
}

var activeDxRow=-1;
function createDxPicker(rowid)
{
var noOfRow=0;
try{
noOfRow=parent.getLoadedFromLeaf();
}
catch(e){noOfRow=0;}
activeDxRow=rowid;
if(editDOS=='')
{
 if(document.getElementById('CPTtxt_'+activeDxRow).value!='')
  { 
    if(noOfRow==1)
    openPicker(1,'selectDxValue',null,4,false,defaultNoOfLines-3)
    else
    openPicker(1,'selectDxValue',null,4,false,defaultNoOfLines)
   }
 else{
	 alert("Select a CPT to proceed !");
 }
  
}
else
{
	if(noOfRow==1)
    openPicker(1,'selectDxValue',null,4,false,defaultNoOfLines-3)
    else
    openPicker(1,'selectDxValue',null,4,false,defaultNoOfLines)
}
}

function createDxPickerNew (rowid)
{
activeDxRow=rowid;
/*if (temp == -1){
	var cptValue=document.getElementById('txtCPT_'+activeDxRow).value;
	editDOS='';
}
else
	var cptValue=document.getElementById('CPTtxt_'+activeDxRow).value;*/
var count=0;
for(var k=1;k<=4;k++){
	if(editDOS=='')
		var dxValue=document.getElementById('DX'+k+'txt_'+activeDxRow).value;
	else
		var dxValue=document.getElementById('txtDX'+k+'_'+activeDxRow).value;
	if(dxValue ==''){
		count++;
		missedDx=k;break;
	}
}

if(count > 0){
alert('The DX'+k+' is missing !');
		return;
}
else{
	if(editDOS=='')
	{
		if(document.getElementById('CPTtxt_'+activeDxRow).value!='')
			openPicker(1,'selectDxValueNew',null,16,false,20)
		else
		  alert("Select a CPT to proceed !");
		
	}
	else{
		if(document.getElementById('txtCPT_'+activeDxRow).value!='')
			openPicker(1,'selectDxValueNew',null,16,false,20)
		else
			
			alert("Select a CPT to proceed !");
	}
}
}

function selectDxValueNew(obj)
{
if(activeDxRow!=-1)
{
var dx='';
var dxDesc='';
for (var i=0;i<16;i++)
 {setDirty();
   if(i<obj.length){
	   dx=obj[i]['col0']+','+dx;
	   document.getElementById('txtDX'+(i+1)+'Desc_'+activeDxRow).value=obj[i]['col1'];
     //dxDesc=obj[i]['col1'];
     }
    /*else{ 
     dx='';
     dxDesc='';
     }*/
 }
	if(dx.split(",").length == 17){
	   dx=dx.split(",").slice(0, -1).join(',');
	   }
	//gss
	   for(var k=0;k<4;k++){
		   var dxData="";
	   if(editDOS=='')
		   dxData=document.getElementById('DX'+(k+1)+'txt_'+activeDxRow).value;
	   else	  
		   dxData=document.getElementById('txtDX'+(k+1)+'_'+activeDxRow).value;
	   if(dxData ==''){
		   alert("Please enter DX"+(k+1)+" !");
		   document.getElementById('DX'+(k+1)+'txt_'+activeDxRow).focus();
		   return;
	   }
	   if(dx.indexOf(dxData) > -1){
		   alert("The dx "+dxData+" is already entered !");
		   dx=dx.replace(dxData+',','');
	   	}
	   }	  
	
   if(editDOS=='')  {	  
	   document.getElementById('D-X5-20txt_'+activeDxRow).value=dx;
   }
   else{
	   document.getElementById('txtD-X5-20_'+activeDxRow).value=dx;
      }
   
activeDxRow=-1;    
}
}


function loadDXFromPreviousRow(rowid)
{
activeDxRow=rowid;
var cur_row=-1;
var cur_val='';
var stop_loop=-1;
if(getServiceid()==-1)
 cur_row=parseInt(activeDxRow.substring(activeDxRow.indexOf('_')+1,activeDxRow.length));
if(cur_row<1)
  alert("No previous row data !");
else
{
if(document.getElementById('CPTtxt_'+activeDxRow).value!='')
{
stop_loop=cur_row;
clearDxFields(getPatientId()+'_'+(cur_row));
document.getElementById('txtDXCodeSystemId_'+getPatientId()+'_'+(cur_row)).value=document.getElementById('txtDXCodeSystemId_'+getPatientId()+'_'+(cur_row-1)).value;
 while(cur_row >0 && stop_loop>0)
{
  try{
  cur_val=document.getElementById('DX1txt_'+getPatientId()+'_'+(cur_row-1)).value;
  cur_row=cur_row-1;
  stop_loop=-1;
  }catch(e){
	  if(cur_row==1){
		  alert("No previous row data !");
		  return;
		  }
  cur_row=cur_row-1;
  stop_loop=cur_row;
  }
}
 for(var i=0;i<4;i++)
  {
   if(getServiceid()==-1){
   document.getElementById('DX'+(i+1)+'txt_'+activeDxRow).value=document.getElementById('DX'+(i+1)+'txt_'+getPatientId()+'_'+(cur_row)).value;
   document.getElementById('DX'+(i+1)+'txt_'+activeDxRow).title=document.getElementById('DX'+(i+1)+'txt_'+getPatientId()+'_'+(cur_row)).title;
   document.getElementById('txtDX'+(i+1)+'Desc_'+activeDxRow).value=document.getElementById('DX'+(i+1)+'txt_'+getPatientId()+'_'+(cur_row)).title;
   } 
   else{
   document.getElementById('DX'+(i+1)+'txt_'+activeDxRow).value=document.getElementById('DX'+(i+1)+'txt_'+getServiceid()+'_'+(cur_row)).value;
   document.getElementById('DX'+(i+1)+'txt_'+activeDxRow).title=document.getElementById('DX'+(i+1)+'txt_'+getServiceid()+'_'+(cur_row)).title;
   document.getElementById('txtDX'+(i+1)+'Desc_'+activeDxRow).value=document.getElementById('DX'+(i+1)+'txt_'+getServiceid()+'_'+(cur_row)).title;
   }
  }
}
else
alert("Select a CPT first to proceed !");
}  

}
var fromCptPicker=0;
var cptSelected="";
var cptInd=0;
function load_xxx(sr)
{
fromCptPicker=1;
var d=document.getElementById('showOnlyPopUp');
if(d.style.display!='block')
{
d.style.left="400px";
d.style.top="300px";
d.innerHTML="<table bgcolor='#E4F6FA' style='border-collapse:collapse;border:2px solid black'><tr height='50px'><td><img src='../../../images/Ajax/Glace-Data-loader.gif' /></td><td><div id='validationmes'><font color=red>CPT data loading. Please wait ...</font><div></td></tr></table>";
d.style.display='block'; 
}
cptSelected=sr;
loadCptData(sr[cptInd]['col0']);
}
function createCptPicker(){
var noOfRow=0;
try{
noOfRow=parent.getLoadedFromLeaf();
}
catch(e){noOfRow=0;}
cptInd=0;
if(noOfRow==1)
openPicker(2,'load_xxx',null,1,false,defaultNoOfLines-3);
else
openPicker(2,'load_xxx',null,1,false,defaultNoOfLines);
}

function createCptPicker_multiple(){
var noOfRow=0;
try{
noOfRow=parent.getLoadedFromLeaf();
}
catch(e){noOfRow=0;}
cptInd=0;
if(noOfRow==1)
openPicker(2,'load_xxx',null,10,false,defaultNoOfLines-3);
else
openPicker(2,'load_xxx',null,10,false,defaultNoOfLines);
}

function getIFrame(frmaehandle){
	var rv = null;
	// if contentDocument exists, W3C compliant (Mozilla)
	if (frmaehandle.contentDocument){
		rv = frmaehandle.contentDocument;
	} else {
 	 // IE
		rv = frmaehandle.document;
	}
	return rv;
}

function showStatus(handle){
//hideRequestDivStatus(tabDetails.SERVICE,0);
	var mess1='';
	if(window.ActiveXObject){
		try{
			var mes=document.frames['sr_serverresponse'].getValue();
			mess1=mes.split('|1978|')[0];
			setSavedId(mes.split('|1978|')[1]);
		}
		catch(e4567){}
	}
	else if(document.implementation){
		var di=getIFrame(handle).body.innerHTML;
		var disp=di.split('|1978|')[0];
		var sID=di.split('|1978|')[1];
		try{
		setSavedId(sID.substr(0,sID.indexOf('" ')));}catch(e){}
		if(disp.indexOf("one") > -1 )
			mess1="one";
		else if(disp.indexOf("two") > -1 )
			mess1="two";
		else if(disp.indexOf("three") > -1 )
			mess1="three";
		else if(disp.indexOf("four") > -1 )
			mess1="four";
		else if(disp.indexOf("five") > -1 )
			mess1="five";
		else if(disp.indexOf("six") > -1 )
			mess1="six";
		else if(disp.indexOf("seven") > -1 )
			mess1="seven";
							
	}
	if(mess1=='one')
	 {
	  //showRequestDivStatus(false,tabDetails.SERVICE,4,true,'');
	  //loadSelPatientBalDetails(false);
	  //setAllToUpdated();
	  updateSavedStatus();
	  reSetDirty();
	 /* if(getServiceid() == -1 )*/
	   goEntry();
	 } 
	else if(mess1=='two')
	{ 
	  //showRequestDivStatus(false,tabDetails.SERVICE,0,true,'Duplicate service found ...');
	  //if(getServiceid() == -1)
	  reSetDirty();
	  //goEntry();
	  }
	else if(mess1=='three')
	 { 
		if(sID.indexOf('Please Enter ICD 10 for DOS greater than 10/01/2015')>-1){
			 alert('Please Enter ICD 10 for DOS greater than 10/01/2015');
		  }
	  //showRequestDivStatus(false,tabDetails.SERVICE,0,true,'Error while saving ...');
	  reSetDirty();
	  }
	  else if(mess1=='four')
	 { 
	  //showRequestDivStatus(false,tabDetails.SERVICE,0,true,'Copay payment CPT not configured ...');
	  reSetDirty();
	  } 
	   else if(mess1=='five')
	 { 
	  //showRequestDivStatus(false,tabDetails.SERVICE,0,true,'AR action will create duplicate service ...');
	  reSetDirty();
	  } 
	   else if(mess1=='six')
	 { 
	  //showRequestDivStatus(false,tabDetails.SERVICE,0,true,'AR action completed successfully ...');
	  reSetDirty();
	  SR_FROM_AR=-1;
	  goEntry();
	  //setAllToUpdated();
	  //loadSelPatientBalDetails(false);
	  clickedTab(tabDetails.ARANALYSIS);
	  ar_onLoadActions();
	  }
	  else if(mess1=='seven')
	 { 
	  //showRequestDivStatus(false,tabDetails.SERVICE,0,true,'AR action failed ...');
	  reSetDirty();
	  }
	try{
	if(savedIdString.indexOf('Glenwood')>-1)
	 savedIdString="";
	 document.serviceinformation.savedIds.value=savedIdString;
	}
	catch(e){}
	try{
if(ENCOUNTER_ID!="-1" && savedIdString!=""){
	parent.performOperation(operationType);
	}
}catch(e){}
sr_checkForPQRI();	
}

function EditCPTLink()
{
	var URL="../configure/AddAndSaveCPT.Action?actionType=display";
    var nwin = window.open(URL,"","toolbar=no,scrollbars=yes,location=no,resizable=yes,direction=no,status=no, menubar=no,top=0,left=0");
}
function uploadMedNotes(ptid,sertype,serid){
if(ptid==-1)
 ptid=PATIENT_ID;
if(getServiceid()==-1)
  alert("Save the service before uploading Med Notes !");
else
{
var updateflag=true;
var flag=1;
if(updateflag==false){
		alert("Not allowed to edit !");
		return;
  	}
var win=null;
var dop ;

	if(flag==2){
		if(!(confirm("Click \"OK\" to Change the Attached Med Notes "))) {
			return ;
		}
	}
	
if(getServiceid()==-1)	
dop = document.getElementById('DOPtxt_').value ;
else if(editDOS!='')
dop = document.getElementById('txtDOP_'+serid).value ;
else
dop = document.getElementById('DOPtxt_').value ;
setDirty();
	win = window.open( "../../../jsp/billing/superbill/UploadMedNotes.jsp?dop="+dop+"&ptid="+ptid+"&serid="+serid+"&sertype="+sertype,"UpLoadMedNotes","left=400,top=250, width=400, height=125, scrollbar=no, resizable=no");

}
}

function loadMedNotesValue(path,serid,sertype){
var prev_med=eval("document.serviceinformation.medNotes_" + serid).value;
if(prev_med=='')
eval("document.serviceinformation.medNotes_" + serid).value = path;
else
eval("document.serviceinformation.medNotes_" + serid).value=prev_med+"-1-9-1-"+path;
}
function checkQueue()
{deQueue();setTimeout("checkQueue()",5000);}

function selectCptValue(obj,e)
{
var target=getTarget(e);
var val=target.getAttribute('value');
if(val != null)
{
loadCptData(val);
}
}

function selectDxValue(obj)
{
if(activeDxRow!=-1)
{
var dx='';
var dxDesc='';
clearDxFields(activeDxRow);
document.getElementById('txtDXCodeSystemId_'+activeDxRow).value='2.16.840.1.113883.6.104';
for (var i=0;i<4;i++)
 {setDirty();
   if(i<obj.length){
     dx=obj[i]['col0'];
     dxDesc=obj[i]['col1'];
     }
    else{ 
     dx=''; 
     dxDesc='';
     }
   if(editDOS==''){  
   document.getElementById('DX'+(i+1)+'txt_'+activeDxRow).value=dx;
   document.getElementById('DX'+(i+1)+'txt_'+activeDxRow).title=dxDesc;
   document.getElementById('txtDX'+(i+1)+'Desc_'+activeDxRow).value=dxDesc;
   }
   else{
      document.getElementById('txtDX'+(i+1)+'_'+activeDxRow).value=dx;
      document.getElementById('txtDX'+(i+1)+'_'+activeDxRow).title=dxDesc;

   }
  }
var dos=new Date(document.getElementById('DOStxt_'+activeDxRow).value);
var icd10StartDate=new Date('10/01/2015')
if(dos>=icd10StartDate)
	setTimeout("saveServices('domapppings')",25);
activeDxRow=-1;    
}
}

function closeMedDiv()
{
var m_div=document.getElementById('MedNotesBoard');
m_div.style.display='none';
}
function viewMedNotes(tifname){
if(getServiceid() == -1)
alert("To view Med Notes upload first !");
else
{
closeMedDiv();
if(tifname !='')
{
var pos=tifname.indexOf('-1-9-1-');
if(pos<5 && pos!=-1)
   tifname=tifname.substr(pos+7,tifname.length);
var fileNames=tifname.split('-1-9-1-');
if(fileNames.length == 1)
 displayMedNotes(fileNames[0]);
else
{
var text="<table><tr nowrap><td bgcolor=red><b>Med Notes Tiff</b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href=javascript:closeMedDiv()>Close</a></td></tr>";
for(var i=0;i<fileNames.length;i++)
	{
		text=text+"<tr><td><a href=javascript:displayMedNotes('"+fileNames[i]+"')>"+fileNames[i]+"</a></td></tr>";
	}
text=text+"</table>";
var m_div=document.getElementById('MedNotesBoard');

  m_div.style.top=400;
  m_div.style.left=400;

m_div.innerHTML=text;
m_div.style.display='block';
}
}
else
alert("Med notes not yet uploaded for this service !");
}
}

function displayMedNotes(tifname)
{
var win=null;
var url=sr_fullcontextpath+"/"+"shared"+"/MedNotes"+"/"+(sr_practicename).replace(/\\/g,'')+"/"+tifname;
closeMedDiv();
win = window.open(url,"");
}


function newServicePayment(row){
var dop = "";
var sid="";
if(getServiceid() == -1)
 alert("Save the service to enter comments !");
else
{
if(editDOS=='')
{
dop=document.getElementById('DOPtxt_').getAttribute('value') ;
sid=getServiceid();
}
else
{
if(row>1)
dop=document.getElementById('txtDOP_'+row).getAttribute('value') ;
sid=row;
}
	if(newSPFVisible==1){
		newSPFVisible = 2;
		var paymentString  ="";

document.getElementById("newServicePaymentFrame1").src = contextpath +"/jsp/billing/Eob/"+"EOBServicePayment.Action?serviceid="+sid+"&saveflag=0&patientid="+PATIENT_ID+"&dop="+dop+"&mode=3&paymentString="+paymentString;
document.getElementById("newServicePaymentFrame").style.visibility = "visible";
	}else{
	    document.getElementById("newServicePaymentFrame").style.visibility = "hidden";
        newSPFVisible = 1;
	}
}
}


function setSaveServicePayment(paymentString , serviceid , mode , patientid ){
	 var responseText = getPostData("EOBServicePayment.Action?serviceid="+serviceid+"&saveflag=1&patientid="+patientid+"&mode="+mode+"&paymentString="+paymentString);
   document.getElementById("newServicePaymentFrame1").src = contextpath +"/jsp/billing/Eob/"+"EOBServicePayment.Action?serviceid="+serviceid+"&saveflag=0&patientid="+patientid+"&mode="+mode+"&paymentString="+paymentString;
}

function setCaseValues(id,description)
{
fetchSelectFromServer(7)
}

/*function formatDate(evt)
		{
		try{
		var str=this.value;
				if(str.length==2)
				  str=str+"/";
				else if(str.length==5)
				  str=str+"/";  
		this.value=str;}
		catch(e){
		evt=getTarget(evt);
		var str=evt.value;
			if(str.length==2)
				  str=str+"/";
				else if(str.length==5)
				  str=str+"/";  
		evt.value=str;
		
		}
	}*/
function formatDateLocal(evt)
{
 FormatDate(getTarget(evt));
}
function formatDateOnBlurLocal(obj)
{	
	if(PATIENT_DOB==undefined||PATIENT_DOB==null)
	  PATIENT_DOB="01/01/1900";
	if(new Date(obj.value)<new Date(PATIENT_DOB)){
	 	alert("DOS should be greater than DOB");
	 	var prevval=obj.getAttribute("orival");
	 	obj.value=prevval;
	} 
	else if(new Date(obj.value)>new Date()){
	 	alert("Future date not allowed.");
	    var prevval=obj.getAttribute("orival");
	 	obj.value=prevval;
	 	obj.focus();
	}
	else{
	 	 CheckDate(obj);
	}

}	
function formatDateOnBlur(str) // function written by ams
		{
			if(str.substr(0,1)=="0")
				{
					str=str.substr(1,str.length-1);
					if(str.substr(2,1)=="0")
						str=str.substr(0,2)+ str.substr(3,str.length);
				}
			else
				{
					if(str.indexOf('/')==1)
						{
							if(str.substr(2,1)=="0")
								str=str.substr(0,2)+ str.substr(3,str.length);
						}

					if(str.substr(3,1)=="0")
					str=str.substr(0,3)+ str.substr(4,str.length);
				}
	
			if(str.substr(str.lastIndexOf("/")+1,4).length!=4)
				str=str.substr(0,str.lastIndexOf('/')+1)+"20"+str.substr(str.length-2,2);
		return str;
		}	
		
function openSetDefault()
{
if(editDOS=='' && getServiceid()==-1)
{
var obj=document.getElementById('defaultValue');
if(obj.style.display=='none')
obj.style.display='block';
else
obj.style.display='none';
}
else
 alert("Defaults can not be set while editing !");
}
function populateDefaultValueDiv()
{
var obj=document.getElementById('defaultValue');
var tab=document.createElement('table');
tab.width='100%';tab.cellSpacing='0px';tab.cellPadding='0px';tab.className='tableStyle';
var tbody=document.createElement('tbody');
var trow1=document.createElement('tr');
trow1.style.height='5px';
var cel01=document.createElement('td');
cel01.colSpan=8;
trow1.appendChild(cel01);
tbody.appendChild(trow1);
var trow=document.createElement('tr');
trow.style.height='23px';
var cel1=document.createElement('td');
cel1.className="othertddata";
var cel2=document.createElement('td');
var cel3=document.createElement('td');
cel3.className="othertddata";
var cel4=document.createElement('td');
var cel5=document.createElement('td');
cel5.className="othertddata";
var cel6=document.createElement('td');
var cel7=document.createElement('td');
cel7.className="othertddata";
var cel8=document.createElement('td');
var cel9=document.createElement('td');
cel9.innerHTML="<a class='btn onbtn' href='javascript:eraseDefaults();'  title='Clear default values'><b><b><b>Clear Defaults</b></b></b></a>";
var dopLabel=document.createTextNode("DOP");
var sDocLabel=document.createTextNode("Service Doctor");
var bDocLabel=document.createTextNode("Billing Doctor");
var posLabel=document.createTextNode("POS");
cel1.appendChild(dopLabel);
trow.appendChild(cel1);
//trow.appendChild(insertCell('', 'defaultDOP',2,0,'databordertd','100px',''));
trow.appendChild(sr_createCell('defaultDOP',9,'generaltextboxwhite',defaultdate,'databordertd','text','',-1,'6%',1));
cel3.appendChild(sDocLabel);
trow.appendChild(cel3);
//trow.appendChild(insertCell('Service Doctor', 'defaultDoctor',3,16,'databordertd','20%',-1));
trow.appendChild(sr_createCell('defaultDoctor',25,'dropdn generaltextbox','Service Doctor','databordertd','combo',-1,16,'180px',1));
cel5.appendChild(bDocLabel);
trow.appendChild(cel5);
//trow.appendChild(insertCell('Service Doctor', 'defaultBillingDoctor',3,16,'databordertd','15%',-1));
trow.appendChild(sr_createCell('defaultBillingDoctor',25,'dropdn generaltextbox','Billing Doctor','databordertd','combo',-1,16,'180px',1));
cel7.appendChild(posLabel);
trow.appendChild(cel7);
//trow.appendChild(insertCell('Place Of Service', 'defaultPOS',3,17,'databordertd','15%',-1));
trow.appendChild(sr_createCell('defaultPOS',25,'dropdn generaltextbox','POS','databordertd','combo',-1,171,'180px',1));
var espace=document.createElement('td');
espace.innerHTML="&nbsp;&nbsp;"
trow.appendChild(espace)
trow.appendChild(cel9);
//trow.appendChild(cel2);

//trow.appendChild(cel4);

//trow.appendChild(cel6);

//trow.appendChild(cel8);
tbody.appendChild(trow);

var trow2=document.createElement('tr');
trow2.style.height='5px';
var cel011=document.createElement('td');
cel011.colSpan=8;
trow2.appendChild(cel011);
tbody.appendChild(trow2);
tab.appendChild(tbody);
obj.appendChild(tab);

var tabSpace=document.createElement('table');
var tbodySpace=document.createElement('tbody');
var srow=document.createElement('tr');
srow.style.height='5px';
var scel=document.createElement('td');
srow.appendChild(scel);
tbodySpace.appendChild(srow);
tabSpace.appendChild(tbodySpace);
obj.appendChild(tabSpace);
}		

function setDefaultDate(evt)
{
evt=getTarget(evt);
var objname=(evt.name).substring(0,(evt.name).length-2);
var val=evt.value;
defaultdateset=val;
//document.getElementById('DOPtxt_').setAttribute('value',val);
document.getElementById('DOPtxt_').value=val;
}

function setDefaultDateIE(evt)
{
var val=getTarget(evt).value;
//document.getElementById('DOPtxt_').setAttribute('value',val);
document.getElementById('DOPtxt_').value=val;
}



/// NEW 


function createTextBoxNew(name,width,styleclass,displaytext,type,comboval,control,x)
{
var txtbox=document.createElement('input');
if(type=='combo')
  txtbox.readOnly=true;
if(isReferringPicker==1){
if( name.indexOf("Referralcmb_")==0 || name.indexOf("XReferralcmb_")==0)
txtbox.readOnly=true;
}  
txtbox.type='text';
txtbox.name=name;
txtbox.id=name;
txtbox.tabIndex=1;
txtbox.className=styleclass;
txtbox.setAttribute("comboval",comboval);
txtbox.setAttribute("controlvalue",control);
txtbox.setAttribute("orival",comboval);
//txtbox.size=width;
if(name.indexOf("DX1")==0)
txtbox.style.width="80%";
else if(name.indexOf("DX")==0)
txtbox.style.width="70%";
else
{
	if(x==-99)
		txtbox.style.width="87%";
	else{
if(x==-100)
{
if(window.ActiveXObject)
txtbox.style.width=width;
else
txtbox.style.width="100%";
}
else
txtbox.style.width="100%";
}
}
txtbox.value=displaytext;
if(type=='combo')
  addEvent(txtbox,'keydown',createComboBox);
if(type=='combo')
  addEvent(txtbox,'click',createComboBox);
if(type=='text')  
  addEvent(txtbox,'focus',changebacktowhite);
if(type=='text')  
  addEvent(txtbox,'blur',takeActionOnBlur);

if(isReferringPicker==1){
if(name.indexOf("Referralcmb_")==0)
   addEvent(txtbox,'click',sr_loadRefferingDoc_1);
else if(name.indexOf("XReferralcmb_")==0)
   {currentRef="";
   addEvent(txtbox,'click',sr_loadRefferingDoc_2);
   }
}

  /*if(document.all)
  {
if(type=='text' && name.indexOf('DOPtxt_')==0)
  addEvent(  txtbox,'focus',fcalled);
  }*/
if(name.indexOf('DOPtxt_')==0 || name.indexOf('DOStxt_')==0 || name.indexOf('defaultDOP')==0 || name.indexOf('txtDOS_')==0 || name.indexOf('txtDOP_')==0 || name.indexOf('dosto_')==0)  
  addEvent(txtbox,'keyup',formatDateLocal);
if(name.indexOf('dosto_')==0 )
	   addEvent(txtbox,'blur',compareDos);
  //addEvent(txtbox,'keyup',formatDate);
if(name.indexOf("DX")==0){
	addEvent(txtbox,'dblclick',openIndividualDxPicker);
	addEvent(txtbox,'blur',changeCase);
}
if(name.indexOf("DX")>-1){
	addEvent(txtbox,'keyup',setDxCodeSystem); 
}
if(name.indexOf("D-X5-20txt")==0 || name.indexOf("txtD-X5-20")==0 ){ 
	txtbox.ondblclick=function(evt){
		var obj = getTarget(evt);
		var rowid=obj.name.substring(obj.name.indexOf('_')+1,obj.name.length);
		createDxPickerNew(rowid);
	}
}
  
if( name.indexOf("Paymentstxt_")==0 || name.indexOf("txtPayments_")==0)
  addEvent(txtbox,'dblclick',setPaymentModeDbClick);
if( name.indexOf("TifReftxt_")==0)
  addEvent(txtbox,'dblclick',fillNextRowTiff);  
if( name.indexOf("Unitstxt_")==0)
  addEvent(txtbox,'dblclick',checkDosageOnDoubleClick);  
/*if(name.indexOf('Copaytxt') == 0 ||name.indexOf('Unitstxt') == 0 )
 addEvent(txtbox,'change',calculateCharge);
 */
if( name.indexOf("D-X5") == 0 || name.indexOf("txtD-X5") == 0){
	   txtbox.onkeypress=function(evt)
	   {
			var unicode = evt.keyCode? evt.keyCode : evt.charCode;
		    if(evt.keyCode==37||evt.keyCode==39||unicode==44||unicode==46||unicode==8||unicode==9||((unicode>=48&&unicode<=122)&&(unicode!=94&&unicode!=95&&unicode!=96)&&unicode!=59&&!(unicode>=58&&unicode<=64)&&!(unicode>=91&&unicode<=93)))
		    {
		    	evt=getTarget(evt);
		    	var dx5to20data=evt.value;
			    var evtValue=String.fromCharCode(unicode);
				var lastChar=dx5to20data.charAt(dx5to20data.length-1);
			    if(((dx5to20data=='' ||  lastChar== ',' || lastChar == '.') && evtValue == ',') || (dx5to20data=='' && evtValue == '.')|| ((lastChar == ','||lastChar == '.') && evtValue == '.'))
					return false;
				else
					{
						if(evtValue == ','){
							var splitData=dx5to20data.split(',');
							var dLength=splitData.length;
							var splitDataLastValue=splitData[dLength-1];
				    		for(var k=0;k<splitData.length-1;k++){
				    			if(splitData[k] == splitDataLastValue){
				    				  var x=splitData[k];
				    				  var y=evt.value.lastIndexOf(x);
				    				  alert("The dx "+x+" is already entered !");
				    				  evt.value=evt.value.substring(0,y);
				    				  return false;
				    			}
				    		}
						}
						return true;
					}
		    }
		    else 
		            return false;	
		} 
}
 
return txtbox;
}
function changeCase(evt){
	if(!evt)evt=window.event;
	var name=getTarget(evt).name;
	var obj = getTarget(evt);
	var val=obj.value;
	obj.value = val.toUpperCase();
}
function setPaymentModeDbClick(evt)
{
if(!evt)evt=window.event;
evt=getTarget(evt);
setPaymentMode(evt.name);
}
function fillNextRowTiff(evt)
{
if(!evt)evt=window.event;
var name=getTarget(evt).name;
var val=getTarget(evt).value;
var line_no=name.substring(name.lastIndexOf('_')+1,name.length);
var next_line=parseInt(line_no)+1;
var line=-1;
var checkCPT="";
for(var i=next_line;i<rowcount;i++)
{
  try{
   checkCPT=document.getElementById('CPTtxt_'+PATIENT_ID+'_'+i).value;
   if(checkCPT!="")
   {
    line=i;
    break;
    }
  }
  catch(e){
  line=-1;
  checkCPT="";
  }
}
if(line != -1 && checkCPT!='')
 document.getElementById('TifReftxt_'+PATIENT_ID+'_'+line).value=val;

}
function openIndividualDxPicker(evt){
var noOfRow=0;
try{
noOfRow=parent.getLoadedFromLeaf();
}
catch(e){noOfRow=0;}
selectedIndividualDx='';
if(!evt)evt=window.event;
var name=getTarget(evt).name;
selectedIndividualDx=name;
var rowid=name.substring(name.indexOf('_')+1,name.length);
var CPT=document.getElementById('CPTtxt_'+rowid).value;
if(CPT=='')
	alert("Select a CPT to proceed !");
else{
	 var dos=new Date(document.getElementById('DOStxt_'+rowid).value);
		var icd10StartDate=new Date('10/01/2015')
		if(dos>=icd10StartDate){
			if(noOfRow==1){
				if(document.getElementById('DOStxt_'+rowid) != undefined && document.getElementById('DOStxt_'+rowid) != null && document.getElementById('DOStxt_'+rowid).value !='')
					openPicker(28,'setIndividualICDCode',null,1,false,defaultNoOfLines-3,undefined,undefined,undefined,undefined,undefined,true,undefined,document.getElementById('DOStxt_'+rowid).value);
				else
					openPicker(28,'setIndividualICDCode',null,1,false,defaultNoOfLines-3,undefined,undefined,undefined,undefined,undefined,true);
			 }
			else{
				if(document.getElementById('DOStxt_'+rowid) != undefined && document.getElementById('DOStxt_'+rowid) != null && document.getElementById('DOStxt_'+rowid).value !='')
					openPicker(28,'setIndividualICDCode',null,1,false,defaultNoOfLines,undefined,undefined,undefined,undefined,undefined,true,undefined,document.getElementById('DOStxt_'+rowid).value);
				else
					openPicker(28,'setIndividualICDCode',null,1,false,defaultNoOfLines,undefined,undefined,undefined,undefined,undefined,true);
			}
		}else{
		 if(noOfRow==1)
		    openPicker(1,'setIndividualDx',null,1,false,defaultNoOfLines-3)
		    else
		    openPicker(1,'setIndividualDx',null,1,false,defaultNoOfLines)
		}
} 
}

function setIndividualICDCode(obj){
	if(selectedIndividualDx!='')
	{
	setDirty();
	var dx=obj.code;
	//gss
	var name=selectedIndividualDx;
	if(name.indexOf('DX') == 0){
	var uniK=name.substring(name.indexOf('_')+1,name.length);
	var dxNo=name.substring(name.indexOf('D')+2,3); 
	var dupDx=0;
	//clearDxFields(uniK);
	  document.getElementById('txtDXCodeSystemId_'+uniK).value='2.16.840.1.113883.6.90';
	  for(var i=1;i<5;i++){
		var dxValue=document.getElementById('DX'+i+'txt_'+uniK).value;
	    if((i!= dxNo && dxValue!='' && dx!='' && dxValue==dx) ||((dxValue !='' && document.getElementById('D-X5-20txt_'+uniK).value!='' && document.getElementById('D-X5-20txt_'+uniK).value.indexOf(dxValue)!=-1)))
	     dupDx++;
	  }
	  var dos=new Date(document.getElementById('DOStxt_'+uniK).value);
	 
	  if(dupDx > 0){
	   var x=dx;
	   //evt.value='';
	   alert("The dx "+x+" is already entered !");
	   document.getElementById(selectedIndividualDx).value='';
	   document.getElementById(selectedIndividualDx).focus();
	   return false;
	   //dxObj=dx;
	   //setTimeout("sr_selectDxBox()",0);
	  }
	}

	document.getElementById(selectedIndividualDx).value=dx;    
	selectedIndividualDx='';
	}    
	}

function setIndividualDx(obj){
if(selectedIndividualDx!='')
{
setDirty();
var dx=obj[0]['col0'];
//gss
var name=selectedIndividualDx;
if(name.indexOf('DX') == 0){
var uniK=name.substring(name.indexOf('_')+1,name.length);
var dxNo=name.substring(name.indexOf('D')+2,3); 
var dupDx=0;
//clearDxFields(uniK);
  document.getElementById('txtDXCodeSystemId_'+uniK).value='2.16.840.1.113883.6.104';
  for(var i=1;i<5;i++){
	var dxValue=document.getElementById('DX'+i+'txt_'+uniK).value;
    if((i!= dxNo && dxValue!='' && dx!='' && dxValue==dx) ||((dxValue !='' && document.getElementById('D-X5-20txt_'+uniK).value!='' && document.getElementById('D-X5-20txt_'+uniK).value.indexOf(dxValue)!=-1)))
     dupDx++;
  }
  var dos=new Date(document.getElementById('DOStxt_'+uniK).value);
  var icd10StartDate=new Date('10/01/2015')
  if(dos>=icd10StartDate)
  	setTimeout("saveServices('domapppings')",25);
  if(dupDx > 0){
   var x=dx;
   //evt.value='';
   alert("The dx "+x+" is already entered !");
   document.getElementById(selectedIndividualDx).value='';
   document.getElementById(selectedIndividualDx).focus();
   return false;
   //dxObj=dx;
   //setTimeout("sr_selectDxBox()",0);
  }
}

document.getElementById(selectedIndividualDx).value=dx;    
selectedIndividualDx='';
}    
}
function fillNextRow(evt)
{
if(!evt)evt=window.event;
var name=getTarget(evt).name;
var val=getTarget(evt).value;
var line_no=name.substring(name.lastIndexOf('_')+1,name.length);
var next_line=parseInt(line_no)+1;
var line=-1;
var checkCPT="";
for(var i=next_line;i<rowcount;i++)
{
  try{
   checkCPT=document.getElementById('CPTtxt_'+PATIENT_ID+'_'+i).value;
   if(checkCPT!="")
   {
    line=i;
    break;
    }
  }
  catch(e){
  line=-1;
  checkCPT="";
  }
}
if(line != -1 && checkCPT!='')
{
if(document.getElementById('DX1txt_'+PATIENT_ID+'_'+line).value=='')
 document.getElementById('DX1txt_'+PATIENT_ID+'_'+line).value=val;
else if(document.getElementById('DX2txt_'+PATIENT_ID+'_'+line).value=='')
 document.getElementById('DX2txt_'+PATIENT_ID+'_'+line).value=val;
else if(document.getElementById('DX3txt_'+PATIENT_ID+'_'+line).value=='')
 document.getElementById('DX3txt_'+PATIENT_ID+'_'+line).value=val;
else if(document.getElementById('DX4txt_'+PATIENT_ID+'_'+line).value=='')
 document.getElementById('DX4txt_'+PATIENT_ID+'_'+line).value=val;  
} 
}
var con=0;
function changebacktowhite(evt)
{
evt=getTarget(evt);
if(evt.name.indexOf('Chargestxt_') == 0  ||  evt.name.indexOf('Copaytxt_') == 0 || evt.name.indexOf('Paymentstxt') == 0 || evt.name.indexOf('txtCharges_') == 0 || evt.name.indexOf('txtCopay_') == 0 || evt.name.indexOf('txtPayments_') == 0) 
 {
 //evt.value=getFormattedCurrency(evt.value,CURR_SYM);
 evt.setAttribute("prevval",getFormattedCurrency(evt.value,CURR_SYM));
 evt.className="generaltextboxwhiterightaligned";
}
else
{
if(evt.className=='generaltextbox')
  evt.className="generaltextboxwhite";
evt.setAttribute("prevval",evt.value);
}

//if(evt.name.indexOf('Unitstxt_') == 0 || evt.name.indexOf('txtUnits_') == 0 || evt.name.indexOf('CPTtxt_') == 0 || evt.name.indexOf('txtCPT_') == 0) 
}
function takeActionOnBlur(evt,targetobj)
{
	if(targetobj){
		evt=targetobj;
	}else{
		if(!evt)evt=window.event;
		evt=getTarget(evt);
	}
	
if(evt.value != evt.getAttribute("prevval"))
 setDirty();
var rowNo=evt.name.substring(evt.name.indexOf('_')+1,evt.name.length);
if(!(evt.name.indexOf('Rlutxt') == 0  ||  evt.name.indexOf('Commentstxt_') == 0 || evt.name.indexOf('DOPtxt') == 0 || evt.name.indexOf('Checktxt') == 0 || evt.name.indexOf('defaultDOP') == 0 || evt.name.indexOf('Mod2txt_') == 0 || evt.name.indexOf('Mod3txt_') == 0 || evt.name.indexOf('Mod4txt_') == 0 || evt.name.indexOf('SpDxtxt_') == 0 || evt.name.indexOf('txtCheck_') == 0 || evt.name.indexOf('txtComments_') == 0 || evt.name.indexOf('txtRlu_') == 0 ||  evt.name.indexOf('txtSpDxtxt_') == 0 || evt.name.indexOf('D-X5-20txt_') == 0 ))
{
if(evt.name.indexOf('Chargestxt_') == 0  ||  evt.name.indexOf('Copaytxt_') == 0 || evt.name.indexOf('Paymentstxt') == 0 || evt.name.indexOf('txtCharges_') == 0 || evt.name.indexOf('txtCopay_') == 0 || evt.name.indexOf('txtPayments_') == 0)
evt.className="generaltextboxrightaligned";
else
evt.className="generaltextbox";
}
if(isReferringPicker==1){
if(evt.name.indexOf('Referralcmb_') == 0 || evt.name.indexOf('XReferralcmb_') == 0)
  evt.className="generaltextboxwhite";
}  
if(evt.name.indexOf('DOPtxt_')==0 || evt.name.indexOf('DOStxt_')==0 ||evt.name.indexOf('txtDOP_')==0 || evt.name.indexOf('txtDOS_')==0|| evt.name.indexOf('defaultDOP')==0)
{    
	
   	// evt.value=formatDateOnBlur(evt.value);
   	 formatDateOnBlurLocal(evt);
 } 
if(evt.name.indexOf('hospadm_date_')==0 || evt.name.indexOf('hospdis_date_')==0){
	CheckDate(evt);
}
if(evt.name.indexOf('CPTtxt') == 0 ||  evt.name.indexOf('txtCPT')==0)
{
var prev_val=evt.getAttribute("prevval");
if(evt.value!=prev_val || fromCptPicker==1)
  createNextRow(evt);
}  
else if(evt.name.indexOf('Chargestxt') == 0 || evt.name.indexOf('txtCharges_') == 0 )
{var prev_val=evt.getAttribute("prevval");
 if(getFormattedCurrency(evt.value,CURR_SYM)!=getFormattedCurrency(prev_val,CURR_SYM))
    eval("document.serviceinformation.hdnCharges_" + rowNo).value=getFormattedCurrency(evt.value,CURR_SYM);
 evt.value=setFormattedCurrency(getFormattedCurrency(evt.value,CURR_SYM),CURR_SYM);
}  
else if(evt.name.indexOf('Paymentstxt') == 0 || evt.name.indexOf('txtPayments_') == 0)
 {
  evt.value=setFormattedCurrency(getFormattedCurrency(evt.value,CURR_SYM),CURR_SYM);
   var prev_val=getFormattedCurrency(evt.getAttribute("prevval"),CURR_SYM);
  if(prev_val != getFormattedCurrency(evt.value,CURR_SYM) && getFormattedCurrency(evt.value,CURR_SYM) != 0)
   {
     setPaymentMode(evt.name);
   }
 }
else if(evt.name.indexOf('Copaytxt') == 0)
  {
  var hCharge=eval("document.serviceinformation.hdnCharges_" + rowNo);
  var objNH=eval("document.serviceinformation.Chargestxt_" + rowNo);
  var objUnit=eval("document.serviceinformation.Unitstxt_" + rowNo);
  var copay=getFormattedCurrency(evt.value,CURR_SYM);
  var prev_val=evt.getAttribute("prevval");
  if(copay=='' || copay==' ')
  copay='0.00';
  if(prev_val != evt.value)
   objNH.value=setFormattedCurrency(parseFloat(hCharge.value)*parseFloat(objUnit.value)-parseFloat(copay),CURR_SYM);
  evt.value=setFormattedCurrency(copay,CURR_SYM);
  }
else if(evt.name.indexOf('txtCopay_') == 0)
{
var hCharge=eval("document.serviceinformation.hdnCharges_" + rowNo);
  var objNH=eval("document.serviceinformation.txtCharges_" + rowNo);
  var objUnit=eval("document.serviceinformation.txtUnits_" + rowNo);
  var copay=getFormattedCurrency(evt.value,CURR_SYM);
  var prev_val=evt.getAttribute("prevval");
  if(copay=='' || copay==' ')
  copay='0.00';
  if(prev_val != evt.value)
   objNH.value=setFormattedCurrency(parseFloat(hCharge.value)*parseFloat(objUnit.value)-parseFloat(copay),CURR_SYM);
  evt.value=setFormattedCurrency(copay,CURR_SYM);
}
else if (evt.name.indexOf('Mod1txt_') == 0)
 {
   if(!evt.getAttribute('visited'))
   {
    evt.setAttribute('visited',1);
    calculateDosage(evt);
   } 
       
 }   
else if(evt.name.indexOf('Unitstxt') == 0 )
{
var hCharge=eval("document.serviceinformation.hdnCharges_" + rowNo);
var objNH=eval("document.serviceinformation.Chargestxt_" + rowNo);
var copay=getFormattedCurrency(eval("document.serviceinformation.Copaytxt_" + rowNo).value,CURR_SYM);
var prev_val=evt.getAttribute("prevval");
if(copay=='' || copay==' ')
  copay='0.00';
if(prev_val != evt.value)  
objNH.value=setFormattedCurrency(parseFloat(hCharge.value)*parseFloat(evt.value)-parseFloat(copay),CURR_SYM);
}
else if(evt.name.indexOf('txtUnits') == 0 )
{
var hCharge=eval("document.serviceinformation.hdnCharges_" + rowNo);
var objNH=eval("document.serviceinformation.txtCharges_" + rowNo);
var copay=getFormattedCurrency(eval("document.serviceinformation.txtCopay_" + rowNo).value,CURR_SYM);
var prev_val=evt.getAttribute("prevval");
if(copay=='' || copay==' ')
  copay='0.00';
if(prev_val != evt.value)  
objNH.value=setFormattedCurrency(parseFloat(hCharge.value)*parseFloat(evt.value)-parseFloat(copay),CURR_SYM);
} 
else if (evt.name.indexOf('defaultDOP') == 0)
  {
  if(document.getElementById("DOPtxt_").value!='')
  document.getElementById("DOPtxt_").value=evt.value;
  defaultdateset=evt.value;
  }

else if(evt.name.indexOf('DX')==0 || evt.name.indexOf('D-X5')==0)
{
 var dxNo=parseInt(evt.name.substring(2,3));
 var uniK;
 if(getServiceid()==-1)
  uniK=rowNo;
  else
  uniK=getServiceid();
 if(evt.name.indexOf('DX')==0){
 if(dxNo>1)
  {  
     if(document.getElementById('DX'+(dxNo-1)+'txt_'+uniK).value=='' && evt.value!='')
      {
    	//document.getElementById('DX'+(dxNo-1)+'txt_'+uniK).title='';
        evt.value='';
        alert("Dx"+(dxNo-1)+" missing !");
        dxObj=evt;
        setTimeout("sr_selectDxBox()",0);
        return;
      }
     /*if(dxNo==4)
       checkDxAvailability(uniK);*/  
  }
  var ln=evt.value.length;
  if(ln>9){
    evt.value='';
    alert("Invalid Dx !");
    dxObj=evt;
    setTimeout("sr_selectDxBox()",0);
    return;
   }else if(evt.value=='NO DX' || evt.value=='NODX'||evt.value=='nodx'){
	//Skip if the DX value is NO DX ( As it contains characters)   
   }else if(ln>=4 && (evt.value.indexOf('.')==-1 || evt.value.indexOf('.')>4 || evt.value.indexOf('.')==(ln-1))){
   evt.value='';
    alert("Invalid Dx !");
    dxObj=evt;
    setTimeout("sr_selectDxBox()",0);
    return;
   }else if(!alphanumeric(evt.value.replace('.',''))){
   evt.value='';
    alert("Invalid Dx !");
    dxObj=evt;
    setTimeout("sr_selectDxBox()",0);
    return;
   }
 }
 //gss
  var dupDx=0;
  var dx5to20Dataa=document.getElementById('D-X5-20txt_'+uniK).value;
  for(var i=1;i<5;i++){
	  var dxValue = document.getElementById('DX'+i+'txt_'+uniK).value;
    if((i!= dxNo && dxValue!='' && evt.value!='' && dxValue==evt.value) || (dxValue !='' && evt.value!='' && dx5to20Dataa!='' && dx5to20Dataa.indexOf(dxValue)!=-1))
     dupDx++;
    if(dupDx > 0)
    	break;
  }
  if(dupDx > 0){
	  if(evt.name.indexOf('D-X5')==0){
		  var x=dxValue;
		  alert("The dx "+x+" is already entered !");
		  if((evt.value.indexOf(x) ==0 && evt.value.indexOf(',') > -1) || (evt.value.lastIndexOf(',') == evt.value.length-1 ) || (dx5to20Dataa.indexOf(x+',') > -1))
			  {
			  evt.value=evt.value.replace(dxValue+',','');
			  }
		  else
			  evt.value=evt.value.replace(dxValue,'');
	  }
	  else
	  {  x=evt.value;
	   evt.value='';
	   alert("The dx "+x+" is already entered !");
	   dxObj=evt;
	   setTimeout("sr_selectDxBox()",0);
	  }
  }
}

}
var dxObj;
function sr_selectDxBox(){
 try{dxObj.focus();}catch(e){}
}
function alphanumeric(alphane){
	var numaric = alphane;
	for(var j=0; j<numaric.length; j++){
	var alphaa = numaric.charAt(j);
	 var hh = alphaa.charCodeAt(0);
	 if((hh > 47 && hh<58) || (hh > 64 && hh<91) || (hh > 96 && hh<123)){
	}else{return false;}}
	return true;
}


function sr_createCell(name,width,styleclass,tvalue,styleclassfortd,type,comboval,control,cellwidth,span)
{
var tdobj=document.createElement('td');
tdobj.className=styleclassfortd;
tdobj.colSpan=span;
tdobj.style.width=cellwidth;
//tdobj.style.width="15%";
tdobj.noWrap=true;
var box=createTextBoxNew(name,cellwidth,styleclass,tvalue,type,comboval,control,width);
if(name.indexOf('DX2')==0 ||name.indexOf('DX3')==0 ||name.indexOf('DX4')==0)
 tdobj.appendChild(createImage(control,2));
tdobj.appendChild(box);
if(name.indexOf('DX1')==0 || name.indexOf('DX2')==0 ||name.indexOf('DX3')==0 )
 tdobj.appendChild(createImage(control,1));

return tdobj;
} 

function createImage(row,x)
{
var dxmove=document.createElement("img" );
var rowid=row.split('~')[0];
var n=row.split('~')[1];
if(x==1)
{
dxmove.src="../../../images/sr_left.gif";
n=parseInt(n);
}
else if(x==2)
{
dxmove.src="../../../images/sr_right.gif";
n=parseInt(n)-1;
}
dxmove.style.cursor='pointer';
dxmove.title='Swap Dx.';
dxmove.width=11;
dxmove.onclick=function(){
		swapDx(rowid,n);
	}
return 	dxmove;
}
var thisCombo;
function setValueFromCombo(evt)
{
if(!evt)evt=window.event;
var comb=getTarget(evt);
var cell=comb.parentNode;
var name=comb.getAttribute("name");
var len=comb.getAttribute("user-size");
var orival=comb.getAttribute("orival");
var celW=cell.style.width;
var control=comb.getAttribute("controlvalue");
var defVal=comb.value;
thisCombo="";
var width=(comb.offsetWidth-1);

if ( cell.hasChildNodes() )	{
		while ( cell.childNodes.length >= 1 ){	cell.removeChild( cell.firstChild );}
}
var newbox;
if(name.indexOf('X')==0)
newbox=createTextBoxNew(name,celW,'dropdn generaltextboxwhite',getValueFromPool(defVal, control),'combo',defVal,control,-100);
else
newbox=createTextBoxNew(name,len,'dropdn generaltextboxwhite',getValueFromPool(defVal, control),'combo',defVal,control,-1);	
newbox.setAttribute("orival",orival);
cell.appendChild(newbox);
if(window.ActiveXObject){}
else{
newbox.focus();}
if(getServiceid()==-1 && editDOS=='')
  {
     if(name.indexOf('VisitTypecmb_') ==0 )
        updateCptCharge(name);
       
     if(name.indexOf('SDoctorcmb_') ==0 && doctorCombinationCheck==1)
        updateBillingAndRDoctor();   
     if(name.indexOf('CPTGroupcmb_') ==0 )
       loadCPTGroupData();   
  }
  
 
/*
if(name.indexOf('Primarycmb_')==0 && getServiceid()==-1)
{
evt=getTarget(evt);
var ins_name=getValueFromPool(parseInt(evt.value), 20);
if(ins_name.indexOf('self pay')==-1 && ins_name.indexOf('selfpay')==-1 && ins_name.indexOf('SELF PAY')==-1 && ins_name.indexOf('SELFPAY')==-1)
 changeSubmitStatus(evt,name);
} */
}

var current_combo;
function createComboBox(evt)
{
if(evt.keyCode==32 || evt.type=='click' )
{
var tex=getTarget(evt);
var cell=tex.parentNode;
current_combo=cell;
var defVal=tex.getAttribute("comboval");
var cntl=tex.getAttribute("controlvalue");
var orival=tex.getAttribute("orival");
var width=(tex.offsetWidth-1)+"px";
if ( cell.hasChildNodes() )	{
		while ( cell.childNodes.length >= 1 ){	cell.removeChild( cell.firstChild );}
}		
var combo=document.createElement('select');
combo.style.width=width;
combo.tabIndex=1;
combo.setAttribute("name",tex.name);
combo.setAttribute("user-size",tex.size);
combo.setAttribute("controlvalue",cntl);
combo.setAttribute("orival",orival);
combo.id='sr_common_combo';
combo.onblur=function(event){
setValueFromCombo(event);
}
combo.onchange=function(event){
setDirty();
setValueOnChageFromCombo(event);
}
var a=selectPool.get(cntl);
a=eval(a);
try
{
// this block is added to draw group combo
if(cntl==171){
var opt=document.createElement('option');
 opt.value='-1';
 opt.appendChild(textNode('None'));
 combo.appendChild(opt);
var oldPos;
var optIn;
var check=0;
for(i=0;i<a.length;i++)
{
check=1;
if(eval(a[i]).hsp003 != oldPos){
 if(i==0){
  opt=document.createElement('optgroup');
  opt.setAttribute('label',eval(a[i]).hsp003);
 }
 else{
  combo.appendChild(opt);
  opt=document.createElement('optgroup');
  opt.setAttribute('label',eval(a[i]).hsp003);
  }
  
} 
optIn=document.createElement('option');
optIn.value=eval(a[i]).hsp001;
optIn.appendChild(textNode(eval(a[i]).hsp002));
opt.appendChild(optIn);
oldPos=eval(a[i]).hsp003;
}
if(check==1)
 combo.appendChild(opt);
 }//end of the new block
else{
var opt=document.createElement('option');
 opt.value='-1';
 opt.appendChild(textNode('None'));
 combo.appendChild(opt);
for(i=0;i<a.length;i++)
{
opt=document.createElement('option');
opt.value=eval(a[i]).hsp001;
opt.appendChild(textNode(eval(a[i]).hsp002));
if(tex.name.indexOf('Authcmb_')==0 && editDOS=='' && getServiceid()==-1)
{
  if(addAuth(tex.name,eval(a[i])))
    combo.appendChild(opt);
}
else
 combo.appendChild(opt);
}
}
}
catch(e){}
combo.value=defVal;
cell.appendChild(combo);
if(!document.all)
combo.focus();
else
{
  if(navigator.appVersion.indexOf("MSIE 7.")!=-1)
   setTimeout("sr_focusObj()",500);
  else
  setTimeout("sr_focusObj()",100);
}
}
}

function sr_focusObj(){
current_combo.firstChild.focus();
}

function locateCell(x)
{
var sel=getTarget(x);
var cell=sel.parentNode;
var row=cell.parentNode;
}

function setValueOnChageFromCombo(evt)
{
if(!evt)evt=window.event;
evt=getTarget(evt);
var na=evt.name;
if(na=='defaultDoctor' )
{
document.getElementById('SDoctorcmb_').value=getValueFromPool(evt.value,16);
document.getElementById('SDoctorcmb_').setAttribute('comboval',evt.value);
defaultDoctor=evt.value;
}
else if(na.indexOf('SDoctorcmb_')==0 && allowSBDoctorCombination==1 )
{
	setConfiguredBillingDoctor(evt.value);
}
else if(na=='defaultBillingDoctor' )
{
document.getElementById('BDoctorcmb_').value=getValueFromPool(evt.value,16);
document.getElementById('BDoctorcmb_').setAttribute('comboval',evt.value);
defaultBillingDoctor=evt.value;
}
else if(na=='defaultPOS' )
{
document.getElementById('POScmb_').value=getValueFromPool(evt.value,171);
document.getElementById('POScmb_').setAttribute('comboval',evt.value);
defaultPOS=evt.value;;
}
/*else if(na.indexOf('Primarycmb_')==0 && getServiceid()==-1)
{
var ins_name=getValueFromPool(parseInt(evt.value), 20);
changeSubmitStatus(evt);
}*/
else if(na.indexOf('Statuscmb_')==0){   // && getServiceid()!=-1 
	var na_l=na.substring(na.indexOf('_')+1,na.length);
	var cptObj=document.getElementById('CPTtxt_'+na_l);
	if(!checkSubmitStatus(evt,cptObj,1)){
	document.getElementById('Statuscmb_'+na_l).value=getValueFromPool(evt.getAttribute('orival'),11);
	document.getElementById('Statuscmb_'+na_l).setAttribute('comboval',evt.getAttribute('orival'));
	}else{
		setOnHoldAction(na,evt,evt.getAttribute('orival'));
	}
}
else if(na.indexOf('Statuscmb_')==0 && getServiceid()==-1 ){
		setOnHoldAction(na,evt,evt.getAttribute('orival'));
	}
}
function setOnHoldAction(name,idVal,defVal){
	if(name.indexOf('Statuscmb_')==0){
	   var newIndex=idVal.selectedIndex;
	   var ssVal=idVal.options[idVal.selectedIndex].text;
   	   if(ssVal.toLowerCase()=='on hold'){
	  	showAROnHoldDiv(name,idVal,defVal);
       }else{
    	removeSelOnHoldData(ssVal,name);
       }
 }
}
var setConfiguredBillingDoctor = function(selval){
	var ele=selectPool.get(53);
	var firstG=eval("("+ele+")");
	var firstLength=firstG.length;
	var tempobj;
	for(var i=0;i<firstLength;i++){
		tempobj = firstG[i];
		if(tempobj.sdoctor == selval){
			document.getElementById('BDoctorcmb_').value=getValueFromPool(tempobj.bdoctor,16);
			document.getElementById('BDoctorcmb_').setAttribute('comboval',tempobj.bdoctor);
			break;
		}
	}
}

function eraseDefaults()
{
defaultPOS=-100;
defaultBillingDoctor=-100;
defaultDoctor=-100;
defaultdateset=defaultdate;
document.getElementById('defaultDOP').value=defaultdate;
document.getElementById('defaultBillingDoctor').value='None';
document.getElementById('defaultBillingDoctor').setAttribute('comboval',-1);
document.getElementById('defaultPOS').value='None';
document.getElementById('defaultPOS').setAttribute('comboval',-1);
document.getElementById('defaultDoctor').value='None';
document.getElementById('defaultDoctor').setAttribute('comboval',-1);
var dataobj=eval("("+selectPool.get(19)+")");
document.getElementById('SDoctorcmb_').value=getValueFromPool(dataobj.pridoctorid,16);
document.getElementById('SDoctorcmb_').setAttribute('comboval',dataobj.pridoctorid);
document.getElementById('BDoctorcmb_').value=getValueFromPool(dataobj.pridoctorid,16);
document.getElementById('BDoctorcmb_').setAttribute('comboval',dataobj.pridoctorid);
document.getElementById('POScmb_').value=getValueFromPool(dataobj.posid,171);
document.getElementById('POScmb_').setAttribute('comboval',dataobj.posid);
document.getElementById('DOPtxt_').value=defaultdate;
}

function showValidationProgress()
{
//window.top.showValidation();
var d=document.getElementById('showOnlyPopUp');
document.getElementById('eventBlocker').style.display='block';
d.style.left="400px";
d.style.top="200px";
//d.innerHTML="<div id='validationPDiv' style='display:block;background-color:#E4F6FA;border:2px solid black;position:absolute;z-index:111;left:400px;top:200px;width:300px;height:100px;'><font color=red>Validation in progress ...</font></div>";
//d.innerHTML="<div id='validationPDiv' style='background-color:#E4F6FA;border:2px solid black;position:absolute;z-index:111;left:400px;top:200px;width:300px;height:100px;'><font color=red>Validation in progress ...</font></div>";
//d.innerHTML="<table bgcolor='#E4F6FA' style='border-collapse:collapse;border:2px solid black'><tr height='50px'><td><img src='../../../images/Ajax/Glace-Data-loader.gif' /></td><td><font color=red>Validation in progress. Please wait ...</font></td><td><a onclick='this.blur();' class='btn onbtn' href='javascript:stopValidation();'  title='Stop validation'><b><b><b>Stop</b></b></b></a></td></tr></table>";
d.innerHTML="<table bgcolor='#E4F6FA' style='border-collapse:collapse;border:2px solid black'><tr height='50px'><td><img src='../../../images/Ajax/Glace-Data-loader.gif' /></td><td><div id='validationmes'><font color=red>Validation in progress. Please wait ...</font><div></td></tr></table>";
d.style.display='block'; 
}

function sr_hideValidationDiv()
{

document.getElementById('showOnlyPopUp').style.display='none';
document.getElementById('eventBlocker').style.display='none';
//window.top.hideValidation();
isValidating=0;
commonStr="";
detailStr="";
}
function stopValidation()
{
sr_hideValidationDiv();
stopProcess();
}
function checkDxAvailability(row)
{
var dx1=document.getElementById('DX1txt_'+row).value;
var dx2=document.getElementById('DX2txt_'+row).value;
var dx3=document.getElementById('DX3txt_'+row).value;
var dx4=document.getElementById('DX4txt_'+row).value;
var callback={
	success:sr_callSuccess2,
	failure:sr_callFailure2,
	progress:sr_callProgress2
	}
getAjaxDataFromServer("../ServiceEntry.Action","action=2&dx1="+dx1+"&dx2="+dx2+"&dx3="+dx3+"&dx4="+dx4,false,callback);	
}

var sr_callSuccess2=function(responseObject)
{
var res=eval(responseObject.responseText);
var dxdata=eval(eval(res)[0]);
var result="";
var check=0;
if(dxdata.dxst4=='0' && dxdata.dxcode4!='')
{check=1;
  result=dxdata.dxcode4;}
if(dxdata.dxst3=='0' && dxdata.dxcode3!='')
{
check=1;
  if(result=='')
    result= dxdata.dxcode3;
  else   
    result= dxdata.dxcode3+", "+result;
 }     
if(dxdata.dxst2=='0' && dxdata.dxcode2!='')
{check=1;
  if(result=='')
    result= dxdata.dxcode2;
  else   
    result= dxdata.dxcode2+", "+result;
 }
if(dxdata.dxst1=='0' && dxdata.dxcode1!='')
{check=1;
  if(result=='')
    result= dxdata.dxcode1;
  else   
    result= dxdata.dxcode1+", "+result;
 }
result=result+" diagnosis code not present in the system."

if(check==1)
 alert(result);  
}
var sr_callFailure2=function(responseObject){}
var sr_callProgress2=function(responseObject){}
function minimizeValidationDiv()
{
if(document.getElementById('postit_content').style.display=='none')
{
document.getElementById('sr_minimize').src="../../../images/alertminus.gif";
document.getElementById('postit_content').style.display='block';
document.getElementById('postit').style.left='300px';
document.getElementById('postit').style.top='200px';
document.getElementById('postit').style.height='178px';
}
else
{
document.getElementById('sr_minimize').src="../../../images/alertplus.gif";
document.getElementById('postit_content').style.display='none';
document.getElementById('postit').style.left='620px';
document.getElementById('postit').style.top=(document.body.clientHeight-20)+'px';
document.getElementById('postit').style.height='20px';
}
}
function closeValidationDiv()
{
document.getElementById('postit').style.display='none';
}	
var closingPayDiv=0;
function closingPay()
{
closingPayDiv=1;
}
var source_name;
function setPaymentMode(name)
{
var payDiv=document.getElementById('paymentDiv');
var payCombo=document.getElementById('payDivCombo');
var left=findPosX(document.getElementById(name),false);
var top=findPosY(document.getElementById(name),false);
source_name=name;
closingPayDiv=0;
if(!payCombo)
{
payCombo=document.createElement('select');
//payCombo.style.width="20px";
payCombo.tabIndex=1;
payCombo.setAttribute("name","payDivCombo");
payCombo.setAttribute("user-size","20");
payCombo.setAttribute("controlvalue",13);
payCombo.id='payDivCombo';
//payCombo.setAttribute("source_name",name);
payCombo.onblur=function(event){
//setValueOnChageFromCombo(event);
setPaymentModeValue(event);
}
payCombo.onchange=function(event){
setDirty();
}
var a=selectPool.get(13);
a=eval(a);
//var opt=document.createElement('option');
 //opt.value='-1';
 //opt.appendChild(textNode('None'));
 //payCombo.appendChild(opt);
for(i=0;i<a.length;i++)
{
opt=document.createElement('option');
opt.value=eval(a[i]).hsp001;
opt.appendChild(textNode(eval(a[i]).hsp002));
payCombo.appendChild(opt);
}

var tab=document.createElement('table');
var tbod= document.createElement('tbody');
var trow=document.createElement('tr');
var td1=document.createElement('td');
var textE=document.createTextNode('Payment Mode ');
td1.appendChild(textE);
var td2=document.createElement('td');
td2.appendChild(payCombo);
td2.colSpan="2";
trow.appendChild(td1);
trow.appendChild(td2);
tbod.appendChild(trow);
trow=document.createElement('tr');
td1=document.createElement('td');
textE=document.createTextNode('Check No. ');
td1.appendChild(textE);
td2=document.createElement('td');
var checkBox=document.createElement('input');
checkBox.id='payCheckBox';
checkBox.size=6;
checkBox.onblur=function(event){
//setValueOnChageFromCombo(event);
setCheckModeValue(event);
}
checkBox.onchange=function(event){
setDirty();
} 
var textCloseLink=document.createElement('a');
textCloseLink.setAttribute("href","javascript:closingPay();javascript:closePayDiv();");
var textClose=textNode('Close');
textCloseLink.appendChild(textClose);
trow.appendChild(td1);
td2.appendChild(checkBox);
var td3=document.createElement('td');
td2.appendChild(textCloseLink);
trow.appendChild(td1);
trow.appendChild(td2);
trow.appendChild(td3);
tbod.appendChild(trow);
tab.appendChild(tbod);
payDiv.appendChild(tab);

}
var unik=name.substring(name.indexOf('_')+1,name.length);
var howid=-1;
var cNo="";
if(editDOS=='')
{
howid=parseInt(document.getElementById('HowPaidcmb_'+unik).getAttribute("comboval"));
cNo=document.getElementById('Checktxt_'+unik).value;
}
else
{
howid=parseInt(document.getElementById('XHowPaidcmb_'+unik).getAttribute("comboval"));
cNo=document.getElementById('txtCheck_'+unik).value;
}
if(howid > 0)
{
document.getElementById("payDivCombo").value=howid;
if(howid == 2)
document.getElementById("payCheckBox").value=cNo;
else
 document.getElementById("payCheckBox").value="";
}
payDiv.style.display='block';
payDiv.style.top=top+"px";
payDiv.style.left=(left+20)+"px";
try{
payCombo.focus();}catch(e){}
}

function setPaymentModeValue(evt)
{
if(!evt)evt=window.event;
evt=getTarget(evt);
var sr_name=source_name;
var ele_name=sr_name.substring(sr_name.indexOf('_')+1,sr_name.length);
var uniqueKey;
if(getServiceid() < 1)
uniqueKey=ele_name;
else
uniqueKey=getServiceid();
if(evt.value==2)
{try{
 document.getElementById('payCheckBox').focus();}catch(e){}
} 
else
{
  if(editDOS=='')
  {
  document.getElementById('HowPaidcmb_'+uniqueKey).value=getValueFromPool(evt.value, 13);
  document.getElementById('HowPaidcmb_'+uniqueKey).setAttribute("comboval",evt.value);
  }
  else
  {
  document.getElementById('XHowPaidcmb_'+uniqueKey).value=getValueFromPool(evt.value, 13);
  document.getElementById('XHowPaidcmb_'+uniqueKey).setAttribute("comboval",evt.value);
  }
  closingPayDiv=0;
  closePayDiv();
}
}

function setCheckModeValue(evt)
{
if(!evt)evt=window.event;
evt=getTarget(evt);
var ele=document.getElementById('payDivCombo');
var sr_name=source_name;
var ele_name=sr_name.substring(sr_name.indexOf('_')+1,sr_name.length);
var uniqueKey;
if(getServiceid() < 1)
uniqueKey=ele_name;
else
uniqueKey=getServiceid();
if(evt.value=='' && ele.value==2)
{alert("Enter check no.");
 document.getElementById('payCheckBox').focus();
 setTimeout("focusCheckBox()",10);
 }
else
{
  if(editDOS=='')
  document.getElementById('Checktxt_'+uniqueKey).value=evt.value;
  else
  document.getElementById('txtCheck_'+uniqueKey).value=evt.value;
  closingPayDiv=0;
  closePayDiv();
}
}
function focusCheckBox()
{
document.getElementById('payCheckBox').focus();
}

function closePayDiv()
{
var x=document.getElementById('payDivCombo');
var y=document.getElementById('payCheckBox');
var sr_name=source_name;
var ele_name=sr_name.substring(sr_name.indexOf('_')+1,sr_name.length);
var uniqueKey;
if(getServiceid() < 1)
uniqueKey=ele_name;
else
uniqueKey=getServiceid();
if(editDOS==''){
document.getElementById('HowPaidcmb_'+uniqueKey).value=getValueFromPool(x.value, 13);
document.getElementById('HowPaidcmb_'+uniqueKey).setAttribute("comboval",x.value);
document.getElementById('Checktxt_'+uniqueKey).value=y.value;  
}
else
{
document.getElementById('XHowPaidcmb_'+uniqueKey).value=getValueFromPool(x.value, 13);
document.getElementById('XHowPaidcmb_'+uniqueKey).setAttribute("comboval",x.value);
document.getElementById('txtCheck_'+uniqueKey).value=y.value; 
}
if(!(x.value == 2 && y.value==''))
 document.getElementById('paymentDiv').style.display='none';
if(closingPayDiv == 0)
{
x.value=1;
y.value='';
source_name='';
}
if(editDOS=='')
document.getElementById('DX1txt_'+uniqueKey).focus();
else
document.getElementById('txtDX1_'+uniqueKey).focus();
}

var current_rowString="";
var current_plan_no=-1;
function updateCptCharge(obj)
{
var rowid=obj.substring(obj.indexOf('_')+1,obj.length);
var cptString="";
var rowString="";
var cptEle;
//for(var i=0;i<rowcount;i++)
//{
try{
cptEle=document.getElementById('CPTtxt_'+rowid);
if(cptEle.value!='')
{
if(cptString=='')
{
cptString+="'"+cptEle.value+"'";
rowString+=i;
}
else
{
cptString+=",'"+cptEle.value+"'";
rowString+=","+i;
}
}
}
catch(e){}
//}
//current_rowString=rowString;
current_rowString=rowid;
var callback={
	success:sr_callSuccess12,
	failure:sr_callFailure12,
	progress:sr_callProgress12
	}
var plan=document.getElementById("VisitTypecmb_"+rowid);
var plan_no=getValueFromPool(plan.getAttribute("comboval"), 10);
if(plan_no=='None')
 plan_no=-1;
 else
plan_no= parseInt(plan_no.substring(0,plan_no.indexOf('-')));
current_plan_no=plan_no;
getAjaxDataFromServer("../ServiceEntry.Action","patientId="+PATIENT_ID+"&action=3&cptCode="+cptString+"&cptPlan="+plan_no+"&randNo="+Math.floor(Math.random()*1121),false,callback);
}
var sr_callFailure12=function(responseObject){} 
var sr_callProgress12=function(responseObject){}
var sr_callSuccess12=function(responseObject)
{
var res=eval(responseObject.responseText);
var s=eval(eval(res)[0]);
var cptdata=eval(s.cptdat);
//var cptmodel=eval(cptdata)[0];
var row_array=current_rowString.split(',');
var code,rate,rowid,copay,unit;
for(var j=0;j<row_array.length;j++)
{
//rowid=PATIENT_ID+'_'+row_array[j];
rowid=row_array[j];
code=eval("document.serviceinformation.CPTtxt_" + rowid).value;
rate=getCostByCode(cptdata,code);
copay=eval("document.serviceinformation.Copaytxt_" + rowid).value;
unit=eval("document.serviceinformation.Unitstxt_" + rowid).value;
eval("document.serviceinformation.hdnCharges_" + rowid).value=rate;
eval("document.serviceinformation.Chargestxt_" + rowid).value=setFormattedCurrency(parseFloat(getFormattedCurrency(rate,CURR_SYM))*parseInt(unit)-parseFloat(getFormattedCurrency(copay,CURR_SYM)),CURR_SYM);
document.getElementById('CostPlancmb_'+rowid).value=getValueFromPool(current_plan_no, 12);
document.getElementById('CostPlancmb_'+rowid).setAttribute("comboval",current_plan_no);
}
}

function getCostByCode(model,code)
{
var cost=0;
for(var i=0;i<model.length;i++)
 {
 if(code==model[i].cptcode)
     cost=model[i].rate;
 }
return cost; 
}

function getCPTString()
{
var CPTString="";
var cptEle;
if(getServiceid()== -1)
{
for(var i=0;i<rowcount;i++)
{
 try{
  cptEle=document.getElementById('CPTtxt_'+PATIENT_ID+'_'+i);
  if(CPTString =='')
    CPTString=cptEle.value;
  else
    CPTString=CPTString+','+cptEle.value;
  }
 catch(e){} 
}
}
else if(getServiceid() > 0)
{
cptEle=document.getElementById('CPTtxt_'+getServiceid());
CPTString=cptEle.value;
}
else if(editDOS != '')
{
CPTString=editCPT;
}
return CPTString;
}


function getSDoctorString()
{
var SDoctorString="";
var sDocEle;
/*for(var i=0;i<rowcount;i++)
{
 try{
  sDocEle=document.getElementById('SDoctorcmb_'+PATIENT_ID+'_'+i);
  if(SDoctorString =='')
    SDoctorString=sDocEle.getAttribute('comboval');
  else
    SDoctorString=SDoctorString+','+sDocEle.getAttribute('comboval');
  }
 catch(e){} 
}*/
try{
  sDocEle=document.getElementById('SDoctorcmb_');
  SDoctorString=sDocEle.getAttribute('comboval');
  }
 catch(e){}
return SDoctorString;
}

function getBDoctorString()
{
var BDoctorString="";
var bDocEle;
/*for(var i=0;i<rowcount;i++)
{
 try{
  bDocEle=document.getElementById('BDoctorcmb_'+PATIENT_ID+'_'+i);
  if(BDoctorString =='')
    BDoctorString=bDocEle.getAttribute('comboval');
  else
    BDoctorString=BDoctorString+','+bDocEle.getAttribute('comboval');
  }
 catch(e){} 
}*/
try{
  bDocEle=document.getElementById('BDoctorcmb_');
   BDoctorString=bDocEle.getAttribute('comboval');
  }
 catch(e){}
return BDoctorString;
}

function getPOSString()
{
var POSString="";
var posEle;
/*for(var i=0;i<rowcount;i++)
{
 try{
  posEle=document.getElementById('POScmb_'+PATIENT_ID+'_'+i);
  if(POSString =='')
    POSString=posEle.getAttribute('comboval');
  else
    POSString=POSString+','+posEle.getAttribute('comboval');
  }
 catch(e){} 
}*/
try{
  posEle=document.getElementById('POScmb_');
  POSString=posEle.getAttribute('comboval');
  }
 catch(e){}

return POSString;
}


function getInsuranceString()
{
var InsString="";
var insEle;
/*for(var i=0;i<rowcount;i++)
{
 try{
  insEle=document.getElementById('Primarycmb_'+PATIENT_ID+'_'+i);
  if(InsString =='')
    InsString=insEle.getAttribute('comboval');
  else
    InsString=InsString+','+insEle.getAttribute('comboval');
  }
 catch(e){} 
}*/
 try{
  insEle=document.getElementById('Primarycmb_'+PATIENT_ID+'_'+i);
   InsString=insEle.getAttribute('comboval');
  }
 catch(e){} 

return InsString;
}

function convertDateToSqliteFormat(dateStr)
{
var dStr=dateStr.split('/');
var day="";
var month="";
if(dStr[0].length ==1)
month="0"+dStr[0];
else
month=dStr[0];

if(dStr[1].length ==1)
day="0"+dStr[1];
else
day=dStr[1];
return dStr[2]+"-"+month+"-"+day;
}

function addAuth(name,ele)
{
var cDate,sDate,eDate;
var remainAuth=-1;
var unik=name.substring(name.indexOf('_')+1,name.length);
cDate = new Date(document.getElementById('DOStxt_'+unik).value);
sDate =new Date(ele.hsp003);
eDate=new Date(ele.hsp004);
remainAuth=parseInt(ele.hsp006);
if((cDate >= sDate) && (cDate<=eDate) && (remainAuth > 0))
  return true;
else
  return false;  
}

function checkAuth(authNo)
{
var a=selectPool.get(6);
var b=selectPool.get(20);
b=eval(b);
a=eval(a);
var doc=parseInt(document.getElementById('SDoctorcmb_').getAttribute("comboval"));
var ins=parseInt(document.getElementById('Primarycmb_').getAttribute("comboval"));
var insAdd=-1;
var check=0;
for(var k=0;k<b.length;k++)
{
 if(ins==parseInt(b[k].hsp001))
	insAdd=parseInt(b[k].hsp003);
}
for(var i=0;i<a.length;i++)
{
 if(a[i].hsp001 == authNo)
 {
    if(doc != parseInt(a[i].hsp005))
    {
    	alert("Authorisation Doctor and service Doctor mismatch !");
    	return false;
    }
    if(insAdd != parseInt(a[i].hsp007))
    {
    	alert("Authorisation Insurance and service Insurance mismatch !");
    	return false;
    }
   check=1; 
 }
}
if(check==0)
{
	alert("Problem is authorisation !");
	return false;
}
else
 return true;
}

function changeSubmitStatus(evt)
{
var ins_name=getValueFromPool(parseInt(evt.value), 20);
var statusEle;
if(ins_name.indexOf('self pay') >-1 || ins_name.indexOf('selfpay') >-1 || ins_name.indexOf('SELF PAY') > -1 || ins_name.indexOf('SELFPAY')>-1 || ins_name.indexOf('Self Pay')>-1 || ins_name.indexOf('SelfPay')>-1 || ins_name.indexOf('SelfPay')>-1 )
{
for(var i=0;i<rowcount;i++)
{
 try{
	  statusEle=document.getElementById('Statuscmb_'+PATIENT_ID+'_'+i);
	  statusEle.setAttribute("comboval","T");
	  statusEle.value="Ready for Patient Billing";
	  document.getElementById('cmbStatus_'+PATIENT_ID+'_'+i).value='T';
  }
  catch(e){}
}
}
else
{
for(var i=0;i<rowcount;i++)
{
 try{
	  statusEle=document.getElementById('Statuscmb_'+PATIENT_ID+'_'+i);
	  statusEle.setAttribute("comboval","0");
	  statusEle.value="EMR Service";
  document.getElementById('cmbStatus_'+PATIENT_ID+'_'+i).value='0';
  }
  catch(e){}
}
}
}

function getDistinctDos()
{
var dos="";
var dosEle;
for(var i=0;i<rowcount;i++)
{
 try{
  dosEle=document.getElementById('DOStxt_'+PATIENT_ID+'_'+i).value;
  if(i==0)
   {
     if(dos.indexOf(dosEle) == -1)
      dos=dosEle;
   }
   else
	{
	if(dos.indexOf(dosEle) == -1)
	 dos=dos+"~"+dosEle;
	}   
  
  }
  catch(e){}
}
return dos;
}

function getCurrentDate(str)
{
str=str.substring(str.indexOf('_')+1,str.length);
var dateval="";
var row=parseInt(str)-1;
for(var j=row;j>=0;j--)
{
  try{
   dateval=document.getElementById('DOStxt_'+PATIENT_ID+'_'+j).value;
   if(dateval!='')
      j=-1;
   }
  
  catch(e){}
}
if(dateval=='')
return defaultdate;
else
return dateval;
}

function validationRule()
{
var win = window.open( "../../../jsp/billing/superbill/ServiceValidationRule.jsp","Validation_Rule","left=200,top=200, width=700, height=365, scrollbar=no, resizable=no");
}

function prepareLogData(id)
{
var logStr="Service edited ";
if(document.getElementById('DOPtxt_').value !=document.getElementById('DOPtxt_').getAttribute('orival'))
 logStr=logStr+"DOP changed from "+document.getElementById('DOPtxt_').getAttribute('orival')+" to "+document.getElementById('DOPtxt_').value;
if(parseInt(document.getElementById('SDoctorcmb_').getAttribute('comboval'))!=parseInt(document.getElementById('SDoctorcmb_').getAttribute('orival')))
 logStr=logStr+"Service doctor changed from "+getValueFromPool(parseInt(document.getElementById('SDoctorcmb_').getAttribute('orival')), 16)+" to "+getValueFromPool(parseInt(document.getElementById('SDoctorcmb_').getAttribute('comboval')), 16)+" ";
if(parseInt(document.getElementById('POScmb_').getAttribute('comboval'))!=parseInt(document.getElementById('POScmb_').getAttribute('orival')))
 logStr=logStr+"POS changed from "+getValueFromPool(parseInt(document.getElementById('POScmb_').getAttribute('orival')), 171)+" to "+getValueFromPool(parseInt(document.getElementById('POScmb_').getAttribute('comboval')), 171)+" ";

if(parseInt(document.getElementById('ServiceTypecmb_').getAttribute('comboval'))!=parseInt(document.getElementById('ServiceTypecmb_').getAttribute('orival')))
 logStr=logStr+"Service type from "+getValueFromPool(parseInt(document.getElementById('ServiceTypecmb_').getAttribute('orival')), 10)+" to "+getValueFromPool(parseInt(document.getElementById('ServiceTypecmb_').getAttribute('comboval')), 10)+" ";
	
if(parseInt(document.getElementById('BDoctorcmb_').getAttribute('comboval'))!=parseInt(document.getElementById('BDoctorcmb_').getAttribute('orival')))
 logStr=logStr+"Billing doctor changed from "+getValueFromPool(parseInt(document.getElementById('BDoctorcmb_').getAttribute('orival')), 16)+" to "+getValueFromPool(parseInt(document.getElementById('BDoctorcmb_').getAttribute('comboval')), 16)+" ";

if(parseInt(document.getElementById('Primarycmb_').getAttribute('comboval'))!=parseInt(document.getElementById('Primarycmb_').getAttribute('orival')))
 logStr=logStr+"Primary insurance changed from "+getValueFromPool(parseInt(document.getElementById('Primarycmb_').getAttribute('orival')), 20)+" to "+getValueFromPool(parseInt(document.getElementById('Primarycmb_').getAttribute('comboval')), 20)+" ";	
	
if(parseInt(document.getElementById('Casecmb_').getAttribute('comboval'))!=parseInt(document.getElementById('Casecmb_').getAttribute('orival')))
 logStr=logStr+"Case changed from "+getValueFromPool(parseInt(document.getElementById('Casecmb_').getAttribute('orival')), 7)+" to "+getValueFromPool(parseInt(document.getElementById('Casecmb_').getAttribute('comboval')), 7)+" ";
 
if(parseInt(document.getElementById('Referralcmb_').getAttribute('comboval'))!=parseInt(document.getElementById('Referralcmb_').getAttribute('orival')))
 logStr=logStr+"Referral doctor changed from "+getValueFromPool(parseInt(document.getElementById('Referralcmb_').getAttribute('orival')), 18)+" to "+getValueFromPool(parseInt(document.getElementById('Referralcmb_').getAttribute('comboval')), 18)+" ";
 
if(parseInt(document.getElementById('Secondcmb_').getAttribute('comboval'))!=parseInt(document.getElementById('Secondcmb_').getAttribute('orival')))
 logStr=logStr+"Secondary insurance changed from "+getValueFromPool(parseInt(document.getElementById('Secondcmb_').getAttribute('orival')), 21)+" to "+getValueFromPool(parseInt(document.getElementById('Secondcmb_').getAttribute('comboval')), 21)+" ";
 
if(parseInt(document.getElementById('OrDoctorcmb_').getAttribute('comboval'))!=parseInt(document.getElementById('OrDoctorcmb_').getAttribute('orival')))
 logStr=logStr+"Or doctor changed from "+getValueFromPool(parseInt(document.getElementById('OrDoctorcmb_').getAttribute('orival')), 16)+" to "+getValueFromPool(parseInt(document.getElementById('OrDoctorcmb_').getAttribute('comboval')), 16)+" ";
if(parseInt(document.getElementById('typeOfServicecmb_').getAttribute('comboval'))!=parseInt(document.getElementById('typeOfServicecmb_').getAttribute('orival')))
 logStr=logStr+"Type of service changed from "+getValueFromPool(parseInt(document.getElementById('typeOfServicecmb_').getAttribute('orival')), 15)+" to "+getValueFromPool(parseInt(document.getElementById('typeOfServicecmb_').getAttribute('comboval')), 15)+" ";
  
if(document.getElementById('Statuscmb_'+id).getAttribute('comboval')!=document.getElementById('Statuscmb_'+id).getAttribute('orival'))
	 logStr=logStr+"Submit status changed from "+getValueFromPool(document.getElementById('Statuscmb_'+id).getAttribute('orival'), 11)+" to "+getValueFromPool(document.getElementById('Statuscmb_'+id).getAttribute('comboval'), 11)+" ";

if(parseInt(document.getElementById('CostPlancmb_'+id).getAttribute('comboval'))!=parseInt(document.getElementById('CostPlancmb_'+id).getAttribute('orival')))
 logStr=logStr+"Rate plan changed from "+getValueFromPool(parseInt(document.getElementById('CostPlancmb_'+id).getAttribute('orival')), 12)+" to "+getValueFromPool(parseInt(document.getElementById('CostPlancmb_'+id).getAttribute('comboval')), 12)+" ";
if(parseInt(document.getElementById('HowPaidcmb_'+id).getAttribute('comboval'))!=parseInt(document.getElementById('HowPaidcmb_'+id).getAttribute('orival')))
 logStr=logStr+"How paid changed from "+getValueFromPool(parseInt(document.getElementById('HowPaidcmb_'+id).getAttribute('orival')), 13)+" to "+getValueFromPool(parseInt(document.getElementById('HowPaidcmb_'+id).getAttribute('comboval')), 13)+" ";	
if(parseInt(document.getElementById('Authcmb_'+id).getAttribute('comboval'))!=parseInt(document.getElementById('Authcmb_'+id).getAttribute('orival')))
 logStr=logStr+"Authorization changed from "+getValueFromPool(parseInt(document.getElementById('Authcmb_'+id).getAttribute('orival')), 6)+" to "+getValueFromPool(parseInt(document.getElementById('Authcmb_'+id).getAttribute('comboval')), 6)+" ";
if(parseInt(document.getElementById('billingReasoncmb_'+id).getAttribute('comboval'))!=parseInt(document.getElementById('billingReasoncmb_'+id).getAttribute('orival')))
 logStr=logStr+"Billing reason changed from "+getValueFromPool(parseInt(document.getElementById('billingReasoncmb_'+id).getAttribute('orival')), 14	)+" to "+getValueFromPool(parseInt(document.getElementById('billingReasoncmb_'+id).getAttribute('comboval')), 14)+" "; 
if(paymentGroup==1)
{
 if(parseInt(document.getElementById('PaymentGroupcmb_'+id).getAttribute('comboval'))!=parseInt(document.getElementById('PaymentGroupcmb_'+id).getAttribute('orival')))
 logStr=logStr+"Payment Group reason changed from "+getValueFromPool(parseInt(document.getElementById('PaymentGroupcmb_'+id).getAttribute('orival')), 41	)+" to "+getValueFromPool(parseInt(document.getElementById('PaymentGroupcmb_'+id).getAttribute('comboval')), 41)+" "; 
}

if(parseInt(document.getElementById('SpDxcmb_'+id).getAttribute('comboval'))!=parseInt(document.getElementById('SpDxcmb_'+id).getAttribute('orival')))
	 logStr=logStr+"Corrected Claim changed from "+getValueFromPool(parseInt(document.getElementById('SpDxcmb_'+id).getAttribute('orival')), 200)+" to "+getValueFromPool(parseInt(document.getElementById('SpDxcmb_'+id).getAttribute('comboval')), 200)+" ";
var fieldData=eval("("+selectPool.get(55)+")");
if(fieldData!=null)
{
	for(var k=0;k<fieldData.length;k++)
	{
		if(fieldData[k].chargetabdispname=='NDC')
			{
			if(document.getElementById('ndc_'+id).value!=document.getElementById('ndc_'+id).getAttribute('orival'))
				logStr=logStr+"NDC changed from "+document.getElementById('ndc_'+id).getAttribute('orival') +" to "+ document.getElementById('ndc_'+id).value+" ";			}
	}
}
if(document.getElementById('DOStxt_'+id).value!=document.getElementById('DOStxt_'+id).getAttribute('orival'))
 logStr=logStr+"DOS changed from "+document.getElementById('DOStxt_'+id).getAttribute('orival') +" to "+document.getElementById('DOStxt_'+id).value+" "; 

if(document.getElementById('dostotxt_'+id).value!=document.getElementById('dostotxt_'+id).getAttribute('orival'))
	 logStr=logStr+"DOSTO changed from "+document.getElementById('dostotxt_'+id).getAttribute('orival') +" to "+document.getElementById('dostotxt_'+id).value+" "; 

if(document.getElementById('CPTtxt_'+id).value!=document.getElementById('CPTtxt_'+id).getAttribute('orival'))
 logStr=logStr+"CPT changed from "+document.getElementById('CPTtxt_'+id).getAttribute('orival') +" to "+document.getElementById('CPTtxt_'+id).value+" "; 
if(document.getElementById('Mod1txt_'+id).value!=document.getElementById('Mod1txt_'+id).getAttribute('orival'))
 logStr=logStr+"Mod1 changed from "+document.getElementById('Mod1txt_'+id).getAttribute('orival') +" to "+document.getElementById('Mod1txt_'+id).value+" ";		
if(document.getElementById('Unitstxt_'+id).value!=document.getElementById('Unitstxt_'+id).getAttribute('orival'))
 logStr=logStr+"Unit changed from "+document.getElementById('Unitstxt_'+id).getAttribute('orival') +" to "+document.getElementById('Unitstxt_'+id).value+" ";
	
if(document.getElementById('Chargestxt_'+id).value!=document.getElementById('Chargestxt_'+id).getAttribute('orival'))
 logStr=logStr+"Charge changed from "+document.getElementById('Chargestxt_'+id).getAttribute('orival') +" to "+document.getElementById('Chargestxt_'+id).value+" ";
  	
if(document.getElementById('Copaytxt_'+id).value!=document.getElementById('Copaytxt_'+id).getAttribute('orival'))
 logStr=logStr+"Copay changed from "+document.getElementById('Copaytxt_'+id).getAttribute('orival') +" to "+document.getElementById('Copaytxt_'+id).value+" ";
 	
if(document.getElementById('Paymentstxt_'+id).value!=document.getElementById('Paymentstxt_'+id).getAttribute('orival'))
 logStr=logStr+"Copay payment changed from "+document.getElementById('Paymentstxt_'+id).getAttribute('orival') +" to "+document.getElementById('Paymentstxt_'+id).value+" ";
 	
if(document.getElementById('DX1txt_'+id).value!=document.getElementById('DX1txt_'+id).getAttribute('orival'))
 logStr=logStr+"Dx1 changed from "+document.getElementById('DX1txt_'+id).getAttribute('orival') +" to "+document.getElementById('DX1txt_'+id).value+" ";
if(document.getElementById('DX2txt_'+id).value!=document.getElementById('DX2txt_'+id).getAttribute('orival'))
 logStr=logStr+"Dx2 changed from "+document.getElementById('DX2txt_'+id).getAttribute('orival') +" to "+document.getElementById('DX2txt_'+id).value+" ";
 	
if(document.getElementById('DX3txt_'+id).value!=document.getElementById('DX3txt_'+id).getAttribute('orival'))
 logStr=logStr+"Dx3 changed from "+document.getElementById('DX3txt_'+id).getAttribute('orival') +" to "+document.getElementById('DX3txt_'+id).value+" ";
 	
if(document.getElementById('DX4txt_'+id).value!=document.getElementById('DX4txt_'+id).getAttribute('orival'))
 logStr=logStr+"Dx4 changed from "+document.getElementById('DX4txt_'+id).getAttribute('orival') +" to "+document.getElementById('DX4txt_'+id).value+" ";

if(document.getElementById('Mod2txt_'+id).value!=document.getElementById('Mod2txt_'+id).getAttribute('orival'))
 logStr=logStr+"Mod2 changed from "+document.getElementById('Mod2txt_'+id).getAttribute('orival') +" to "+document.getElementById('Mod2txt_'+id).value+" ";

if(document.getElementById('Mod3txt_'+id).value!=document.getElementById('Mod3txt_'+id).getAttribute('orival'))
 logStr=logStr+"Mod3 changed from "+document.getElementById('Mod3txt_'+id).getAttribute('orival') +" to "+document.getElementById('Mod3txt_'+id).value+" ";
 
 if(document.getElementById('Mod4txt_'+id).value!=document.getElementById('Mod4txt_'+id).getAttribute('orival'))
 logStr=logStr+"Mod4 changed from "+document.getElementById('Mod4txt_'+id).getAttribute('orival') +" to "+document.getElementById('Mod4txt_'+id).value+" ";
 
 if(document.getElementById('TifReftxt_'+id).value!=document.getElementById('TifReftxt_'+id).getAttribute('orival'))
 logStr=logStr+"Tiff referrance changed from "+document.getElementById('TifReftxt_'+id).getAttribute('orival') +" to "+document.getElementById('TifReftxt_'+id).value+" "; 
 
  if(document.getElementById('Checktxt_'+id).value!=document.getElementById('Checktxt_'+id).getAttribute('orival'))
 logStr=logStr+"Check no changed from "+document.getElementById('Checktxt_'+id).getAttribute('orival') +" to "+document.getElementById('Checktxt_'+id).value+" ";
  if(document.getElementById('Commentstxt_'+id).value!=document.getElementById('Commentstxt_'+id).getAttribute('orival'))
 logStr=logStr+"Comment changed from "+document.getElementById('Commentstxt_'+id).getAttribute('orival') +" to "+document.getElementById('Commentstxt_'+id).value+" ";
  if(document.getElementById('Rlutxt_'+id).value!=document.getElementById('Rlutxt_'+id).getAttribute('orival'))
 logStr=logStr+"RLU changed from "+document.getElementById('Rlutxt_'+id).getAttribute('orival') +" to "+document.getElementById('Rlutxt_'+id).value+" ";
 // if(document.getElementById('SpDxtxt_'+id).value!=document.getElementById('SpDxtxt_'+id).getAttribute('orival'))
 //logStr=logStr+"Corrected Claim changed from "+document.getElementById('SpDxtxt_'+id).getAttribute('orival') +" to "+document.getElementById('SpDxtxt_'+id).value+" ";
return logStr;
}

function showARDiv()
{
document.getElementById('sr_frameBlocker').style.display='block';

var ardiv=document.getElementById("ar_SelectedActionTable");
var popUpDiv=document.getElementById("service_ywin");
			var bDObj=cm_y_getPopUpBContent(popUpDiv);
			bDObj.style.backgroundColor="#E4F6FA";
			setChildToDiv(bDObj,ardiv);
			popUpDiv.style.width="400px";
			cm_y_getPopUpHContent(popUpDiv).innerHTML="Resubmit to Primary with Changes";
			cm_y_getPopUpFContent(popUpDiv).innerHTML="<span style='color:red;'>*</span> Mandatory field(s)";
			YAHOO.glace.servicepanel.needGarbager=true;
			YAHOO.glace.servicepanel.callGarbager="sr_garbageCollect";
			YAHOO.glace.servicepanel.show();
}


function saveServiceAfterARAction()
{
showRequestDivStatus(false,tabDetails.SERVICE,0,false,'Saving ...');
var frm = eval("document.serviceinformation");
		if(getSaveFlag() == 1){
		    if(getServiceid()==-1)
		    {
		    frm.actionType.value = "UPDATEINSERT";
		    eval("document.serviceinformation.takeARAction").value=-1;
		    }
			else
			{
			frm.actionType.value = "UPDATE_SERVICE";
			var divobj=document.getElementById('service_ypopupdata');
			divobj = chooseNode(divobj, "firstChild");
			divobj = chooseNode(divobj, "firstChild");
			divobj =divobj.childNodes;
			eval("document.serviceinformation.takeARAction").value=getARAction();
			eval("document.serviceinformation.ac_problem").value=(((divobj[0].childNodes)[1]).childNodes)[0].value;
			eval("document.serviceinformation.ac_nextfollowupaction").value=(((divobj[1].childNodes)[1]).childNodes)[0].value;
			eval("document.serviceinformation.ac_nextfollowupdate").value=(((divobj[2].childNodes)[1]).childNodes)[0].value;
			eval("document.serviceinformation.ac_notes").value=(((divobj[3].childNodes)[1]).childNodes)[0].value;
			}
			document.serviceinformation.logdata.value="Services Updated or Enterred";
			frm.servicedata.value='';
			var uniqueIDSec;
			for (var j=0; j <  removedRow.length-1; j++){
				i=getRemovedRow(j);
				if(i==-1)
					continue;
					if(getServiceid()==-1)
					 uniqueIDSec=PATIENT_ID+"_"+i;
					 else
					 uniqueIDSec=getServiceid();
			if (document.getElementById('CPTtxt_'+uniqueIDSec).getAttribute('cpttype')!=0 && document.getElementById('CPTtxt_'+uniqueIDSec).value!='')
				frm.servicedata.value += uniqueIDSec + "~";
			}
			document.serviceinformation.submit();
		}
		else
			alert("No data to save");
}


function sr_garbageCollect()
{
if(getServiceid()>0 && getARAction()==1)
	    document.getElementById('sr_frameBlocker').style.display='none';
}
function sr_garbageCollect_new()
{
   document.getElementById('sr_frameBlocker').style.display='none';
   setPreviousStatus(oldVal);
}
function getAjaxDataFromServer(fileurl,data,isSync,callback,reqType,transId){
	if(!isSync){
		try{
			if(transId!=null && transId!=undefined){
				var reqTransId=AJAX_REQ_SENDED[transId];
				if(reqTransId!=null && reqTransId!=undefined){
					if(AjaxConnect.isCallInProgress(reqTransId))
						AjaxConnect.abort(reqTransId);
				}
			}
			var serverRes=AjaxConnect.sendAsynchRequest((reqType!=null && reqType!=undefined)?(reqType):("POST"),fileurl,callback,data);
			if(transId!=null && transId!=undefined){
				AJAX_REQ_SENDED[transId]=serverRes;
			}
		}catch(e){}
	}else{
		return getResponseData(fileurl+"?"+data);
	}
}

function getTarget(evt){
	return (evt.target)?evt.target:evt.srcElement;
}

function getFormattedCurrency(stringval,currencySym){
		var returnVal;
		if(stringval){
			var currencyInd=stringval.indexOf(currencySym);
			if(currencyInd!=-1){
				var negInd=stringval.indexOf("(");
				
				if( negInd != -1 ){
					returnVal="-"+stringval.substring(currencyInd+2,stringval.indexOf(")"));
				}else if( currencyInd !=-1 ){
				    returnVal=stringval.substring(currencyInd+1);
				}else{
					returnVal=stringval;
				}
				var isNo=Number(returnVal);
				//returnVal=Number(returnVal);
				if( isNaN(isNo) || (""+isNo).length==0 ){
					returnVal=stringval;
				}
			}else{
				returnVal=stringval;
			}
		}else{
			returnVal=stringval;
		}
		//alert(returnVal);
		return returnVal;
}

function setFormattedCurrency(amtval,currencySym){
		var chkamtval=parseFloat(amtval);
		amtval=convertTocurrency(""+Math.abs(chkamtval),true);
		var rtnval;
		rtnval=((chkamtval<0)?("("+amtval+")"):(amtval));
		rtnval=currencySym+rtnval;
		return rtnval;
}
function convertTocurrency(textboxvalue,skipNegative){
	if(isNaN(textboxvalue)){
		return "0.00";
	}else{
		if(textboxvalue.indexOf(".")==-1){
			if(Number(textboxvalue)<0){
				if(!skipNegative){
					alert("Negative payment not allowed");
					return "0.00";
				}else
					return (textboxvalue*1)+".00";
			}else{
				return (textboxvalue*1)+".00";
			}
		}else{
				var rnum = textboxvalue;
				var rlength = 2; // The number of decimal places to round to
				if (rnum > 8191 && rnum < 10485) {
					rnum = rnum-5000;
					var newnumber = Math.round(rnum*Math.pow(10,rlength))/Math.pow(10,rlength);
					newnumber = newnumber+5000;
				} else {
					var newnumber = Math.round(rnum*Math.pow(10,rlength))/Math.pow(10,rlength);
				}
				if(newnumber<0 && !skipNegative){
					/*if(!skipNegative){*/
						alert("Negative payment not allowed");
						return "0.00";
					/*}else
						return newnumber;*/
				}else{
					newnumber=""+newnumber;
					if(newnumber.indexOf(".")==-1){
						newnumber=newnumber+".00";
					}
					return newnumber;
					
				}
		}
	}
}

function cm_y_getPopUpBContent(divObj){
	var bodyObj=childnod(divObj,1);
	bodyObj.innerHTML="";
	return bodyObj;
}

function cm_y_getPopUpHContent(divObj){
	var spanObj=childnod(childnod(divObj,0),1);
	return spanObj;
}

function cm_y_getPopUpFContent(divObj){
	var spanObj=childnod(childnod(divObj,2),1);
	return spanObj;
}
function childnod(obj,index)
{
  var count=0;
  for(var i=0;i<obj.childNodes.length;i++)
  {
   if(obj.childNodes[i].nodeType==1)
   {
     if(count==index)
        return obj.childNodes[i];   
     count++;  
   }
  }
}
function setChildToDiv(divobj,objtoappend){
	var chds=divobj.childNodes;
	var tmpobj,chdslen=chds.length;
	//var chdobj=chooseNode(divobj,"firstChild");
	if(chdslen>0){
 		if(chdslen==1)
 			divobj.replaceChild(objtoappend,chds[0]);
 		else{
 			for(var lp=(chdslen-1);lp>=0;lp--){
 				tmpobj=chds[lp];
 				if(tmpobj.nodeType==1){
 					divobj.removeChild(tmpobj);
 				}
 			}
 			divobj.appendChild(objtoappend);	
 		}
	}else
 		divobj.appendChild(objtoappend);
}

function sr_loadPQRI()
{
	defaultPOSId=document.getElementById('POScmb_').getAttribute('comboval');
	defaultProviderId=document.getElementById('SDoctorcmb_').getAttribute('comboval');
	if(contextpath=='')
		setTimeout("sr_loadPQRI()",100);
	else
	{
		setPQRIload=0;
		var counter = 0;
		var CPTobj = document.getElementById('servicegrid').getElementsByTagName('input');
		var i=0;
		for(var i=1;i<CPTobj.length;i++){

			if(CPTobj[i].id.indexOf('CPTtxt_') >= 0 ){
				if(CPTobj[i].getAttribute("disabled")==undefined){
					if(CPTobj[i].value.trim().length != 0){
						counter++;
					}

				}

			}

		}
		if(getDirty() == 0){
			if(counter<=0){ 
				alert("Enter valid CPT code"); 
			}else 
				pqri_checkPQRI(contextpath, getPatientId(), defaultdate,defaultPOSId,defaultProviderId);
		}
		else 
		{
			if(counter<=0){ alert("Enter valid CPT code"); }
			else{
				setPQRIload=1;
				saveServices();
			} 
		}
	}
}

function validateDx(){
if(dxString!=''){
//showRequestDivStatus(false,tabDetails.SERVICE,0,false,'Validating Dx ...');
	var dosDate="-1"; 
	if(document.getElementById('DOStxt_'+PATIENT_ID+'_0')!=undefined && document.getElementById('DOStxt_'+PATIENT_ID+'_0')!=null)
		dosDate= document.getElementById('DOStxt_'+PATIENT_ID+'_0').value;
	else
		dosDate="-1";
	a=eval(getResponseData("../ServiceEntry.Action?action=2&dosDate="+dosDate+"&dxstring="+dxString+"&rand="+Math.random()));
//hideRequestDivStatus(tabDetails.SERVICE,0);
var t=eval(a[0]);
if(t.status=='failure'){
alert("Dx "+t.message+" do not exist in the valid ICDM list ! \nService details not saved !");
throw "Dx "+t.message+" do not exist in the valid ICDM list ! \nService details not saved !";
return(0);
}
else
 return(1);
}
return(1);
}



function loadGroupCptData(cptCode)
{
var d=document.getElementById('showOnlyPopUp');
if(d.style.display!='block')
{
d.style.left="400px";
d.style.top="300px";
d.innerHTML="<table bgcolor='#E4F6FA' style='border-collapse:collapse;border:2px solid black'><tr height='50px'><td><img src='../../../images/Ajax/Glace-Data-loader.gif' /></td><td><div id='validationmes'><font color=red>Please wait ... CPT loading ...</font><div></td></tr></table>";
d.style.display='block'; 
}
var cptEle=document.getElementById('CPTtxt_'+getCurrentRowId());	
cptEle.value=cptCode;
createNextRow(cptEle);
}


function sr_loadEMCPT()
{

var cptCode="";
try{
cptCode=parent.getCurrentEandMcode();
}
catch(e){cptCode="";}
if(cptCode=="")
 alert("No E&M CPT available !");
else
  {fromCptPicker=1;
  loadCptData(cptCode);
  }
}

function sr_checkForPQRI()
{
 if(setPQRIload==1)
 {
 setPQRIload=0;
 pqri_checkPQRI(contextpath, getPatientId(), defaultdate,defaultPOSId,defaultProviderId);
 }
}

function updateBillingAndRDoctor()
{
var SDoctor=document.getElementById("SDoctorcmb_").getAttribute("comboval");
var msg="31,32,33"
var callback={
	success:sr_callSuccess1221,
	failure:sr_callFailure1221,
	progress:sr_callProgress1221
	}
	getAjaxDataFromServer("../ServiceEntry.Action","patientId="+PATIENT_ID+"&group="+msg+"&providerid="+SDoctor+"&randNo="+Math.floor(Math.random()*1121),false,callback);
//a=eval(getResponseData("../ServiceEntry.Action?group="+msg+"&patientId="+PATIENT_ID+"&providerid="+SDoctor+"&rand="+Math.floor(Math.random()*1121)));
/*	for(j=0;j<a.length;j++){ 		
		var t=eval(a[j]);
		selectPool.set(t.key,t.valu);
	}
document.getElementById('BDoctorcmb_').value='None';
document.getElementById('BDoctorcmb_').setAttribute('comboval',-1);
document.getElementById('OrDoctorcmb_').value='None';
document.getElementById('OrDoctorcmb_').setAttribute('comboval',-1);
*/
}

var sr_callFailure1221=function(responseObject){} 
var sr_callProgress1221=function(responseObject){}
var sr_callSuccess1221=function(responseObject)
{
var res=eval(responseObject.responseText);
var s1=eval(eval(res)[0]);
selectPool.set(s1.key,s1.valu);
var s2=eval(eval(res)[1]);
selectPool.set(s2.key,s2.valu);
var s3=eval(eval(res)[2]);
selectPool.set(s3.key,s3.valu);
document.getElementById('BDoctorcmb_').value='None';
document.getElementById('BDoctorcmb_').setAttribute('comboval',-1);
document.getElementById('OrDoctorcmb_').value='None';
document.getElementById('OrDoctorcmb_').setAttribute('comboval',-1);
}

function checkDoctorCombination()
{
var store=eval("("+selectPool.get(33)+")");
var check=0;
var bID=document.getElementById("BDoctorcmb_").getAttribute("comboval");
var rID=document.getElementById("OrDoctorcmb_").getAttribute("comboval");
for(var i=0;i<store.length;i++)
{
 if(bID==store[i].hsp001 && rID==store[i].hsp002)
	check=1; 
}
return check ; 
}

//For Dosage
function calculateDosage(e)
{
var name=e.name;
var left=findPosX(document.getElementById(name),false);
var top=findPosY(document.getElementById(name),false);
var a=name.substring(name.indexOf('_')+1,name.length);
setSelectedDosage(a);
var unitVal=eval("document.serviceinformation.txtDosageAmt_"+a).value;
var unit=eval("document.serviceinformation.txtDosageUnits_"+a).value;
var past=eval("document.serviceinformation.txtDosage_"+a).value;
if((Trim(unitVal) != '' && unitVal != 0 && Trim(unitVal)!=' ') || Trim(past) !='')
{
if(past!= '')
{
 document.getElementById('dosage').value=past.substring(0,past.indexOf("X"));
 document.getElementById('qty').value=past.substring(past.indexOf("X")+1,past.indexOf("="));
 unit=past.substring(past.indexOf("-")+1,past.length);
 //eval("document.serviceinformation.txtDosageAmt_"+a).value=
}
else
 {
 document.getElementById('dosage').value='';
 document.getElementById('qty').value='';
 }
 document.getElementById('DosageCalc').style.top=top+20;
 document.getElementById('DosageCalc').style.left=left+50;

document.getElementById('eventBlockerForDosage').style.display='block';
document.getElementById('DosageCalc').style.display='block';
setTimeout("setCFDD()",100);
if(unit=='MCG')
{
 document.getElementById('unit').options[0].selected=true;
 document.getElementById('unit').options[1].selected=false;
 document.getElementById('unit').options[2].selected=false;
 }
else if(unit=='MG')
{
 document.getElementById('unit').options[1].selected=true;
 document.getElementById('unit').options[0].selected=false;
 document.getElementById('unit').options[2].selected=false;
 }
else if(unit=='ML')
{
 document.getElementById('unit').options[2].selected=true;
 document.getElementById('unit').options[1].selected=false;
 document.getElementById('unit').options[0].selected=false;
} 	
}
}

function setDosage()
{
var a=getSelectedDosage();
//eval("document.serviceinformation.txtUnits_"+a).focus();
var amt=document.getElementById('dosage').value;
var qty=document.getElementById('qty').value;
if(Trim(amt)!='' && Trim(qty)!=''){
var unitCombo=document.getElementById('unit');
var ut=unitCombo.value;
eval("document.serviceinformation.txtDosage_"+a).value=amt+"X"+qty+"="+amt*qty+"-"+unitCombo.options[unitCombo.selectedIndex].text;
var unitVal=eval("document.serviceinformation.txtDosageAmt_"+a).value;
var dosageUnit=eval("document.serviceinformation.txtDosageUnits_"+a).value;
var charge=eval("document.serviceinformation.txtCharges_"+a).value;
var unit;
var unitComboValue=unitCombo.options[unitCombo.selectedIndex].text;
if(unitCombo == dosageUnit) 
 unit=Math.ceil((amt*qty)/unitVal);
else
 {
 if(unitComboValue == 'MG')
    amt = (10)*amt;
  else if(unitComboValue == 'ML')
    amt = (10/3)*amt;
    
  if(dosageUnit == 'MG')
    unitVal = (10)*unitVal;
  else if(dosageUnit == 'ML')
    unitVal = (10/3)*unitVal;
    
  unit=Math.ceil((amt*qty)/unitVal);      
 } 
if(unit==0)
 unit=1;
document.getElementById('Unitstxt_'+a).value=unit;
document.getElementById('Chargestxt_'+a).value=setFormattedCurrency(parseFloat(document.getElementById('hdnCharges_'+a).value*unit),CURR_SYM);
document.getElementById('DosageCalc').style.display='none';
document.getElementById('eventBlockerForDosage').style.display='none';
}else{
	document.getElementById('DosageCalc').style.display='none';
	document.getElementById('eventBlockerForDosage').style.display='none';
}
}
function hideDosage()
{
document.getElementById('DosageCalc').style.display='none';
document.getElementById('eventBlockerForDosage').style.display='none';
}
function setNextFocus()
{
setTimeout("setCFD()",100);
}

function setCFD()
{
var a=getSelectedDosage();
document.getElementById("Unitstxt_"+a).focus();
}
function setCFDD()
{
document.getElementById('dosage').focus();
}


function checkDosageOnDoubleClick(evt)
{
if(!evt)evt=window.event;
evt=getTarget(evt);
var name=evt.name;
var a=name.substring(name.indexOf('_')+1,name.length);
var modEle=eval("document.serviceinformation.Mod1txt_"+a);
if(modEle.getAttribute('visited'))
   calculateDosage(evt);
else
{modEle.setAttribute('visited','1');
calculateDosage(evt);}   
}

function closeDosageDiv()
{
setDosage();
setNextFocus();
}
//End of For Dosage

function updateSavedStatus()
{
try{
var i=0;
for(i=0;i<rowcount-1;i++)
 {
 try{
 var obj =document.getElementById('downlink_'+getPatientId()+'_'+i);
 obj.parentNode.className='bottomsidebordertdbackground';
  }catch(e1){}
 }
}
catch(e){}
}

function sr_loadRefferingDoc_1()
{
openPicker(8,'setRefDoctor_1',null,1,false,10,PATIENT_ID);
}
function sr_loadRefferingDoc_2(evt)
{
var tex=getTarget(evt);
currentRef=tex.name;
openPicker(8,'setRefDoctor_2',null,1,false,10);
}
function setRefDoctor_1(obj)
{
 setRefDoctor(obj,1);
}
function setRefDoctor_2(obj)
{
  setRefDoctor(obj,2);
}

function setRefDoctor(obj,x)
{
try{
var strJson="[";
var store=eval("("+selectPool.get(18)+")");
for(var i=0;i<store.length;i++)
 {
   if(i==0)
   strJson=strJson+'{"hsp001":"'+store[i].hsp001+'","hsp002":"'+store[i].hsp002+'"}';
   else
   strJson=strJson+',{"hsp001":"'+store[i].hsp001+'","hsp002":"'+store[i].hsp002+'"}';
}
if(strJson.length>10)
 strJson=strJson+',{"hsp001":"'+obj[0]['id']+'","hsp002":"'+obj[0]['col1']+", "+obj[0]['col2']+'"}';
 else
 strJson=strJson+'{"hsp001":"'+obj[0]['id']+'","hsp002":"'+obj[0]['col1']+", "+obj[0]['col2']+'"}';

strJson=strJson+"]";
selectPool.set('18',strJson);
if(x==1){
document.getElementById('Referralcmb_').setAttribute('comboval',obj[0]['id']);
document.getElementById('Referralcmb_').value=obj[0]['col1']+", "+obj[0]['col2'];
}
else if(x==2 && currentRef!='')
{
document.getElementById(currentRef).setAttribute('comboval',obj[0]['id']);
document.getElementById(currentRef).value=obj[0]['col1']+", "+obj[0]['col2'];
}
setDirty();
}
catch(e){}
}
function sr_loadEMCode(cpt){
fromCptPicker=1;
loadCptData(cpt);
/*if (document.getElementById('CPTtxt_'+ getCurrentRowId()).value != '')
loadDXInfo(getCurrentRowId());*/
}

function sr_loadPQRISummary(){
	var defaultPOSId=document.getElementById('POScmb_').getAttribute('comboval');
	var default_ProviderId=document.getElementById('SDoctorcmb_').getAttribute('comboval');
	loadPQRISummaryData(getPatientId(),defaultdate,default_ProviderId,defaultPOSId);
}

function setBillingReason(x){
	var bReason=document.getElementById("billingReasoncmb_"+x);
	var isSaved=document.getElementById('CPTtxt_'+x).getAttribute("issaved");
	var ins_name=getValueFromPool(parseInt(document.getElementById('Primarycmb_').getAttribute('comboval')), 20);
	var DefaultBReason=eval("("+selectPool.get(50)+")");
	if(isSaved!==1 && (ins_name.indexOf('self pay') > -1 || ins_name.indexOf('selfpay') >-1 || ins_name.indexOf('SELF PAY') > -1 || ins_name.indexOf('SELFPAY') > -1 || ins_name.indexOf('Self Pay') >-1 || ins_name.indexOf('Self-Pay') >-1 )){
		bReason.value=DefaultBReason.defBReasonName;
		bReason.setAttribute("comboval",DefaultBReason.defBReasonid);
		bReason.setAttribute("orival","-1");
	}
	
}
function loadPQRINeedDiv(){
  var ins_name=getValueFromPool(parseInt(document.getElementById('Primarycmb_').getAttribute('comboval')), 20);
  if(ins_name.indexOf('medicare')>-1 || ins_name.indexOf('Medicare')>-1 || ins_name.indexOf('MEDICARE')>-1){ 
  	 constructPQRIAlertDiv();
  }
}
var tempid;
function deleteService(rowid){
	showpromtpassword(true);
    tempid=rowid;
}
function authenticateReceiptPassword(){
    var password=document.getElementById("editreceiptpasssword").value;
	var stat='000000';
	if(password==stat){
		showpromtpassword(false);
		deleteFromServer(tempid);
	}else{
		document.getElementById("editreceiptpasssword").value = "";
		document.getElementById("editreceiptpasssword").focus();
		alert("Invalid Password");
	}
}
function showpromtpassword(isShow){
	document.getElementById("passwordprompter").style.display=(isShow)?"block":"none";
	var eventBlocker = document.getElementById("eventBlocker");
	eventBlocker.style.opacity = (isShow)?'1.4':'0.6';
	eventBlocker.style.display=(isShow)?"block":"none";
	document.getElementById("editreceiptpasssword").value = "";
	if(isShow)
		document.getElementById("editreceiptpasssword").focus();
}

function deleteFromServer(rowid){
	var obj=document.getElementById("CPTtxt_"+rowid);
	var cpt=obj.value;
	var unit=document.getElementById("Unitstxt_"+rowid).value;
	var cost=document.getElementById("Chargestxt_"+rowid).value;
	var copay=document.getElementById("Copaytxt_"+rowid).value;
	var serviceid=obj.getAttribute('serviceid');
	var a=eval(getResponseData("../ServiceEntry.Action?action=10&patientId="+PATIENT_ID+"&serviceId="+serviceid+"&cpt="+cpt+"&unit="+unit+"&cost="+cost+"&copay="+copay+"&rand="+Math.floor(Math.random()*1121)));
	var res=eval(a[0]);
	if(Trim(res.status)=='0'){
		  alert("Service deleted successfully ! The page will be reloaded.");
		  goEntry();
	}else if(Trim(res.status)=='1')
		  alert("Service can't be deleted as payments exists !");
	else
		  alert("Service deletation failed !");  
}
/*
function deleteService(rowid){
var co=prompt("Please enter the verification code !");
if(Trim(co)=='000000'){
var obj=document.getElementById("CPTtxt_"+rowid);
var cpt=obj.value;
var unit=document.getElementById("Unitstxt_"+rowid).value;
var cost=document.getElementById("Chargestxt_"+rowid).value;
var serviceid=obj.getAttribute('serviceid')
//var patentid=
var a=eval(getResponseData("../ServiceEntry.Action?action=10&patientId="+PATIENT_ID+"&serviceId="+serviceid+"&cpt="+cpt+"&unit="+unit+"&cost="+cost+"&rand="+Math.floor(Math.random()*1121)));
var res=eval(a[0]);
if(Trim(res.status)=='0'){
	  alert("Service deleted successfully ! The page will be reloaded.");
	  goEntry();
	  }
 else if(Trim(res.status)=='1')
	  alert("Service can't be deleted as payments exists !");
	else
	  alert("Service deletation failed !");  
}else
  alert("Incorrect verification code !")
}
*/
function sr_loadPreviousVisit(){
if(getServiceid() == -1){
loadingLastVisit=1;
cptInd=0;
//showRequestDivStatus(false,tabDetails.SERVICE,0,false,'Loading previous visit info ...');
a=eval(getResponseData("../ServiceEntry.Action?action=8&patientId=" + PATIENT_ID+"&rand="+Math.floor(Math.random()*11)));
//hideRequestDivStatus(tabDetails.SERVICE,0);
var t=eval(a[0]);
prevCptData=eval(t.prev_service_result);
prevCptDataDxDesc=eval(t.prev_service_result_dx_description);
if(prevCptData.length>0)
 load_prevcpt('Previous visit data loading. Please wait ...');
else{
	loadingLastVisit=0;
 alert("No previous visit data found !");
}
}
}


function setDxDescription(rowno,controlno){
var descriptionDat='';
if(controlno==888 || controlno==890){
for(var i=1;i<=4;i++){
  if(Trim(document.getElementById('DX'+i+'txt_'+rowno).value)!=''){
	 descriptionDat=getDxDescription(document.getElementById('DX'+i+'txt_'+rowno).value,controlno);
	 if(descriptionDat!='')
     document.getElementById('DX'+i+'txt_'+rowno).title=descriptionDat;
	 else
		 document.getElementById('DX'+i+'txt_'+rowno).title=document.getElementById('txtDX'+i+'Desc_'+rowno).value;
  }
}
}else if(controlno==889){
for(var i=1;i<=4;i++){
  if(Trim(document.getElementById('txtDX'+i+'_'+rowno).value)!='')
     document.getElementById('txtDX'+i+'_'+rowno).title=getDxDescription(document.getElementById('txtDX'+i+'_'+rowno).value,controlno);
}
}else if(controlno==895){
for(var i=1;i<=4;i++){
 if(Trim(document.getElementById('DX'+i+'txt_'+rowno).value)!='')
     document.getElementById('DX'+i+'txt_'+rowno).title=getDxDescription(document.getElementById('DX'+i+'txt_'+rowno).value,controlno);
}
}else if(controlno==891){
for(var i=1;i<=4;i++){
 if(Trim(document.getElementById('DX'+i+'txt_'+rowno).value)!=''){
	 descriptionDat=getDxDescription(document.getElementById('DX'+i+'txt_'+rowno).value,controlno);
     document.getElementById('DX'+i+'txt_'+rowno).title=descriptionDat;
     document.getElementById('txtDX'+i+'Desc_'+rowno).value=descriptionDat;
 }
}
}
}

function getDxDescription(dx,controlno){
var dsc='';
var dxDescription;
if(controlno==895)
dxDescription=prevCptDataDxDesc;
else
dxDescription=eval("("+selectPool.get(controlno)+")");
for(var i=0;i<dxDescription.length;i++){
 if(Trim(dxDescription[i].dx)==Trim(dx)+'')
   dsc=dxDescription[i].description;
}
return dsc;   
}

function load_prevcpt(txt)
{
var d=document.getElementById('showOnlyPopUp');
if(d.style.display!='block')
{
d.style.left="400px";
d.style.top="300px";
d.innerHTML="<table bgcolor='#E4F6FA' style='border-collapse:collapse;border:2px solid black'><tr height='50px'><td><img src='../../../images/Ajax/Glace-Data-loader.gif' /></td><td><div id='validationmes'><font color=red>"+txt+"</font><div></td></tr></table>";
d.style.display='block'; 
}
var cptEle=document.getElementById('CPTtxt_'+getCurrentRowId());	
cptEle.value=prevCptData[cptInd].cpt;
createNextRow(cptEle);
}

function loadCPTGroupData(){
if(getServiceid()==-1 ){
loadingLastVisit=1;
cptInd=0;
var id=document.getElementById("CPTGroupcmb_").getAttribute('comboval');
//showRequestDivStatus(false,tabDetails.SERVICE,0,false,'Loading CPT grouping info ...');
a=eval(getResponseData("../ServiceEntry.Action?action=9&groupId=" + id+"&rand="+Math.floor(Math.random()*1121)));
//hideRequestDivStatus(tabDetails.SERVICE,0);
var t=eval(a[0]);
prevCptData=eval(t.cpt_group);
prevCptDataDxDesc=eval(t.cpt_group_dx_description);
if(prevCptData.length>0)
 load_prevcpt('CPT grouping data loading. Please wait ...');
else{
	loadingLastVisit=0;	
 alert("No group information found !");
}
}
}
function addGCodes(){
a=eval(getResponseData("../ServiceEntry.Action?action=12&patientId=" + PATIENT_ID+"&dos="+defaultdate+"&rand="+Math.floor(Math.random()*1121)));
var t=eval(a[0]);
var statuscode=eval(t.gcodes);
var cptcode="";
if(statuscode==1)
  cptcode='G8553';
if(cptcode=='')
alert("No eRx sent for today's visit!");//alert("No G Code found !");
else  
sr_loadEMCode(cptcode);
}
function isAuthPresent(key){
	var cDate,sDate,eDate;
	var remainAuth=-1;
	var authDoctor=-1;
	var authIns=-1;
	var authCpt='';
	var authCount=0;
	var insAdd=-1;
	var ele=selectPool.get(6);
	ele=eval(ele);
	var doc=parseInt(document.getElementById('SDoctorcmb_').getAttribute("comboval"));
	var ins=parseInt(document.getElementById('Primarycmb_').getAttribute("comboval"));
	var cpt=document.getElementById('CPTtxt_'+key).value;
	var insCombo=selectPool.get(20);
	insCombo=eval(insCombo);
	for(var k=0;k<insCombo.length;k++)
	{
	 if(ins==parseInt(insCombo[k].hsp001))
		insAdd=parseInt(insCombo[k].hsp003);
	}
	cDate = new Date(document.getElementById('DOStxt_'+key).value);
	for(var i=0;i<ele.length;i++){
	sDate =new Date(ele[i].hsp003);
	eDate=new Date((Trim(ele[i].hsp004)=='')?'01/01/2020':ele[i].hsp004);
	remainAuth=parseInt(ele[i].hsp006);
	authDoctor=parseInt(ele[i].hsp005);
	authIns=parseInt(ele[i].hsp007); 
	authCpt=parseInt(ele[i].hsp008);
	/*if(cpt == authCpt){
	alert('>>>>>'+doc+'<<===>>>>'+authDoctor+'<<<<<<');
	alert('>>>>>'+insAdd+'<<===>>>>'+authIns+'<<<<<<');
	}*/
	if((cDate >= sDate) && (cDate<=eDate) && (remainAuth > 0) && (doc == authDoctor) && (insAdd==authIns) && (cpt == authCpt))
	  authCount++;
	}

	if(authCount > 0)
	 return true;
	else
	 return false;
	}

function adjustLinkDiv(){
try{
	var groupdiv = document.getElementById("div3");
		var dataobj = document.getElementById('datacontainer');
		var ht;
		if(initialHeight==-1){
			ht = dataobj.style.height;
			if(ht.indexOf("px")!=-1){
				ht = ht.replace("px","");
			}
			try{
				ht = parseInt(ht);
			}catch(e){
				return;
			}
			initialHeight = ht;
		}
	if(!groupdiv || groupdiv.style.display == "none"){
		document.getElementById("EMCodes").style.top="87%";
		 ht = (initialHeight)+"px";
		 dataobj.style.height = ht;
	}else{
		document.getElementById("EMCodes").style.top="87%";
		ht = (initialHeight)+"px";
		dataobj.style.height = ht;
	}
/*
var rowNo=getCurrentRowId();
rowNo=rowNo.substring(rowNo.indexOf('_')+1,rowNo.length);
var currentRowNo=parseInt(rowNo)+1;

if(currentRowNo <=2)
	document.getElementById("EMCodes").style.top="60%";
else if(currentRowNo ==3)
	document.getElementById("EMCodes").style.top="67%";
else if(currentRowNo ==4)
	document.getElementById("EMCodes").style.top="74%";
else if(currentRowNo ==5)
	document.getElementById("EMCodes").style.top="81%";
else if(currentRowNo == 6)
	document.getElementById("EMCodes").style.top="86%";
else 
	document.getElementById("EMCodes").style.top="89%";
*/
}catch(e){}
document.getElementById("EMCodes").style.display='block';
}
var initialHeight = -1;
var cptGroup = new Array();
var loadCount = -1;
var processedCPTArray = null;
var processedCPTCount = 0;
var activeModifier = "";
var activeUnits = "";
var activeDx1 = "";
var activeDx2 = "";
var activeDx3 = "";
var activeDx4 = "";
var activeDxCodeSystem="";
var quickDxImg = new Image();
quickDxImg.src ='../../../images/pinocular.gif';
quickDxImg.title = "Pick Dx";
quickDxImg.style.cursor = "pointer";

var quickPrevDxImg = new Image();
quickPrevDxImg.src="../../../images/next4.gif";
quickPrevDxImg.title = "Load previous row dx code";
quickPrevDxImg.style.cursor = "pointer";

var activeQuickTr;
var loadPrevQuickDx=function(obj){
	if(obj){
		var parentTr = obj.parentNode.parentNode;
		var isProcessed = parentTr.getAttribute("isprocessed");
		if(isProcessed && isProcessed==1){
			var prevTr = parentTr.previousSibling;
			if(prevTr){
				for(i=0;i<4;i++){
					(parentTr.cells[4+i].firstChild).value = (prevTr.cells[4+i].firstChild).value;
				}
			}
		}else{
			alert("Select a CPT to proceed !");
		}
	}
}
var createQuickDxPicker=function(obj){
	if(obj){
		var parentTr = obj.parentNode.parentNode;
		activeQuickTr=parentTr;
		var isProcessed = parentTr.getAttribute("isprocessed");
		if(isProcessed && isProcessed==1){
			openPicker(1,'selectQuickDxValue',null,4);
		}else{
			alert("Select a CPT to proceed !");
		}
	}
	//openPicker(1,'selectDxValue',null,4,false,20);	
}

var createQuickDx10Picker=function(obj){
	if(obj){
		var parentTr = obj.parentNode.parentNode;
		activeQuickTr=parentTr;
		var isProcessed = parentTr.getAttribute("isprocessed");
		if(isProcessed && isProcessed==1){
			openPicker(28,'selectQuickICD10Value',null,4,false,80,undefined,undefined,undefined,undefined,undefined,true)
		}else{
			alert("Select a CPT to proceed !");
		}
	}
}
var selectQuickDxValue=function(respobj){
	if(activeQuickTr){
		var i;
		activeQuickTr.cells[7].childNodes[1].value="2.16.840.1.113883.6.104";
		for(i=0;i<respobj.length;i++){
			(activeQuickTr.cells[4+i].firstChild).value = respobj[i]['col0'];
		}
		for(i;i<4;i++){
			(activeQuickTr.cells[4+i].firstChild).value = "";
		}
	}
	activeQuickTr=null;
}
var selectQuickICD10Value=function(respobj){
	if(activeQuickTr){
		var i;
		activeQuickTr.cells[7].childNodes[1].value="2.16.840.1.113883.6.90";
		for(i=0;i<respobj.length;i++){
			(activeQuickTr.cells[4+i].firstChild).value = respobj[i][0];
		}
		for(i;i<4;i++){
			(activeQuickTr.cells[4+i].firstChild).value = "";
		}
	}
	activeQuickTr=null;
}
var setProcessedCPT = function(currentCptObj,cptmodel){
	var name=currentCptObj.name;
	var comrowid=name.substring(name.indexOf('_')+1,name.length);
	processedCPTArray[processedCPTCount] = [{"cptcode":"\""+cptmodel.cptcode+"\"","rowid":"\""+comrowid+"\""}];
	processedCPTCount ++;
	//mod -- comrowid
}
var clearProcessedCPTArray = function(){
	processedCPTArray = null;
	processedCPTArray = new Array();
	processedCPTCount = 0;
}
var isAlreadyProcessed = function(cptMod){
	var temp = cptMod.split("@");
	if(temp[0]){
		var tempGroup,tempcptcode,currow,tempmodobj,tempmod;
		if(!temp[1]){
			temp[1] = "";
		}
		for(var data in processedCPTArray){
			tempGroup = processedCPTArray[data];
			if(tempGroup){
				tempGroup = eval(tempGroup)[0];
				tempcptcode = tempGroup.cptcode;
				currow = tempGroup.rowid;
				currow = eval(currow);
				if(eval(tempcptcode) == temp[0] && currow){
					tempmodobj = document.getElementById('Mod1txt_'+currow);
					if(tempmodobj){
						tempmod = tempmodobj.value;
						if(temp[1]==tempmod){
							return false;
						}
					}
				}
			}
		}
	}
	return true;
}
var setQuickModifierUnits = function(currentCptObj){
	var name=currentCptObj.name;
	var comrowid=name.substring(name.indexOf('_')+1,name.length);
	var tempmodobj = document.getElementById('Mod1txt_'+comrowid);
	if(tempmodobj){
		tempmodobj.value = (activeModifier && activeModifier.length > 0)?activeModifier:"";
		activeModifier = "";
	}
	var tempmodobj = document.getElementById('Unitstxt_'+comrowid);
	if(tempmodobj){
		tempmodobj.value = (activeUnits && activeUnits.length > 0)?activeUnits:"1";
		activeUnits = "";
		takeActionOnBlur(null,tempmodobj);
	}
	var tempdx1obj = document.getElementById('DX1txt_'+comrowid);
	if(tempdx1obj){
		document.getElementById('txtDXCodeSystemId_'+comrowid).value=(activeDxCodeSystem && activeDxCodeSystem.length > 0)?activeDxCodeSystem:"";
		tempdx1obj.value = (activeDx1 && activeDx1.length > 0)?activeDx1:"";
		if(tempdx1obj.value==''){
            loadDXInfo(comrowid)
        }
		activeDx1 = "";
		activeDxCodeSystem="";
	}
	var tempdx2obj = document.getElementById('DX2txt_'+comrowid);
	if(tempdx2obj){
		tempdx2obj.value = (activeDx2 && activeDx2.length > 0)?activeDx2:"";
		activeDx2 = "";
	}
	var tempdx3obj = document.getElementById('DX3txt_'+comrowid);
	if(tempdx3obj){
		tempdx3obj.value = (activeDx3 && activeDx3.length > 0)?activeDx3:"";
		activeDx3 = "";
	}
	var tempdx4obj = document.getElementById('DX4txt_'+comrowid);
	if(tempdx4obj){
		tempdx4obj.value = (activeDx4 && activeDx4.length > 0)?activeDx4:"";
		activeDx4 = "";
	}	
}
var loadSelectedGroup = function(cptsToLoad){
	if(cptsToLoad==-1)
		return;
	loadDXFromAssesment();
	cptGroup = cptsToLoad.split(",");
	loadCount = -1;
	testLoadGroup();
}
var testLoadGroup = function(){
try{
	if(loadCount==-1){
		loadCount = 0;
		for(var test in cptGroup){
			loadCount++;
		}
	}
	var temp,tempcpt;
	for(var test in cptGroup){
		tempcpt = cptGroup[test];
		if(tempcpt)
			loadCount -= 1;
		cptGroup[test] = false;
		if(tempcpt && isAlreadyProcessed(tempcpt)){
			temp = (tempcpt).split("@");
			sr_loadEMCode(temp[0]);
			activeModifier = temp[1];
			activeUnits = temp[2];
			var dx1AvalFlag=0;
			if(Trim(temp[3])!='' && Trim(temp[3])!='undefined'){
				activeDx1= temp[3];
				activeDxCodeSystem=temp[7];
				dx1AvalFlag=1;
			}else{
				activeDx1= dx1FromAssesment;
				activeDx2= dx2FromAssesment;
				activeDx3= dx3FromAssesment;
				activeDx4= dx4FromAssesment;
				activeDxCodeSystem=dxcodesystem;
			}	
			if(dx1AvalFlag==1){
				activeDx2= temp[4];
				activeDx3= temp[5];
				activeDx4= temp[6];
			}	
			break;
		}
	}
}catch(e){
	alert(e);
}
}
var drawQuickCPTGroup = function(x){
var ele=selectPool.get(52);
var firstG=eval("("+ele+")");
if(!firstG){
	return;
}
var firstLength=firstG.length;
	var resultdata = "";
	resultdata = "<div style='display:block; background-color:#F1F0F1;color:black;overflow:auto;width:100%;height:55%; overflow:auto;' ><table class='othertddata' width='70%'>";
		resultdata += "<tr width='100%'>";
		var count = 0;
	for(var i=0;i<firstLength && i<12 ;i++){
		if(count%3==0){
			resultdata += "</tr>";
			resultdata += "<tr width='100%'>";
		}
		resultdata += "<td width='50%' nowrap>"+"<a href=javascript:loadSelectedGroup('"+firstG[i].hsp001+"'); >"+firstG[i].hsp002 +"</a> </td>";
		count ++;
	}
	resultdata += "</tr>";
	resultdata += "</table></div>";
var obj=new DialogBox("div3","Setting Page",300,100,400,200);
obj.setContentBackgroundColor("#F1F0F1");
	obj.setContentForegroundColor("black");
	obj.setTitleBackgroundColor("#c3d9ff");
	obj.setTitleForegroundColor("white");
	obj.setPosition("74%","162px","25%","20%");
	obj.setContent(resultdata);
	obj.setTitle("Quick CPT<span id='QCPTGroupCmb'></span> &nbsp;&nbsp; <a href='javascript:showHideQShortcuts(true);' title='add/edit groups' > <u>Add/Edit</u></a>");
	obj.setBorderSize(5);
	obj.setZindex(9);
	obj.dialogBox();
	var quickCptgrpObj = document.getElementById("dragableDiv");
	document.getElementById("div3").setAttribute("isdragable","1");
	quickCptgrpObj.onmouseover=function(){
		quickCptgrpObj.style.cursor="move";
	}

	quickCptgrpObj.onmousedown=function(e){
		down('div3',e);
	}
	quickCptgrpObj.onmouseup=function(){
		quickCptgrpObj.style.cursor="auto";
		quickCptgrpObj.style.zIndex = (z)?z:0;
		document.onmousemove = null;
	}
	adjustLinkDiv();
	constructShortCutConfigDiv(x);
	constructQuickCptCombo(x);

}
var constructShortCutConfigDiv = function(optiontoselect){
	var ele=selectPool.get(52);
	var firstG=eval("("+ele+")");
	if(!firstG){
		return;
	}
	var firstLength=firstG.length;
	optiontoselect = (optiontoselect)?optiontoselect:-1;
	var tmpSchild,bodytableObj,foottableObj,rowObj,cellObj,temptable,temptr,temptd,tempspan,tempselect,rowid=1;
			bodytableObj=document.createElement("table");
			foottableObj=document.createElement("table");
	var mainSCDiv = document.getElementById("QCPTConfigDiv");
	gen_newPopUpAttachment(mainSCDiv,"Quick CPT Shortcuts",bodytableObj,foottableObj);
	//onmouseup="javascript:up('left_div_1');" onmousedown="javascript:down('left_div_1',event);"
	var dDiv = mainSCDiv.firstChild;
	dDiv.onmouseup = function(){
		up("QCPTConfigDiv");
	}
	dDiv.onmousedown = function(event){
		down("QCPTConfigDiv",event);
	}
			bodytableObj.cellSpacing="3px";
			bodytableObj.cellPadding="3px";
			
			rowObj=bodytableObj.insertRow(-1);
				tmpSchild=document.createElement("div");
				tmpSchild.id="shortcut_operations";
			temptable = document.createElement("table");
				temptable.id="operations_table";
				//temptable.width='60%';
				temptr=temptable.insertRow(-1);
				tempspan=document.createElement("span");
				tempspan.className="label-class";
				tempspan.innerHTML="Select shortcut";
			appendTdItem(tempspan,temptr,-1);
			tempselect=document.createElement("select");
				tempselect.style.width = "150px";
				tempselect.id="shortcutcombo";

				var opt = addOption(tempselect,-1,"none",0);
				opt.selected = "1";
				for(var i=0;i<firstLength;i++){
					opt = addOption(tempselect,firstG[i].hsp001,firstG[i].hsp002,i+1);
					opt.setAttribute("scid",firstG[i].qcgid);
					if(optiontoselect == firstG[i].qcgid ){
						opt.selected = "1";
					}
				}
			appendTdItem(tempselect,temptr,-1);
				tempspan=document.createElement("span");
				tempspan.style.cursor = "pointer";
				tempspan.className="label-class";
				tempspan.innerHTML="<img height=18px src='../../../images/add_ik1.gif' border=0>";
			temptd=appendTdItem(tempspan,temptr,-1);
			temptd.onclick=function(){
				addNewQCPTShortcut();
			}
			temptd.title="Click to add new Shortcut";
				tempspan=document.createElement("span");
				tempspan.className="label-class";
				tempspan.innerHTML="&nbsp;&nbsp;";
			appendTdItem(tempspan,temptr,-1);
				tempspan=document.createElement("span");
				tempspan.className="label-class";
				tempspan.innerHTML="<a id='hsp_edit_shortcut' tabindex='1' style='padding-bottom:2px;padding-left:3px;float:right;' onclick='this.blur();' tabIndex=-1 href='javascript:editQCShortcut();' class='btn onbtn' title='Edit shortcut'><b><b><b>Edit</b></b></b></a>";
			appendTdItem(tempspan,temptr,-1);
			tmpSchild.appendChild(temptable);
			cellObj=appendTdItem(tmpSchild,rowObj,-1);
			
			foottableObj.style.display="inline-block";
			rowObj=foottableObj.insertRow(-1);
				cellObj=insertTdItem("<a id='hsp_load_shortcut' tabindex='1' style='padding-bottom:2px;padding-left:3px;float:right;' onclick='this.blur();' tabIndex=-1 href='javascript:loadQCPTFromConfig();' class='btn onbtn' title='Load shortcut services.'><b><b><b>Load</b></b></b></a>",rowObj,-1);
				cellObj=insertTdItem("<a id='hsp_shortcut_cancel' tabindex='1' style='padding-bottom:2px;padding-left:3px;float:left;' onclick='this.blur();' tabIndex=-1 href='javascript:showHideQShortcuts(false);' class='btn onbtn' title='Cancel'><b><b><b>Cancel</b></b></b></a>",rowObj,-1);
}
var editQCShortcut = function(){
	var qscSelect = document.getElementById("shortcutcombo");
	var selvalue = qscSelect.options[qscSelect.selectedIndex].value;
	if(selvalue != -1 && selvalue != "-1"){
		constructQCShortcutConfigDetails(true);
	}else{
		alert("Please select Shortcut to edit");
	}
}
var addNewQCPTShortcut = function() {
	constructQCShortcutConfigDetails(false);
}
var activeRowObj;
var checkQCPT = function(obj){
	if(obj){
		var objpar = obj.parentNode.parentNode;
			var unitsobj = objpar.cells[2].firstChild;
			unitsobj.value = 1;
		if((obj.value).trim().length > 1){
			activeRowObj = objpar;
			var callback={
				success:QCPTCheck_success,
				failure:QCPTCheck_Failure
			}
			getAjaxDataFromServer("../ServiceEntry.Action","action=16&cptCode="+obj.value+"&randNo="+Math.random(),false,callback);
		}else{
			objpar.setAttribute("isProcessed",0);
		}
		
	}
}
var QCPTCheck_success = function(responseObject){
	var res=eval(responseObject.responseText);
	var s1=eval(eval(res)[0]);
	var isfound = s1.iscptfound;
	if(isfound && isfound==1){
		if(activeRowObj){
			activeRowObj.setAttribute("isProcessed",1);
			activeRowObj.lastChild.innerHTML = "<img src='../../../images/close.gif' style='cursor:pointer;' title='Remove' onclick='removeServiceEntry(this);'>";
		}
		addNewQCPTRow();
		activeRowObj = null;
	}else{
		if(activeRowObj){
			activeRowObj.setAttribute("isProcessed",0);
			activeRowObj = null;
		}
		alert("Sorry, CPT not found !");
	}
}
var QCPTCheck_Failure = function(){
	alert("failure")
};
var constructQCShortcutConfigDetails = function(isFromEdit){
		var tempspan,tempobj,testbody1,rowObjser,constructLable=false;
		var divobj=document.getElementById("QCPTConfigDiv_details");
		
			var tmpSchild,testtable,foottableObj,rowObj,cellObj,temptable,temptr,temptd,tempspan,tempselect,rowid=1;
			testtable=document.createElement("table");
			testtable.id='shortcut_body_tab';
			testtable.border='1';
			testtable.borderColor ='#056B92';
			testtable.style.width='94%';

			foottableObj=document.createElement("table");
			var divName = (isFromEdit)?"Edit Shortcut":"Add New Shortcut";
	gen_newPopUpAttachment(divobj,divName,testtable,foottableObj);
	
	var dDiv = divobj.firstChild;
	dDiv.onmouseup = function(){
		up("QCPTConfigDiv_details");
	}
	dDiv.onmousedown = function(event){
		down("QCPTConfigDiv_details",event);
	}
	
			rowObjser=testtable.insertRow(-1);
			var tobj = document.createElement('table');
			var ttrobj = tobj.insertRow(-1);
			var ttdobj ;
				tempspan=document.createElement("span");
				tempspan.innerHTML="Name :&nbsp;<input type=text name=sc_name id=sc_name size=35>";
				ttdobj=appendTdItem(tempspan,ttrobj,-1);
				ttdobj.className = 'scmenuButton';
				ttdobj.align='left'; 
				ttdobj.width = '65%'; 
				ttdobj.border='0';
				
		var savebt,saveloadbt,cancelbt;
		if(isFromEdit){
			saveloadbt="<a id='hsp_add_load_shortcut' tabindex='1' style='padding-bottom:2px;padding-left:3px;float:right;' onclick='this.blur();' tabIndex=-1 href='javascript:addQCPTShortcut(false,true);' class='btn onbtn' title='Save & Load'><b><b><b>Save & Load</b></b></b></a>";
			savebt="<a id='hsp_add_shortcut' tabindex='1' style='padding-bottom:2px;padding-left:3px;float:right;' onclick='this.blur();' tabIndex=-1 href='javascript:addQCPTShortcut(true);' class='btn onbtn' title='Save'><b><b><b>Save</b></b></b></a>";
		}else{
			saveloadbt="<a id='hsp_add_load_shortcut' tabindex='1' style='padding-bottom:2px;padding-left:3px;float:right;' onclick='this.blur();' tabIndex=-1 href='javascript:addQCPTShortcut(false,true);' class='btn onbtn' title='Add & Load'><b><b><b>Add & Load</b></b></b></a>";
			savebt="<a id='hsp_add_shortcut' tabindex='1' style='padding-bottom:2px;padding-left:3px;float:right;' onclick='this.blur();' tabIndex=-1 href='javascript:addQCPTShortcut(false);' class='btn onbtn' title='Add'><b><b><b>Add</b></b></b></a>";
		}
		cancelbt="<a id='hsp_shortcut_cancel' tabindex='1' style='padding-bottom:2px;padding-left:3px;float:right;' onclick='this.blur();' tabIndex=-1 href='javascript:hsp_showHideShortcutdetails(false);' class='btn onbtn' title='Cancel'><b><b><b>Cancel</b></b></b></a>";		
				tempspan=document.createElement("span");
				tempspan.innerHTML=saveloadbt;
				ttdobj=appendTdItem(tempspan,ttrobj,-1);
				ttdobj.align='right';
				ttdobj.border='0';

				tempspan=document.createElement("span");
				tempspan.innerHTML=savebt;
				ttdobj=appendTdItem(tempspan,ttrobj,-1);
				ttdobj.align='right';
				ttdobj.border='0';

				tempspan=document.createElement("span");
				tempspan.innerHTML=cancelbt;
				ttdobj=appendTdItem(tempspan,ttrobj,-1);
				ttdobj.align='right';
				ttdobj.border='0';

				tempobj=appendTdItem(tobj,rowObjser,-1);
				tempobj.className = 'scmenuButton';
				tempobj.border='0';
				tempobj.style.colSpan=10;
				tempobj.colSpan=10;

				testbody1=document.createElement('tbody');
				//testbody1.className = 'editableGridService';
				testbody1.appendChild(rowObjser);
				testtable.appendChild(testbody1);
			
				testbody1=document.createElement('tbody');
				constructLable=true;

				rowObjser=testtable.insertRow(-1);
				rowObjser.className='headStrip';
				rowObjser.setAttribute("isProcessed",1);
				temptd = insertTdItem("CPT&nbsp;&nbsp;",rowObjser,-1);
				temptd.className="scmenuButton";
					var dximg2=document.createElement('img');
					dximg2.src='../../../images/pinocular.gif';
					dximg2.title='Pick CPT';
					dximg2.style.cursor='pointer';
					addEvent(dximg2, 'click', openQCPTPicker);
					temptd.appendChild(dximg2);
					
					temptd = insertTdItem("Mod1",rowObjser,-1);
					temptd.className="scmenuButton";
					
					temptd = insertTdItem("Units",rowObjser,-1);
					temptd.className="scmenuButton";

					temptd = insertTdItem("&nbsp;",rowObjser,-1);
					temptd.className="scmenuButton";
					
					temptd = insertTdItem("Dx1",rowObjser,-1);
					temptd.className="scmenuButton";
					
					temptd = insertTdItem("Dx2",rowObjser,-1);
					temptd.className="scmenuButton";
					
					temptd = insertTdItem("Dx3",rowObjser,-1);
					temptd.className="scmenuButton";
					
					temptd = insertTdItem("Dx4",rowObjser,-1);
					temptd.className="scmenuButton";

					temptd = insertTdItem("&nbsp;&nbsp;",rowObjser,-1);
					temptd.className="scmenuButton";

				testbody1.appendChild(rowObjser);
				testtable.appendChild(testbody1);
			testbody1=document.createElement('tbody');		
			testbody1.id="service_tbody";
				testtable.appendChild(testbody1);

				addNewQCPTRow();
/*
				if(!isFromEdit)
					addNewRow(0);
*/
			divobj.style.display="block";
			foottableObj.style.display="inline-block";
			rowObj=foottableObj.insertRow(-1);
		if(isFromEdit){
			loadQCPTDataToEdit();
		}
}
var addQCPTShortcut = function(isFromEdit,isload){
	var scNameObj = document.getElementById("sc_name");
	var scName = scNameObj.value;
	if((scName.trim()).length < 1){
		alert("Enter Shortcut name");
		return;
	}
	var tabobj = document.getElementById("service_tbody");
	trobjs = tabobj.rows;
	var cptobj,modobj,unitsobj,dx1obj,dx2obj,dx3obj,dx4obj,tempobj,attrobj,dataFound=false;
	var datatosave = "";
	var dxcodesystem='';
	for(var index=0;index<trobjs.length;index++){
		tempobj = trobjs[index];
		attrobj = tempobj.getAttribute("isprocessed");
		if(attrobj && attrobj==1){
			cptobj = tempobj.cells[0].firstChild;
			modobj = tempobj.cells[1].firstChild;
			unitsobj = tempobj.cells[2].firstChild;
			dx1obj = tempobj.cells[4].firstChild;
			dx2obj = tempobj.cells[5].firstChild;
			dx3obj = tempobj.cells[6].firstChild;
			dx4obj = tempobj.cells[7].firstChild;
			dxcodesystem=tempobj.cells[7].childNodes[1].value;
			if(dataFound){
				datatosave += ",";
			}
			datatosave += cptobj.value+"@"+modobj.value+"@"+unitsobj.value+"@"+dx1obj.value+"@"+dx2obj.value+"@"+dx3obj.value+"@"+dx4obj.value+"@"+dxcodesystem;
			dataFound = true;
		}
	}
	if(dataFound){
		var scid;
		scid = scNameObj.getAttribute("qscid");
		scid = (scid)?scid:-1;
		isload = (isload)?1:0;
		var callback={
			success:QCPTSave_success,
			failure:QCPTSave_Failure
		}
		getAjaxDataFromServer("../ServiceEntry.Action","action=17&isload="+isload+"&scname="+scName+"&shortcutid="+scid+"&scdata="+datatosave+"&randNo="+Math.random(),false,callback);
		//fetchSelectFromServer();
	}else{
		alert("No data to save");
	}
}
var QCPTSave_success = function(responseObject){
	var res=eval(responseObject.responseText);
	var s1=eval(eval(res)[0]);
	var isfound = s1.iscptfound;
	var shortcutid=s1.shortcutid;
    var isload = s1.isload;
    var updateddata = s1.updateddata;
	selectPool.set(52,updateddata);
    constructShortCutConfigDiv(x);
	//drawQuickCPTGroup(shortcutid);
	var t=document.getElementById('QuickCPT_Combo');
	hsp_showHideShortcutdetails(false);
	if(isload && isload==1){
		constructGrp(t,shortcutid);
		showHideQShortcuts(false);
	}else{
		constructGrp(t,-1);
	}
}
var QCPTSave_Failure = function(){
	alert("Saving failed");
}
var loadQCPTDataToEdit = function(){
	var qscSelect = document.getElementById("shortcutcombo");
	var selOpt = qscSelect.options[qscSelect.selectedIndex];
	var selvalue = selOpt.value;
	if(selvalue != -1 && selvalue != "-1"){
		setQCPTScName(selOpt.text,selOpt.getAttribute("scid"));
		loadQCptData(selvalue);
	}else{
		alert("Please select Shortcut to edit");
	}
}
var setQCPTScName = function(scName,scid){
	if(scName){
		var scNameObj = document.getElementById("sc_name")
		scNameObj.value = scName;
		scNameObj.setAttribute("qscid",scid);
	}
}
var loadQCptData = function(selvalue){
	var cptgrp = selvalue.split(",");
	var tempcpt;
	var jsonArrStr = "[";
	var isFirst = true;
	for(var test in cptgrp){
		tempcpt = cptgrp[test];
		temp = (tempcpt).split("@");
		if(!isFirst){
			jsonArrStr += ",";
		}
		jsonArrStr+="{";
		jsonArrStr+="\"col0\":\""+temp[0]+"\","
		jsonArrStr+="\"col1\":\""+((temp[1])?temp[1]:'')+"\",";
		jsonArrStr+="\"col2\":\""+((temp[2])?temp[2]:'')+"\",";
		jsonArrStr+="\"col3\":\""+((temp[3])?temp[3]:'')+"\",";
		jsonArrStr+="\"col4\":\""+((temp[4])?temp[4]:'')+"\",";
		jsonArrStr+="\"col5\":\""+((temp[5])?temp[5]:'')+"\",";
		jsonArrStr+="\"col6\":\""+((temp[6])?temp[6]:'')+"\",";
		jsonArrStr+="\"col7\":\""+((temp[7])?temp[7]:'')+"\"";
		jsonArrStr+="}";
		isFirst = false;
	}
	jsonArrStr += "]";
	load_selectedQCPT(eval(jsonArrStr),true);
}
var hsp_showHideShortcutdetails = function(isShow){
	document.getElementById("QCPTConfigDiv_details").style.display=(isShow)?"block":"none";
}
var openQCPTPicker = function(){
	openPicker(2,'load_selectedQCPT',null,10,false,20);
}
var load_selectedQCPT = function(cptArr,fromEdit){
	var tabobj = document.getElementById("service_tbody");
	var trobjs ;
	var attrobj,tempobj,cptobj,unitsobj,modobj,dxobj;
	var tempcell;
	for(var data in cptArr){
		trobjs = tabobj.rows;
		tempobj = null;
		for(var index=0;index<trobjs.length;index++){
			attrobj = (trobjs[index]).getAttribute("isprocessed");
			if(!attrobj || attrobj==0){
				tempobj = trobjs[index];
				break;
			}
		}
		if(!tempobj || tempobj==null){
			tempobj = addNewQCPTRow();
		}
		cptobj = tempobj.cells[0].firstChild;
		cptobj.value = cptArr[data]['col0'];
		if(fromEdit){
			modobj = tempobj.cells[1].firstChild;
			modobj.value = cptArr[data]['col1'];
			unitsobj = tempobj.cells[2].firstChild;
			unitsobj.value = cptArr[data]['col2'];
			dxobj = tempobj.cells[4].firstChild;
			dxobj.value = cptArr[data]['col3'];
			dxobj = tempobj.cells[5].firstChild;
			dxobj.value = cptArr[data]['col4'];
			dxobj = tempobj.cells[6].firstChild;
			dxobj.value = cptArr[data]['col5'];
			dxobj = tempobj.cells[7].firstChild;
			dxobj.value = cptArr[data]['col6'];
		}else{
			unitsobj = tempobj.cells[2].firstChild;
			unitsobj.value = 1;
		}
		tempobj.lastChild.innerHTML = "<img src='../../../images/close.gif' style='cursor:pointer;' title='Remove' onclick='removeServiceEntry(this);'>";
		tempobj.setAttribute("isProcessed",1);
	}
	addNewQCPTRow();
}
var addNewQCPTRow = function(){
	var returntr;
	var temptd;
	var rowObjser;
	var tbodyobj ;
	tbodyobj = document.getElementById("service_tbody");
	var trs = tbodyobj.rows;
	var scddiv = document.getElementById("QCPTConfigDiv_details");
	//var detailsdiv = cm_y_getPopUpBContent(scddiv,true);
	var lengthoftr = trs.length;
	var newDxImg,tempdxdiv;	
	for(var l=0;l<trs.length;l++){
		var childtr = trs[l];
		var ctrattr = childtr.getAttribute("isProcessed");
		if(!ctrattr || ctrattr==0){
			returntr = trs[l];
			return returntr;
		}
	}
	rowObjser = tbodyobj.insertRow(-1);
	rowObjser.noWrap=true;
		temptd = insertTdItem("<input type=text id=CPTtxt  name=CPTtxt onchange='checkQCPT(this);' size=6 class=hsbTextbox style='width:100%;' >",rowObjser,-1);
		temptd = insertTdItem("<input type=text id=Mod1txt name=Mod1txt size=6 class=hsbTextbox style='width:100%;' >",rowObjser,-1);
		temptd = insertTdItem("<input type=text id=Unitstxt name=Unitstxt size=6 class=hsbTextbox style='width:100%;' >",rowObjser,-1);
		
		newDxImg = quickPrevDxImg.cloneNode(true);
		newDxImg.onclick=function(){
			loadPrevQuickDx(this);
		}
		temptd = appendTdItem(newDxImg,rowObjser,-1);
		
		newDxImg = quickDxImg.cloneNode(true);
		newDxImg.onclick=function(){
			createQuickDxPicker(this);
		}
		
		var icd10Img = new Image();
		icd10Img.src ='../../../images/blue14x14/Picker.png';
		icd10Img.title = "Pick ICD10 Dx";
		icd10Img.style.cursor = "pointer";
		icd10Img.onclick=function(){
			createQuickDx10Picker(this);
		}
		
		temptd.appendChild(newDxImg);
		temptd.appendChild(icd10Img);
		
		temptd = insertTdItem("<input type=text id=dx1txt name=dx1txt size=8 class=hsbTextbox style='width:100%;' >",rowObjser,-1);
		temptd = insertTdItem("<input type=text id=dx2txt name=dx2txt size=8 class=hsbTextbox style='width:100%;' >",rowObjser,-1);
		temptd = insertTdItem("<input type=text id=dx3txt name=dx3txt size=8 class=hsbTextbox style='width:100%;' >",rowObjser,-1);
		temptd = insertTdItem("<input type=text id=dx4txt name=dx4txt size=8 class=hsbTextbox style='width:100%;'/><input type=hidden id='quickdxcodesystem' name='quickdxcodesystem' size=8 class=hsbTextbox style='width:100%;'/>",rowObjser,-1);
			
		temptd = insertTdItem("&nbsp;&nbsp;",rowObjser,-1);

	tbodyobj.appendChild(rowObjser);
	//gen_setDivToCenter(scddiv);
	return rowObjser;
}
var removeServiceEntry = function(obj){
	if(obj){
		var par = obj.parentNode.parentNode;
		par.parentNode.removeChild(par);
	}
}
var loadQCPTFromConfig = function() {
	var qscSelect = document.getElementById("shortcutcombo");
	var selvalue = qscSelect.options[qscSelect.selectedIndex].value;
	if(selvalue != -1 && selvalue != "-1"){
		showHideQShortcuts(false);
		loadSelectedGroup(selvalue);
	}else{
		alert("Please select Shortcut to load");
	}
}
var resetQCPTComboValue = function(){
	var combo = document.getElementById("shortcutcombo");
	if(combo){
		combo.selectedIndex = 0;
	}
}
var showHideQShortcuts = function(isShow){
	document.getElementById("QCPTConfigDiv").style.display=(isShow)?"block":"none";
	resetQCPTComboValue();
	showHideEvents(isShow);
}
var showHideEvents = function(isShow){
	document.getElementById('eventBlocker').style.display=(isShow)?"block":"none";
}
var loadSelecteGroupCPTs = function(obj){
	//loadDXFromAssesment();
	if(obj){
		var cpts = obj.options[obj.selectedIndex].value;
		if(cpts!="-1")
			loadSelectedGroup(cpts);
	}
}
var constructQuickCptCombo = function(x){
	var tarobj = document.getElementById("QCPTGroupCmb");
	if(tarobj){
		tarobj.innerHTML="";
	var selectElt = document.createElement("select");
	selectElt.style.width = "70px";
	selectElt.onchange = function(){
		loadSelecteGroupCPTs(this);
	}
	var ele=selectPool.get(52);
	var firstG=eval("("+ele+")");
	if(!firstG){
		return;
	}
	x = (x)?x:-1;
	var firstLength=firstG.length;
	var opt = addOption(selectElt,"-1","None",0);
	//opt.selected = "1";
	for(var i=0;i<firstLength;i++){
		opt = addOption(selectElt,firstG[i].hsp001,firstG[i].hsp002,i+1);
		if(x == firstG[i].qcgid){
			opt.selected = "1"; 
		}
	}
	if(tarobj != null)    //to Avoid script error while QCPTGroupCmb is not available
		tarobj.appendChild(selectElt);
}
	//tarobj.appendChild(selectElt);
}
var addOption = function(selectElt,optval,opttext,position){
	if(selectElt){
		var opt = new Option();
	    	opt.value=optval;
			opt.text=opttext;
		if(navigator.appName=="Netscape"){
			selectElt.add(opt, null);
		}else{
	    	selectElt.add(opt,position);
	    }
	    return opt;
	}
}
function drawQuickCPT(){
	var ele=selectPool.get(51);
	var eleObj=eval("("+ele+")");
	var firstG=eleObj.FirstGroup;
	var secondG=eleObj.SecondGroup;
	var thirdG=eleObj.ThirdGroup;
	var fourthG=eleObj.FourthGroup;
	var firstLength=firstG.length;
	var secondLength=secondG.length;
	var thirdLength=thirdG.length;
	var fourthLength=fourthG.length;
	var inH="<table width='100%'style='border-collapse:collapse' class='generaltextbox'>";
	inH+="<tr><td colspan=21><b>Please click on the CPT code to load</b></td></tr>";
	if(firstLength > 0)
	 inH+="<tr width='100%'><td width='15%'><b>"+firstG[0].groupname+"</b></td>";
	 else
		 inH+="<tr width='100%'><td width='15%'><b>&nbsp;</b></td>";	 
	 for(var i=0;i<5;i++){
		 if(i==4){
			 if(i < firstLength)
					inH+="<td><a href=\"javascript:sr_loadEMCode('"+firstG[i].code+"');\" title='"+firstG[i].cptdesc+"' >"+firstG[i].code+"</a></td>";	
				else
					inH+="<td>&nbsp;</td>";
		 }else{
		if(i < firstLength)
			inH+="<td><a href=\"javascript:sr_loadEMCode('"+firstG[i].code+"');\" title='"+firstG[i].cptdesc+"' >"+firstG[i].code+"</a></td><td>&nbsp;</td>";	
		else
			inH+="<td>&nbsp;</td><td>&nbsp;</td>";
		 }
	} 
	inH+="<td width='20%'>&nbsp;</td>";

	if(secondLength > 0)
		 inH+="<td width='20%'><b>"+secondG[0].groupname+"</b></td>";
		 else
			 inH+="<td width='20%'><b>&nbsp;</b></td>";	 
		 for(var i=0;i<5;i++){
			 if(i==4){
				 if(i < secondLength)
						inH+="<td><a href=\"javascript:sr_loadEMCode('"+secondG[i].code+"');\" title='"+secondG[i].cptdesc+"' >"+secondG[i].code+"</a></td>";	
					else
						inH+="<td>&nbsp;</td>";
			 }else{
			if(i < secondLength)
				inH+="<td><a href=\"javascript:sr_loadEMCode('"+secondG[i].code+"');\" title='"+secondG[i].cptdesc+"' >"+secondG[i].code+"</a></td><td>&nbsp;</td>";	
			else
				inH+="<td>&nbsp;</td><td>&nbsp;</td>";
			 }
		}
		 inH+="</tr>";
	if(thirdLength > 0)
			 inH+="<tr width='100%'><td width='15%'><b>"+thirdG[0].groupname+"</b></td>";
			 else
				 inH+="<tr width='100%'><td width='15%'><b>&nbsp;</b></td>";	 
			 for(var i=0;i<5;i++){
				 if(i==4){
					 if(i < thirdLength)
							inH+="<td><a href=\"javascript:sr_loadEMCode('"+thirdG[i].code+"');\" title='"+thirdG[i].cptdesc+"' >"+thirdG[i].code+"</a></td>";	
						else
							inH+="<td>&nbsp;</td>";
				 }else{
				if(i < thirdLength)
					inH+="<td><a href=\"javascript:sr_loadEMCode('"+thirdG[i].code+"');\" title='"+thirdG[i].cptdesc+"' >"+thirdG[i].code+"</a></td><td>&nbsp;</td>";	
				else
					inH+="<td>&nbsp;</td><td>&nbsp;</td>";
				 }
			} 
	inH+="<td width='20%'>&nbsp;</td>";
	if(fourthLength > 0)
		 inH+="<td width='20%'><b>"+fourthG[0].groupname+"</b></td>";
		 else
			 inH+="<td width='20%'><b>&nbsp;</b></td>";	 
		 for(var i=0;i<5;i++){
			 if(i==4){
				 if(i < fourthLength)
						inH+="<td><a href=\"javascript:sr_loadEMCode('"+fourthG[i].code+"');\" title='"+fourthG[i].cptdesc+"' >"+fourthG[i].code+"</a></td>";	
					else
						inH+="<td>&nbsp;</td>";
			 }else{
			if(i < fourthLength)
				inH+="<td><a href=\"javascript:sr_loadEMCode('"+fourthG[i].code+"');\" title='"+fourthG[i].cptdesc+"' >"+fourthG[i].code+"</a></td><td>&nbsp;</td>";	
			else
				inH+="<td>&nbsp;</td><td>&nbsp;</td>";
			 }
		}
		 inH+="</tr>";
	inH+="</table>";
	var inDiv=document.getElementById('EMCodes');
	inDiv.innerHTML=inH;
	var quickCptObj=document.getElementById('EMCodes');
		quickCptObj.setAttribute("isdragable","1");
		quickCptObj.onmouseover=function(){
		quickCptObj.style.cursor="move";
	}

	quickCptObj.onmousedown=function(e){
		down('EMCodes',e);
	}
	quickCptObj.onmouseup=function(){
		up('EMCodes');
	}
}
function sr_ReceiptManagement(){
	if(defaultdate=='')
		setDefaults();
	var URL="../Eob/ReceiptManagementLayout.Action?noofresults=20&patientId="+PATIENT_ID+"&receiptDate="+defaultdate;
	var xtop=0;
  	var xleft=0;
  	var xheight=(screen.height-61);
  	var xwidth=(screen.width-13);     
  	var win = window.open(URL,"Deposit","width="+xwidth+",height="+xheight+",top="+xtop+",left="+xleft+",resizable=no");    
	win.focus();
}
/* DIV DRAGING SCRIPT START  */

var n = 500;
var dragok = false;
var y,x,d,dy,dx,zind;
function move(e){
	if (!e) e = window.event;
	 if (dragok){
		  d.style.left = dx + e.clientX - x + "px";
		  d.style.top  = dy + e.clientY - y + "px";
		  return false;
	 }
}

function down(divid,e){
	if (!e) e = window.event;
/*	var temp = (typeof e.target != "undefined")?e.target:e.srcElement;
	if (temp.tagName != "HTML"|"BODY" && temp.className != "dragclass"){
		 temp = (typeof temp.parentNode != "undefined")?temp.parentNode:temp.parentElement;
	 }
*/	 
	var temp = document.getElementById(divid);
	if (temp.getAttribute("isdragable")=="1"){
		 dragok = true;
		 zind = temp.style.zIndex;
		 temp.style.zIndex = n++;
		 d = temp;
		 if(divid=="div3" || divid=="EMCodes" || divid=="div2"){
			 dx = parseInt(temp.offsetLeft+0);
			 dy = parseInt(temp.offsetTop+0);
		 }else{
		 dx = parseInt(temp.style.left+0);
		 dy = parseInt(temp.style.top+0);
		 }

		 x = e.clientX;
		 y = e.clientY;
		 document.onmousemove = move;
		 return false;
	 }
}

function up(divid){
	var temp = document.getElementById(divid);
	if (temp.getAttribute("isdragable")=="1"){
		temp.style.zIndex = (zind)?zind:0;
	}
	dragok = false;
	document.onmousemove = null; 
}

/*  DIV DRAGING SCRIPT END  */

/*         COMMONSCRIPT FUNCTIONS           */
var gen_newPopUpAttachment=function(filterDivObj,headerName,bodyTable,footerTable,isAlert,isDraggable){
	var dynObj,docObj,tmpSchild;
	docObj=filterDivObj;
	docObj.innerHTML="";
		dynObj=document.createElement("div");
		dynObj.className=((isAlert)?("modal-dialog-title-alert modal-dialog-title-draggable"):("modal-dialog-title modal-dialog-title-draggable"));
		dynObj.className=((isDraggable)?(dynObj.className+" draggable"):(dynObj.className));
		docObj.appendChild(dynObj);
			tmpSchild=document.createElement("span");
			tmpSchild.className=((isAlert)?("modal-dialog-title-text-alert"):("modal-dialog-title-text"));
			tmpSchild.innerHTML=headerName;
			dynObj.appendChild(tmpSchild);
		dynObj=document.createElement("div");
		dynObj.className="modal-dialog-content";
		docObj.appendChild(dynObj);
		
		dynObj.appendChild(bodyTable);
		
		dynObj=document.createElement("div");
		dynObj.className="modal-dialog-buttons";
		dynObj.style.textAlign="center";
		docObj.appendChild(dynObj);
		
		dynObj.appendChild(footerTable);
}
function showStatusPopup(isShow){		
	document.getElementById("serviceStatusDiv").style.display = ((isShow) ? "block": "none");		
//	document.getElementById("serviceStatusIFrame").style.display = ((isShow) ? "block": "none");		
	moreDateAppend="";		
}
var insertTdItem=function(dataval,rowobj,pos){
	var tdobj=rowobj.insertCell(pos);
	tdobj.innerHTML=dataval;
	return tdobj; 
}
var addEvent=function(evtobj,evt,myFunction){
	if (evtobj.addEventListener) {
		evtobj.addEventListener (evt,myFunction ,false);
	} else if (evtobj.attachEvent) {
		evtobj.attachEvent ("on"+evt,myFunction);
	}
}
var appendTdItem=function(dataobj,rowobj,pos){
	var tdobj=rowobj.insertCell(pos);
	tdobj.appendChild(dataobj);
	return tdobj; 
}
String.prototype.trim = function() {
	return this.replace(/^\s+|\s+$/g,"");
}


var dx1FromAssesment="";
var dx2FromAssesment="";
var dx3FromAssesment="";
var dx4FromAssesment="";
var dxcodesystem="";

function loadDXFromAssesment(){
	dx1FromAssesment = "";
	dx2FromAssesment = "";
	dx3FromAssesment = "";
	dx4FromAssesment = "";
	var dos=document.getElementById('DOStxt_'+getCurrentRowId()).value;
	var a=eval(getResponseData("../ServiceEntry.Action?action=11&patientId="+PATIENT_ID+"&dos="+dos+"&rand="+Math.floor(Math.random()*1121)));
	var data=eval(a[0]);
	var dxD=eval(data.assessment_dx);
	if(dxD.length >0){
		if(0<dxD.length){
			dx1FromAssesment = Trim(dxD[0].dxcode);
		}
		if(1<dxD.length){
			dx2FromAssesment = Trim(dxD[1].dxcode);
		}
		if(2<dxD.length){
			dx3FromAssesment = Trim(dxD[2].dxcode);
		}
		if(3<dxD.length){
			dx4FromAssesment = Trim(dxD[3].dxcode);
		}
		dxcodesystem=Trim(dxD[0].codesystemid);
	}else{
		dx1FromAssesment = "";
		dx2FromAssesment = "";
		dx3FromAssesment = "";
		dx4FromAssesment = "";
	}
}
function openOrHidediv(){
	var divObj=document.getElementById("div3");
	if(divObj!=null && divObj!=undefined){
	if(divObj.style.display=="block"){
		closeDialog("div3",false,0);
	}else{
		divObj.style.display="block";
	}
	}else{
		drawQuickCPTGroup();
	} 
}

var disableFieldsForFullySetteledServices = function(rowId){
	document.getElementById('CPTtxt_'+rowId).setAttribute("disabled","disabled");
	document.getElementById('DOStxt_'+rowId).setAttribute("disabled","disabled");
	document.getElementById('dosto_'+rowId).setAttribute("disabled","disabled");
	document.getElementById('Mod1txt_'+rowId).setAttribute("disabled","disabled");
	document.getElementById('Unitstxt_'+rowId).setAttribute("disabled","disabled");
	document.getElementById('Chargestxt_'+rowId).setAttribute("disabled","disabled");
	document.getElementById('Copaytxt_'+rowId).setAttribute("disabled","disabled");
	document.getElementById('Paymentstxt_'+rowId).setAttribute("disabled","disabled");
	document.getElementById('DX1txt_'+rowId).setAttribute("disabled","disabled");
	document.getElementById('DX2txt_'+rowId).setAttribute("disabled","disabled");
	document.getElementById('DX3txt_'+rowId).setAttribute("disabled","disabled");
	document.getElementById('DX4txt_'+rowId).setAttribute("disabled","disabled");
	document.getElementById('TifReftxt_'+rowId).setAttribute("disabled","disabled");
	document.getElementById('CostPlancmb_'+rowId).setAttribute("disabled","true");
	document.getElementById('D-X5-20txt_'+rowId).setAttribute("disabled","true");
	if(paymentGroup==1)
		document.getElementById('PaymentGroupcmb_'+rowId).setAttribute("disabled","true");
	document.getElementById('HowPaidcmb_'+rowId).setAttribute("disabled","true");
	document.getElementById('Checktxt_'+rowId).setAttribute("disabled","disabled");
	document.getElementById('Authcmb_'+rowId).setAttribute("disabled","true");
	//document.getElementById('SpDxtxt_'+rowId).setAttribute("disabled","disabled");
	document.getElementById('Commentstxt_'+rowId).setAttribute("disabled","true");
	document.getElementById('billingReasoncmb_'+rowId).setAttribute("disabled","true");
	document.getElementById('Mod2txt_'+rowId).setAttribute("disabled","disabled");
	document.getElementById('Mod3txt_'+rowId).setAttribute("disabled","disabled");
	document.getElementById('Mod4txt_'+rowId).setAttribute("disabled","disabled");
	document.getElementById('Rlutxt_'+rowId).setAttribute("disabled","disabled");
	document.getElementById('VisitTypecmb_'+rowId).setAttribute("disabled","true");
	document.getElementById('Statuscmb_'+rowId).setAttribute("disabled","true");
	
}
var showFormValidationRules = function(){
	window.open("GlaceValidationsAction.Action?rand="+Math.random(),"GlaceServiceValidations","'width=400,height=800,scrollbars=1,resize=true'");
}
/*         COMMONSCRIPT FUNCTIONS           */
function alertPageScriptDownloaded(){

}
var alertPageScriptDownloadedForIE=function(obj){
	
}

function compareDos(evt)
{
	
	if(!evt)evt=window.event;
	var obj = getTarget(evt);
	var name=obj.name;
	var dosFrom="";
	var id=name.substring(name.indexOf("_")+1,name.length);
	dosFrom= eval("document.serviceinformation.DOStxt_" + id).value;
	if(dosFrom!='' && obj.value!='')
	if(new Date(dosFrom) > new Date(obj.value))
	{   var orival="";
		
			if(document.getElementById('dosto_' + id).getAttribute('orival')!=null)
				orival=document.getElementById('dosto_' + id).getAttribute('orival');
	    alert("Dos To cannot be less than DOS date!");
		obj.value=orival;
		obj.focus();
	
	}else if(new Date(dosFrom).getTime() != new Date(obj.value).getTime()){
		disableUnrelatedFieldsForBulkInsert(id,0); //Given DOS From and DOS To with date diff more than one
		formatDateOnBlurLocal(obj);
	}else{
		disableUnrelatedFieldsForBulkInsert(id,1);
	}
}

var disableUnrelatedFieldsForBulkInsert = function(objId,mode){
	if(mode==0){
		document.getElementById('Paymentstxt_'+objId).setAttribute("readonly","true");
		document.getElementById('Paymentstxt_'+objId).style.color = "#996666";


		document.getElementById("Checktxt_"+objId).setAttribute("readonly","true");
		document.getElementById("Checktxt_"+objId).style.color = "#996666";
	}else{
		document.getElementById('Paymentstxt_'+objId).removeAttribute("readonly");
		document.getElementById('Paymentstxt_'+objId).style.color = "#000000";

		document.getElementById("Checktxt_"+objId).removeAttribute("readonly");
		document.getElementById("Checktxt_"+objId).style.color = "#000000";
	}
}

function addOnHoldHiddenData(){
	try{
		var corrected_dataString="";
		var tempdataString=dataString.split(",");
		for(var i=0;i<tempdataString.length;i++){
			if(tempdataString[i]!='No Data' && tempdataString[i]!='' && tempdataString[i]!='undefined'){
				corrected_dataString+=tempdataString[i]+",";
			}
		}
		if(corrected_dataString.lastIndexOf(",") == corrected_dataString.length-1){
	        		corrected_dataString = corrected_dataString.substring(0,corrected_dataString.length-1);
	     }
		addHiddenFieldWithValue(document.serviceinformation,'dataString',corrected_dataString);
	}catch(e){alert(e.message)}
}

var globalOnHoldProblemsList,insertNameAR,nxtFollowupDate,oldVal;
function removeSelOnHoldData(ssVal,name){
	 var rowIdVal,globalOnHoldReconProbList="",tempStr="",len;
	 if(name=="Statuscmb_"+PATIENT_ID){
	 		rowIdVal=0;	
	 }else{
	  	rowIdVal=name.split("_")[2];
	 }	
	 tempStr=dataString.split(",");
	 len=tempStr.length;
	 var delIndex=-1;
	 for(var i=0;i<len;i++){
	 	delIndex=tempStr[i].indexOf("~#"+rowIdVal);
	 	if(delIndex<0)
	 		globalOnHoldReconProbList+=tempStr[i]+",";
	 	else
	 	   globalOnHoldReconProbList+="No Data,";
	 }
	 if(ssVal.toLowerCase()!='on hold'){
	  dataString=globalOnHoldReconProbList.replace(",,",",");
	 if(dataString.length==1)
	   	dataString="";
	 }
}
function showAROnHoldDiv(name,idVal,defval){
insertNameAR=name;
oldVal=defval;
if(globalOnHoldProblemsList==null || globalOnHoldProblemsList=='undefined'){
	var callback={
		success:drawOnHoldDivFieldsSuccess,
		failure:drawOnHoldDivFieldsFailure,
		progress:drawOnHoldDivFieldsProgress
	};
	getAjaxDataFromServer('QuickArAnalysis.Action',"group=3",false,callback);
}else{
	constructOnHoldAction();
}
}
var drawOnHoldDivFieldsSuccess=function(responseObject){
	var response = responseObject.responseText;
    var onHoldProblemsVec = cart_getResult(response, "onHoldProblemsList");
 	globalOnHoldProblemsList = eval(onHoldProblemsVec);
	nxtFollowupDate=eval('(' + response + ')')[0].onHoldSerNxtFollDate;
	constructOnHoldAction();
}
var drawOnHoldDivFieldsFailure=function(responseObject){}
var drawOnHoldDivFieldsProgress=function(responseObject){}
function constructOnHoldAction(){
	var resobj,str="";
 	document.getElementById('sr_frameBlocker').style.display='block';
	var popUpDiv=document.getElementById("service_ywin");
	var bDObj=cm_y_getPopUpBContent(popUpDiv);
	bDObj.style.backgroundColor="#E4F6FA";
 	str+="<table width=100% style='font-family:arial,verdana,sans-serif;font-size:11px;white-space:nowrap;'>" +
		"<tr><td>Problem Type <span style='color:red;'>&nbsp;*</span></td>";
	str+="<td><select id='probIndex' style='width:100%;'><option value=-1>None</option>";
 	for(var i=0;i<globalOnHoldProblemsList.length;i++){
		resobj=eval(globalOnHoldProblemsList[i]);
 	 	str+="<option value="+resobj.probid+" >"+resobj.problem+"</option>";
	 }
 	str+="</select></td></tr>";
 	str+="<tr><td>Reference </td><td><input type='text' id='serRef_txt'></td></tr>";
 	str+="<tr><td>Next Followup Date <span style='color:red;'>&nbsp;*</span></td><td><input type='text' id='serNxtFollow_txt' maxLength='10' size='10' value="+nxtFollowupDate+" onBlur='JavaScript:CheckDate(this)' onKeyUp='JavaScript:FormatDate(this);'>&nbsp;&nbsp;<div class='calendar' onclick='gen_setCalendarParent(this)'></div></td></tr>";
 	str+="<tr><td>Notes </td><td><textarea style='width: 100%;' id='serNotes_txt' name='serNotes_txt'></textarea></td></tr>";
 	str+="<tr ><td></td><td ><a title='Save' class='btn onbtn' href='javascript:actionFrameBlock(true);' id='save_actionid'><b><b><b>Save</b></b></b></a><a title='Cancel' href='javascript:actionFrameBlock(false);' class='btn onbtn'><b><b><b>Cancel</b></b></b></a></td></tr>";
	str+="</table>";
	bDObj.innerHTML=str;
	popUpDiv.style.width="400px";
	cm_y_getPopUpHContent(popUpDiv).innerHTML="Mark as OnHold";
	cm_y_getPopUpFContent(popUpDiv).innerHTML="<span style='color:red;'>*</span> Mandatory field(s)";
	if(popUpDiv.style.display='none'){
		popUpDiv.style.display='block';
	}	
			YAHOO.glace.servicepanel.needGarbager=true;
			YAHOO.glace.servicepanel.callGarbager="sr_garbageCollect_new";
			YAHOO.glace.servicepanel.show();

}
	
function actionFrameBlock(toBlock){
	 var problemid=document.getElementById("probIndex");
	 var nxtFollDate=document.getElementById("serNxtFollow_txt")
	 var nxtfolldate=document.getElementById("serNxtFollow_txt");
	 var reference=document.getElementById("serRef_txt");
	 var notes=document.getElementById("serNotes_txt");
	 var popUpDiv=document.getElementById("service_ywin");
	 var blockDiv=document.getElementById("sr_frameBlocker");
	 var localDataString,indexVal,tempStr,dataReconString="";
	 var moveArr=new Array();
	 var resetArr=new Array();
	 if(!toBlock){
	 	popUpDiv.style.display='none';
	 	blockDiv.style.display='none';
	 	setPreviousStatus(oldVal);
		
	 }else{
	 	if(problemid.options[problemid.selectedIndex].value==-1 || problemid.options[problemid.selectedIndex].value=='undefined'){
	 		alert("Select problemid");
	 		return;
	 	}
	 	if(nxtFollDate.value==null || nxtFollDate.value=="" || nxtFollDate.value=="undefined"){
	 		alert("Enter next followup date");
	 		return;
	 	}
	 	var tempIndexArr=insertNameAR.split("_");
	 	if(tempIndexArr.length<3){
	 		indexVal=0;
	 		resetArr[resetArr.length]=indexVal;
	 		dataString="";
	 	}else{
	 		indexVal=tempIndexArr[2];
	 		resetArr[resetArr.length]=indexVal;
	 	}	
	 	for(var i=0;i<resetArr.length;i++){
	 		if(resetArr[i]==indexVal){
	 			removeSelOnHoldData("",insertNameAR);
	 		}
	 	}
	 	localDataString=problemid.value+"~"+nxtfolldate.value+"~"+reference.value+"~"+notes.value+"~#"+indexVal;
	 	tempStr=dataString.split(",");
	 	tempStr[indexVal]=localDataString;
	 	for(var i=0;i<tempStr.length;i++){
	 		dataReconString+=tempStr[i]+",";
	 	}
	 	dataReconString=dataReconString.replace(",,",",");
	 	dataString=dataReconString;
	 	if(dataString.charAt(0)==",")
	 		dataString=dataString.substring(1,dataString.length);
	 	dataString=dataString.replace(",,",",");
	 	
	 	if(popUpDiv.style.display='block'){
	 		popUpDiv.style.display='none';
	 	}	
	 	if(blockDiv.style.display='block'){
	 		blockDiv.style.display='none';
	 	}
	 }
	 
	}
function setPreviousStatus(oldVal){try{ 
	var text;
	if(oldVal=='0'){
		text="EMR Service";
	}else if(oldVal=='A'){
		text="On Hold";
	}
	else if(oldVal=='B'){
		text="Bad Debt";
	}
	else if(oldVal=='C'){
		text="Capitation Payment";
	}
	else if(oldVal=='G'){
		text="Ready for Other Insurance";
	}
	else if(oldVal=='H'){
		text="Sent to Other Insurance";
	}
	else if(oldVal=='P'){
		text="Ready for Primary";
	}
	else if(oldVal=='Q'){
		text="Ready for Secondary";
	}
	else if(oldVal=='R'){
		text="Primary sent";
	}
	else if(oldVal=='S'){
		text="Secondary sent";
	}
	else if(oldVal=='T'){
		text="Ready for Patient Billing";
	}
	else if(oldVal=='X'){
		text="Fully Settled";
	}
	else if(oldVal=='Y'){
		text="Void";
	}
	document.getElementById(insertNameAR).value=text;
	document.getElementById(insertNameAR).setAttribute("comboval",oldVal);
	document.getElementById(insertNameAR).setAttribute("orival",oldVal);
}catch(e){alert(e.message);}
}
	
function checkSubmitStatus(evt,cptObj,flag){
	var past=evt.getAttribute('orival');
	var ch=false;
	var present='-1';
	if(evt.type=='text' || evt.type=='Text' || evt.type=='TEXT')
	present=evt.getAttribute('comboval');
	else
	present=evt.value;

	if(present=='A'){
	 if(past=='0' || past=='P' || past=='T')
	  ch=true;
	}
	if(present=='0'){
	 if(past=='A' || past=='Y' || past=='C')
	  ch=true;
	}
	
	if(present=='T'){
	 if(past=='A')
	  ch=true;
	}
	if(present=='Y' || present=='C' || present=='B'){
	 ch=true;
	}
	if(present==past)
		ch=true;
	if(flag==0 && (cptObj.getAttribute('cpttype')!=1 || cptObj.value=='INSXS' || cptObj.value=='PTSXS' || cptObj.value=='INT00' || cptObj.value=='00INT' || cptObj.value=='INSINT' || cptObj.value=='CAP00' || cptObj.value=='00CNT' || cptObj.value=='CNT00' || cptObj.value=='MISC' || cptObj.value=='NOSHOW' || cptObj.value=='SELF' || cptObj.value=='REFRES' || cptObj.value=='REFACC' || cptObj.value=='00CAP'))
	 {ch=true;}
	if(flag==1 && (cptObj.value=='INSXS' || cptObj.value=='PTSXS' || cptObj.value=='INT00' || cptObj.value=='00INT' || cptObj.value=='INSINT' || cptObj.value=='CAP00' || cptObj.value=='00CNT' || cptObj.value=='CNT00' || cptObj.value=='MISC' || cptObj.value=='NOSHOW' || cptObj.value=='SELF' || cptObj.value=='REFRES' || cptObj.value=='REFACC' || cptObj.value=='00CAP'))
	 {ch=true;}
	if(!ch){
	alert("Changing status from ["+getValueFromPool(past,11)+"] to ["+getValueFromPool(present,11)+"] is not valid !");
	}
	return ch;
	}
function changeSubmitStatus(evt)
{
var ins_name=getValueFromPool(parseInt(evt.value), 20);
var statusEle;
if(ins_name.indexOf('self pay') >-1 || ins_name.indexOf('selfpay') >-1 || ins_name.indexOf('SELF PAY') > -1 || ins_name.indexOf('SELFPAY')>-1 || ins_name.indexOf('Self Pay')>-1 )
{
for(var i=0;i<rowcount;i++)
{
 try{
  statusEle=document.getElementById('Statuscmb_'+PATIENT_ID+'_'+i);
  statusEle.setAttribute("comboval","T");
  statusEle.value="Ready for Patient Billing";
  }
  catch(e){}
}
}
else
{
for(var i=0;i<rowcount;i++)
{
 try{
  statusEle=document.getElementById('Statuscmb_'+PATIENT_ID+'_'+i);
  statusEle.setAttribute("comboval","0");
  statusEle.value="EMR Service";
  }
  catch(e){}
}
}
}
function cart_getResult(response, paramname){
	var tmpobj = eval(response);
	for(var data in tmpobj)
	{
		var tmpobj1 = eval(tmpobj[data]);
		var paramname = eval("tmpobj1." + paramname);
		return eval(paramname);
 	}
}
var getSavedServiceIDArray = function(rowId){
	var arrayIndex=rowId.split('_')[1];
	if(savedServiceIDArray[arrayIndex])
		return savedServiceIDArray[arrayIndex];
	else
		return -1;
}
var clearsavedServiceIDArray = function(){
	savedServiceIDArray = null;
	savedServiceIDArray = new Array();
}
function setDxCodeSystem(evt){
	if(!evt)evt=window.event;
	var name=getTarget(evt).name;
	var obj = getTarget(evt);
	var refid=obj.id;
	var val=obj.value;
	var code='';
	var character='';
	if(evt.keyCode) 
		code=evt.keyCode;
	else if (e.which) 
		code = e.which;
	character = String.fromCharCode(code);
	var callback={
		success:systemid_callSuccess,
		failure:systemid_callFailure
	}
	getSyncAjaxDataFromServer("../../patientstmt/ReleasePatient.Action","mode=25&dxcode="+val+"&rowid="+refid,false,callback);
}
var systemid_callSuccess=function(responseObject)
{
	var result=eval(responseObject.responseText);
	var systemdid=result[0].val;
	var refid=result[0].rowid;
	if(refid.split('_')[2]==undefined){
		document.getElementById('txtDXCodeSystemId_'+refid.split('_')[1]).value=systemdid;
	}
	else{
		document.getElementById('txtDXCodeSystemId_'+refid.split('_')[1]+"_"+refid.split('_')[2]).value=systemdid;
	}
}
var systemid_callFailure=function(responseObject){
	//alert("Error while getting code systemd id");
}
function createICD10Picker(rowid,pickerId){
	activeDxRow=rowid;
	if(editDOS=='')
	{
		if(document.getElementById('CPTtxt_'+activeDxRow).value!=''){
			if(pickerId==1){
				if(document.getElementById('DOStxt_'+activeDxRow) != undefined && document.getElementById('DOStxt_'+activeDxRow) != null && document.getElementById('DOStxt_'+activeDxRow).value !='')
			 		openPicker(28,'selectICD10Value',null,10,false,80,undefined,undefined,undefined,undefined,undefined,true,undefined,document.getElementById('DOStxt_'+activeDxRow).value);
				else
					openPicker(28,'selectICD10Value',null,10,false,80,undefined,undefined,undefined,undefined,undefined,true);
			} 
			if(pickerId==2){
			if(document.getElementById('DOStxt_'+activeDxRow) != undefined && document.getElementById('DOStxt_'+activeDxRow) != null && document.getElementById('DOStxt_'+activeDxRow).value !='')
			 	openPicker(45,'selectICD10Value',null,10,false,10,undefined,undefined,undefined,undefined,undefined,true,undefined,document.getElementById('DOStxt_'+activeDxRow).value);
			 else
				openPicker(45,'selectICD10Value',null,10,false,10,undefined,undefined,undefined,undefined,undefined,true);
			}
		}
		else
			alert("Select a CPT to proceed !");
	}
	else{
		if(document.getElementById('txtCPT_'+activeDxRow).value!=''){
			if(pickerId==1){
				if(document.getElementById('DOStxt_'+activeDxRow) != undefined && document.getElementById('DOStxt_'+activeDxRow) != null && document.getElementById('DOStxt_'+activeDxRow).value !='')
 				 	openPicker(28,'selectICD10Value',null,10,false,80,undefined,undefined,undefined,undefined,undefined,true,undefined,document.getElementById('DOStxt_'+activeDxRow).value);
			 	else
			 		openPicker(28,'selectICD10Value',null,10,false,80,undefined,undefined,undefined,undefined,undefined,true);
 			}
 			if(pickerId==2){
				if(document.getElementById('DOStxt_'+activeDxRow) != undefined && document.getElementById('DOStxt_'+activeDxRow) != null && document.getElementById('DOStxt_'+activeDxRow).value !='')
 					openPicker(45,'selectICD10Value',null,10,false,10,undefined,undefined,undefined,undefined,undefined,true,undefined,document.getElementById('DOStxt_'+activeDxRow).value);
 				else
 					openPicker(45,'selectICD10Value',null,10,false,10,undefined,undefined,undefined,undefined,undefined,true);
 			}
		}
		else
			alert("Select a CPT to proceed !");
	}
}
function selectICD10Value(responseValue){
	try{
		activeDxRow=activerowid;
		clearDxFields(activeDxRow);
		document.getElementById('txtDXCodeSystemId_'+activeDxRow).value='2.16.840.1.113883.6.90';
		if(responseValue.code!=undefined){
			document.getElementById('txtDX1_'+activeDxRow).value=responseValue.code;
			document.getElementById('DX1txt_'+activeDxRow).value=responseValue.code;
		}else{
			for(var i=0;i<responseValue.length;i++){
				if(i<4){
					document.getElementById('txtDX'+(i+1)+'_'+activeDxRow).value=responseValue[i][0];
					document.getElementById('txtDX'+(i+1)+'_'+activeDxRow).title=responseValue[i][1];
					document.getElementById('txtDX'+(i+1)+'Desc_'+activeDxRow).value=responseValue[i][1];
					document.getElementById('DX'+(i+1)+'txt_'+activeDxRow).value=responseValue[i][0];
					document.getElementById('DX'+(i+1)+'txt_'+activeDxRow).title=responseValue[i][1];
				}
			}
			var dxcode='';
			if(responseValue.length>=4){
				for(var i=4;i<responseValue.length;i++){
					document.getElementById('txtDX'+(i+1)+'_'+activeDxRow).value=responseValue[i][0];
					document.getElementById('txtDX'+(i+1)+'_'+activeDxRow).title=responseValue[i][1];
					document.getElementById('txtDX'+(i+1)+'Desc_'+activeDxRow).value=responseValue[i][1];
					dxcode=dxcode+","+responseValue[i][0];
				}
				document.getElementById('D-X5-20txt_'+activeDxRow).value=dxcode.substring(1);
			}
		}
		var dos=new Date(document.getElementById('DOStxt_'+activeDxRow).value);
		var icd10StartDate=new Date('10/01/2015')
		if(dos<icd10StartDate)
			setTimeout("saveServices('domapppings')",25);
	}catch(e){
		alert(e.message);
	}
	}
function setMappingCodes(responseValue){
	var dxrowids=[];
	var selectedcount=0;
	var index=0;
	var previousrowid='';
	var dxcode='';
	var currentrow='';
	for(var i=0;i<responseValue.length;i++){
		var activerowid='';
		if(responseValue[i][1].split("_").length>2)
			activerowid=responseValue[i][1].split("_")[1]+"_"+responseValue[i][1].split("_")[2];
		else
			activerowid=responseValue[i][1].split("_")[1];
		if(previousrowid!=activerowid){
			clearDxFields(activerowid);
			previousrowid=activerowid;
			index=0;
		}
		var currDate=new Date(document.getElementById('DOStxt_'+activerowid).value);
		var icd10StartDate=new Date('10/01/2015');
		if(currDate<=icd10StartDate){
			document.getElementById('txtDXCodeSystemId_'+activerowid).value='2.16.840.1.113883.6.104';
		}else if(currDate>icd10StartDate){
			document.getElementById('txtDXCodeSystemId_'+activerowid).value='2.16.840.1.113883.6.90';
		}
		if(index<4){
			document.getElementById('txtDX'+(index+1)+'_'+activerowid).value=responseValue[i][0];
			document.getElementById('txtDX'+(index+1)+'Desc_'+activerowid).value=responseValue[i][1];
			document.getElementById('txtDX'+(index+1)+'_'+activerowid).title=responseValue[i][1];
			document.getElementById('DX'+(index+1)+'txt_'+activerowid).value=responseValue[i][0];
			document.getElementById('DX'+(index+1)+'txt_'+activerowid).titlr=responseValue[i][1];
		}
		if(index>=4){
			document.getElementById('txtDX'+(index+1)+'_'+activerowid).value=responseValue[i][0];
			document.getElementById('txtDX'+(index+1)+'Desc_'+activerowid).value=responseValue[i][1];
			dxcode=dxcode+","+responseValue[i][0];
		}
		document.getElementById('D-X5-20txt_'+activerowid).value=dxcode.substring(1);
		currentrow=activerowid;
		index++;
	}
	if(nomappingneededcodes.length>0){
		for(var i=0;i<nomappingneededcodes.length && index<20;i++){
			document.getElementById('txtDX'+(index+1)+'_'+activerowid).value = nomappingneededcodes[i];
			if(index<4){
				document.getElementById('DX'+(index+1)+'txt_'+activerowid).value=nomappingneededcodes[i];
			}else{
				if(document.getElementById('D-X5-20txt_'+activerowid).value=='')
					document.getElementById('D-X5-20txt_'+activerowid).value=nomappingneededcodes[i];
				else
				document.getElementById('D-X5-20txt_'+activerowid).value=document.getElementById('D-X5-20txt_'+activerowid).value+","+nomappingneededcodes[i];
			}
			index++;
		}
		nomappingneededcodes=[];
	}
}
function clearDxFields(rowid){
	for(var i=1;i<=20;i++){
		document.getElementById('txtDX'+i+'_'+rowid).value='';
		document.getElementById('txtDX'+i+'Desc_'+rowid).value='';

	}
	for(var i=1;i<=4;i++){
		document.getElementById('DX'+i+'txt_'+rowid).value='';
	}
	document.getElementById('D-X5-20txt_'+rowid).value='';
	document.getElementById('txtDXCodeSystemId_'+rowid).value='';
}
/*R13 gss*/

function getSyncAjaxDataFromServer(fileurl,data,isSync,callback,reqType,transId){
	if(!isSync){
		try{
			AjaxConnect.abortRequests();
			var serverRes=AjaxConnect.sendAsynchRequest((reqType!=null && reqType!=undefined)?(reqType):("POST"),fileurl,callback,data);
		}catch(e){}
	}else{
		return getResponseData(fileurl+"?"+data);
	}
}


function eb_getDivResult(obj,dat){
	var tmpdat=dat.split(codeSplitter);
	obj.setAttribute("optiondesc",(tmpdat.length>1)?tmpdat[1]:tmpdat[0]);
	return tmpdat[0];
}
function openChangeServiceOrder(){		
	
}		
/*function enableProcessingStip(){		
    document.getElementById("progressStatusDiv").innerHTML = '<table align="center"  style="background: #FFF1A8;"><tr><td style="color:black;font-family:arial;font-size:12px; font-weight:bold; text-decoration:none;text-align:center">Processing...</td></tr></table>';		
    document.getElementById("progressStatusDiv").style.display="block";		
    document.getElementById("progressStatusDiv").style.align="center";		
    document.getElementById("progressStatusDiv").style.width="100%";		
}		
function disableProcessingStip(){		
    document.getElementById("progressStatusDiv").innerHTML = "";		
    document.getElementById("progressStatusDiv").style.width="20%";		
    document.getElementById("progressStatusDiv").style.display="none";		
}*/		
function createHeadger(cptValue,rowidOfService){		
//	cptCell.firstChild.value +" - Service Invalid Reasons"		
	var processingTable="<table align='center' id='processingTable' style='margin-left: 45%;position: absolute;background: #FFF1A8;display:none;'><tr><td style='color:black;font-family:arial;font-size:12px; font-weight:bold; text-decoration:none;text-align:center'>Processing...</td></tr></table>";		
//	 var header="<div class='panel panel-primary' style='visibility:visible;'>"+cptValue+" - Service Invalid Reasons"+processingTable+"<img border='0' id='status_close' onclick='this.blur();showHideEvents(false);showStatusPopup(false);' style='cursor:pointer;float:right;visibility:visible;' src='../../../images/toolbar/new/Close.png'><img border='0' id='status_ok' onclick='this.blur();showHideEvents(false);showStatusPopup(false);javascript:updateSelectedValue(\""+rowidOfService+"\");' style='cursor:pointer;float:right;padding-right:10px;visibility:visible;' src='../../../images/chart/prescription/Ok.gif'></div>";		
	 var header="<div class='panel panel-primary headerPanelStyles' >"+cptValue+" - Service Invalid Reasons"+processingTable+"<input type='button'  id='status_close' onclick='this.blur();showHideEvents(false);showStatusPopup(false);' class='okBtnStyles closeBtnStyles' value='Close' /><input type='button' id='status_ok' class='okBtnStyles' value='Ok' onclick='this.blur();showHideEvents(false);showStatusPopup(false);javascript:updateSelectedValue(\""+rowidOfService+"\");'  /><u id='medical_necessity_link' class='medicalNecessityView' style='display:none;'>View Medical Necessity</u></div>";		
	 return header;		
}		
function requestToGetDxDescription(startingIndex,endingIndex,dosinfo){		
	document.getElementById("processingTable").style.display="block";		
	document.getElementById("resonInfoShowing").style.display="none";		
	var reqDesc="",moreDateAppend="";		
	for(var i=startingIndex; i>=startingIndex && i<=endingIndex ;i++){		
		if(i==startingIndex){		
			reqDesc=splitString[i];		
		}else{		
			reqDesc=reqDesc+","+splitString[i];		
		}		
	}		
	var callBack ={		
			success:handleResponse,		
			progress:handleProgress,		
			failure:handleFailure		
	};		
	window.top.AjaxConnect.sendAsynchRequest('POST', "SuperbillRules.Action", callBack, "mode=1&dosinfo="+dosinfo+"&reqDesc="+reqDesc);		
}		
function handleResponse(response){		
	foottableObj.innerHTML="";		
	foottableObj.innerHTML=createInformationData(medicalNecessityDesc,medicalNecessityType,response,mNDos);		
	document.getElementById("processingTable").style.display="none";		
	/*document.getElementById("necesstyMoreBtn").style.display="block";		
	if(endingIndex>=(totalCount-1)){		
		endingIndex=totalCount-1;		
		document.getElementById("necesstyMoreBtn").style.display="none";		
	}*/		
}		
function handleProgress(){		
	document.getElementById("processingTable").style.display="block";		
}		
function handleFailure(response){		
	document.getElementById("processingTable").style.display="none";		
}		
function createInformationData(medicalNecessityDesc,medicalNecessityType,responseValue,mNDosinfo){		
	var mainDiv="";		
	var mainDivHeight=document.getElementById('serviceStatusDiv').clientHeight;		
	var MNScrollHeight=mainDivHeight-111;		
	mainDiv="<div class='subheaderStyles'> "+medicalNecessityDesc+"</div>";		
	mainDiv=mainDiv+"<div id='MNDXListScroll' style='background-color: #CCCCCC;height: "+MNScrollHeight+"px;overflow-x: hidden;width:100%;overflow-y: scroll;text-align: center;' ><table id='dxCodesList' style='width:100%;border-collapse: collapse;border-spacing: 0;'>";		
	moreResults(responseValue);		
	mainDiv=mainDiv+moreDateAppend+"</table></div><input type='button' id='necesstyMoreBtn' text='More' title='Next values' value='More' class='okBtnStyles' onclick=javascript:extendData("+mNDosinfo+"); >";		
	//	var closeBtn="<a id='status_close' tabindex='1' style='padding-bottom:2px;float:left;' onclick='this.blur();showHideEvents(false);' tabIndex=-1 href='javascript:showStatusPopup(false);' class='btn onbtn' title='close'><b><b><b>Close</b></b></b></a>";		
	return mainDiv;		
}		
function moreResults(responseValue){		
	var list=null,moreDateAppend="";		
	list=eval('(' + responseValue.responseText + ')')		
	var responseData = JSON.parse(list.data);		
	for(var i=0;i<responseData.length;i++){		
		var backColor="";		
		if(i%2==0){		
			backColor="#F7F7F7";		
		}else{		
			backColor="#CCCCCC";		
		}		
		moreDateAppend=moreDateAppend+"<tr  class='listItemsStyles'><td ><input type='checkbox' id='"+responseData[i].code+"'  code='"+responseData[i].code+"' description='"+responseData[i].desc+"'  onclick='handleChkClick(this.id,this);'></td><td ><label class='checkboxLabelStyles' style='width:80px;'>"+responseData[i].code+"</label></td><td ><label class='checkboxLabelStyles'>"+responseData[i].desc+"</label></td></tr>"		
	}		
//	return moreDateAppend;		
}		
function extendData(mNDosinfo){		
	startingIndex=endingIndex+1;		
	endingIndex=endingIndex+20;		
	if(endingIndex>=(totalCount-1)){		
		endingIndex=totalCount-1;		
		document.getElementById("necesstyMoreBtn").style.display="none";		
	}		
	moreToGetDxDescription(mNDosinfo);		
}		
function moreToGetDxDescription(mNDosinfo){		
	var reqDesc=""		
	for(var i=startingIndex; i>=startingIndex && i<=endingIndex ;i++){		
		if(i==startingIndex){		
			reqDesc=splitString[i];		
		}else{		
			reqDesc=reqDesc+","+splitString[i];		
		}		
	}		
	document.getElementById("processingTable").style.display="block";		
	var callBack ={		
			success:moreResponse,		
			progress:handleProgress,		
			failure:handleFailure		
	};		
	window.top.AjaxConnect.sendAsynchRequest('POST', "SuperbillRules.Action", callBack, "mode=1&dosinfo="+mNDosinfo+"&reqDesc="+reqDesc);		
}		
function moreResponse(response){		
	moreResults(response);		
	document.getElementById("dxCodesList").innerHTML=moreDateAppend;		
	document.getElementById("processingTable").style.display="none";		
}		
function updateSelectedValue(rowidOfService){		
//	alert("<<<<<<<<<<<<<<rowidOfService<<<<<<<<"+rowidOfService);		
	document.getElementById('DX1txt_'+rowidOfService).value=choosenValue;		
	document.getElementById('DX1txt_'+rowidOfService).title=choosenDescValue;		
	document.getElementById('txtDX1Desc_'+rowidOfService).value=choosenDescValue;		
	setDirty();		
}		
function handleChkClick(id,event){		
	choosenValue=event.getAttribute('code');		
	choosenDescValue=event.getAttribute('description');		
//	alert("<<<<<<code<<<<<<<<<"+id+">>>>>>>>>>>desc>>>>"+event.getAttribute('code')+"<<<<<<<<<<<desc<<<<<<<"+event.getAttribute('description'));		
}		
function setSTFClose(savetypeinfo){		
	saveTypeInfo=savetypeinfo;		
}		
function onEventSetup(){		
	showHideEvents(true);		
	hideMultiplePopup(true);		
	multiDxProcess(false);		
	multifoottableObj1.style.display="none";		
	document.getElementById('multiPanelFirstScroller').style.display="block";		
	var mainDivHeight=document.getElementById('multipleSSDiv').clientHeight;		
	var MNScrollHeight=mainDivHeight-52;		
	document.getElementById('multiPanelFirstScroller').style.height=MNScrollHeight;		
	document.getElementById('mutilpnaelDxinfo').style.height=(MNScrollHeight-35);		
	document.getElementById('LMRPPopLabel').innerHTML="Validation Problem";		
}		
function openMultipleService(){
//	document.getElementById("multipleSSDiv").style.display = "block";		
	var mainSSDiv= document.getElementById("multipleSSDiv");		
	mainSSDiv.className="mainDivStyles";		
	/*multibodytableObj = document.createElement("table"); //for rule engine		
	multifoottableObj1 = document.createElement("div"); //for rule engine*/		
	multibodytableObj.className="mutiplePanelTableRow";		
	multibodytableObj.id="mutilPanelTable";		
	multibodytableObj.style.display="table";		
	multifoottableObj1.id="multiPanelDx";		
	multifoottableObj1.style.display="none";		
	multifoottableObj1.innerHTML=dxShownPanel();		
	var tableParentDiv=document.createElement("div");		
	tableParentDiv.appendChild(multibodytableObj);		
	tableParentDiv.id="multiPanelFirstScroller"		
	tableParentDiv.setAttribute("style","background-color: #CCCCCC;overflow-x: hidden;width:100%;overflow-y: scroll;text-align: center;");		
	var headerBar=createMultipleHeader();		
	gen_newPopUpAttachment(mainSSDiv,headerBar, tableParentDiv,multifoottableObj1);		
//	hideMultiplePopup(true);		
}		
function hideMultiplePopup(isShow){		
	document.getElementById("multipleSSDiv").style.display = ((isShow) ? "block": "none");		
}		
function multiDxProcess(isShow){		
	document.getElementById("multipleProcessDiv").style.display = ((isShow) ? "block": "none");		
}		
function createMultipleHeader(){		
	var processingTable="<table align='center' id='multipleProcessDiv' style='margin-left: 45%;position: absolute;background: #FFF1A8;display:none;'><tr><td style='color:black;font-family:arial;font-size:12px; font-weight:bold; text-decoration:none;text-align:center'>Processing...</td></tr></table>";		
	 var header="<div class='panel panel-primary headerPanelStyles' ><span id='LMRPPopLabel'>Validation Problem</span>"+processingTable+"<input type='button'  id='multiple_status_close' onclick='this.blur();showHideEvents(false);hideMultiplePopup(false);' class='okBtnStyles closeBtnStyles' value='Close' /><input type='button' id='multiple_status_ok' class='okBtnStyles' value='Ok' onclick='this.blur();showHideEvents(false);hideMultiplePopup(false);updateDataToRecords();'  /></div>";		
	 return header;		
}		
function dxShownPanel(){		
	var contentWindow="";		
	contentWindow="<div id='mutilpnaelDxinfo' style='background-color:#CCCCCC;overflow-x: hidden;width:100%;overflow-y: scroll;text-align: center;'></div><div style='padding-top:5px;'><input id='multiDxMore' type='button' text='More' title='Next values' value='More' class='okBtnStyles' onclick='getMoreDxInformation();' /><input id='multiDxBack' type='button' text='Back' title='Back' value='Back' class='okBtnStyles' style='background-color: #676767; border: 1px solid #676767;' onclick='loadPreviousPageToView();' /></div>";		
	return contentWindow;		
}		
function loadPreviousPageToView(){		
	document.getElementById('multiPanelFirstScroller').style.display="block";		
	document.getElementById('LMRPPopLabel').innerHTML="Validation Problem";		
	multifoottableObj1.style.display="none";		
	multiDxProcess(false);		
	var rowidSplit=currentlySelectedRow.split("_");		
	/*var rowidSplit=currentlySelectedRow.split("_");		
	var existedTableInfo=document.getElementById("dxListInfo_"+currentlySelectedRow).outerHTML;		
	mNSDXLoadedAry[rowidSplit[1]]={value:existedTableInfo};*/		
}		
function getMedicalDxCodes(serviceId,rowid,medicalDos,medicalDx){		
	var rowidSplit=rowid.split("_");		
	mNSDXAry[rowidSplit[1]]={};		
	mNSDXAry[rowidSplit[1]]={value:medicalDx, dosInfo:medicalDos};		
	document.getElementById("multipleProcessDiv").style.display="block";		
	var startingIndex=0,endingIndex=0;		
	var reqDesc="";		
	var splitStringCount=medicalDx.split(",");		
	var totalMDXCount=splitStringCount.length;		
	if(totalMDXCount>40){		
		endingIndex=39;							
	}else{		
		endingIndex=totalMDXCount;		
	}		
	if((totalMDXCount==endingIndex)||((totalMDXCount-1)==endingIndex)){		
		document.getElementById("multiDxMore").style.display="none";		
	}else{		
		document.getElementById("multiDxMore").style.display="block";		
	}		
	var tagInfo=document.getElementById('medical_necessity_link_'+rowid);		
	tagInfo.setAttribute("s_location_"+rowid,"0");		
	tagInfo.setAttribute("e_location_"+rowid,endingIndex);		
	tagInfo.setAttribute("t_location_"+rowid,totalMDXCount);		
	tagInfo.setAttribute("medical_serviceid_"+rowid,serviceId);		
	for(var i=startingIndex; i>=startingIndex && i<=endingIndex ;i++){		
		if(i==startingIndex){		
			reqDesc=splitStringCount[i];		
		}else{		
			reqDesc=reqDesc+","+splitStringCount[i];		
		}		
	}		
	var callBack ={		
			success:handleMDxResponse,		
			progress:handleMDxProgress,		
			failure:handleMDxFailure		
	};		
	window.top.AjaxConnect.sendAsynchRequest('POST', "SuperbillRules.Action", callBack, "mode=1&dosinfo="+medicalDos+"&reqDesc="+reqDesc+"&rowIdInfo="+rowid);		
}		
function handleMDxResponse(response){		
	try {		
		document.getElementById("multipleProcessDiv").style.display="none";		
		var list=null;		
		list=eval('(' + response.responseText + ')')		
		var responseData = JSON.parse(list.data);		
		var rowIdInfo=list.rowId;		
		var rowidSplit=rowIdInfo.split("_");		
		var formedTableRowInfo=createWidget(responseData,rowIdInfo);		
		var appnedDatetoScroll="<table id='dxListInfo_"+rowIdInfo+"' style='width:100%;border-collapse: collapse;border-spacing: 0;'>"+formedTableRowInfo+"</table>"		
//		mNSDXLoadedAry={};		
//		mNSDXLoadedAry.push({key: rowidSplit[1], value: appnedDatetoScroll});		
		/*mNSDXLoadedAry[rowidSplit[1]].key=rowidSplit[1];		
		mNSDXLoadedAry[rowidSplit[1]].value=appnedDatetoScroll;*/		
		mNSDXLoadedAry[rowidSplit[1]]={value:appnedDatetoScroll};		
		document.getElementById("mutilpnaelDxinfo").innerHTML=appnedDatetoScroll;		
	} catch (e) {		
	}		
}		
function  handleMDxProgress(){		
	document.getElementById("multipleProcessDiv").style.display="block";		
}		
function handleMDxFailure(){		
	document.getElementById("multipleProcessDiv").style.display="none";		
}		
function createWidget(responseValue,rowIdInfo){		
	var scrollerWidth=(document.getElementById('mutilpnaelDxinfo').clientWidth)/2;		
	var newScrollWidth=scrollerWidth-110;		
	var moreDataAppend="";		
	try {		
		for(var i=0;i<responseValue.length;){		
			var backColor="";		
			if(i%2==0){		
				backColor="#F7F7F7";		
			}else{		
				backColor="#CCCCCC";		
			}		
			moreDataAppend=moreDataAppend+"<tr  class='listItemsStyles'><td><div width='"+scrollerWidth+"px'><input type='checkbox' id='"+responseValue[i].code+"_"+rowIdInfo+"'  code='"+responseValue[i].code+"' description='"+responseValue[i].desc+"' rowId='"+rowIdInfo+"' onclick='handleMultiChkClick(this.id,this);' style='float:left;width=10px;' ><label class='checkboxLabelStyles chkBoxOverRideStyles'>"+responseValue[i].code+"</label><label class='checkboxLabelStyles dxDescStyle' style='width:"+newScrollWidth+"px;' >"+responseValue[i].desc+"</label></div></td>";		
			moreDataAppend=moreDataAppend+"<td><div width='"+scrollerWidth+"px'><input type='checkbox' id='"+responseValue[i+1].code+"_"+rowIdInfo+"'  code='"+responseValue[i+1].code+"' description='"+responseValue[i+1].desc+"' rowId='"+rowIdInfo+"'  onclick='handleMultiChkClick(this.id,this);' style='float:left;width=10px;'><label class='checkboxLabelStyles chkBoxOverRideStyles'>"+responseValue[i+1].code+"</label><label class='checkboxLabelStyles dxDescStyle'  style='width:"+newScrollWidth+"px;'>"+responseValue[i+1].desc+"</label></div></td></tr>"; 		
			i=i+2;		
		}		
	} catch (e) {		
	}		
	return moreDataAppend;		
}		
function handleMultiChkClick(id,event){		
	var rowidSplit=event.getAttribute('rowId').split("_");		
	if(event.checked){		
		selectedDxInfo[rowidSplit[1]]=({dxCode:event.getAttribute('code') ,description:event.getAttribute('description')})		
		document.getElementById("selected_Dx_value_"+event.getAttribute('rowId')).innerHTML=event.getAttribute('code');		
		loadPreviousPageToView();		
	}else{		
		document.getElementById("selected_Dx_value_"+event.getAttribute('rowId')).innerHTML="";		
		 delete selectedDxInfo[rowidSplit[1]];		
	}		
}		
function getMoreDxInformation(){		
	var rowidSplit=currentlySelectedRow.split("_");		
	var currentPostionDx=document.getElementById("medical_necessity_link_"+currentlySelectedRow).getAttribute("e_location_"+currentlySelectedRow);		
	var totallyExistedCount=document.getElementById("medical_necessity_link_"+currentlySelectedRow).getAttribute("t_location_"+currentlySelectedRow)		
	var sIndex=parseInt(currentPostionDx)+1;		
	var eIndex=parseInt(currentPostionDx)+39;		
	if(eIndex>=(totallyExistedCount-1)){		
		eIndex=totallyExistedCount-1;		
		document.getElementById("multiDxMore").style.display="none";		
	}		
	var tagInfo=document.getElementById('medical_necessity_link_'+currentlySelectedRow);		
	tagInfo.setAttribute("e_location_"+currentlySelectedRow,eIndex);		
	var reqDesc=""		
	var splitStringCount=mNSDXAry[rowidSplit[1]].value.split(",");		
	for(var i=sIndex; i>=sIndex && i<=eIndex ;i++){		
		if(i==sIndex){		
			reqDesc=splitStringCount[i];		
		}else{		
			reqDesc=reqDesc+","+splitStringCount[i];		
		}		
	}		
	document.getElementById("multipleProcessDiv").style.display="block";		
	var callBack ={		
			success:handleMoreMDxResponse,		
			progress:handleMDxProgress,		
			failure:handleMDxFailure		
	};		
	window.top.AjaxConnect.sendAsynchRequest('POST', "SuperbillRules.Action", callBack, "mode=1&dosinfo="+mNSDXAry[rowidSplit[1]].dosInfo+"&reqDesc="+reqDesc+"&rowIdInfo="+currentlySelectedRow);		
}		
function handleMoreMDxResponse(response){		
	try {		
		document.getElementById("multipleProcessDiv").style.display="none";		
		var list=null;		
		list=eval('(' + response.responseText + ')')		
		var responseData = JSON.parse(list.data);		
		var rowIdInfo=list.rowId;		
		var rowidSplit=rowIdInfo.split("_");		
		var formedTableRowInfo=createWidget(responseData,rowIdInfo);		
		var existedData=document.getElementById("dxListInfo_"+rowIdInfo).innerHTML;		
		document.getElementById("dxListInfo_"+rowIdInfo).innerHTML=existedData+formedTableRowInfo;		
		var newDataForTable=document.getElementById("dxListInfo_"+rowIdInfo).outerHTML;		
		mNSDXLoadedAry[rowidSplit[1]]={value:newDataForTable};		
	} catch (e) {		
	}		
}		
function updateDataToRecords(){		
	var changedRecordIds=medicalNeeded.split(",");		
	for(var i=0;i<changedRecordIds.length;i++){		
		var rowidSplit=changedRecordIds[i].split("_");		
		if(selectedDxInfo[rowidSplit[1]]!=undefined || selectedDxInfo[rowidSplit[1]]!=null){		
			document.getElementById('DX1txt_'+changedRecordIds[i]).value=selectedDxInfo[rowidSplit[1]].dxCode;		
			document.getElementById('DX1txt_'+changedRecordIds[i]).title=selectedDxInfo[rowidSplit[1]].description;		
			document.getElementById('txtDX1Desc_'+changedRecordIds[i]).value=selectedDxInfo[rowidSplit[1]].description;		
			setDirty();		
		}		
	}		
}

var closePopupfordiv =function(rowid) {

	//rowcount=0;
	alert("in closing "+rowid);
	//postdxorder(rowid);
	
	document.getElementById("ServiceOrder").style.display='none';

	var rows = document.getElementsByTagName("table")[0].rows;
	var last = rows[rows.length - 1];
	var cell = last.cells[0];
	var value = cell.innerHTML;
		
}

function insertCommonTdItem(dataval,rowobj,pos,title,clas,i){
	//	alert(dataval);
		var t = title.split('####');
		//alert("title----"+t);
		var c = clas.split('####');
		//alert("class"+c);
		var tdobj=rowobj.insertCell(pos);	
		tdobj.noWrap=true;		
		for(var i=0;i<t.length;i++){
			if(t[i]=='class')
				tdobj.className=c[i];
			else{
				tdobj.setAttribute(t[i],c[i]);
			}	
				
		}
		if(dataval == '')
			tdobj.innerHTML='&nbsp;';
		else
			tdobj.innerHTML=dataval;
		
		//tdobj.innerHTML=deleteButtonval;
		return tdobj; 
	}

/*function insertCommonTdItem1(dataval,rowobj,pos,title,clas,i){
	//	alert(dataval);
		var t = title.split('####');
		//alert("title----"+t);
		var c = clas.split('####');
		//alert("class"+c);
		var tdobj=rowobj.insertCell(pos);	
		tdobj.noWrap=true;		
		for(var i=0;i<t.length;i++){
			if(t[i]=='class')
				tdobj.className=c[i];
			else{
				tdobj.setAttribute(t[i],c[i]);
			}	
				
		}
		if(dataval == '')
			tdobj.innerHTML='&nbsp;';
		else
			tdobj.innerHTML=dataval;
		
		//tdobj.innerHTML=deleteButtonval;
		return tdobj; 
	}*/


function onChangeServiceList(){
	  
		var det=fetchDefaults();
	    var model=new ServiceDetail();
		var dataobj=eval(det)[0];
		var dosInfo=dataobj.dop;
		
	var patientId=getPatientId();
	model.posId=dataobj.pos;
	model.sdoctorId=dataobj.sdoc;
	model.bdoctorId=dataobj.bdoc;
	
	var pos=model.posId;
	var sdoc=model.sdoctorId;
	var bdoc=model.bdoctorId;
		
	var callback={
			success:onChangeService,
			failure:onFailure,
	}
	getAjaxDataFromServer("ServiceEntry.Action","&patientId="+patientId+"&dosInfo="+dosInfo+"&pos="+pos+"&sdoc="+sdoc+"&bdoc="+bdoc+"&mode="+36+"&rand="+Math.random(),false,callback,"GET");
}
function onChangeService(responseObject){
	alert("=====in my function==="+JSON.stringify(responseObject));//var myJSON = JSON.stringify(obj); 
	try {
		var responseValue = eval(responseObject.responseText);
		var tmpSchild,maindiv,bodytableObj,foottableObj,rowObj,cellObj,temptable;
		bodytableObj=document.createElement("table");
		foottableObj=document.createElement("table");
		var mainSCDiv1 = document.getElementById("ServiceOrder");
		document.getElementById('ServiceOrder').style.display='block';
		gen_newPopUpAttachment(mainSCDiv1,"Service Order",bodytableObj,foottableObj,'',1);
		var dDiv1 = mainSCDiv1.firstChild;
		dDiv1.setAttribute("styletable","background-color:#c3d9ff; border:0px;border-width:0px;");

		dDiv1.onmouseup = function(){
			up("QCPTConfigDiv");
		}
		dDiv1.onmousedown = function(event){
			down("QCPTConfigDiv",event);
		}
		
		bodytableObj.id="dxorder_maindiv";
		bodytableObj.cellSpacing="5";
		bodytableObj.cellPadding="5";
		bodytableObj.setAttribute("style","width:auto; height:auto; background-color:#FFFFFF;border:1px solid #0099cc;border-radius:8px;padding-bottom:20px;");
		//bodytableObj.setAttribute("style","overflow-y:scroll;height:100px;width:100px;");
		rowObj=bodytableObj.insertRow(-1);
		tmpSchild=document.createElement("div");
		tmpSchild.id="shortcut_operations";
		temptable = document.createElement("table");
		temptable.id="operations_table";
		temptable.setAttribute("style","width:117%; height:40px; background-color:#FFFFFF;border:1px solid #0099cc;border-radius:5px;");
		temptable.setAttribute("cellspacing", "0");
		temptable.setAttribute("cellpadding", "0");
		temptable.setAttribute("id", "changesorder");
		var bodyRow = temptable.insertRow(-1);//HEADING TABLE
		insertCommonTdItem('CPT', bodyRow, -1, "title####style", "####position:relative;width:60px;left:11px;",i);
		insertCommonTdItem('Modifier', bodyRow, -1,"title####style","####width:60px;",i);
		insertCommonTdItem('Units', bodyRow, -1,"title####style","####width:60px;",i);
		insertCommonTdItem('Charges', bodyRow, -1,"title####style","####width:100px;",i);
		insertCommonTdItem('Dx1', bodyRow, -1,"title####style","####width:60px;",i);
		insertCommonTdItem('', bodyRow, -1,"title####style","####width:20px;",i);
		insertCommonTdItem('', bodyRow, -1,"title####style","####width:20px;",i);
		bodyRow.className = "ledgerTabColHeader";
		bodyRow.setAttribute("style", "background-color:#0099CC");
		tmpSchild.appendChild(temptable);

  		previousOrder=new Array();
  		for(var i=0;i<responseValue.length;i++){
  			var upArrowBlock="",downArrowBlock="";
  			if(i==0){
  				  upArrowBlock="display:none";
  			      }
  			if(i==(responseValue.length-1)){
  				  downArrowBlock="display:none";
  			     }
			previousOrder[i]=responseValue[i].serviceid+"--"+responseValue[i].orderid;
			var downArrow = "<img id=movedown_"+i+ " title='Move down' onclick='javascript:MoveDown("+i+");'  src='../../../images/blue14x14/Grid_MoveDown.png' style='cursor:pointer;"+ downArrowBlock + "'>";
			var upArrow = "<img  id=moveup_"+i+ " title='Move up'  onclick='javascript:MoveUp("+i+");' src='../../../images/blue14x14/Grid_MoveUp.png' style='cursor:pointer;"+ upArrowBlock + "'>";
			
			//bodyRow = temptable.insertRow(-1);//DATA
			bodyRow = bodytableObj.insertRow(-1);
			bodyRow.setAttribute("service_service_id",responseValue[i].serviceid);
			bodyRow.setAttribute("service_order_id",responseValue[i].orderid);
			insertCommonTdItem(responseValue[i].cptcode, bodyRow, -1,"title####style","####position:absolute;width:60px;",i);
			insertCommonTdItem(responseValue[i].modifier1, bodyRow, -1,"title####style","####position:absolute;right:313px;width:60px;",i);
			insertCommonTdItem(responseValue[i].units, bodyRow, -1,"title####style","####position:absolute;right:244px;width:60px;",i);
			insertCommonTdItem("$"+responseValue[i].charges, bodyRow, -1,"title####style","####position:absolute;right:155px;width:100px;",i);
			insertCommonTdItem(responseValue[i].dx1, bodyRow, -1,"title####style","####position:absolute;right:86px;width:60px;",i);
			insertCommonTdItem(downArrow, bodyRow, -1, "title####style","####position:relative;right:11px;width:20px;",i);
			insertCommonTdItem(upArrow, bodyRow, -1, "title####style","####position:relative;right:10px;width:20px;",i);
		      bodyRow.className = "ledgerSelectedServiceRow";
		}
  		//bodytableObj.appendChild(bodyRow);

		/*tempspan=document.createElement("span");
		tempspan.className="label-class";
		appendTdItem(tempspan,temptr,-1);
		tmpSchild.appendChild(temptable);*/
		cellObj=appendTdItem(tmpSchild,rowObj,-1);
		
		foottableObj.style.display="inline-block";
		foottableObj.style.height="auto";
		
		rowObj=foottableObj.insertRow(-1);
		//alert("==== rowObj before cpt  ==== "+rowid); //\""+mcnDel+"\"
		//cellObj=insertTdItem("<a id='popupsave' tabindex='1' style='padding-bottom:2px;padding-left:3px;float:right;' onclick='this.blur();' tabIndex=-1 href='javascript:closePopupdivforDxorder(\""+rowid+"\");' class='btn onbtn' title='save'><b><b><b>Save</b></b></b></a>",rowObj,-1);
		//cellObj=insertTdItem("<a id='popupClose' tabindex='1' style='padding-bottom:2px;padding-left:3px;float:right;' onclick='this.blur();' tabIndex=-1 href='javascript:closePopupdivforDxorder(\""+rowid+"\");' class='btn onbtn' title='cancel'><b><b><b>Cancel</b></b></b></a>",rowObj,-1);

		cellObj=insertTdItem("<a class='btn onbtn' style='padding-bottom:2px;padding-left:3px;float:right;' onclick='this.blur();' href=\"javascript:closePopupfordiv();\"><b><b><b>Save</b></b></b></a>",rowObj,-1);
		cellObj=insertTdItem("<a class='btn onbtn' style='padding-bottom:2px;padding-left:3px;float:right;' onclick='this.blur();' href=\"javascript:closePopupfordiv();\"><b><b><b>Cancel</b></b></b></a>",rowObj,-1);

		var bbbb = [].slice.call( document.getElementById("changesorder").rows );
		//alert("==== bbbb ==== "+bbbb.sectionRowIndex );
	} catch (e) {
	}
	
}
function onFailure()
{

}
function MoveDown(rowIndex){
	
	//Firtst row function change
	document.getElementById("movedown_"+rowIndex).setAttribute("onclick","javascript:MoveDown("+(rowIndex+1)+")");
	document.getElementById("moveup_"+rowIndex).setAttribute("onclick","javascript:MoveUp("+(rowIndex+1)+")");
	//Second row function change
	document.getElementById("movedown_"+(rowIndex+1)).setAttribute("onclick","javascript:MoveDown("+(rowIndex)+")");
	document.getElementById("moveup_"+(rowIndex+1)).setAttribute("onclick","javascript:MoveUp("+(rowIndex)+")");
	//Move up id change
	document.getElementById("moveup_"+rowIndex).setAttribute("id","moveup_-1");
	document.getElementById("moveup_"+(rowIndex+1)).setAttribute("id","moveup_"+(rowIndex));
	document.getElementById("moveup_-1").setAttribute("id","moveup_"+(rowIndex+1));
	//Move down id change
	document.getElementById("movedown_"+rowIndex).setAttribute("id","movedown_-1");
	document.getElementById("movedown_"+(rowIndex+1)).setAttribute("id","movedown_"+(rowIndex));
	document.getElementById("movedown_-1").setAttribute("id","movedown_"+(rowIndex+1));
	//Getting records for both rows
	var currentRow=document.getElementById("dxorder_maindiv").rows[rowIndex+1].outerHTML;
	var nextRow=document.getElementById("dxorder_maindiv").rows[rowIndex+2].outerHTML;
//	document.getElementById("movedown_"+rowIndex).setAttribute("id","movedown_"+(rowIndex+1));
	//Resetting rows
	document.getElementById("dxorder_maindiv").rows[rowIndex+1].outerHTML=nextRow;
	document.getElementById("dxorder_maindiv").rows[rowIndex+2].outerHTML=currentRow;
	var cotlength= document.getElementById("dxorder_maindiv").rows.length;
	if(rowIndex==0){
		document.getElementById("moveup_"+rowIndex).style.display="none";
		document.getElementById("moveup_"+(rowIndex+1)).style.display="block";
	}
	if(rowIndex==(cotlength-3)){
		document.getElementById("movedown_"+rowIndex).style.display="block";
		document.getElementById("movedown_"+(rowIndex+1)).style.display="none";
	}
}
function MoveUp(rowIndex){
	//Firtst row function change
	document.getElementById("movedown_"+rowIndex).setAttribute("onclick","javascript:MoveDown("+(rowIndex-1)+")");
	document.getElementById("moveup_"+rowIndex).setAttribute("onclick","javascript:MoveUp("+(rowIndex-1)+")");
	//Second row function change
	document.getElementById("movedown_"+(rowIndex-1)).setAttribute("onclick","javascript:MoveDown("+(rowIndex)+")");
	document.getElementById("moveup_"+(rowIndex-1)).setAttribute("onclick","javascript:MoveUp("+(rowIndex)+")");
	//Move up id change
	document.getElementById("moveup_"+rowIndex).setAttribute("id","moveup_-1");
	document.getElementById("moveup_"+(rowIndex-1)).setAttribute("id","moveup_"+(rowIndex));
	document.getElementById("moveup_-1").setAttribute("id","moveup_"+(rowIndex-1));
	//Move down id change
	document.getElementById("movedown_"+rowIndex).setAttribute("id","movedown_-1");
	document.getElementById("movedown_"+(rowIndex-1)).setAttribute("id","movedown_"+(rowIndex));
	document.getElementById("movedown_-1").setAttribute("id","movedown_"+(rowIndex-1));
	//Getting records for both rows
	var currentRow=document.getElementById("dxorder_maindiv").rows[rowIndex+1].outerHTML;
	var previousRow=document.getElementById("dxorder_maindiv").rows[rowIndex].outerHTML;
//	document.getElementById("movedown_"+rowIndex).setAttribute("id","movedown_"+(rowIndex+1));
	//Resetting rows
	document.getElementById("dxorder_maindiv").rows[rowIndex+1].outerHTML=previousRow;
	document.getElementById("dxorder_maindiv").rows[rowIndex].outerHTML=currentRow;
	var cotlength= document.getElementById("dxorder_maindiv").rows.length;
	if(rowIndex==1){
		document.getElementById("moveup_"+rowIndex).style.display="block";
		document.getElementById("moveup_"+(rowIndex-1)).style.display="none";
	}
	if(rowIndex==(cotlength-2)){
		document.getElementById("movedown_"+(rowIndex-1)).style.display="block";
		document.getElementById("movedown_"+rowIndex).style.display="none";
	}
}

