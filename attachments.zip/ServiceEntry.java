package com.glenwood.hcare.actions.billing.superbill;

import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

import javax.servlet.ServletConfig;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.JSONArray;
import org.json.JSONObject;

import com.glenwood.glaceemr.utils.GWTJSONBean;
import com.glenwood.hcare.actions.billing.BillingConstants;
import com.glenwood.hcare.actions.chart.prescription.PrescriptionModel;
import com.glenwood.hcare.actions.pickers.GetPickerDataModel;
import com.glenwood.hcare.design.GlaceOutLoggingStream;
import com.glenwood.hcare.design.HtmlAction;
import com.glenwood.hcare.design.DBFarm.TimeZoneContext;
import com.glenwood.hcare.hfc.eob.EOBPostingDAO;
import com.glenwood.hcare.log.AuditTrail;
import com.glenwood.hcare.log.EventLog;
import com.glenwood.hcare.utils.DataBaseUtils;
import com.glenwood.hcare.utils.HUtil;

public class ServiceEntry implements HtmlAction{
	ServletConfig config;
	/**
	 * @param args
	 */
	public void init(ServletConfig xConfig){
		config = xConfig;
		
	}
	 
	public String performAction(HttpServletRequest request, HttpServletResponse response)throws Exception{
		int check=0;
		GlaceOutLoggingStream.console("In SERVIE >>>>> ");
		int mode=Integer.parseInt(HUtil.Nz(request.getParameter("mode"),"-1"));
		int action=Integer.parseInt(HUtil.Nz(request.getParameter("action"),"-1"));
		String group=HUtil.Nz(request.getParameter("group"),"-1");
		String providerid=HUtil.Nz(request.getParameter("providerid"),"-1");
		String user=(String)request.getSession(false).getAttribute("username");
		if(user == null)
			user="";
		GlaceOutLoggingStream.console("ACTION ID >>> "+action);
		DataBaseUtils dbutils=null;
		String message="";
		JSONArray jarray=new JSONArray();
		JSONObject jobject=new JSONObject();
		JSONArray jsarray;
		HttpSession session = request.getSession(false);
		TimeZoneContext TZContext = (TimeZoneContext) session.getAttribute("TZContext");
		String ptdob="01/01/1900";
		//JSONArray jarray	= new JSONArray();
		try 
		{		
		dbutils=new DataBaseUtils(request.getSession(false).getAttribute("connectString").toString());
		if(!group.equalsIgnoreCase("-1"))
		{
			String[] modes=group.split(",");
			
		for(String element:modes)
		{ 
		 mode=Integer.parseInt(HUtil.Nz(element,"-1"));
		 GlaceOutLoggingStream.console(mode);
		 if(mode == 4)
			{
				String cptGroup="select id as hsp001, coalesce(name,'') as hsp002 from service_cpt_group where isactive is true";
				jsarray=dbutils.executeQueryToJSONArray(cptGroup,true);
				message=jsarray.toString();
			}	
		 if(mode == 5)
			{
				String patientId=HUtil.Nz(request.getParameter("patientId"),"-1");
	            String prevDate=dbutils.newTableLookUp("coalesce(to_mmddyyyy(max(service_detail_dos)),'01/01/1900')","service_detail inner join cpt on cpt_id=service_detail_cptid and cpt_cpttype=1","service_detail_patientid="+patientId+" and service_detail_dos<now()::date");
	            StringBuffer prevDx=new StringBuffer();
	            prevDx.append(" select coalesce(service_detail_dx1,'') as hsp001, coalesce(service_detail_dx2,'') as hsp002,coalesce(service_detail_dx3,'') as hsp003,coalesce(service_detail_dx4,'') as hsp004,coalesce(service_detail_dx5,'') as hsp005, coalesce(service_detail_dx6,'') as hsp006,coalesce(service_detail_dx7,'') as hsp007,coalesce(service_detail_dx8,'') as hsp008, ");
	            prevDx.append(" coalesce(service_detail_dx9,'') as hsp009, coalesce(service_detail_dx10,'') as hsp010,coalesce(service_detail_dx11,'') as hsp011,coalesce(service_detail_dx12,'') as hsp012,coalesce(service_detail_dx13,'') as hsp013, coalesce(service_detail_dx14,'') as hsp014,coalesce(service_detail_dx15,'') as hsp015,coalesce(service_detail_dx16,'') as hsp016, ");
	            prevDx.append(" coalesce(service_detail_dx17,'') as hsp017, coalesce(service_detail_dx18,'') as hsp018,coalesce(service_detail_dx19,'') as hsp019,coalesce(service_detail_dx20,'') as hsp020, ");
	            prevDx.append(" coalesce(service_detail_dx1desc,'') as dx1desc,coalesce(service_detail_dx2desc,'') as dx2desc,coalesce(service_detail_dx3desc,'') as dx3desc,coalesce(service_detail_dx4desc,'') as dx4desc,coalesce(service_detail_dx5desc,'') as dx5desc,coalesce(service_detail_dx6desc,'') as dx6desc,coalesce(service_detail_dx7desc,'') as dx7desc,coalesce(service_detail_dx8desc,'') as dx8desc, ");
	            prevDx.append(" coalesce(service_detail_dx9desc,'') as dx9desc,coalesce(service_detail_dx10desc,'') as dx10desc,coalesce(service_detail_dx11desc,'') as dx11desc,coalesce(service_detail_dx12desc,'') as dx12desc,coalesce(service_detail_dx13desc,'') as dx13desc,coalesce(service_detail_dx14desc,'') as dx14desc,coalesce(service_detail_dx15desc,'') as dx15desc,coalesce(service_detail_dx16desc,'') as dx16desc, ");
	            prevDx.append(" coalesce(service_detail_dx17desc,'') as dx17desc,coalesce(service_detail_dx18desc,'') as dx18desc,coalesce(service_detail_dx19desc,'') as dx19desc,coalesce(service_detail_dx20desc,'') as dx20desc from service_detail inner join cpt on cpt_id=service_detail_cptid and cpt_cpttype=1 where service_detail_dos=' "+prevDate+"'::date and service_detail_patientid="+patientId);
	//String prevDx="select coalesce(service_detail_dx1,'') as hsp001, coalesce(service_detail_dx2,'') as hsp002,coalesce(service_detail_dx3,'') as hsp003,coalesce(service_detail_dx4,'') as hsp004,coalesce(service_detail_dx5,'') as hsp005, coalesce(service_detail_dx6,'') as hsp006,coalesce(service_detail_dx7,'') as hsp007,coalesce(service_detail_dx8,'') as hsp008,coalesce(service_detail_dx1desc,'') as dx1desc,coalesce(service_detail_dx2desc,'') as dx2desc,coalesce(service_detail_dx3desc,'') as dx3desc,coalesce(service_detail_dx4desc,'') as dx4desc from service_detail inner join cpt on cpt_id=service_detail_cptid and cpt_cpttype=1 where service_detail_dos='"+prevDate+"'::date and service_detail_patientid="+patientId);
	            String codeSystem=dbutils.newTableLookUp("service_detail_dxsystem","service_detail inner join cpt on cpt_id=service_detail_cptid and cpt_cpttype=1 ","service_detail_dos='"+prevDate+"'::date and service_detail_patientid="+patientId+"");
	            JSONArray result = dbutils.executeQueryToJSONArray(prevDx.toString(),true);
	            //message=result.toString();
	            Set<String> dxSet=new LinkedHashSet<String>();
	            Set<String> dxDesc=new LinkedHashSet<String>();
	            StringBuilder dxString=new StringBuilder();
	            for(int i=0;i<result.length();i++){
	                for(int j=0;j<20;j++){
	                    int localIValue=j+1;
	                    String dxGetString="";
	                    String dxGetDesc="dx"+localIValue+"desc";
	                    if(j<9){
	                        dxGetString="hsp00"+localIValue;
	                    }else{
	                        dxGetString="hsp0"+localIValue;
	                    }
	                    if(!result.getJSONObject(i).getString(dxGetString).equals("")){
	                        dxSet.add(result.getJSONObject(i).getString(dxGetString).trim());
	                        dxDesc.add(result.getJSONObject(i).getString(dxGetDesc).trim());
	                        //System.out.println("=====================================>"+result.getJSONObject(i).getString(dxGetString).trim());
	                        //System.out.println("---------------------------------------------->"+result.getJSONObject(i).getString(dxGetDesc).trim());

	                    }
	                }
				}
				Iterator<String> it=dxSet.iterator();
				Iterator<String> dit=dxDesc.iterator();
				JSONArray dxArray = new JSONArray();
				JSONArray dxDescArray = new JSONArray();
				JSONArray row;
				int colCount=0;
				row = new JSONArray();
				while(it.hasNext()){
					JSONObject codedesc=new JSONObject();
					String dx=it.next().toString();
					row.put(colCount,dx);
					if(dit.hasNext()){
						codedesc.put("dx", dx);
						codedesc.put("description",dit.next().toString());
						dxDescArray.put(codedesc);
					}
					colCount++;
					dxString.append("'").append(dx).append("',");
				}
				if(colCount==0)
					 dxArray.put(0,new JSONObject());
				else
					dxArray.put(0,row);
				JSONObject rowObj=new JSONObject();
				rowObj.put("dxcount",colCount);
				rowObj.put("dxsystem",codeSystem);
				dxArray.put(1,rowObj);
				dxString.append("''");
				GlaceOutLoggingStream.console("Dx >>>>   "+dxArray.toString());
				message=dxArray.toString();
				JSONArray dxResult = dbutils.executeQueryToJSONArray("select icdm_icdcode as dx,icdm_description as description from icdm where icdm_icdcode in ("+dxString+")",true);
				JSONObject jsobj=new JSONObject();
				jsobj.put("key","891");
				if(dxResult.length()!=0)
				    jsobj.put("valu",dxResult.toString());
				else
					jsobj.put("valu",dxDescArray.toString());
			    jarray.put(jsobj);
			}	
		if(mode == 6)
		{
			String patientId=HUtil.Nz(request.getParameter("patientId"),"-1");
			StringBuffer AuthQuery = new StringBuffer();
			AuthQuery.append(" Select authorization_referral_id as hsp001,   case when authorization_referral_doctor_id=-1 then 'All' else emp_profile_doctorid end || '-' ||authorization_referral_auth_no ||'('||coalesce(blook_name ,'Service Wise')||')'|| '-('|| authorization_referral_auth_cptcode || ')-'||coalesce(authorization_referral_total_visits,0) - coalesce(authorization_referral_used_visits,0)||'-'||ins_company_name as hsp002 , to_mmddyyyy(authorization_referral_start_date) as hsp003, to_mmddyyyy(authorization_referral_end_date) as hsp004,authorization_referral_doctor_id as hsp005,coalesce(authorization_referral_total_visits,0) - coalesce(authorization_referral_used_visits,0) as hsp006,authorization_referral_auth_ins as hsp007,coalesce(authorization_referral_auth_cptcode,'') as hsp008 , coalesce(authorization_referral_authtype,1) as hsp009 ");
			AuthQuery.append("  ");
			AuthQuery.append(" from authorization_referral inner join ins_comp_addr on ins_comp_addr_id=authorization_referral_auth_ins::int");
			AuthQuery.append(" inner join ins_company on ins_comp_addr_inscompany_id=ins_company_id");
			AuthQuery.append(" left join billinglookup on blook_intid = authorization_referral_authtype and blook_group = 255 ");
			AuthQuery.append(" left join emp_profile on emp_profile_empid=authorization_referral_doctor_id  ");
			AuthQuery.append(" where authorization_referral_patient_id=" + patientId);
			jsarray=dbutils.executeQueryToJSONArray(AuthQuery.toString(),true);
			message=jsarray.toString();
		}
		
		 if(mode==7)
		{
		String patientId=HUtil.Nz(request.getParameter("patientId"),"-1");
		String CaseQuery="select caseno as hsp001,case_description as hsp002 from case_tab where status is true and patientid="+patientId;
		jsarray=dbutils.executeQueryToJSONArray(CaseQuery,true);
		message=jsarray.toString();
		}		 
		if(mode==8)
		{
		String patientId=HUtil.Nz(request.getParameter("patientId"),"-1");
		String CHDPQuery="select patient_ins_detail_id as hsp001,patient_ins_detail_patientid as hsp002 from patient_ins_detail inner join ins_comp_addr on ins_comp_addr_id=patient_ins_detail_insaddressid inner join ins_company on ins_company_id=ins_comp_addr_inscompany_id where patient_ins_detail_patientid="+patientId+" and patient_ins_detail_instype=4 and patient_ins_detail_isactive is true";
		jsarray=dbutils.executeQueryToJSONArray(CHDPQuery,true);
		message=jsarray.toString();
		}		 
		
		if(mode==9)
		{
		String patientId=HUtil.Nz(request.getParameter("patientId"),"-1");
		String WCQuery="select patient_ins_detail_id as hsp001,patient_ins_detail_patientid as hsp002 from patient_ins_detail inner join ins_comp_addr on ins_comp_addr_id=patient_ins_detail_insaddressid inner join ins_company on ins_company_id=ins_comp_addr_inscompany_id where patient_ins_detail_patientid="+patientId+" and patient_ins_detail_instype=5 and patient_ins_detail_isactive is true";
		jsarray=dbutils.executeQueryToJSONArray(WCQuery,true);
		message=jsarray.toString();
		}
		if(mode==10)
		{
			String typeQuery="select patient_encounter_type_group.groupid as hsp001, plantype||' - '||groupname as hsp002 from patient_encounter_type_group inner join patient_encounter_type on patient_encounter_type_group.groupid=patient_encounter_type.groupid order by 1";
			jsarray=dbutils.executeQueryToDistinctJSONArray(typeQuery,true);
			message=jsarray.toString();
		}
		if(mode==11)
		{
			
			String qrysubmitstatus="select submit_status_code as hsp001, case when length(trim(submit_status_description)) > 20 then substring(trim(submit_status_description),0,20) || '..' else trim(submit_status_description) end as hsp002 from submit_status  order by hsp001 ";
			jsarray=dbutils.executeQueryToJSONArray(qrysubmitstatus,true);
			message=jsarray.toString();
			GlaceOutLoggingStream.console(message);
			
		}
		if(mode==12)
		{
			
			String qry="select rate_plan_id as hsp001, rate_plan_plan_name as hsp002 from rate_plan order by hsp002";
			 jsarray=dbutils.executeQueryToJSONArray(qry,true);
			message=jsarray.toString();
			
			
		}
		
		if(mode==13)
		{
			
			String qry="select blook_intid as hsp001, blook_name as hsp002 from billinglookup where blook_group=5";
			 jsarray=dbutils.executeQueryToJSONArray(qry,true);
			message=jsarray.toString();
			
			
		}
		if(mode==13)
		{
			
			String qry="select blook_intid as hsp001, blook_name as hsp002 from billinglookup where blook_group=5";
			 jsarray=dbutils.executeQueryToJSONArray(qry,true);
			message=jsarray.toString();
			
			
		}
		if(mode==41)
		{
			
			String qry="select blook_intid as hsp001, blook_name as hsp002 from billinglookup where blook_group=130";
			 jsarray=dbutils.executeQueryToJSONArray(qry,true);
			message=jsarray.toString();
			
			
		}
		if(mode==14)
		{
			
			String qry="select billing_reason_id as hsp001,case when length(trim(billing_reason_desc)) > 20 then substring(trim(billing_reason_desc),0,20) || '..' else trim(billing_reason_desc) end  as hsp002  from billing_reason where billing_reason_isactive is true order by hsp002";
			 jsarray=dbutils.executeQueryToJSONArray(qry,true);
			message=jsarray.toString();
			
			
		}
		if(mode==15)
		{
			
			String qry="select blook_intid as hsp001,blook_name as hsp002 from billinglookup  where blook_group=3 order by 2";
		 jsarray=dbutils.executeQueryToJSONArray(qry,true);
			message=jsarray.toString();
			
			
		}
		//QRY for Corrected CLM drop down
		if(mode==200)
		{
		String qry="select blook_intid as hsp001, blook_name as hsp002 from billinglookup where blook_group=265 order by 1 ";
		jsarray=dbutils.executeQueryToJSONArray(qry,true);
		message=jsarray.toString();
		}
		if(mode==201){
			String patientId=HUtil.Nz(request.getParameter("patientId"),"-1");
			String hspAdmsDate = HUtil.Nz(dbutils.newTableLookUp("to_char(admission_admitted_date,'mm/dd/yyyy')", "admission", "admission_patient_id = "+patientId+" and admission_discharged_date is null "),"01/01/1900");
			message = hspAdmsDate.toString();
		}
		if(mode==16)
		{
			String showIdInDocCombo = HUtil.Nz(dbutils.newTableLookUp("initial_settings_option_value", "initial_settings", "initial_settings_option_name ilike 'Show ID in Doc Combo ?'"),"0");
			String qry="";
			int includeNurse=Integer.parseInt(HUtil.Nz(dbutils.newTableLookUp("initial_settings_option_value","initial_settings","initial_settings_option_name_desc ilike '%Include Nurses in service doctor list%'"),"0"));
			if(showIdInDocCombo.equals("1")){
				if(includeNurse==0)
					qry=" select emp_profile_empid as hsp001, emp_profile_doctorid||'-'||case when length(trim(emp_profile_fullname)) > 20 then substring(trim(emp_profile_fullname),0,20) || '..' else trim(emp_profile_fullname) end  as hsp002 from emp_profile where emp_profile_groupid in (-1,-10,-25)  and emp_profile_is_active is true order by hsp002 ";
				else
					qry=" select emp_profile_empid as hsp001, emp_profile_doctorid||'-'||case when length(trim(emp_profile_fullname)) > 20 then substring(trim(emp_profile_fullname),0,20) || '..' else trim(emp_profile_fullname) end  as hsp002 from emp_profile where emp_profile_groupid in (-1,-2,-10,-25)  and emp_profile_is_active is true order by hsp002 ";
			}
			else{
				if(includeNurse==0)
				   qry=" select emp_profile_empid as hsp001, case when length(trim(emp_profile_fullname)) > 20 then substring(trim(emp_profile_fullname),0,20) || '..' else trim(emp_profile_fullname) end  as hsp002 from emp_profile where emp_profile_groupid in (-1,-10,-25)  and emp_profile_is_active is true order by hsp002 ";
				else
					qry=" select emp_profile_empid as hsp001, case when length(trim(emp_profile_fullname)) > 20 then substring(trim(emp_profile_fullname),0,20) || '..' else trim(emp_profile_fullname) end  as hsp002 from emp_profile where emp_profile_groupid in (-1,-2,-10,-25)  and emp_profile_is_active is true order by hsp002 ";
			}
		 jsarray=dbutils.executeQueryToJSONArray(qry,true);
			message=jsarray.toString();
			
			
		}
		if(mode==17)
		{
			String qry="";
			String fromScheduler=HUtil.Nz(request.getParameter("fromSch"),"-1");
			String checkOfficePos=HUtil.Nz(dbutils.newTableLookUp("initial_settings_option_value","initial_settings","initial_settings_option_name ilike 'Show only Office POS in Service Screen ?'"),"0");
			if(checkOfficePos.equals("1") && fromScheduler.equals("1"))
				qry=" select pos_table_relation_id as hsp001, '(' || coalesce(pos_table_pos_code,-2) || ')' || '(' || coalesce(pos_table_place_of_service,'') || ')' || case when length(trim(pos_table_facility_comments)) > 20 then substring(trim(pos_table_facility_comments),0,20) || '..' else trim(pos_table_facility_comments) end as hsp002 from pos_table where pos_table_pos_code::varchar ilike '1%' and coalesce(pos_table_is_active,true) and pos_table_pos_code not in(40)  order by hsp002" ;
			else
				qry=" select pos_table_relation_id as hsp001, '(' || coalesce(pos_table_pos_code,-2) || ')' || '(' || coalesce(pos_table_place_of_service,'') || ')' || case when length(trim(pos_table_facility_comments)) > 20 then substring(trim(pos_table_facility_comments),0,20) || '..' else trim(pos_table_facility_comments) end as hsp002 from pos_table where coalesce(pos_table_is_active,true) and pos_table_pos_code not in(40)  order by hsp002" ;
		 jsarray=dbutils.executeQueryToJSONArray(qry,true);
			message=jsarray.toString();
			
			
		}
		//This code is added for scenario - While Edit Service we need to show all (Active and Inactive) POS Locations
		if(mode==170)
		{
			String qry="";
			String fromScheduler=HUtil.Nz(request.getParameter("fromSch"),"-1");
			String checkOfficePos=HUtil.Nz(dbutils.newTableLookUp("initial_settings_option_value","initial_settings","initial_settings_option_name ilike 'Show only Office POS in Service Screen ?'"),"0");
			if(checkOfficePos.equals("1") && fromScheduler.equals("1"))
				qry=" select pos_table_relation_id as hsp001, '(' || coalesce(pos_table_pos_code,-2) || ')' || '(' || coalesce(pos_table_place_of_service,'') || ')' || case when length(trim(pos_table_facility_comments)) > 20 then substring(trim(pos_table_facility_comments),0,20) || '..' else trim(pos_table_facility_comments) end as hsp002 from pos_table where pos_table_pos_code::varchar ilike '1%' and pos_table_pos_code<>-1  and  pos_table_pos_code not in(40) and trim(coalesce(pos_table_place_of_service,''))<>'' order by hsp002" ;
			else
				qry=" select pos_table_relation_id as hsp001, '(' || coalesce(pos_table_pos_code,-2) || ')' || '(' || coalesce(pos_table_place_of_service,'') || ')' || case when length(trim(pos_table_facility_comments)) > 20 then substring(trim(pos_table_facility_comments),0,20) || '..' else trim(pos_table_facility_comments) end as hsp002 from pos_table where pos_table_pos_code<>-1 and pos_table_pos_code not in(40)  and trim(coalesce(pos_table_place_of_service,''))<>'' order by hsp002" ;
			jsarray=dbutils.executeQueryToJSONArray(qry,true);
			message=jsarray.toString();
		}
		// This code is added to group the pos by POS Type
		if(mode==171)
		{
			StringBuilder qry=new StringBuilder();
			String fromScheduler=HUtil.Nz(request.getParameter("fromSch"),"-1");
			String checkOfficePos=HUtil.Nz(dbutils.newTableLookUp("initial_settings_option_value","initial_settings","initial_settings_option_name ilike 'Show only Office POS in Service Screen ?'"),"0");
			qry.append("select pos_table_relation_id as hsp001," );
			qry.append("  '(' || coalesce(pos_table_place_of_service,'') || ')' || case when length(trim(pos_table_facility_comments)) > 35 then substring(trim(pos_table_facility_comments),0,35) || '..' else trim(pos_table_facility_comments) end as hsp002,  ");
			qry.append("case when coalesce(pos_table_pos_code,-2)::varchar ilike '1%' then 'Office' else case when coalesce(pos_table_pos_code,-2)::varchar ilike '2%' then 'Hospital' else ");
			qry.append("case when coalesce(pos_table_pos_code,-2)::varchar ilike '3%' then 'Nursing' else 'Others' end  end end as hsp003, ");
			qry.append("case when coalesce(pos_table_pos_code,-2)::varchar ilike '1%' then 1 else case when coalesce(pos_table_pos_code,-2)::varchar ilike '2%' then 2 else "); 
			qry.append("case when coalesce(pos_table_pos_code,-2)::varchar ilike '3%' then 3 else 4 end  end end as hsp004  from pos_table ");
			if(checkOfficePos.equals("1") && fromScheduler.equals("1")){
				qry.append(" where pos_table_pos_code ilike '1%' and coalesce(pos_table_is_active,true) order by hsp004,hsp002" );
			}
				else{
					qry.append("  where coalesce(pos_table_is_active,true) order by hsp004,hsp002" );
				}	
		 jsarray=dbutils.executeQueryToJSONArray(qry.toString(),true);
			message=jsarray.toString();
			
			
		}
		// end of the change
		if(mode==18  )
		{
			String patientId=HUtil.Nz(request.getParameter("patientId"),"-1");
			String refDocId=HUtil.Nz(request.getParameter("refDocId"),"-1");
			String encounterId=HUtil.Nz(request.getParameter("encounterId"),"-1");
			String isReferringPicker="",qry="";
			String isfromEditService=HUtil.Nz(request.getParameter("isfromEditService"),"-1");
			int refcount=Integer.parseInt(HUtil.Nz(dbutils.newTableLookUp("count(*)","referring_doctor","referring_doctor_isactive is true and trim(coalesce(referring_doctor_lastname,''))<>'' and trim(coalesce(referring_doctor_firstname,''))<>'' and trim(coalesce(referring_doctor_referringdoctor,''))<>'' "),"-1"));
			if(refcount>80){
				request.getSession(false).setAttribute("isReferringPicker", "1");
			}
			if(request.getSession(false).getAttribute("isReferringPicker")==null)
			{
				isReferringPicker=HUtil.Nz(dbutils.newTableLookUp("initial_settings_option_value","initial_settings","initial_settings_option_name = 'Referring Doctor Picker ?'"),"0");
			request.getSession(false).setAttribute("isReferringPicker", isReferringPicker);
			}
			else
				isReferringPicker=request.getSession(false).getAttribute("isReferringPicker").toString();
			if(isReferringPicker.equals("1")){
				String encounterRefDoc=HUtil.Nz(dbutils.newTableLookUp("encounter_ref_doctor","encounter","encounter_id="+encounterId),"-1");
			    if(refDocId.equals(""))
			    	refDocId="-1";
			    if(encounterRefDoc.equals(""))
			    	encounterRefDoc="-1";
			    if(Integer.parseInt(encounterRefDoc)>0){
			    	qry=" select distinct referring_doctor_uniqueid as hsp001, coalesce(referring_doctor_referringdoctor,'') as hsp002 from referring_doctor inner join authorization_referral on authorization_referral_doctor_id=referring_doctor_uniqueid and (authorization_referral_patient_id="+ patientId+" or referring_doctor_uniqueid ="+refDocId+ ") UNION select referring_doctor_uniqueid as hsp001, coalesce(referring_doctor_referringdoctor,'') as hsp002 from referring_doctor WHERE referring_doctor_uniqueid ="+encounterRefDoc+" order by hsp002";
			    	
			    }
			    else
				qry=" select distinct referring_doctor_uniqueid as hsp001, coalesce(referring_doctor_referringdoctor,'') as hsp002 from referring_doctor inner join authorization_referral on authorization_referral_doctor_id=referring_doctor_uniqueid and (authorization_referral_patient_id="+ patientId+" or referring_doctor_uniqueid in("+refDocId+ ","+encounterRefDoc+")) order by hsp002 ";
				    
			    if(isfromEditService.equalsIgnoreCase("1")){
			    	qry=" select distinct referring_doctor_uniqueid as hsp001, coalesce(referring_doctor_referringdoctor,'') as hsp002 from referring_doctor  WHERE referring_doctor_uniqueid ="+refDocId+" order by hsp002";
			    	jsarray=dbutils.executeQueryToJSONArray(qry,true);
					message=jsarray.toString(); 
			    }
			}
			else
			 qry=" select referring_doctor_uniqueid as hsp001, case when length(trim(coalesce(referring_doctor_referringdoctor,''))) > 18 then substring(trim(coalesce(referring_doctor_referringdoctor,'')),0,18) || '..' else trim(coalesce(referring_doctor_referringdoctor,'')) end   as hsp002 from referring_doctor where referring_doctor_isactive is true and trim(coalesce(referring_doctor_lastname,''))<>'' and trim(coalesce(referring_doctor_firstname,''))<>'' and trim(coalesce(referring_doctor_referringdoctor,''))<>'' order by hsp002 ";
			if(!isReferringPicker.equals("1")){
				jsarray=dbutils.executeQueryToJSONArray(qry,true);
				message=jsarray.toString(); 
			}
			
			
		} 
		
		if(mode==19)
		{
			String patientId=HUtil.Nz(request.getParameter("patientId"),"-1");
			String cartType=HUtil.Nz(request.getParameter("sr_cartType"),"-1");
			String cartKey=HUtil.Nz(request.getParameter("sr_cartKey"),"");
			String appDate=HUtil.Nz(request.getParameter("sr_AppDate"),"");
			JSONObject jobj=new JSONObject();
			 GlaceOutLoggingStream.console("Patient Id "+patientId);
			if(!(patientId.equals("-1"))){

				ResultSet rst;	
				rst = dbutils.executeQuery("select patient_registration_id as ptid,coalesce(patient_registration_last_name,'') as lname,coalesce(patient_registration_mid_initial,'') as mi,coalesce(patient_registration_first_name,'') as fname,coalesce(patient_registration.patient_registration_pos_id,0) as pos,coalesce(patient_ins_detail_1.patient_ins_detail_id,0) as pri_ins,coalesce(patient_ins_detail_2.patient_ins_detail_id,0) as sec_ins,coalesce(patient_ins_detail_3.patient_ins_detail_id,-1) as third_ins ,coalesce(patient_registration.patient_registration_principal_doctor,0) as pri_doctor,coalesce(patient_registration.patient_registration_refering_physician,0) as ref_physician,case when coalesce(ins_company_1.ins_company_name,'') ilike 'self%pay%' then 'T' else '0' end  as s_status,coalesce(patient_registration_basediagnosis,'') as dx,coalesce(account_type_description,'-1') as acctype,coalesce(patient_ins_detail_1.patient_ins_detail_copay,0) as copay_amt from patient_registration   left  join patient_ins_detail patient_ins_detail_1 on patient_registration_id = patient_ins_detail_1.patient_ins_detail_patientid and patient_ins_detail_1.patient_ins_detail_instype=1 and patient_ins_detail_1.patient_ins_detail_isactive is true  left  join ins_comp_addr ins_comp_addr_1 on patient_ins_detail_1.patient_ins_detail_insaddressid = ins_comp_addr_1.ins_comp_addr_id   left  join ins_company ins_company_1 on ins_comp_addr_1.ins_comp_addr_inscompany_id = ins_company_1.ins_company_id  left  join patient_ins_detail patient_ins_detail_2 on patient_registration_id = patient_ins_detail_2.patient_ins_detail_patientid and patient_ins_detail_2.patient_ins_detail_instype=2 and patient_ins_detail_2.patient_ins_detail_isactive is true  and patient_ins_detail_2.patient_ins_detail_insaddressid >0 left  join ins_comp_addr ins_comp_addr_2 on patient_ins_detail_2.patient_ins_detail_insaddressid = ins_comp_addr_2.ins_comp_addr_id left  join patient_ins_detail patient_ins_detail_3 on patient_registration_id = patient_ins_detail_3.patient_ins_detail_patientid and patient_ins_detail_3.patient_ins_detail_instype=3 and patient_ins_detail_3.patient_ins_detail_isactive is true  left  join ins_comp_addr ins_comp_addr_3 on patient_ins_detail_3.patient_ins_detail_insaddressid = ins_comp_addr_3.ins_comp_addr_id left join account_type on account_type_id=patient_registration_accttype where patient_registration_id = "+patientId+" limit 1"); //,ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY
				if(rst.next()){
				String pos_id        = rst.getString("pos");
				String pri_insid     = rst.getString("pri_ins");
				String sec_insid     = rst.getString("sec_ins");
				String pri_doctorid  = rst.getString("pri_doctor");
				String ref_physician = rst.getString("ref_physician");
				String s_status      = rst.getString("s_status");
				String ptid      = rst.getString("ptid");
				String lname      = rst.getString("lname");
				String mi      = rst.getString("mi");
				String fname      = rst.getString("fname");
				String acctype = rst.getString("acctype");
				String third_ins=rst.getString("third_ins");
				String copay_amt=rst.getString("copay_amt");
				String logInDoctor="";
				if(request.getSession(false).getAttribute("loadLogInDoctor")==null)
				{
		        	logInDoctor=HUtil.Nz(dbutils.newTableLookUp("initial_settings_option_value","initial_settings","initial_settings_option_name ilike 'Log In Doctor ?'"),"-1");
				request.getSession(false).setAttribute("enablevalidator", logInDoctor);
				}
				else
					logInDoctor=request.getSession(false).getAttribute("loadLogInDoctor").toString();
		        
		        if(logInDoctor.equals("1"))
		        {
		        	String userId =(String)request.getSession(false).getAttribute("userId");
		        	String userType=HUtil.Nz(dbutils.newTableLookUp("emp_profile_groupid","emp_profile","emp_profile_empid="+userId),"0");
		        	if(userType.equals("-1")||userType.equals("-25"))
		        		pri_doctorid=userId;
		        	
		        }
		        
		        if(!cartType.equals("-1") && cartKey.equals("todappt") && !appDate.equals(""))
		        {
		        	String appDoctor=HUtil.Nz(dbutils.newTableLookUp("coalesce(sch_resource_doctor_id,-1)","sch_appt inner join sch_resource on sch_appt_resource=sch_resource_id","sch_appt_patient_id="+patientId+" and sch_appt_date::date='"+appDate+"'::date"),"-1");
		        	GlaceOutLoggingStream.console("APPOINTMENT >>>>>>>>>>> "+appDoctor);
		        	if(!appDoctor.equals("-1") && !appDoctor.equals(""))
		        	{
		        		pri_doctorid=appDoctor;
		        	}
		        }
		        String codingSystem = HUtil.Nz(dbutils.newTableLookUp("initial_settings_option_value", "initial_settings", "initial_settings_option_name_desc='Problem list Coding System'"),"1");
					jobj.put("posid",pos_id);
					jobj.put("priinsid",pri_insid);
					jobj.put("secinsid",sec_insid);
					providerid=pri_doctorid;
					jobj.put("pridoctorid",pri_doctorid);
					jobj.put("refphysician",ref_physician);
					jobj.put("sstatus",s_status);
					jobj.put("thirdinsid",third_ins);
					jobj.put("ptid",ptid);
					jobj.put("lname",lname);
					jobj.put("mi",mi);
					jobj.put("fname",fname);
					jobj.put("copay_amt",copay_amt);
					jobj.put("contextpath",request.getContextPath());
					jobj.put("accountID",request.getSession(false).getAttribute("accountID").toString());
					jobj.put("fullcontextpath", request.getScheme()+"://"+request.getServerName()+":"+request.getServerPort()+request.getContextPath());
					jobj.put("practicename",request.getSession(false).getAttribute("practiceName"));
					jobj.put("accType",acctype);
					jobj.put("defaultDxCodeSystem", codingSystem);

				}					
				rst.close();}
			String allowLocalValidation;
			if(request.getSession(false).getAttribute("enablevalidator")==null)
			{
			 allowLocalValidation=HUtil.Nz(dbutils.newTableLookUp("initial_settings_option_value","initial_settings","initial_settings_option_name ='Perform Local Validation ?'"),"-1");
			request.getSession(false).setAttribute("enablevalidator", allowLocalValidation);
			}
			else
				allowLocalValidation=request.getSession(false).getAttribute("enablevalidator").toString();
			jobj.put("allowLocalValidation", allowLocalValidation);
			
			String allowDoctorCombination="";
			if(request.getSession(false).getAttribute("enabledoccombination")==null)
			{
				allowDoctorCombination=HUtil.Nz(dbutils.newTableLookUp("initial_settings_option_value","initial_settings","initial_settings_option_name='Check Dr. Combination ?'"),"-1");
			request.getSession(false).setAttribute("enabledoccombination", allowDoctorCombination);
			}
			else
				allowDoctorCombination=request.getSession(false).getAttribute("enabledoccombination").toString();
			jobj.put("allowDoctorCombination", allowDoctorCombination);
			
			String allowSBDoctorCombination="";
			if(request.getSession(false).getAttribute("allowSBDoctorCombination")==null){
				allowSBDoctorCombination=HUtil.Nz(dbutils.newTableLookUp("initial_settings_option_value","initial_settings","initial_settings_option_name='Service & Billing doctor combination'"),"-1");
				request.getSession(false).setAttribute("allowSBDoctorCombination", allowSBDoctorCombination);
			}else{
				allowSBDoctorCombination=request.getSession(false).getAttribute("allowSBDoctorCombination").toString();
			}
			jobj.put("allowSBDoctorCombination", allowSBDoctorCombination);
			
			String defaultBillingReason;
			if(request.getSession(false).getAttribute("defaultBillingReason")==null)
			{
				defaultBillingReason=HUtil.Nz(dbutils.newTableLookUp("initial_settings_option_value","initial_settings","initial_settings_option_name = 'Default Billing Reason'"),"-1");
			request.getSession(false).setAttribute("defaultBillingReason", defaultBillingReason);
			}
			else
				defaultBillingReason=request.getSession(false).getAttribute("defaultBillingReason").toString();
			jobj.put("defaultBillingReason", defaultBillingReason);
			
			String paymentGroupOption;
			if(request.getSession(false).getAttribute("paymentGroupOption")==null)
			{
				paymentGroupOption=HUtil.Nz(dbutils.newTableLookUp("initial_settings_option_value","initial_settings","initial_settings_option_name = 'Payment Group'"),"0");
			request.getSession(false).setAttribute("paymentGroupOption", paymentGroupOption);
			}
			else
				paymentGroupOption=request.getSession(false).getAttribute("paymentGroupOption").toString();
			jobj.put("paymentGroupOption", paymentGroupOption);
			
			String loadCPTPickerAtStartUp;
			if(request.getSession(false).getAttribute("loadCPTPickerAtStartUp")==null)
			{
				loadCPTPickerAtStartUp=HUtil.Nz(dbutils.newTableLookUp("initial_settings_option_value","initial_settings","initial_settings_option_name = 'Auto Cpt Picker ?'"),"0");
			request.getSession(false).setAttribute("loadCPTPickerAtStartUp", loadCPTPickerAtStartUp);
			}
			else
				loadCPTPickerAtStartUp=request.getSession(false).getAttribute("loadCPTPickerAtStartUp").toString();
			jobj.put("loadCPTPickerAtStartUp", loadCPTPickerAtStartUp);
			
			String isReferringPicker;
			if(request.getSession(false).getAttribute("isReferringPicker")==null)
			{
				isReferringPicker=HUtil.Nz(dbutils.newTableLookUp("initial_settings_option_value","initial_settings","initial_settings_option_name = 'Referring Doctor Picker ?'"),"0");
			request.getSession(false).setAttribute("isReferringPicker", isReferringPicker);
			}
			else
				isReferringPicker=request.getSession(false).getAttribute("isReferringPicker").toString();
			jobj.put("isReferringPicker", isReferringPicker);
			
			String isFry;
			try{
			if(request.getSession(false).getAttribute("isFry")==null)
			{
				isFry=HUtil.Nz(dbutils.newTableLookUp("initial_settings_option_value","initial_settings","initial_settings_option_type=5913"),"0");
				request.getSession(false).setAttribute("isFry", isFry);
			}
			else
				isFry=request.getSession(false).getAttribute("isFry").toString();
			}
			catch(Exception e){
				isFry="0";
				request.getSession(false).setAttribute("isFry", isFry);
			}
			jobj.put("isFry", isFry);
			
			message=jobj.toString();
		}
		
		if(mode==20)
		{
			String patientId=HUtil.Nz(request.getParameter("patientId"),"-1");
			String priInsQry		="select patient_ins_detail_id as hsp001, '('||coalesce(patient_ins_detail_patientinsuranceid,'')||')'||case when length(trim(ins_company_name)) > 20 then substring(trim(ins_company_name),0,20) || '..' ||' Type-'||	case when coalesce(patient_ins_detail_instype,-1)=1 then 'P' else case when coalesce(patient_ins_detail_instype,-1)=4 then 'CHDP' else case when coalesce(patient_ins_detail_instype,-1)=5 then 'WC' else case when coalesce(patient_ins_detail_instype,-1)=6 then 'IPA' else case when coalesce(patient_ins_detail_instype,-1)=7 then 'AUTO' else case when coalesce(patient_ins_detail_instype,-1)=8 then 'PIP' else '' end end end end end end    else trim(ins_company_name )||' Type-'||case when coalesce(patient_ins_detail_instype,-1)=1 then 'P' else case when coalesce(patient_ins_detail_instype,-1)=4 then 'CHDP' else case when coalesce(patient_ins_detail_instype,-1)=5 then 'WC' else case when coalesce(patient_ins_detail_instype,-1)=6 then 'IPA' else case when coalesce(patient_ins_detail_instype,-1)=7 then 'AUTO' else case when coalesce(patient_ins_detail_instype,-1)=8 then 'PIP' else '' end end end end end end end as hsp002,ins_comp_addr_id as hsp003,patient_ins_detail_isactive from patient_ins_detail inner join ins_comp_addr on ins_comp_addr_id=patient_ins_detail_insaddressid inner join ins_company on ins_company_id=ins_comp_addr_inscompany_id where (patient_ins_detail_patientid=" +  patientId + "   ) and patient_ins_detail_instype in (1,4,5,6,7,8) union select -99 as hsp001,'Patient Responsibility' as hsp002,-99 as hsp003,false as patient_ins_detail_isactive order by patient_ins_detail_isactive desc";
			
			message=dbutils.executeQueryToJSONArray(priInsQry,true).toString();
		
		}
		if(mode==21)
		{	 
			String patientId=HUtil.Nz(request.getParameter("patientId"),"-1");
			String secInsQry       ="select patient_ins_detail_id as hsp001, case when length(trim(ins_company_name)) > 20 then substring(trim(ins_company_name),0,20) || '..' ||' Type-'||case when coalesce(patient_ins_detail_instype,-1)=2 then 'S' else '' end else trim(ins_company_name ) ||' Type-'||case when coalesce(patient_ins_detail_instype,-1)=2 then 'S' else '' end end as hsp002 from patient_ins_detail inner join ins_comp_addr on ins_comp_addr_id=patient_ins_detail_insaddressid inner join ins_company on ins_company_id=ins_comp_addr_inscompany_id where patient_ins_detail_patientid=" + patientId + " and patient_ins_detail_instype=2 order by patient_ins_detail_isactive desc ";
			message=dbutils.executeQueryToJSONArray(secInsQry,true).toString();
					
		}
		if(mode==30)
		{//For Third Insurance	 
			String patientId=HUtil.Nz(request.getParameter("patientId"),"-1");
			String secInsQry       ="select patient_ins_detail_id as hsp001, case when length(trim(ins_company_name)) > 20 then substring(trim(ins_company_name),0,20) || '..' ||' Type-'||case when coalesce(patient_ins_detail_instype,-1)=3 then 'T' else '' end else trim(ins_company_name ) ||' Type-'||case when coalesce(patient_ins_detail_instype,-1)=3 then 'T' else '' end end as hsp002 from patient_ins_detail inner join ins_comp_addr on ins_comp_addr_id=patient_ins_detail_insaddressid inner join ins_company on ins_company_id=ins_comp_addr_inscompany_id where patient_ins_detail_patientid=" + patientId + " and patient_ins_detail_instype=3 order by patient_ins_detail_isactive desc ";
			message=dbutils.executeQueryToJSONArray(secInsQry,true).toString();
		}
		if(mode==31)
		{//For Billing Doctor depending on Provider	 
			if(request.getSession(false).getAttribute("enabledoccombination")!=null)
			{
				if(request.getSession(false).getAttribute("enabledoccombination").toString().equals("1"))
				{
			String billingDocQry       ="select bdoctorid as hsp001,emp_profile_doctorid||'-'||emp_profile_fullname as hsp002 from doctor_mapping inner join emp_profile on emp_profile_empid=bdoctorid where providerid="+providerid+" order by 2";
			message=dbutils.executeQueryToDistinctJSONArray(billingDocQry,true).toString();
				}
			}		
		}
		if(mode==32)
		{//For R Doctor depending on Provider
			if(request.getSession(false).getAttribute("enabledoccombination")!=null)
			{
				if(request.getSession(false).getAttribute("enabledoccombination").toString().equals("1"))
				{
			String RDocQry       ="select rdoctorid as hsp001,emp_profile_doctorid||'-'||emp_profile_fullname as hsp002 from doctor_mapping inner join emp_profile on emp_profile_empid=rdoctorid where providerid="+providerid+" order by 2";
			message=dbutils.executeQueryToDistinctJSONArray(RDocQry,true).toString();
				}
			}		
		}
		if(mode==33)
		{//For R Doctor depending on Provider
			if(request.getSession(false).getAttribute("enabledoccombination")!=null)
			{
				if(request.getSession(false).getAttribute("enabledoccombination").toString().equals("1"))
				{
			String RDocQry       ="select bdoctorid as hsp001, rdoctorid as hsp002 from doctor_mapping where providerid="+providerid;
			message=dbutils.executeQueryToJSONArray(RDocQry,true).toString();
				}
			}		
		}
		if(mode==34)
		{//For Doctor combination for Edit Service By DOS depending on Provider
			if(request.getSession(false).getAttribute("enabledoccombination")!=null)
			{
				if(request.getSession(false).getAttribute("enabledoccombination").toString().equals("1"))
				{
			String RDocQry       ="select bdoctorid as hsp001, rdoctorid as hsp002 from doctor_mapping where providerid in ("+providerid+")";
			message=dbutils.executeQueryToJSONArray(RDocQry,true).toString();
				}
			}		
		}
		if(mode==22)
		{
			String patientId=HUtil.Nz(request.getParameter("patientId"),"-1");
			String dos=HUtil.Nz(request.getParameter("dos"),"01/01/1980");
			String copayCptId = dbutils.newTableLookUp("billing_config_table_config_id", "billing_config_table", "billing_config_table_lookup_id=65 and billing_config_table_mapping_desc='1'");
			//String ptPmtCptId = dbutils.tableLookUp("billing_config_table_config_id", "billing_config_table", "billing_config_table_lookup_id=69 and billing_config_table_mapping_desc=1");
			GlaceOutLoggingStream.console("DOS >>> "+dos+"      Copay >>> "+copayCptId);
			String serviceQuery=patientServiceQry(patientId,"1",dos,"","-1","-1",copayCptId,0,"","");
			GlaceOutLoggingStream.console("Service Query >>> "+serviceQuery);
			long  x= System.currentTimeMillis();
			message=dbutils.executeQueryToJSONArray(serviceQuery,true).toString();
			GlaceOutLoggingStream.console("END TIME : "+System.currentTimeMillis());
			long  y=System.currentTimeMillis();
			GlaceOutLoggingStream.console("QUERY FINISHED At : "+System.currentTimeMillis());
			GlaceOutLoggingStream.console("Time Required : "+(y-x));
		}
		if(mode==23)
		{
			String patientId=HUtil.Nz(request.getParameter("patientId"),"-1");
			String serviceId=HUtil.Nz(request.getParameter("serviceId"),"-1");
			String copayCptId = dbutils.newTableLookUp("billing_config_table_config_id", "billing_config_table", "billing_config_table_lookup_id=65 and billing_config_table_mapping_desc='1'");
			//String ptPmtCptId = dbutils.tableLookUp("billing_config_table_config_id", "billing_config_table", "billing_config_table_lookup_id=69 and billing_config_table_mapping_desc=1");
			GlaceOutLoggingStream.console("Service Id  >>> "+serviceId+"      Copay >>> "+copayCptId);
			String serviceQuery=patientServiceEditQry(patientId,serviceId,copayCptId);
			GlaceOutLoggingStream.console("Service Query >>> "+serviceQuery);
			long  x= System.currentTimeMillis();
			JSONArray result = dbutils.executeQueryToJSONArray(serviceQuery,true);
			Set<String> dxSet=new LinkedHashSet<String>();
			StringBuilder dxString=new StringBuilder();
			message=result.toString();
			for(int i=0;i<result.length();i++){
				if(!result.getJSONObject(i).getString("dx1").equals(""))
					dxSet.add(result.getJSONObject(i).getString("dx1"));
				if(!result.getJSONObject(i).getString("dx2").equals(""))
					dxSet.add(result.getJSONObject(i).getString("dx2"));
				if(!result.getJSONObject(i).getString("dx3").equals(""))
					dxSet.add(result.getJSONObject(i).getString("dx3"));
				if(!result.getJSONObject(i).getString("dx4").equals(""))
					dxSet.add(result.getJSONObject(i).getString("dx4"));
			}
			Iterator<String> it=dxSet.iterator();
			while(it.hasNext()){
				dxString.append("'").append(it.next().toString()).append("',");
			}
			dxString.append("''");
			JSONArray dxResult = dbutils.executeQueryToJSONArray("select icdm_icdcode as dx,icdm_description as description from icdm where icdm_icdcode in ("+dxString+")",true);
			JSONObject jsobj=new JSONObject();
			jsobj.put("key",888);
			jsobj.put("valu",dxResult.toString());
		    jarray.put(jsobj);
			GlaceOutLoggingStream.console("END TIME : "+System.currentTimeMillis());
			long  y=System.currentTimeMillis();
			GlaceOutLoggingStream.console("QUERY FINISHED At : "+System.currentTimeMillis());
			GlaceOutLoggingStream.console("Time Required : "+(y-x));
		}
		if(mode==24)
		{
			String patientId=HUtil.Nz(request.getParameter("patientId"),"-1");
			String dos=HUtil.Nz(request.getParameter("editDOS"),"01/01/1800");
			String copayCptId = dbutils.newTableLookUp("billing_config_table_config_id", "billing_config_table", "billing_config_table_lookup_id=65 and billing_config_table_mapping_desc='1'");
			String serviceQuery=patientServiceEditQryByDos(patientId,dos,copayCptId);
			GlaceOutLoggingStream.console("Service Query1212 >>> "+serviceQuery);
			long  x= System.currentTimeMillis();
			JSONArray result = dbutils.executeQueryToJSONArray(serviceQuery,true);
			message=result.toString();
			Set<String> dxSet=new LinkedHashSet<String>();
			StringBuilder dxString=new StringBuilder();
			for(int i=0;i<result.length();i++){
				if(!result.getJSONObject(i).getString("dx1").equals(""))
					dxSet.add(result.getJSONObject(i).getString("dx1"));
				if(!result.getJSONObject(i).getString("dx2").equals(""))
					dxSet.add(result.getJSONObject(i).getString("dx2"));
				if(!result.getJSONObject(i).getString("dx3").equals(""))
					dxSet.add(result.getJSONObject(i).getString("dx3"));
				if(!result.getJSONObject(i).getString("dx4").equals(""))
					dxSet.add(result.getJSONObject(i).getString("dx4"));
			}
			Iterator<String> it=dxSet.iterator();
			while(it.hasNext()){
				dxString.append("'").append(it.next().toString()).append("',");
			}
			dxString.append("''");
			JSONArray dxResult = dbutils.executeQueryToJSONArray("select icdm_icdcode as dx,icdm_description as description from icdm where icdm_icdcode in ("+dxString+")",true);
			JSONObject jsobj=new JSONObject();
			jsobj.put("key","889");
			jsobj.put("valu",dxResult.toString());
		    jarray.put(jsobj);
			GlaceOutLoggingStream.console("END TIME : "+System.currentTimeMillis());
			long  y=System.currentTimeMillis();
			GlaceOutLoggingStream.console("QUERY FINISHED At : "+System.currentTimeMillis());
			GlaceOutLoggingStream.console("Time Required : "+(y-x));
		}
		if(mode==39) /// FOR EMR TO LOAD SERVICE ON THE SAME DAY
		{
			System.out.println("==========Entering into mode 39============"+request.getParameter("patientId"));
			String patientId=HUtil.Nz(request.getParameter("patientId"),"-1");
			String dos=HUtil.Nz(request.getParameter("dos"),"");
			String sdoc=HUtil.Nz(request.getParameter("sdoc"),"");
			System.out.println(sdoc);
			String pos=HUtil.Nz(request.getParameter("pos"),"");
			String isself=HUtil.Nz(request.getParameter("isSelf"),"0");
			String copayCptId = dbutils.newTableLookUp("billing_config_table_config_id", "billing_config_table", "billing_config_table_lookup_id=65 and billing_config_table_mapping_desc='1'");
			String patPayCode=HUtil.Nz(dbutils.newTableLookUp("billing_config_table_config_id","billing_config_table","billing_config_table_lookup_id ="+BillingConstants.NOR_PATPAY_CONFIG),"-1");
			String serviceQuery="";
			if(isself.equals("0")){
				serviceQuery=patientServiceForEMR(patientId,dos,pos,sdoc,copayCptId);
				//serviceQuery=dbutils.executeQueryToJSONArray(serviceQuery,true).toString();
			}
			else{
				serviceQuery=patientServiceForEMR(patientId,dos,pos,sdoc,patPayCode);
			//	serviceQuery=dbutils.executeQueryToJSONArray(serviceQuery,true).toString();
			}
				GlaceOutLoggingStream.console("Service Query >>> "+serviceQuery);
			long  x= System.currentTimeMillis();
			JSONArray result = dbutils.executeQueryToJSONArray(serviceQuery,true);
			message=result.toString();
			Set<String> dxSet=new LinkedHashSet<String>();
			StringBuilder dxString=new StringBuilder();
			for(int i=0;i<result.length();i++){
				if(!result.getJSONObject(i).getString("dx1").equals(""))
					dxSet.add(result.getJSONObject(i).getString("dx1"));
				if(!result.getJSONObject(i).getString("dx2").equals(""))
					dxSet.add(result.getJSONObject(i).getString("dx2"));
				if(!result.getJSONObject(i).getString("dx3").equals(""))
					dxSet.add(result.getJSONObject(i).getString("dx3"));
				if(!result.getJSONObject(i).getString("dx4").equals(""))
					dxSet.add(result.getJSONObject(i).getString("dx4"));
			}
			Iterator<String> it=dxSet.iterator();
			while(it.hasNext()){
				dxString.append("'").append(it.next().toString()).append("',");
			}
			dxString.append("''");
			JSONArray dxResult = dbutils.executeQueryToJSONArray("select icdm_icdcode as dx,icdm_description as description from icdm where icdm_icdcode in ("+dxString+")",true);
			JSONObject jsobj=new JSONObject();
			jsobj.put("key","890");
			jsobj.put("valu",dxResult.toString());
		    jarray.put(jsobj);
			GlaceOutLoggingStream.console("END TIME : "+System.currentTimeMillis());
			long  y=System.currentTimeMillis();
			GlaceOutLoggingStream.console("QUERY FINISHED At : "+System.currentTimeMillis());
			GlaceOutLoggingStream.console("Time Required : "+(y-x));
			System.out.println("exiting mode 39"+result);	
		}
		
		if(mode==40) /// FOR EMR TO LOAD SERVICE ON THE SAME DAY
		{
			System.out.println("=======Entering into mode 40=========");
			GlaceOutLoggingStream.console(">>>>>>>>>>>>>>>>  In Mode 40 ");
			String patientId=HUtil.Nz(request.getParameter("patientId"),"-1");
			String dos=HUtil.Nz(request.getParameter("dos"),"");
			String sdoc=HUtil.Nz(request.getParameter("sdoc"),"");
			String pos=HUtil.Nz(request.getParameter("pos"),"");
			String serviceQuery=checkService(patientId,dos,pos,sdoc);
			GlaceOutLoggingStream.console("Check Query >>> "+serviceQuery);
			long  x= System.currentTimeMillis();
			message=dbutils.executeQueryToJSONArray(serviceQuery,true).toString();
			GlaceOutLoggingStream.console("END TIME : "+System.currentTimeMillis());
			long  y=System.currentTimeMillis();
			GlaceOutLoggingStream.console("QUERY FINISHED At : "+System.currentTimeMillis());
			GlaceOutLoggingStream.console("Time Required : "+(y-x));
			System.out.println("exiting mode 40");	
		}
		
		if(mode==25)
		{
			JSONObject jobj=new JSONObject();
			jobj.put("contextpath",request.getContextPath());
			jobj.put("accountID",request.getSession(false).getAttribute("accountID").toString());
			jobj.put("fullcontextpath", request.getScheme()+"://"+request.getServerName()+":"+request.getServerPort()+request.getContextPath());
			jobj.put("practicename",request.getSession(false).getAttribute("practiceName"));
			String allowLocalValidation;
			if(request.getSession(false).getAttribute("enablevalidator")==null)
			{
			 allowLocalValidation=HUtil.Nz(dbutils.newTableLookUp("initial_settings_option_value","initial_settings","initial_settings_option_name='Perform Local Validation ?'"),"-1");
			request.getSession(false).setAttribute("enablevalidator", allowLocalValidation);
			}
			else
				allowLocalValidation=request.getSession(false).getAttribute("enablevalidator").toString();
			
			
			jobj.put("allowLocalValidation", allowLocalValidation);
			
			String allowDoctorCombination;
			if(request.getSession(false).getAttribute("enabledoccombination")==null)
			{
				allowDoctorCombination=HUtil.Nz(dbutils.newTableLookUp("initial_settings_option_value","initial_settings","initial_settings_option_name ='Check Dr. Combination ?'"),"-1");
			request.getSession(false).setAttribute("enabledoccombination", allowDoctorCombination);
			}
			else
				allowDoctorCombination=request.getSession(false).getAttribute("enabledoccombination").toString();
			jobj.put("allowDoctorCombination", allowDoctorCombination);
			
			String allowSBDoctorCombination="";
			if(request.getSession(false).getAttribute("allowSBDoctorCombination")==null){
				allowSBDoctorCombination=HUtil.Nz(dbutils.newTableLookUp("initial_settings_option_value","initial_settings","initial_settings_option_name='Service & Billing doctor combination'"),"-1");
				request.getSession(false).setAttribute("allowSBDoctorCombination", allowSBDoctorCombination);
			}else{
				allowSBDoctorCombination=request.getSession(false).getAttribute("allowSBDoctorCombination").toString();
			}
			jobj.put("allowSBDoctorCombination", allowSBDoctorCombination);
			
			String paymentGroupOption;
			if(request.getSession(false).getAttribute("paymentGroupOption")==null)
			{
				paymentGroupOption=HUtil.Nz(dbutils.newTableLookUp("initial_settings_option_value","initial_settings","initial_settings_option_name = 'Payment Group'"),"0");
			request.getSession(false).setAttribute("paymentGroupOption", paymentGroupOption);
			}
			else
				paymentGroupOption=request.getSession(false).getAttribute("paymentGroupOption").toString();
			jobj.put("paymentGroupOption", paymentGroupOption);
			
			String loadCPTPickerAtStartUp;
			if(request.getSession(false).getAttribute("loadCPTPickerAtStartUp")==null)
			{
				loadCPTPickerAtStartUp=HUtil.Nz(dbutils.newTableLookUp("initial_settings_option_value","initial_settings","initial_settings_option_name = 'Auto Cpt Picker ?'"),"0");
			request.getSession(false).setAttribute("loadCPTPickerAtStartUp", loadCPTPickerAtStartUp);
			}
			else
				loadCPTPickerAtStartUp=request.getSession(false).getAttribute("loadCPTPickerAtStartUp").toString();
			jobj.put("loadCPTPickerAtStartUp", loadCPTPickerAtStartUp);
			
			String isReferringPicker;
			if(request.getSession(false).getAttribute("isReferringPicker")==null)
			{
				isReferringPicker=HUtil.Nz(dbutils.newTableLookUp("initial_settings_option_value","initial_settings","initial_settings_option_name = 'Referring Doctor Picker ?'"),"0");
			request.getSession(false).setAttribute("isReferringPicker", isReferringPicker);
			}
			else
				isReferringPicker=request.getSession(false).getAttribute("isReferringPicker").toString();
			jobj.put("isReferringPicker", isReferringPicker);
			
			message=jobj.toString();
		}
		
		if (mode==50){
			JSONObject jobj=new JSONObject();
			String    defBReasonid,defBReasonName;
			defBReasonid=HUtil.Nz(dbutils.newTableLookUp("initial_settings_option_value","initial_settings","initial_settings_option_name = 'Default Billing Reason'"),"-1");
			jobj.put("defBReasonid",defBReasonid);
			defBReasonName=HUtil.Nz(dbutils.newTableLookUp("coalesce(billing_reason_desc,'')","billing_reason"," billing_reason_isactive=true and billing_reason_id="+defBReasonid+""),"");
			jobj.put("defBReasonName",defBReasonName);
			message=jobj.toString();
		}

		if (mode==51){
			JSONObject jobj=new JSONObject();
			JSONArray jobjArray1=new JSONArray();
			JSONArray jobjArray2=new JSONArray();
			JSONArray jobjArray3=new JSONArray();
			JSONArray jobjArray4=new JSONArray();
			jobjArray1=dbutils.executeQueryToDistinctJSONArray("select group_name as groupname,cpt_code as code,coalesce(cpt_desc,'') as cptdesc,coalesce(trim(generic_cpt_genericcptcode),'') as gcptcode,coalesce(generic_cpt_insuranceid,'') as cptinsid from quickcpt inner join cpt on quickcpt.cpt_code=cpt.cpt_cptcode left join generic_cpt on trim(cpt.cpt_cptcode)=trim(generic_cpt_cptcode) where cpt_isactive=true and group_no=1 order by cpt_code", true);
			jobj.put("FirstGroup", jobjArray1);
			jobjArray2=dbutils.executeQueryToDistinctJSONArray("select group_name as groupname,cpt_code as code,coalesce(cpt_desc,'') as cptdesc,coalesce(trim(generic_cpt_genericcptcode),'') as gcptcode,coalesce(generic_cpt_insuranceid,'') as cptinsid from quickcpt inner join cpt on quickcpt.cpt_code=cpt.cpt_cptcode left join generic_cpt on trim(cpt.cpt_cptcode)=trim(generic_cpt_cptcode) where cpt_isactive=true and group_no=2 order by cpt_code", true);
			jobj.put("SecondGroup", jobjArray2);
			jobjArray3=dbutils.executeQueryToDistinctJSONArray("select group_name as groupname,cpt_code as code,coalesce(cpt_desc,'') as cptdesc,coalesce(trim(generic_cpt_genericcptcode),'') as gcptcode,coalesce(generic_cpt_insuranceid,'') as cptinsid from quickcpt inner join cpt on quickcpt.cpt_code=cpt.cpt_cptcode left join generic_cpt on trim(cpt.cpt_cptcode)=trim(generic_cpt_cptcode) where cpt_isactive=true and group_no=3 order by cpt_code", true);
			jobj.put("ThirdGroup", jobjArray3);
			jobjArray4=dbutils.executeQueryToDistinctJSONArray("select group_name as groupname,cpt_code as code,coalesce(cpt_desc,'') as cptdesc,coalesce(trim(generic_cpt_genericcptcode),'') as gcptcode,coalesce(generic_cpt_insuranceid,'') as cptinsid from quickcpt inner join cpt on quickcpt.cpt_code=cpt.cpt_cptcode left join generic_cpt on trim(cpt.cpt_cptcode)=trim(generic_cpt_cptcode) where cpt_isactive=true and group_no=4 order by cpt_code", true);
			jobj.put("FourthGroup", jobjArray4);
			message=jobj.toString();
		}
		if (mode==52){
			jsarray=dbutils.executeQueryToDistinctJSONArray("select quickcptgroup_name as hsp002,quickcptgroup_cptcodes as hsp001,quickcptgroup_id as qcgid,quickcptgroup_isactive as isactive from quickcptgroup order by quickcptgroup_name", true);
			message=jsarray.toString();
		}
		if (mode==53){
			String qry = "select service_billing_doctor_mapping_id as id, service_billing_doctor_mapping_servicedoctor as sdoctor,service_billing_doctor_mapping_billingdoctor as bdoctor ";
					qry +=" from service_billing_doctor_mapping order by service_billing_doctor_mapping_id ";
			jsarray=dbutils.executeQueryToDistinctJSONArray(qry, true);
			message=jsarray.toString();
		}
		if (mode==55){
			String qry = "select ledger_chargetabfield_id as chargetabfieldid,trim(ledger_chargetabfield_name) as chargetabname,trim(ledger_chargetabfield_displayname) as chargetabdispname,trim(ledger_chargetabfield_type) as chargetabfieldtype from ledger_chargetabfield where ledger_chargetabfield_isactive is true order by 1 ";
			jsarray=dbutils.executeQueryToDistinctJSONArray(qry, true);
			message=jsarray.toString();
		}
		if (mode==56){
			String patientId=HUtil.Nz(request.getParameter("patientId"),"-1");
			String serviceQuery=defaultAdditionalServiceFielData(patientId);
			jsarray = dbutils.executeQueryToJSONArray(serviceQuery,true);
			message=jsarray.toString();
		}
		if(mode==57)
		{
			String patientId=HUtil.Nz(request.getParameter("patientId"),"-1");
			String serviceId=HUtil.Nz(request.getParameter("serviceId"),"-1");
			String qry=" select ndc as hsp002,row as hsp001 from (select (case when trim(cpt_ndc) ilike '%;%' then unnest(array[string_to_array(trim(cpt_ndc),';')]) else unnest(array[string_to_array(trim(cpt_ndc),',')]) end) as ndc,row_number() over (order by (case when trim(cpt_ndc) ilike '%;%' then unnest(array[string_to_array(trim(cpt_ndc),';')]) else unnest(array[string_to_array(trim(cpt_ndc),',')]) end) desc) as Row from service_detail inner join cpt on cpt_id=service_detail_cptid ";
			       qry+=" where service_detail_patientid= "+patientId+"  and service_detail_id="+serviceId+"  )a ";
			jsarray=dbutils.executeQueryToDistinctJSONArray(qry, true);
			message=jsarray.toString();
		}
		if(mode==58)
		{
			JSONArray jsonarray;
			String patientId=HUtil.Nz(request.getParameter("patientId"),"-1");
			String dos=HUtil.Nz(request.getParameter("editDOS"),"01/01/1800");
		
			String qry=" select service_detail_id as serviceid from service_detail inner join cpt on cpt_id=service_detail_cptid   ";
		       qry+=" where service_detail_patientid= "+patientId+"  and service_detail_dos='"+dos+"' and service_detail_submit_status not like 'X'  ";
	
		       jsonarray=dbutils.executeQueryToJSONArray(qry);
				for(int i=0;i<jsonarray.length();i++){
				    int serviceRowId = jsonarray.getJSONArray(i).getInt(0);
					
				String valueQRY="  select ndc as hsp002,row as hsp001 from (select (case when trim(cpt_ndc) ilike '%;%' then unnest(array[string_to_array(trim(cpt_ndc),';')]) else unnest(array[string_to_array(trim(cpt_ndc),',')]) end) as ndc,row_number() over (order by (case when trim(cpt_ndc) ilike '%;%' then unnest(array[string_to_array(trim(cpt_ndc),';')]) else unnest(array[string_to_array(trim(cpt_ndc),',')]) end) desc) as Row from service_detail inner join cpt on cpt_id=service_detail_cptid ";
				       valueQRY+="  where service_detail_id="+serviceRowId+" and service_detail_submit_status not like 'X' )a ";
					 
				       jsarray=  dbutils.executeQueryToDistinctJSONArray(valueQRY, true);
					   JSONObject jsobj=new JSONObject();
						jsobj.put("key",serviceRowId);
						jsobj.put("valu",jsarray.toString());
						jarray.put(jsobj);
			}
		}
		if(mode==59) //Getting Patient Ins Addr ID
		{
			String patientId=HUtil.Nz(request.getParameter("patientId"),"-1");
			String qry=" select ins_comp_addr_id as patinsaddrid from patient_registration inner join patient_ins_detail  ";
			       qry+=" on patient_registration_id=patient_ins_detail_patientid and patient_ins_detail_instype=1 and patient_ins_detail_isactive is true ";
			       qry+=" inner join ins_comp_addr on ins_comp_addr_id=patient_ins_detail_insaddressid where patient_registration_id= "+patientId+" ";
		jsarray=dbutils.executeQueryToDistinctJSONArray(qry, true);
		message=jsarray.toString();
			
		}
		JSONObject jsobj=new JSONObject();
		if(mode==57)
		{
			String serviceId=HUtil.Nz(request.getParameter("serviceId"),"-1");
		}
		else
		{
		jsobj.put("key",mode);
		}
		jsobj.put("valu",message);
		 jarray.put(jsobj);
		 if(mode==6){  // To get all the used visit type auth DOS
				String patientId=HUtil.Nz(request.getParameter("patientId"),"-1");
				StringBuffer AuthQuery = new StringBuffer();
				AuthQuery.append(" select distinct authorization_referral_id as authid,to_mmddyyyy(coalesce(service_detail_dos,'1900-01-01'::date)) as useddos from service_detail ");
				AuthQuery.append(" inner join authorization_referral on authorization_referral_id = service_detail_authid and service_detail_patientid = authorization_referral_patient_id and authorization_referral_authtype=2 ");
				AuthQuery.append(" where authorization_referral_patient_id=" + patientId);
				jsarray=dbutils.executeQueryToJSONArray(AuthQuery.toString(),true);
				message=jsarray.toString();
				jsobj=new JSONObject();
				jsobj.put("key",100);
				jsobj.put("valu",message);
				 jarray.put(jsobj);
				 
		 }
			}
		}
		
		if(action==1)
		{
			String cptCost = "";
			String cptCode = HUtil.Nz(request.getParameter("cptCode"),"");
			int cptPlan =Integer.parseInt(HUtil.Nz(request.getParameter("cptPlan"),"-2"));
			int patientId=Integer.parseInt(HUtil.Nz(request.getParameter("patientId"),"-1"));
			String dos = HUtil.Nz(request.getParameter("dos"),"");
			boolean fetchCopay =  Boolean.parseBoolean(HUtil.Nz(request.getParameter("fetchCopay"),"true"));
			GlaceOutLoggingStream.console("Plan from jsp "+cptPlan);
			String authinfo = "";
			String officeVisitCopayCpts = "99201,99202,99203,99204,99205,99211,99212,99213,99214,99215,99241,99242,99243,99244,99245,99381,99382,99383,99384,99385,99386,99387,99391,99392,99393,99394,99395,99396,99397,90801,90862,95970,95974,90804,90806,90846,";
			if (cptPlan == -2)
			 cptPlan = Integer.parseInt(dbutils.newTableLookUp("coalesce(patient_registration_costplan,-2)", "patient_registration", "patient_registration_id=" + patientId));
			GlaceOutLoggingStream.console("PLAN >>>> "+cptPlan);
			String qry;		  
			if(cptPlan == 7 || cptPlan ==8)
				qry = "select coalesce(cpt_cptcode,'') as cptcode,substring(trim(coalesce(cpt_description,'')),0,50) as shortdesc,coalesce(cpt_cpttype,-1) as type,coalesce(cpt_mod_1,'') as mod1,coalesce(cpt_mod_2,'') as mod2 ,coalesce(cpt_mod_3,'') as mod3,coalesce(cpt_mod_4,'')as mod4,case when coalesce(cpt_cost_plan_cpt_cost,0.00)>0 then coalesce(cpt_cost_plan_cpt_cost,0.00) else coalesce(cpt_cost,0.00) end as rate,coalesce(cpt_unit_charge,0) as qty,coalesce(cpt_dosage_units,1) as dunits,coalesce(cpt_ndc,'') as ndcno from cpt left join cpt_cost_plan on cpt_id=cpt_cost_plan_cpt_id and  cpt_cost_plan_costplan=" + cptPlan + "where  (cpt_cpttype=1 or cpt_cpttype=6) and cpt_isactive is true and cpt_cptcode ilike '"+cptCode+"'";
			else
				qry = "select coalesce(cpt_cptcode,'') as cptcode,substring(trim(coalesce(cpt_description,'')),0,50) as shortdesc,coalesce(cpt_cpttype,-1) as type,case when coalesce(cpt_cost_plan_cpt_cost,0.00)>0 then coalesce(cpt_cost_plan_cpt_cost,0.00) else coalesce(cpt_cost,0.00) end as rate,coalesce(cpt_mod_1,'') as mod1,coalesce(cpt_mod_2,'') as mod2 ,coalesce(cpt_mod_3,'') as mod3,coalesce(cpt_mod_4,'')as mod4,coalesce(cpt_unit_charge,0) as qty,coalesce(cpt_dosage_units,1) as dunits,coalesce(cpt_ndc,'') as ndcno from cpt left join cpt_cost_plan on cpt_id=cpt_cost_plan_cpt_id and  cpt_cost_plan_costplan=" + cptPlan + " where  (cpt_cpttype=1 or cpt_cpttype=6) and cpt_isactive is true and cpt_cptcode ilike '"+cptCode+"'";
			JSONObject jobj=new JSONObject();
			jobj.put("cptdat",dbutils.executeQueryToJSONArray(qry,true).toString());
			jarray=new JSONArray();
			 jarray.put(jobj);
			String copayCPTFromConfigurationPage;
			if(request.getSession(false).getAttribute("copayCPT")==null)
			{
				copayCPTFromConfigurationPage=HUtil.Nz(dbutils.newTableLookUp("initial_settings_option_value","initial_settings","initial_settings_option_name = 'Copay Cpt'"),"");
			request.getSession(false).setAttribute("copayCPT", copayCPTFromConfigurationPage);
			}
			else
				copayCPTFromConfigurationPage=request.getSession(false).getAttribute("copayCPT").toString();
			copayCPTFromConfigurationPage=copayCPTFromConfigurationPage.replaceAll("%", "");
			
			if(!copayCPTFromConfigurationPage.trim().equals(""))
				officeVisitCopayCpts+=copayCPTFromConfigurationPage.trim();
			
			String copay="0";
			boolean hasCopayForDOS = false;
			int serviceCountHavingCopay = 0;

			if(!dos.equalsIgnoreCase("") && fetchCopay && officeVisitCopayCpts.contains(cptCode)){
				serviceCountHavingCopay = Integer.parseInt(HUtil.Nz(dbutils.newTableLookUp("count(*) ","service_detail","service_detail_patientid = "+patientId+" and service_detail_dos ='"+dos+"'::date and coalesce(service_detail_copay,0)>0"),"0"));
				if(serviceCountHavingCopay>0)
					hasCopayForDOS=true;
				if(!hasCopayForDOS){
					String ptCopay=HUtil.Nz(dbutils.newTableLookUp("coalesce(patient_registration_copay,0)","patient_registration","patient_registration_id="+patientId),"0");
					copay=ptCopay;
				}
			}
			JSONObject copayObj=new JSONObject();
			copayObj.put("copay", copay);
			jarray.put(copayObj);
		
			
		}
		if(action==2)
		{
			String dxString=HUtil.Nz(request.getParameter("dxstring"),"");
			GlaceOutLoggingStream.console("Dx String >>>> "+dxString);
			dxString = dxString.toUpperCase(); 
			String[] splitDx=dxString.split("~");
			Set<String> dxStore=new LinkedHashSet<String>();
			for(int i=0;i<splitDx.length;i++){
				if(!splitDx[i].equals("00000"))
				 dxStore.add((splitDx[i]).toUpperCase());
			}
			GlaceOutLoggingStream.console(dxStore);
			StringBuilder newDxArray=new StringBuilder();
			Iterator it = dxStore.iterator();
		    while (it.hasNext()) {
		    	if(newDxArray.length()==0){
		    	 newDxArray.append("'").append((String)it.next()).append("'");
		    	}else{
		    		newDxArray.append(",'").append((String)it.next()).append("'");
		    	}
		    }
		    GlaceOutLoggingStream.console("Dx String >>>>>>  "+newDxArray);
		    StringBuilder dxQuery=new StringBuilder();
		    dxQuery.append("select icdm_icdcode as dx from icdm where upper(icdm_icdcode::text) in (").append(newDxArray.toString()).append(")");
			Vector checkDx=new Vector(); 
			if(newDxArray.length() > 0)
			checkDx=dbutils.executeQueryToVector(dxQuery.toString());
			Map<String,String> checkDxMap=new HashMap<String,String>();
			for(int i=0;i<checkDx.size();i++){
				checkDxMap.put((String)(((Vector)checkDx.get(i)).get(0)), "1");
				GlaceOutLoggingStream.console(checkDxMap);
			}
			Iterator it1 = dxStore.iterator();
			StringBuilder missingDx=new StringBuilder();
			String tempDx="";
		    while (it1.hasNext()) {
		    	tempDx=(String)it1.next();
		    	GlaceOutLoggingStream.console(tempDx);
		    	if(!checkDxMap.containsKey(tempDx)){
		    		GlaceOutLoggingStream.console("***");
		    	if(missingDx.length()==0){
		    		if(tempDx.equalsIgnoreCase("NODX") || tempDx.equalsIgnoreCase("NO DX")){
		    			
		    		}else
		    		missingDx.append(tempDx.toUpperCase());
		    	}
		    	else{if(tempDx.equalsIgnoreCase("NODX") || tempDx.equalsIgnoreCase("NO DX")){
	    			
	    		}else
		    		missingDx.append(",").append(tempDx.toUpperCase());
		    	}
		    	}
		    }
		    JSONObject jobj=new JSONObject();
		    if(missingDx.length()==0){
		      jobj.put("status","success");
		      jobj.put("message",missingDx);
		    }
		    else{
		    	String dxCodes="";
		    	String dosDate= getEncounterDate(request,dbutils);
		    	String accountId = HUtil.Nz(session.getAttribute("accountID")," ");
		    	GetPickerDataModel pickerDataModel=new GetPickerDataModel();
	        	String urlfromdb=HUtil.Nz(dbutils.newTableLookUp("url","central_hub"),"-1");
	        	boolean isicd10dx=true;
	        	String dxArray=newDxArray.toString().replaceAll("'","");
	        	
	        		String data=pickerDataModel.getICD10Data(urlfromdb+"/DataGateway/validateICD10Code?dos="+dosDate+"&codeList="+missingDx.toString(),accountId);
	        		if(data!=null && !data.equals("") ){
	        			JSONObject obj=new JSONObject(data);
	        			for(String currDx:missingDx.toString().split(",")){
	        				if(obj.get(currDx).toString().equalsIgnoreCase("false")){
	        				dxCodes=currDx;
	        				isicd10dx=false;
	        				break;
	        				}else{
	    	        			isicd10dx=true;
	    	        		}
	        			}
	        		}
	        
	        	if(!isicd10dx){
	        		jobj.put("status","failure");
	        		jobj.put("message",dxCodes);
	        	}else
	        		jobj.put("status","success");
		    }
		    jarray=new JSONArray();
			jarray.put(jobj);
			
		}
		if(action == 3)
		{
			String cptCode = HUtil.Nz(request.getParameter("cptCode"),"'-1'");
			int cptPlan =Integer.parseInt(HUtil.Nz(request.getParameter("cptPlan"),"-2"));
			int patientId=Integer.parseInt(HUtil.Nz(request.getParameter("patientId"),"-1"));
			GlaceOutLoggingStream.console("Plan from jsp "+cptPlan);
			String authinfo = "";
		GlaceOutLoggingStream.console("Chking for CPT validation");
			GlaceOutLoggingStream.console("PLAN >>>> "+cptPlan);
		
			String qry="";
			if(cptPlan == 7 || cptPlan ==8)
			qry = "select coalesce(cpt_cptcode,'') as cptcode,case when coalesce(cpt_cost_plan_cpt_cost,0.00)>0 then coalesce(cpt_cost_plan_cpt_cost,0.00) else coalesce(cpt_cost,0.00) end as rate,coalesce(cpt_ndc,'') as ndcno from cpt left join cpt_cost_plan on cpt_id=cpt_cost_plan_cpt_id and  cpt_cost_plan_costplan=" + cptPlan + "where  (cpt_cpttype=1 or cpt_cpttype=6)  and cpt_cptcode in ("+cptCode+")";
			else
				qry = "select coalesce(cpt_cptcode,'') as cptcode,coalesce(cpt_description,'') as shortdesc,coalesce(cpt_cpttype,-1) as type,case when coalesce(cpt_cost_plan_cpt_cost,0.00)>0 then coalesce(cpt_cost_plan_cpt_cost,0.00) else coalesce(cpt_cost,0.00) end as rate,coalesce(cpt_mod_1,'') as mod1,coalesce(cpt_mod_2,'') as mod2 ,coalesce(cpt_mod_3,'') as mod3,coalesce(cpt_mod_4,'')as mod4,coalesce(cpt_unit_charge,0) as qty,coalesce(cpt_dosage_units,1) as dunits,coalesce(cpt_ndc,'') as ndcno from cpt left join cpt_cost_plan on cpt_id=cpt_cost_plan_cpt_id and  cpt_cost_plan_costplan=" + cptPlan +  " where  (cpt_cpttype=1 or cpt_cpttype=6)  and cpt_cptcode in ("+cptCode+")";	
			GlaceOutLoggingStream.console(qry);
			JSONObject jobj=new JSONObject();
			jobj.put("cptdat",dbutils.executeQueryToJSONArray(qry,true).toString());
			 jarray=new JSONArray();
			 jarray.put(jobj);
			
		}
		if(action == 4)
		{
			int encounterId=Integer.parseInt(HUtil.Nz(request.getParameter("encounterId"),"-1"));
			int p_Id=Integer.parseInt(HUtil.Nz(request.getParameter("patientId"),"-1"));
			int emrSuperbillSerDoctor=Integer.parseInt((HUtil.Nz(request.getSession(false).getAttribute("emrSuperbillSerDoctor"),"-1")).toString());
			String chart_Id="";
			String doctor_Id="";
			String billing_doctor="";
			String pos_Id="";
			String refdoc_Id="";
			String eDate="";
			String p_Ins_Id="-1";
			String s_Ins_Id="-2";
			String t_Ins_Id="-1";
			String p_Ins_Id_default="-1";
			String s_Ins_Id_default="-2";
			String t_Ins_id_default="-1";
			
			String group_id="";
			String plan_type="";
			int type;
			Vector sdata=new Vector();
			StringBuffer query=new StringBuffer();
			query.append("select encounter_id, encounter_chartid, to_char(encounter_date,'MM/DD/YYYY'),");
			if(emrSuperbillSerDoctor < 0)
				query.append(" coalesce(encounter_service_doctor,-1), ");
			else
				query.append(emrSuperbillSerDoctor+" , ");
			
	        query.append(" COALESCE(encounter_pos,-1), encounter_ref_doctor ,coalesce(groupid,2), coalesce(plantype,-1) from "); 
	        query.append(" encounter inner join chart on encounter_chartid = chart_id");
	        query.append(" inner join patient_encounter_type on categoryid=encounter_visittype");
	        query.append(" where encounter_id = "+encounterId);
	        try
	 	   {
	        	sdata.removeAllElements();
	         sdata = dbutils.executeQueryToVector(query.toString());
	         if(sdata.size()!=0)
	         {
	         Vector d=(Vector)sdata.get(0);
	         chart_Id=(String)d.get(1);
	         eDate=(String)d.get(2);
	         doctor_Id=(String)d.get(3);
	         pos_Id=(String)d.get(4);
	         refdoc_Id=(String)d.get(5);
	         group_id=(String)d.get(6);
	         plan_type=(String)d.get(7);
	         }
	         if(doctor_Id.equals(""))
	        	 doctor_Id="-1";
	         if(pos_Id.equals(""))
	        	 pos_Id="-1";
	         GlaceOutLoggingStream.console("NEW SERVICE ENTRY >>>>>>>>>>>>>>>>");
	         GlaceOutLoggingStream.console("Chart Id >>> "+chart_Id);
	         GlaceOutLoggingStream.console("Encounter Id >>> "+eDate);
	         GlaceOutLoggingStream.console("Service doctor Id >>> "+doctor_Id);
	         GlaceOutLoggingStream.console("POS Id >>> "+pos_Id);
	         GlaceOutLoggingStream.console("Ref doctor Id >>> "+refdoc_Id);
	         GlaceOutLoggingStream.console("2nd");
	         String query2="select patient_ins_detail_id,patient_ins_detail_instype from patient_ins_detail where patient_ins_detail_instype in (1,2,3) and patient_ins_detail_isactive is true and patient_ins_detail_patientid= "+p_Id+" order by patient_ins_detail_instype";
	         Vector rs=dbutils.executeQueryToVector(query2);
	         
	          for(int i=0;i<rs.size();i++)
	          {
	             Vector p=(Vector)rs.get(i);
	             type=Integer.parseInt((String)p.get(1));
	               if(type==1){
	            	   p_Ins_Id_default=p_Ins_Id=(String)p.get(0);
	               }
	               else if(type==2){
	            	   s_Ins_Id_default=s_Ins_Id=(String)p.get(0);
	               }
	               else if(type==3){
	            	   t_Ins_id_default=t_Ins_Id =(String)p.get(0);
	               }
	          }
	          
	          if(group_id.equals("3"))
	          {
	         	 p_Ins_Id=HUtil.Nz(dbutils.newTableLookUp("patient_ins_detail_id","patient_ins_detail inner join ins_comp_addr on ins_comp_addr_id=patient_ins_detail_insaddressid inner join ins_company on ins_company_id=ins_comp_addr_inscompany_id","patient_ins_detail_patientid="+p_Id+" and patient_ins_detail_instype=4 and patient_ins_detail_isactive is true"),"-1");
	         	 s_Ins_Id="-1";
	         	 t_Ins_Id="-1";
	          }
	          else if(group_id.equals("4"))
	          {
	         	 p_Ins_Id=HUtil.Nz(dbutils.newTableLookUp("patient_ins_detail_id","patient_ins_detail inner join ins_comp_addr on ins_comp_addr_id=patient_ins_detail_insaddressid inner join ins_company on ins_company_id=ins_comp_addr_inscompany_id","patient_ins_detail_patientid="+p_Id+" and patient_ins_detail_instype=5 and patient_ins_detail_isactive is true"),"-1");
	         	 s_Ins_Id="-1";
	         	 t_Ins_Id="-1";
	          }
	          else if(group_id.equals("5"))
	          {
	         	 p_Ins_Id=HUtil.Nz(dbutils.newTableLookUp("patient_ins_detail_id","patient_ins_detail inner join ins_comp_addr on ins_comp_addr_id=patient_ins_detail_insaddressid inner join ins_company on ins_company_id=ins_comp_addr_inscompany_id","patient_ins_detail_patientid="+p_Id+" and patient_ins_detail_instype=6 and patient_ins_detail_isactive is true"),"-1");
	         	 s_Ins_Id="-1";
	         	 t_Ins_Id="-1";
	          }
	          else if(group_id.equals("6"))
	          {
	         	 p_Ins_Id=HUtil.Nz(dbutils.newTableLookUp("patient_ins_detail_id","patient_ins_detail inner join ins_comp_addr on ins_comp_addr_id=patient_ins_detail_insaddressid inner join ins_company on ins_company_id=ins_comp_addr_inscompany_id","patient_ins_detail_patientid="+p_Id+" and patient_ins_detail_instype=7 and patient_ins_detail_isactive is true"),"-1");
	         	 s_Ins_Id="-1";
	         	 t_Ins_Id="-1";
	          }
	          else if(group_id.equals("7"))
	          {
	         	 p_Ins_Id=HUtil.Nz(dbutils.newTableLookUp("patient_ins_detail_id","patient_ins_detail inner join ins_comp_addr on ins_comp_addr_id=patient_ins_detail_insaddressid inner join ins_company on ins_company_id=ins_comp_addr_inscompany_id","patient_ins_detail_patientid="+p_Id+" and patient_ins_detail_instype=8 and patient_ins_detail_isactive is true"),"-1");
	         	 s_Ins_Id="-1";
	         	 t_Ins_Id="-1";
	          }
	          
	         if(p_Ins_Id.equals("-1")){
	        	  p_Ins_Id = p_Ins_Id_default;
	        	  s_Ins_Id = s_Ins_Id_default;
	        	  t_Ins_Id = t_Ins_id_default;
	          }
	          
	          if(encounterId==-1||doctor_Id.equals("-1"))
	          {
	          ResultSet rst;	
	 			rst = dbutils.executeQuery("select coalesce(patient_registration.patient_registration_pos_id,0) as pos,coalesce(patient_ins_detail_1.patient_ins_detail_id,0) as pri_ins,coalesce(patient_ins_detail_2.patient_ins_detail_id,0) as sec_ins ,coalesce(patient_registration.patient_registration_principal_doctor,0) as pri_doctor,coalesce(patient_registration.patient_registration_refering_physician,0) as ref_physician,case when coalesce(ins_company_1.ins_company_name,'') ilike 'self%pay%' then 'T' else '0' end  as s_status,coalesce(patient_registration_basediagnosis,'') as dx from patient_registration   left  join patient_ins_detail patient_ins_detail_1 on patient_registration_id = patient_ins_detail_1.patient_ins_detail_patientid and patient_ins_detail_1.patient_ins_detail_instype=1 and patient_ins_detail_1.patient_ins_detail_isactive is true  left  join ins_comp_addr ins_comp_addr_1 on patient_ins_detail_1.patient_ins_detail_insaddressid = ins_comp_addr_1.ins_comp_addr_id   left  join ins_company ins_company_1 on ins_comp_addr_1.ins_comp_addr_inscompany_id = ins_company_1.ins_company_id  left  join patient_ins_detail patient_ins_detail_2 on patient_registration_id = patient_ins_detail_2.patient_ins_detail_patientid and patient_ins_detail_2.patient_ins_detail_instype=2 and patient_ins_detail_2.patient_ins_detail_isactive is true  left  join ins_comp_addr ins_comp_addr_2 on patient_ins_detail_2.patient_ins_detail_insaddressid = ins_comp_addr_2.ins_comp_addr_id  where patient_registration_id = "+p_Id+"limit 1");//,ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY
	 			if(rst.next()){	
	 			pos_Id        = rst.getString("pos");
	 			doctor_Id  = rst.getString("pri_doctor");
	 			refdoc_Id = rst.getString("ref_physician");
	 			}
	 			rst.close();
	          }
	          
	          ptdob= HUtil.Nz(dbutils.newTableLookUp("glace_timezone(patient_registration_dob,'"+TZContext.getLocaltimeZone()+"','"+TZContext.getDbFullPattern()+"')","patient_registration","patient_registration_id="+p_Id),"01/01/1900");
	          int includeDefaultBillingDoc=Integer.parseInt(HUtil.Nz(dbutils.newTableLookUp("initial_settings_option_value","initial_settings","initial_settings_option_name_desc ilike '%Needed Default Billing Doctor%'"),"0"));
	          if(includeDefaultBillingDoc==1)
	          {
	          Vector rs1=dbutils.executeQueryToVector("select max(initial_settings_option_value) from initial_settings where initial_settings_option_name ilike 'Default Billing Doctor'");
	          if(rs1.size()!=0)
	          {
	          		Vector pp=(Vector)rs1.get(0);
	              	billing_doctor=(String)pp.get(0);
	          }
	          else
	          {
	          		billing_doctor=doctor_Id;
	          }
	          }
	          
	          if(billing_doctor.equals("-1") || billing_doctor.equals("-2") || billing_doctor.equals("") || billing_doctor.equals("0"))
	          	billing_doctor=doctor_Id;
	          
	 	   }
	        catch(Exception e)
	 	   {
	        	GlaceOutLoggingStream.console("Exception In NewServiceAction" + e);
	 		
	 	   }
	        
	        String logInDoctor;
	        if(request.getSession(false).getAttribute("loadLogInDoctor")==null)
			{
	        	logInDoctor=HUtil.Nz(dbutils.newTableLookUp("initial_settings_option_value","initial_settings","initial_settings_option_name ilike 'Log In Doctor ?'"),"-1");
			request.getSession(false).setAttribute("enablevalidator", logInDoctor);
			}
			else
				logInDoctor=request.getSession(false).getAttribute("loadLogInDoctor").toString();
	        
	        if(logInDoctor.equals("1"))
	        {
	        	String userId =(String)request.getSession(false).getAttribute("userId");
	        	String userType=HUtil.Nz(dbutils.newTableLookUp("emp_profile_groupid","emp_profile","emp_profile_empid="+userId),"0");
	        	if(userType.equals("-1"))
	        	{
	        		doctor_Id=userId;
	        		billing_doctor=userId;
	        	}
	        	else
	        	{
	        		doctor_Id="-1";
	        		billing_doctor="-1";
	        	}
	        }
	        String codingSystem = HUtil.Nz(dbutils.newTableLookUp("initial_settings_option_value", "initial_settings", "initial_settings_option_name_desc='Problem list Coding System'"),"1");
		
	        JSONObject jobj=new JSONObject();
	        if(eDate.equalsIgnoreCase(""))
	        	eDate=(String)dbutils.newTableLookUp("to_mmddyyyy(now()::date)");
			jobj.put("dop",eDate);
			jobj.put("pos",pos_Id);
			jobj.put("sdoc",doctor_Id);
			jobj.put("bdoc",billing_doctor);
			jobj.put("rdoc",refdoc_Id);
			jobj.put("pins",p_Ins_Id);
			jobj.put("sins",s_Ins_Id);
			jobj.put("thirdinsid",t_Ins_Id);
			jobj.put("encounterId",""+encounterId);
			jobj.put("group_id",group_id);
			jobj.put("plan_type",plan_type);
			jobj.put("contextpath",request.getContextPath());
			jobj.put("accountID",request.getSession(false).getAttribute("accountID").toString());
			jobj.put("ptdob",ptdob);
			jobj.put("fullcontextpath", request.getScheme()+"://"+request.getServerName()+":"+request.getServerPort()+request.getContextPath());
			jobj.put("practicename",request.getSession(false).getAttribute("practiceName"));
			jobj.put("defaultDxCodeSystem", codingSystem);
			String allowLocalValidation;
			if(request.getSession(false).getAttribute("enablevalidator")==null)
			{
			 allowLocalValidation=HUtil.Nz(dbutils.newTableLookUp("initial_settings_option_value","initial_settings","initial_settings_option_name ilike 'Perform Local Validation ?'"),"-1");
			request.getSession(false).setAttribute("enablevalidator", allowLocalValidation);
			}
			else
				allowLocalValidation=request.getSession(false).getAttribute("enablevalidator").toString();
			jobj.put("allowLocalValidation", allowLocalValidation);
			
			String allowDoctorCombination;
			if(request.getSession(false).getAttribute("enabledoccombination")==null)
			{
				allowDoctorCombination=HUtil.Nz(dbutils.newTableLookUp("initial_settings_option_value","initial_settings","initial_settings_option_name ilike 'Check Dr. Combination ?'"),"-1");
			request.getSession(false).setAttribute("enabledoccombination", allowDoctorCombination);
			}
			else
				allowDoctorCombination=request.getSession(false).getAttribute("enabledoccombination").toString();
			jobj.put("allowDoctorCombination", allowDoctorCombination);
			
			String allowSBDoctorCombination="";
			if(request.getSession(false).getAttribute("allowSBDoctorCombination")==null){
				allowSBDoctorCombination=HUtil.Nz(dbutils.newTableLookUp("initial_settings_option_value","initial_settings","initial_settings_option_name='Service & Billing doctor combination'"),"-1");
				request.getSession(false).setAttribute("allowSBDoctorCombination", allowSBDoctorCombination);
			}else{
				allowSBDoctorCombination=request.getSession(false).getAttribute("allowSBDoctorCombination").toString();
			}
			jobj.put("allowSBDoctorCombination", allowSBDoctorCombination);
			
			String defaultBillingReason;
			if(request.getSession(false).getAttribute("defaultBillingReason")==null)
			{
				defaultBillingReason=HUtil.Nz(dbutils.newTableLookUp("initial_settings_option_value","initial_settings","initial_settings_option_name = 'Default Billing Reason'"),"-1");
			request.getSession(false).setAttribute("defaultBillingReason", defaultBillingReason);
			}
			else
				defaultBillingReason=request.getSession(false).getAttribute("defaultBillingReason").toString();
			jobj.put("defaultBillingReason", defaultBillingReason);
			
			
			String defaultNoOfLines;
			if(request.getSession(false).getAttribute("defaultNoOfLines")==null)
			{
				defaultNoOfLines=HUtil.Nz(dbutils.newTableLookUp("initial_settings_option_value","initial_settings","initial_settings_option_name = 'No Of Lines'"),"15");
			request.getSession(false).setAttribute("defaultNoOfLines", defaultNoOfLines);
			}
			else
				defaultNoOfLines=request.getSession(false).getAttribute("defaultNoOfLines").toString();
			jobj.put("defaultNoOfLines", defaultNoOfLines);
			
			String paymentGroupOption;
			if(request.getSession(false).getAttribute("paymentGroupOption")==null)
			{
				paymentGroupOption=HUtil.Nz(dbutils.newTableLookUp("initial_settings_option_value","initial_settings","initial_settings_option_name = 'Payment Group'"),"0");
			request.getSession(false).setAttribute("paymentGroupOption", paymentGroupOption);
			}
			else
				paymentGroupOption=request.getSession(false).getAttribute("paymentGroupOption").toString();
			jobj.put("paymentGroupOption", paymentGroupOption);
			
			String loadCPTPickerAtStartUp;
			if(request.getSession(false).getAttribute("loadCPTPickerAtStartUp")==null)
			{
				loadCPTPickerAtStartUp=HUtil.Nz(dbutils.newTableLookUp("initial_settings_option_value","initial_settings","initial_settings_option_name = 'Auto Cpt Picker ?'"),"0");
			request.getSession(false).setAttribute("loadCPTPickerAtStartUp", loadCPTPickerAtStartUp);
			}
			else
				loadCPTPickerAtStartUp=request.getSession(false).getAttribute("loadCPTPickerAtStartUp").toString();
			jobj.put("loadCPTPickerAtStartUp", loadCPTPickerAtStartUp);
			
			String isReferringPicker;
			if(request.getSession(false).getAttribute("isReferringPicker")==null)
			{
				isReferringPicker=HUtil.Nz(dbutils.newTableLookUp("initial_settings_option_value","initial_settings","initial_settings_option_name = 'Referring Doctor Picker ?'"),"0");
			request.getSession(false).setAttribute("isReferringPicker", isReferringPicker);
			}
			else
				isReferringPicker=request.getSession(false).getAttribute("isReferringPicker").toString();
			jobj.put("isReferringPicker", isReferringPicker);
			 jarray=new JSONArray();
			 GlaceOutLoggingStream.console("QQQ "+jarray.toString());
			 jarray.put(jobj);
		}
		
		if(action == 5)
		{
			String patientId = HUtil.Nz(request.getParameter("patientId"),"");
			String isSelfPay = HUtil.Nz(request.getParameter("isSelfPay"),"0");
			String dos = HUtil.Nz(request.getParameter("dos"),"");
			StringBuffer query=new StringBuffer();
			query.append("select sum(coalesce(receipt_detail_receipt_amt,0))-sum(coalesce(k.pay,0)+coalesce(receipt_detail_refund_amount,0)+coalesce(receipt_detail_writeoff_amount,0)) as amt "); 
			query.append("from receipt_detail ");
			query.append("left join ( ");
			query.append("select non_service_detail_check_id as pid,sum(coalesce(non_service_detail_amount,0)) as pay from non_service_detail "); 
			query.append("inner join receipt_detail on receipt_detail_id=non_service_detail_check_id and  receipt_detail_payer_id=").append(patientId);
			if(isSelfPay.equals("0"))
			 query.append(" and receipt_detail_is_copay is true ");
			query.append(" and receipt_detail_payer_type=1 ");
			query.append(" and receipt_detail_deposit_date='").append(dos).append("'::date ");
			query.append("inner  join cpt on cpt_id = non_service_detail_payment_cpt_id where  ( cpt_cpttype = 2 or  cpt_cpttype = 3 or cpt_cpttype = 8 or cpt_cpttype = 12 ) ");
			query.append("group by non_service_detail_check_id )k on k.pid=receipt_detail_id where receipt_detail_payer_type=1");
			if(isSelfPay.equals("0"))
			query.append(" and receipt_detail_is_copay is true ");
			query.append("and receipt_detail_payer_id=").append(patientId).append(" and receipt_detail_deposit_date='").append(dos).append("'::date ");

			GlaceOutLoggingStream.console("CREDIT Q >>>> "+query.toString());
			JSONObject jobj=new JSONObject();
			jobj.put("creditamt",dbutils.executeQueryToJSONArray(query.toString(),true).toString());
			 jarray=new JSONArray();
			 jarray.put(jobj);
			
		}
		if(action == 6)
		{
			String patientId = HUtil.Nz(request.getParameter("patientId"),"");
			String dos = HUtil.Nz(request.getParameter("dos"),"");
			String isSelfPay = HUtil.Nz(request.getParameter("isSelfPay"),"0");
			StringBuffer query=new StringBuffer();
			query.append("select receipt_detail_id as checkid,sum(coalesce(receipt_detail_receipt_amt,0)-(coalesce(receipt_detail_refund_amount,0)+coalesce(receipt_detail_writeoff_amount,0))) as amt,sum(coalesce(k.pay,0)) as applied,sum(coalesce(receipt_detail_receipt_amt,0))-sum(coalesce(k.pay,0)+coalesce(receipt_detail_refund_amount,0)+coalesce(receipt_detail_writeoff_amount,0)) as bal "); 
			query.append("from receipt_detail ");
			query.append("left join ( ");
			query.append("select non_service_detail_check_id as pid,sum(coalesce(non_service_detail_amount,0)) as pay from non_service_detail "); 
			query.append("inner join receipt_detail on receipt_detail_id=non_service_detail_check_id and  receipt_detail_payer_id=").append(patientId);
			if(isSelfPay.equals("0"))
			 query.append(" and receipt_detail_is_copay is true ");
			query.append(" and receipt_detail_payer_type=1 ");
			if(isSelfPay.equals("0"))
			 query.append(" and receipt_detail_deposit_date='").append(dos).append("'::date ");
			query.append(" inner  join cpt on cpt_id = non_service_detail_payment_cpt_id where  ( cpt_cpttype = 2 or  cpt_cpttype = 3 or cpt_cpttype = 8 or cpt_cpttype = 12 ) ");
			query.append(" group by non_service_detail_check_id )k on k.pid=receipt_detail_id where receipt_detail_payer_type=1");
			if(isSelfPay.equals("0"))
			 query.append(" and receipt_detail_is_copay is true ");
			query.append(" and receipt_detail_payer_id=").append(patientId);
			if(isSelfPay.equals("0"))
			 query.append(" and receipt_detail_deposit_date='").append(dos).append("'::date ");
			
			if(isSelfPay.equals("1"))
			 query.append("and coalesce(receipt_detail_receipt_amt,0) - (coalesce(k.pay,0)+coalesce(receipt_detail_refund_amount,0)+coalesce(receipt_detail_writeoff_amount,0)) >0 ");
			query.append(" group by receipt_detail_id order by 4 desc");

			GlaceOutLoggingStream.console("CREDIT Q >>>> "+query.toString());
			JSONObject jobj=new JSONObject();
			jobj.put("creditdetail",dbutils.executeQueryToJSONArray(query.toString(),true).toString());
			 jarray=new JSONArray();
			 jarray.put(jobj);
			
		}
		
		if(action == 7)
		{
			String patientId = HUtil.Nz(request.getParameter("patientId"),"");
			String dos = HUtil.Nz(request.getParameter("dos"),"");
			String payment_method=HUtil.Nz(request.getParameter("payment_method"),"-1");
			String check_no=HUtil.Nz(request.getParameter("check_no"),"");
			String check_date=HUtil.Nz(request.getParameter("check_date"),"");
			String amount=HUtil.Nz(request.getParameter("amount"),"0.00");
			String iscopay=HUtil.Nz(request.getParameter("iscopay"),"");
			String payment_reason=HUtil.Nz(request.getParameter("payment_reason"),"");
			EOBPostingDAO newPosting=new EOBPostingDAO(dbutils);
			boolean is_copay=true;
			if(iscopay.equals("false"))
				is_copay=false;
			String depoid=newPosting.createPosting(check_no, dos,
					Integer.parseInt(patientId), Double.parseDouble(amount), 0.00, user,
					false, "",payment_reason,1,Integer.parseInt(payment_method),
					is_copay,-1,-1,-1,
					-1,-1,-1,"Service Screen",
					dos, user,1, Integer.parseInt(patientId),payment_reason,check_date,0.00,true,-1);
											
			JSONObject jobj=new JSONObject();
			if(Integer.parseInt(depoid)> 0){
				jobj.put("deposit_result","true");
				jobj.put("checkid",depoid);
				jobj.put("amount",amount);
				jobj.put("iscopay",is_copay);
				
			}
			else
				jobj.put("deposit_result","false");
			 jarray=new JSONArray();
			 jarray.put(jobj);
			
		}
		
		if(action == 8)
		{
			String patientId = HUtil.Nz(request.getParameter("patientId"),"-1");
			String lastDos=HUtil.Nz(dbutils.newTableLookUp("to_mmddyyyy(max(service_detail_dos))","service_detail inner join cpt on cpt_id= service_detail_cptid and cpt_cpttype=1","service_detail_patientid="+patientId+" and service_detail_dos<now()::date"), "01/01/1900");
			StringBuilder prevSerQ=new StringBuilder();
			prevSerQ.append("select cpt_cptcode as cpt,coalesce(service_detail_dx1,'') as dx1,coalesce(service_detail_dx2,'') as dx2,coalesce(service_detail_dx3,'') as dx3,coalesce(service_detail_dx4,'') as dx4 ,coalesce(service_detail_modifier1,'') as modifier1,coalesce(service_detail_modifier2,'') as modifier2,coalesce(service_detail_modifier3,'') as modifier3,coalesce(service_detail_modifier4,'') as modifier4 ");
			prevSerQ.append("from service_detail inner join cpt on cpt_id= service_detail_cptid and cpt_cpttype=1 and cpt_cptcode not in ('INSXS','PTSXS','INT00','CNT00','REFRQ') ");
			prevSerQ.append("where service_detail_patientid=").append(patientId).append(" and service_detail_dos='").append(lastDos).append("'::date ");
			JSONObject jobj=new JSONObject();
			GlaceOutLoggingStream.console(prevSerQ);
			JSONArray result = dbutils.executeQueryToJSONArray(prevSerQ.toString(),true);
			jobj.put("prev_service_result",result.toString());
			Set<String> dxSet=new LinkedHashSet<String>();
			StringBuilder dxString=new StringBuilder();
			for(int i=0;i<result.length();i++){
				if(!result.getJSONObject(i).getString("dx1").equals(""))
					dxSet.add(result.getJSONObject(i).getString("dx1"));
				if(!result.getJSONObject(i).getString("dx2").equals(""))
					dxSet.add(result.getJSONObject(i).getString("dx2"));
				if(!result.getJSONObject(i).getString("dx3").equals(""))
					dxSet.add(result.getJSONObject(i).getString("dx3"));
				if(!result.getJSONObject(i).getString("dx4").equals(""))
					dxSet.add(result.getJSONObject(i).getString("dx4"));
			}
			Iterator<String> it=dxSet.iterator();
			while(it.hasNext()){
				dxString.append("'").append(it.next().toString()).append("',");
			}
			dxString.append("''");
			JSONArray dxResult = dbutils.executeQueryToJSONArray("select icdm_icdcode as dx,icdm_description as description from icdm where icdm_icdcode in ("+dxString+")",true);
			jobj.put("prev_service_result_dx_description",dxResult.toString());
			jarray=new JSONArray();
			jarray.put(jobj);
			
		}
		if(action == 9)
		{
			String groupId = HUtil.Nz(request.getParameter("groupId"),"-1");
			StringBuilder cptGroupDetail=new StringBuilder();
			cptGroupDetail.append("select coalesce(cpt,'') as cpt,coalesce(dx1,'') as dx1,coalesce(dx2,'') as dx2,coalesce(dx3,'') as dx3,coalesce(dx4,'') as dx4,'' as modifier1,'' as modifier2,'' as modifier3,'' as modifier4 from service_cpt_group_detail where cptgroupid=").append(groupId);
			JSONObject jobj=new JSONObject();
			GlaceOutLoggingStream.console(cptGroupDetail);
			JSONArray result = dbutils.executeQueryToJSONArray(cptGroupDetail.toString(),true);
			jobj.put("cpt_group",result.toString());
			Set<String> dxSet=new LinkedHashSet<String>();
			StringBuilder dxString=new StringBuilder();
			for(int i=0;i<result.length();i++){
				if(!result.getJSONObject(i).getString("dx1").equals(""))
					dxSet.add(result.getJSONObject(i).getString("dx1"));
				if(!result.getJSONObject(i).getString("dx2").equals(""))
					dxSet.add(result.getJSONObject(i).getString("dx2"));
				if(!result.getJSONObject(i).getString("dx3").equals(""))
					dxSet.add(result.getJSONObject(i).getString("dx3"));
				if(!result.getJSONObject(i).getString("dx4").equals(""))
					dxSet.add(result.getJSONObject(i).getString("dx4"));
			}
			Iterator<String> it=dxSet.iterator();
			while(it.hasNext()){
				dxString.append("'").append(it.next().toString()).append("',");
			}
			dxString.append("''");
			JSONArray dxResult = dbutils.executeQueryToJSONArray("select icdm_icdcode as dx,icdm_description as description from icdm where icdm_icdcode in ("+dxString+")",true);
			jobj.put("cpt_group_dx_description",dxResult.toString());
			jarray=new JSONArray();
			jarray.put(jobj);
			
		}
		if(action == 10)
		{
			String serviceId = HUtil.Nz(request.getParameter("serviceId"),"-1");
			String patientId = HUtil.Nz(request.getParameter("patientId"),"-1");
			String cost= HUtil.Nz(request.getParameter("cost"),"0.00");
			String cpt= HUtil.Nz(request.getParameter("cpt"),"");
			String unit= HUtil.Nz(request.getParameter("unit"),"0");
			String copay = HUtil.Nz(request.getParameter("copay"),"0");
			String commentCPTId=HUtil.Nz(dbutils.newTableLookUp("cpt_id","cpt","cpt_cptcode ilike '00COM'"), "-1");
			StringBuilder commentStr=new StringBuilder();
			commentStr.append("CPT : ").append(cpt).append(" Unit : ").append(unit).append(" Cost : ").append(cost).append(" copay : ").append(copay);
			String payment =HUtil.Nz(dbutils.newTableLookUp("coalesce(sum(coalesce(non_service_detail_amount,0)),0)","non_service_detail inner join cpt on cpt_id=non_service_detail_payment_cpt_id","cpt_cpttype in (2,3,8) and non_service_detail_service_id="+serviceId), "0.00");
			String status="0";
			if(!commentCPTId.equals("-1") && Double.parseDouble(payment)==0){
				StringBuilder updateQ=new StringBuilder();
				updateQ.append("update service_detail set service_detail_submit_status='X',service_detail_charges=0,service_detail_copay=0,service_detail_unknown2=0,service_detail_expected_payments=0,service_detail_cptid=").append(commentCPTId); //Making Copay and Allowed amount columns to zero as the service is deleted from EMR Super bill tab. Issue raised as PT Balance was showing wrong 
				updateQ.append(",service_detail_comments='").append(commentStr.toString()).append("' where service_detail_id=").append(serviceId);
				try{
				dbutils.executeUpdate(updateQ.toString());
				status="0";
				EventLog.LogEvent(AuditTrail.GLACE_LOG , AuditTrail.Service , AuditTrail.UPDATE , -1,AuditTrail.SUCCESS,"Service deleted",Integer.parseInt(request.getSession(false).getAttribute("loginId").toString()),request.getRemoteUser(),request.getRemoteAddr(),Integer.parseInt(patientId),-1,-1,AuditTrail.USER_LOGIN,request,dbutils,"Service deleted. "+commentStr.toString());
				}
				catch(Exception e){
					EventLog.LogEvent(AuditTrail.GLACE_LOG , AuditTrail.Service , AuditTrail.UPDATE , -1,AuditTrail.FAILURE,"Service deleted",Integer.parseInt(request.getSession(false).getAttribute("loginId").toString()),request.getRemoteUser(),request.getRemoteAddr(),Integer.parseInt(patientId),-1,-1,AuditTrail.USER_LOGIN,request,dbutils,"Service deleted. "+commentStr.toString());
					e.printStackTrace();
					status="3";
				}
			}else if(Double.parseDouble(payment)!=0)
				status="1";
			else if(commentCPTId.equals("-1"))
				status="2";
			else
				status="3";
			GlaceOutLoggingStream.console("Service Deletion Status >>>  "+status);
			JSONObject jobj=new JSONObject();
			jobj.put("status",status);
			jarray=new JSONArray();
			jarray.put(jobj);
			
		}
		if(action == 11){
			String encounterIdGWT=request.getParameter("encounterIdGWT");
			String patientId = HUtil.Nz(request.getParameter("patientId"),"-1");
			String dos = HUtil.Nz(request.getParameter("dos"),"01/01/1900");
			JSONObject jobj=new JSONObject();
			JSONArray dxResult=new JSONArray();
			JSONArray dxResultDesc=new JSONArray();
			String encounterId = "";
			if(encounterIdGWT == null)
				encounterId = HUtil.Nz(dbutils.newTableLookUp("max(encounter_id)","encounter inner join chart on encounter_chartid=chart_id","chart_patientid="+patientId+" and encounter_date::date='"+dos+"'::date"), "-1");
			else
				encounterId = encounterIdGWT;
			GlaceOutLoggingStream.console(" Encounter ID >>>  "+encounterId);
			if(Integer.parseInt(encounterId) > 0){
				dxResult = dbutils.executeQueryToJSONArray("select patient_assessments_id as dxId,patient_assessments_dxdescription as desc,  case when coalesce(patient_assessments_dxcode,'')='' then substr(patient_assessments_dxdescription,0,10) else coalesce(patient_assessments_dxcode,'') end as dxcode,patient_assessments_coding_systemid as codesystemid from patient_assessments where patient_assessments_isactive is false and patient_assessments_encounterid = " + encounterId + " and patient_assessments_patientId = " + patientId +"order by patient_assessments_dxorder asc ",true);
				GlaceOutLoggingStream.console("Dx >>>   "+dxResult.toString());
				jobj.put("assessment_dx",dxResult.toString());
				Set<String> dxSet=new LinkedHashSet<String>();
				StringBuilder dxString=new StringBuilder();
				for(int i=0;i<dxResult.length();i++){
					if(!dxResult.getJSONObject(i).getString("dxcode").equals(""))
						dxSet.add(dxResult.getJSONObject(i).getString("dxcode").trim());
				}
				Iterator<String> it=dxSet.iterator();
				while(it.hasNext()){
					dxString.append("'").append(it.next().toString()).append("',");
				}
				dxString.append("''");
				GlaceOutLoggingStream.console("select icdm_icdcode as dx,icdm_description as description from icdm where icdm_icdcode in ("+dxString+")");
				dxResultDesc = dbutils.executeQueryToJSONArray("select icdm_icdcode as dx,icdm_description as description from icdm where icdm_icdcode in ("+dxString+")",true);
				GlaceOutLoggingStream.console(" Description >>>  "+dxResultDesc.toString());
				jobj.put("assessment_dx_description",dxResultDesc.toString());
			}
			jobj.put("assessment_dx",dxResult.toString());
			jobj.put("assessment_dx_description",dxResultDesc.toString());
			String assessment_dx_codesystem=HUtil.Nz(dbutils.newTableLookUp("patient_assessments_coding_systemid","patient_assessments","patient_assessments_isactive is false and patient_assessments_encounterid = " + encounterId + " and patient_assessments_patientId = " + patientId +""),"");
			jobj.put("dxcodesystem",assessment_dx_codesystem);
			jarray=new JSONArray();
			jarray.put(jobj);
		 }
		if(action == 12){
			String patientId = HUtil.Nz(request.getParameter("patientId"),"-1");
			String dos = HUtil.Nz(request.getParameter("dos"),"01/01/1900");
			JSONObject jobj=new JSONObject();
			PrescriptionModel pModel =new PrescriptionModel();
			int status=pModel.ePrescriptionReport(dbutils, Integer.parseInt(patientId), dos);
			jobj.put("gcodes",status+"");
				jarray=new JSONArray();
			jarray.put(jobj);
		}
		if(action == 13){
			String patientId = HUtil.Nz(request.getParameter("patientId"),"-1");
			StringBuilder query=new StringBuilder();
			query.append("select upper(coalesce(patient_registration_address1,'')) as address,upper(coalesce(patient_registration_city,'')) as city,upper(coalesce(billing_config_table_lookup_desc,'')) as state,upper(coalesce(patient_registration_zip,'')) as zip,");

			query.append("glace_timezone(patient_registration_last_modified_date,'"+TZContext.getLocaltimeZone()+"','"+TZContext.getDbFullPattern()+"') as insertedon,");
			query.append("trim(upper(coalesce(emp_profile_lname,''))||', '||upper(coalesce(emp_profile_fname,''))||' '||coalesce(upper(emp_profile_mi),'')||' '||coalesce(upper(emp_profile_credentials),''),'') as modifiedby,patient_registration_address_start_date as startdate ");
			query.append("from patient_registration_data_backup inner join billing_config_table on patient_registration_state::integer=billing_config_table_config_id "); 
			query.append("and billing_config_table_lookup_id=5001 ");
			query.append("inner join emp_profile on emp_profile_empid=patient_registration_last_modified_by ");
			query.append("where patient_registration_id=").append(patientId).append(" and coalesce(patient_registration_address_start_date,'01/01/1900')<>'01/01/1900' and historyflag ilike '_1%'");
			query.append(" order by patient_registration_last_modified_date desc");
						
			JSONObject jobj=new JSONObject();
			GlaceOutLoggingStream.console(query.toString());
			JSONArray dxResult = dbutils.executeQueryToJSONArray(query.toString(),true);
			jobj.put("addresslog",dxResult.toString());
			
			StringBuilder queryCurrent=new StringBuilder();
			queryCurrent.append("select upper(coalesce(patient_registration_address1,'')) as address,upper(coalesce(patient_registration_city,'')) as city,upper(coalesce(billing_config_table_lookup_desc,'')) as state,upper(coalesce(patient_registration_zip,'')) as zip,");
			queryCurrent.append("glace_timezone(patient_registration_last_modified_date,'"+TZContext.getLocaltimeZone()+"','"+TZContext.getDbFullPattern()+"') as insertedon,");
			queryCurrent.append("trim(upper(coalesce(emp_profile_lname,''))||', '||upper(coalesce(emp_profile_fname,''))||' '||coalesce(upper(emp_profile_mi),'')||' '||coalesce(upper(emp_profile_credentials),''),'') as modifiedby,patient_registration_address_start_date as startdate ");
			queryCurrent.append("from patient_registration inner join billing_config_table on patient_registration_state::integer=billing_config_table_config_id ");
			queryCurrent.append("and billing_config_table_lookup_id=5001 ");
			queryCurrent.append("inner join emp_profile on emp_profile_empid=patient_registration_last_modified_by ");
			queryCurrent.append("where patient_registration_id=").append(patientId).append(" order by patient_registration_last_modified_date desc");
			
			JSONArray dxResultCurrent=dbutils.executeQueryToJSONArray(queryCurrent.toString(),true);
			jobj.put("addresslogcurrent",dxResultCurrent.toString());
			
			jarray=new JSONArray();
			jarray.put(jobj);
		}
		if(action == 14){
			String patientId = HUtil.Nz(request.getParameter("patientId"),"-1");
			StringBuilder query=new StringBuilder();
			query.append("select upper(coalesce(patient_registration_last_name,'')) as lastname,upper(coalesce(patient_registration_first_name,'')) as firstname,upper(coalesce(patient_registration_mid_initial,'')) as middlename ,");
			query.append("glace_timezone(patient_registration_last_modified_date,'"+TZContext.getLocaltimeZone()+"','"+TZContext.getDbFullPattern()+"') as insertedon,");

			query.append("trim(upper(coalesce(emp_profile_lname,''))||', '||upper(coalesce(emp_profile_fname,''))||' '||coalesce(upper(emp_profile_mi),'')||' '||coalesce(upper(emp_profile_credentials),''),'') as modifiedby ");
			query.append("from patient_registration_data_backup "); 
			query.append("inner join emp_profile on emp_profile_empid=patient_registration_last_modified_by ");
			query.append("where patient_registration_id=").append(patientId).append(" and historyflag ilike '1%'");
			query.append(" order by patient_registration_last_modified_date desc");
	
			JSONObject jobj=new JSONObject();
			JSONArray dxResult = dbutils.executeQueryToJSONArray(query.toString(),true);
			jobj.put("namelog",dxResult.toString());
		
			StringBuilder queryCurrent=new StringBuilder();
			queryCurrent.append("select upper(coalesce(patient_registration_last_name,'')) as lastname,upper(coalesce(patient_registration_first_name,'')) as firstname,upper(coalesce(patient_registration_mid_initial,'')) as middlename ,");
			queryCurrent.append("glace_timezone(patient_registration_last_modified_date,'"+TZContext.getLocaltimeZone()+"','"+TZContext.getDbFullPattern()+"') as insertedon,");

			queryCurrent.append("trim(upper(coalesce(emp_profile_lname,''))||', '||upper(coalesce(emp_profile_fname,''))||' '||coalesce(upper(emp_profile_mi),'')||' '||coalesce(upper(emp_profile_credentials),''),'') as modifiedby ");
			queryCurrent.append("from patient_registration "); 
			queryCurrent.append("inner join emp_profile on emp_profile_empid=patient_registration_last_modified_by ");
			queryCurrent.append("where patient_registration_id=").append(patientId).append(" order by patient_registration_last_modified_date desc");
			
			JSONArray dxResultCurrent=dbutils.executeQueryToJSONArray(queryCurrent.toString(),true);
			jobj.put("namelogcurrent",dxResultCurrent.toString());
			
			
			jarray=new JSONArray();
			jarray.put(jobj);
		}
		if(action == 15){
			String patientId = HUtil.Nz(request.getParameter("patientId"),"-1");
			StringBuilder query=new StringBuilder();
			query.append("select  formatphoneno(coalesce(replace(patient_registration_phone_no,'-',''),'')) as homephone, formatphoneno(coalesce(replace(patient_registration_work_no,'-',''),'')) as workphone, formatphoneno(coalesce(replace(patient_registration_cellno,'-',''),'')) as cellphone ,");
			query.append("coalesce(patient_registration_mail_id,'') as email,");
			query.append("glace_timezone(patient_registration_last_modified_date,'"+TZContext.getLocaltimeZone()+"','"+TZContext.getDbFullPattern()+"') as insertedon,");

			query.append("trim(upper(coalesce(emp_profile_lname,''))||', '||upper(coalesce(emp_profile_fname,''))||' '||coalesce(upper(emp_profile_mi),'')||' '||coalesce(upper(emp_profile_credentials),''),'') as modifiedby ");
			query.append("from patient_registration_data_backup "); 
			query.append("inner join emp_profile on emp_profile_empid=patient_registration_last_modified_by ");
			query.append("where patient_registration_id=").append(patientId).append(" and historyflag ilike '__1%'");
			query.append(" order by patient_registration_last_modified_date desc");
			
			JSONObject jobj=new JSONObject();
			JSONArray dxResult = dbutils.executeQueryToJSONArray(query.toString(),true);
			jobj.put("contactdetailslog",dxResult.toString());
			
			StringBuilder queryCurrent=new StringBuilder();
			queryCurrent.append("select formatphoneno(coalesce(replace(patient_registration_phone_no,'-',''),'')) as homephone, formatphoneno(coalesce(replace(patient_registration_work_no,'-',''),''))as workphone, formatphoneno(coalesce(replace(patient_registration_cellno,'-',''),''))as cellphone ,");
			queryCurrent.append("coalesce(patient_registration_mail_id,'') as email,");
			queryCurrent.append("glace_timezone(patient_registration_last_modified_date,'"+TZContext.getLocaltimeZone()+"','"+TZContext.getDbFullPattern()+"') as insertedon,");

			queryCurrent.append("trim(upper(coalesce(emp_profile_lname,''))||', '||upper(coalesce(emp_profile_fname,''))||' '||coalesce(upper(emp_profile_mi),'')||' '||coalesce(upper(emp_profile_credentials),''),'') as modifiedby ");
			queryCurrent.append("from patient_registration "); 
			queryCurrent.append("inner join emp_profile on emp_profile_empid=patient_registration_last_modified_by ");
			queryCurrent.append("where patient_registration_id=").append(patientId);
			JSONArray dxResultCurrent=dbutils.executeQueryToJSONArray(queryCurrent.toString(),true);
			jobj.put("contactdetailslogcurrent",dxResultCurrent.toString());
			jarray=new JSONArray();
			jarray.put(jobj);
		}
		if(action == 16){
        	boolean cptFound = false;
            String cptCode = null;
        	cptCode = HUtil.Nz(request.getParameter("cptCode"),"");
        	if(cptCode.length()>0){
        		cptFound = dbutils.tableCheckUp("cpt_id", "cpt", "cpt_cptcode ilike '"+cptCode+"'");
        		GlaceOutLoggingStream.console("cptFound---->"+cptFound);
        	}
        	JSONObject retunnData=new JSONObject();
    		retunnData.put("iscptfound",(cptFound)?1:0);
    		jarray=new JSONArray();
    		jarray.put(retunnData);
		}
		if(action == 17){
            String scdata = HUtil.Nz(request.getParameter("scdata"),"");
            String scname = HUtil.Nz(request.getParameter("scname"),"");
            boolean isActive = Boolean.parseBoolean(HUtil.Nz(request.getParameter("isactive"),"false"));
            String mkActive = HUtil.Nz(request.getParameter("mkActive"),"0");
            int isLoad = Integer.parseInt(HUtil.Nz(request.getParameter("isload"),"0"));
            long shortcutid = Long.parseLong(HUtil.Nz(request.getParameter("shortcutid"),"-1"));
            StringBuilder qryStr = new StringBuilder();
            if(shortcutid == -1){
            	qryStr.append("insert into quickcptgroup values ( ")
            		.append(" (select coalesce(max(quickcptgroup_id),0)+1 from quickcptgroup) ") 
	            	.append(",'"+scname+"'")
	            	.append(",'"+scdata+"'")
	            	.append(",'t'")
	            	.append(")");
            	shortcutid = dbutils.executeAndGetGeneretedKey(qryStr.toString(), "quickcptgroup_id");
            }else{
            	if(mkActive.equals("0")){
            	qryStr.append("update quickcptgroup set ")
            		.append(" quickcptgroup_name = '"+scname+"'")
            		.append(" ,quickcptgroup_cptcodes = '"+scdata+"'")
	            	.append(" where quickcptgroup_id="+shortcutid);
            	}else{
            		qryStr.append("update quickcptgroup set ")
            		.append(" quickcptgroup_isactive = '"+isActive+"'")
            		.append(" where quickcptgroup_id="+shortcutid);
            	}
            	dbutils.executeUpdate(qryStr.toString());
            }
            JSONArray updateddata=dbutils.executeQueryToDistinctJSONArray("select quickcptgroup_name as hsp002,quickcptgroup_cptcodes as hsp001,quickcptgroup_id as qcgid,quickcptgroup_isactive as isactive from quickcptgroup order by quickcptgroup_name", true);            
        	JSONObject retunnData=new JSONObject();
    		retunnData.put("shortcutid",shortcutid);
    		retunnData.put("isload",isLoad);
    		retunnData.put("updateddata",updateddata.toString());
    		jarray=new JSONArray();
    		jarray.put(retunnData);
		}
		if(action == 18){
			String patientId = HUtil.Nz(request.getParameter("patientId"),"-1");
			StringBuilder query=new StringBuilder();

			query.append(" select format_name(guarantor_first_name,guarantor_last_name,guarantor_middle_initial,'',1) as name,coalesce(blook_name) as relation,");
			query.append(" glace_timezone(guarantor_last_modifiedon,'"+TZContext.getLocaltimeZone()+"','"+TZContext.getDbFullPattern()+"') as insertedon,format_name(emp_profile_fname,emp_profile_lname,emp_profile_mi,'',1 )  as lastmodifiedby,upper(trim(coalesce(guarantor_address,''))) as address,upper(trim(coalesce(guarantor_city,''))||' '|| coalesce(billing_config_table_lookup_desc,'') ||' '||trim(coalesce(guarantor_zip,''))) as city,guarantor_relations_isguarantor as gflag ");
			query.append(" from guarantor_history inner join guarantor_relations on guarantor_key = guarantor_relations_guarantor_key  inner join billinglookup on  blook_intid = guarantor_relations_relation_id and blook_group =12  and  ghistory_flag = '1' and guarantor_relations_patient_id = "+patientId+" inner join emp_profile on emp_profile_empid = guarantor_last_modifiedby left join billing_config_table on trim(guarantor_state)=trim(billing_config_table_config_id::varchar) and billing_config_table_lookup_id=5001 order by guarantor_key,guarantor_last_modifiedon desc ");
			
			JSONObject jobj=new JSONObject();
			JSONArray relResult = dbutils.executeQueryToJSONArray(query.toString(),true);
			jobj.put("relationlog",relResult.toString());
			
			StringBuilder queryCurrent=new StringBuilder();
			
			queryCurrent.append(" select format_name(guarantor_first_name,guarantor_last_name,guarantor_middle_initial,'',1) as name,coalesce(blook_name) as relation,");
			queryCurrent.append(" glace_timezone(guarantor_last_modifiedon,'"+TZContext.getLocaltimeZone()+"','"+TZContext.getDbFullPattern()+"') as insertedon,format_name(emp_profile_fname,emp_profile_lname,emp_profile_mi,'',1 )  as lastmodifiedby,upper(trim(coalesce(guarantor_address,''))) as address,upper(trim(coalesce(guarantor_city,''))||' '|| coalesce(billing_config_table_lookup_desc,'') ||' '||trim(coalesce(guarantor_zip,''))) as city,guarantor_relations_isguarantor as gflag ");
			queryCurrent.append(" from guarantor inner join guarantor_relations on guarantor_key = guarantor_relations_guarantor_key  inner join billinglookup on  blook_intid = guarantor_relations_relation_id and blook_group =12   and guarantor_relations_patient_id = "+patientId+" inner join emp_profile on emp_profile_empid = guarantor_last_modifiedby left join billing_config_table on trim(guarantor_state)=trim(billing_config_table_config_id::varchar) and billing_config_table_lookup_id=5001 order by guarantor_last_modifiedon desc");
 
			
			JSONArray relResultCurrent=dbutils.executeQueryToJSONArray(queryCurrent.toString(),true);
			jobj.put("relationlogcurrent",relResultCurrent.toString());
			jarray=new JSONArray();
			jarray.put(jobj);
		}
		if(action == 19){
			String patientId = HUtil.Nz(request.getParameter("patientId"),"-1");
			StringBuilder query=new StringBuilder();
			query.append("select upper(coalesce(patient_registration_address2,'')) as address,upper(coalesce(patient_registration_city,'')) as city,upper(coalesce(billing_config_table_lookup_desc,'')) as state,upper(coalesce(patient_registration_zip,'')) as zip,");

			query.append("glace_timezone(patient_registration_last_modified_date,'"+TZContext.getLocaltimeZone()+"','"+TZContext.getDbFullPattern()+"') as insertedon,");
			query.append("trim(upper(coalesce(emp_profile_lname,''))||', '||upper(coalesce(emp_profile_fname,''))||' '||coalesce(upper(emp_profile_mi),'')||' '||coalesce(upper(emp_profile_credentials),''),'') as modifiedby ");
			query.append("from patient_registration_data_backup inner join billing_config_table on patient_registration_state::integer=billing_config_table_config_id "); 
			query.append("and billing_config_table_lookup_id=5001 ");
			query.append("inner join emp_profile on emp_profile_empid=patient_registration_last_modified_by ");
			query.append("where patient_registration_id=").append(patientId).append(" and historyflag ilike '_1%'");
			query.append(" order by patient_registration_last_modified_date desc");
						
			JSONObject jobj=new JSONObject();
			GlaceOutLoggingStream.console(query.toString());
			JSONArray dxResult = dbutils.executeQueryToJSONArray(query.toString(),true);
			jobj.put("addresslog",dxResult.toString());
			
			StringBuilder queryCurrent=new StringBuilder();
			queryCurrent.append("select upper(coalesce(patient_registration_address2,'')) as address,upper(coalesce(patient_registration_city,'')) as city,upper(coalesce(billing_config_table_lookup_desc,'')) as state,upper(coalesce(patient_registration_zip,'')) as zip,");
			queryCurrent.append("glace_timezone(patient_registration_last_modified_date,'"+TZContext.getLocaltimeZone()+"','"+TZContext.getDbFullPattern()+"') as insertedon,");
			queryCurrent.append("trim(upper(coalesce(emp_profile_lname,''))||', '||upper(coalesce(emp_profile_fname,''))||' '||coalesce(upper(emp_profile_mi),'')||' '||coalesce(upper(emp_profile_credentials),''),'') as modifiedby ");
			queryCurrent.append("from patient_registration inner join billing_config_table on patient_registration_state::integer=billing_config_table_config_id ");
			queryCurrent.append("and billing_config_table_lookup_id=5001 ");
			queryCurrent.append("inner join emp_profile on emp_profile_empid=patient_registration_last_modified_by ");
			queryCurrent.append("where patient_registration_id=").append(patientId).append(" order by patient_registration_last_modified_date desc");
			
			JSONArray dxResultCurrent=dbutils.executeQueryToJSONArray(queryCurrent.toString(),true);
			jobj.put("addresslogcurrent",dxResultCurrent.toString());
			
			jarray=new JSONArray();
			jarray.put(jobj);
		}
		/*if(mode==53){
			System.out.println("==== in mode 53");//patId
			JSONObject modifedJsonObj=new JSONObject(HUtil.Nz(request.getParameter("dataObject"),""));
			JSONArray modifiedArray=(JSONArray) modifedJsonObj.get("modifiedorder");
			String preOrderInfo=HUtil.Nz(request.getParameter("previousOrder"),"");
			String praName;
			String patId=HUtil.Nz(request.getParameter("patId"),"");
			try {
				for(int i=0;i<modifiedArray.length();i++){
					 JSONObject eachRecord=new JSONObject(modifiedArray.getString(i));
					 dbutils.executeUpdate("update service_detail set service_detail_order="+eachRecord.getString("orderid").trim()+" where service_detail_id="+eachRecord.getString("serviceid")); 
				}
				praName="Order Saved Successfully";
			EventLog.LogEvent(AuditTrail.GLACE_LOG , AuditTrail.Service , AuditTrail.UPDATE , -1,AuditTrail.SUCCESS,"Service order change",Integer.parseInt(request.getSession(false).getAttribute("loginId").toString()),request.getRemoteUser(),request.getRemoteAddr(),Integer.parseInt(patId),-1,-1,AuditTrail.USER_LOGIN,request,dbutils,"Service order changed:Previous[ "+preOrderInfo.toString()+"]::After::"+modifiedArray.toString());
			} catch (Exception e) {
				praName="Order Saving Fail";
			EventLog.LogEvent(AuditTrail.GLACE_LOG , AuditTrail.Service , AuditTrail.UPDATE , -1,AuditTrail.FAILURE,"Service order change",Integer.parseInt(request.getSession(false).getAttribute("loginId").toString()),request.getRemoteUser(),request.getRemoteAddr(),Integer.parseInt(patId),-1,-1,AuditTrail.USER_LOGIN,request,dbutils,"Service order failure case:Previous[ "+preOrderInfo.toString()+"]::After::"+modifiedArray.toString());
			}
			System.out.println("==== completion in mode 53");
		}*/
		else if(mode==36){
			String dosInfo=HUtil.Nz(request.getParameter("dosInfo"),"-1");
			System.out.println("dosInfo------------====="+dosInfo);
			String patientId=HUtil.Nz(request.getParameter("patientId"),"-1");
			StringBuilder queryString = new StringBuilder();
			queryString.append(" select service_detail_id as serviceId,service_detail_cptid as cptId,coalesce(service_detail_unit,1) as units,coalesce(service_detail_modifier1) as modifier1,coalesce(service_detail_charges,0.00) as charges,cpt_cptcode as cptcode,coalesce(service_detail_dx1,'') as dx1,service_detail_order as orderid, ");
			queryString.append(" submit_status_description as submitstatus,coalesce(cpt_short_cut_desc,'') as cptshotdesc ");
			queryString.append(" from service_detail  ");
			queryString.append(" inner join cpt on cpt_id=service_detail_cptid  ");
			queryString.append(" inner join submit_status on submit_status_code=service_detail_submit_status  ");
			queryString.append(" where service_detail_patientid= "+patientId+"::bigint and service_detail_dos::date='"+dosInfo+"' order by service_detail_order asc,service_detail_dos desc,service_detail_id asc");
			//System.out.println(" \n error query ############ Ledger page data  ##### "+queryString);
			jarray =  dbutils.executeQueryToJSONArray(queryString.toString(),true);
			//System.out.println("\n \n ############ Ledger page data result ##### "+jarray);
		}
		
		}
		catch(Exception e)
		{check=1;
		if((GWTJSONBean.getGwtRequestMode(request))==1){
			GWTJSONBean.setSuccess(request,false);
		}
		else{
		     e.printStackTrace();
		}
		}
		finally
		{if(GWTJSONBean.getGwtRequestMode(request)==1){
			if(check==0){
				GWTJSONBean.setSuccess(request,true);
			    GWTJSONBean.setJsonData(request,jarray.toString());
		}
		}
			try{
				if(dbutils!=null)
					dbutils.destroy();   
					dbutils = null;
            }catch(Exception e){
                e.printStackTrace();
            }
			
		}
		
		
		request.setAttribute("message",jarray.toString());
		return "ServiceEntryData.Screen";
	
	
	}
	
	public void destroy(){
		config = null;
	}
	
		private String  getSubmitStatus(DataBaseUtils dbutils) throws Exception
		{	

			String qrysubmitstatus="select submit_status_code as hsp001, case when length(trim(submit_status_description)) > 20 then substring(trim(submit_status_description),0,20) || '..' else trim(submit_status_description) end as hsp002 from submit_status  order by hsp001 ";
			JSONArray jsarray=dbutils.executeQueryToJSONArray(qrysubmitstatus,true);
			return jsarray.toString();
		}
		
		private String getRatePlans(DataBaseUtils dbutils) throws Exception
		{

			String qry="select rate_plan_id as hsp001, rate_plan_plan_name as hsp002 from rate_plan order by hsp002";
			JSONArray jsarray=dbutils.executeQueryToJSONArray(qry,true);
			return jsarray.toString();
		
		}
		private String getHowPaid(DataBaseUtils dbutils) throws Exception
		{
			String qry="select billing_reason_id as hsp001,case when length(trim(billing_reason_desc)) > 20 then substring(trim(billing_reason_desc),0,20) || '..' else trim(billing_reason_desc) end  as hsp002  from billing_reason order by hsp002";
			JSONArray jsarray=dbutils.executeQueryToJSONArray(qry,true);
			return jsarray.toString();
		}
		private String getTYpeOfService(DataBaseUtils dbutils) throws Exception
		{
			String qry="select blook_intid as hsp001,blook_name as hsp002 from billinglookup  where blook_group=3 order by 2";
			JSONArray jsarray=dbutils.executeQueryToJSONArray(qry,true);
			return jsarray.toString();
		}
		public String getAuthQry(String patientId, String cptCode){
			StringBuffer strQry = new StringBuffer();
			
			strQry.append(" Select authorization_referral_id as hsp001, authorization_referral_auth_no || '-('|| authorization_referral_auth_cptcode ||'-'||authorization_referral_auth_ins||')-'||  ins_company_name || '-' || authorization_referral_total_visits || '-' || authorization_referral_used_visits as hsp002 ,to_mmddyyyy(authorization_referral_start_date) as hsp003, to_mmddyyyy(authorization_referral_end_date) as hsp004,authorization_referral_doctor_id as hsp005,authorization_referral_total_visits - authorization_referral_used_visits as hsp006,authorization_referral_auth_cptcode as hsp007, authorization_referral_auth_ins as hsp008 from authorization_referral inner join ins_comp_addr on ins_comp_addr_id::text=authorization_referral_auth_ins::text");
			strQry.append(" inner join ins_company on ins_comp_addr_inscompany_id=ins_company_id");
			strQry.append(" where authorization_referral_reference_type=0 and authorization_referral_patient_id=" + patientId);
			
			return strQry.toString();
		}
		
		public String patientServiceQry(String patientId, String dosordop, String serdate, String servicetype, String posId, String doctorId, String copayCptId,int service,String lockdays,String current_date){
			StringBuffer strQry = new StringBuffer();
			strQry.append(" select service_detail_id as serviceid, service_detail_patientid as patientid, service_detail_submit_status as submit_status, claimstatus(service_detail_submit_status) as statusdesc ,to_mmddyyyy(service_detail_dos) as dosfrom,to_mmddyyyy(service_detail_dos_from) as dosto, to_mmddyyyy(service_detail_dop) as dop,");
			strQry.append(" cpt_cptcode as cptcode, service_detail_cptid as cptid, service_detail_comments as scomments, coalesce(service_detail_modifier1,'') as mod1, coalesce(service_detail_modifier2,'') as mod2, coalesce(service_detail_sdoctorid,-1) as sdoctorid, '' as sdoctor,");
			strQry.append(" '' as bdoctor, coalesce(service_detail_bdoctorid,-1) as bdoctorid, coalesce(service_detail_authid,-1) as authid, '' as authno, '' as referral,coalesce(ref.authorization_referral_doctor_id,-1) as referralid,");
			strQry.append(" '' as pos, coalesce(service_detail_posid,-1) as posid, coalesce(service_detail_unit,1) as units, coalesce(service_detail_charges,0) as charges, coalesce(service_detail_copay,0) as copay,");
			strQry.append(" service_detail_reference as tif_ref, service_detail_dx1 as dx1, service_detail_dx2 as dx2, service_detail_dx3 as dx3, service_detail_dx4 as dx4, coalesce(service_detail_primaryins,-1) as priinsid,");
			strQry.append(" '' as primaryins, coalesce(service_detail_secondaryins,-1) as secinsid, '' as secondins, coalesce(service_detail_other_ins,-1) as otherinsid, '' as otherins,");
			strQry.append(" patient_registration_id as gaurantorid, coalesce(patient_registration_last_name,'') as gaurantorlname, coalesce(patient_registration_first_name,'') as gaurantorfname, coalesce(patient_registration_mid_initial,'') as gaurantormi,");
			strQry.append(" rate_plan_plan_name as costplan, coalesce(associate_service_detail_costplan,-1) as costplanid, coalesce(payment.payments,0) as payments, 9999 as ptpayments,coalesce(payment.howpaidid,-1) as howpaidid,");
			strQry.append(" coalesce(payment.howpaid,'') as howpaid, coalesce(payment.checkid,-1) as checkid, coalesce(payment.checkno,'') as checkno ,coalesce(service_detail_billing_reason,-1) as billingreason, ");
			strQry.append(" coalesce(associate_service_detail_med_notes,'') as mednotes ,coalesce(service_detail_modifier3,'') as mod3 ,coalesce(service_detail_modifier4,'') as mod4 ,coalesce(service_detail_type_of_service,-1) as typeofservice,coalesce(service_detail_rlu_claim,'') as rlu_claim, ");
			strQry.append(" coalesce(service_detail_primary_claimid,-1) as claim_p, coalesce(service_detail_secondary_claimid,-1) as claim_s, coalesce(service_detail_rdoctorid,-2) as rdoctorid, coalesce(associate_service_detail_dosage,'') as dosage, coalesce(service_detail_other_ins,-1) as otherinsid,coalesce(est_pat_bal,0.00) as est_pat_pay,coalesce(service_detail_payment_group,-1) as paymentgroup,coalesce(servicetype,-1) as visittype, coalesce(service_detail_dx5,'') as dx5, coalesce(service_detail_dx6,'') as dx6, coalesce(service_detail_dx7,'') as dx7, coalesce(service_detail_dx8,'') as dx8,coalesce(service_detail_second_primary,-1) as secondprimary ");
			strQry.append(" ,coalesce(cpt_short_cut_desc,'') as cptdesc ");
			strQry.append(" from service_detail left join associate_service_detail on associate_service_detail_service_id=service_detail_id");
			strQry.append(" inner join patient_registration on patient_registration_id=service_detail_patientid inner join cpt on cpt_id=service_detail_cptid");
			
			strQry.append(" left join (select non_service_detail_service_id, sum(coalesce(non_service_detail_amount,0)) as payments,max(non_service_detail_payment_method) as howpaidid, max(names_mapping_plan_name) as howpaid,  max(non_service_detail_check_id) as checkid, max(receipt_detail_reference_no) as checkno from non_service_detail");
			strQry.append(" left join names_mapping on names_mapping_plan_id=non_service_detail_payment_method left join receipt_detail on receipt_detail_id=non_service_detail_check_id where non_service_detail_payment_cpt_id=" + copayCptId + " and non_service_detail_patient_id=" + patientId + " group by non_service_detail_service_id )payment on service_detail_id=non_service_detail_service_id");
			
			
			strQry.append(" left join authorization_referral ref on ref.authorization_referral_id=service_detail_referralid and ref.authorization_referral_reference_type=1");
			strQry.append(" left join rate_plan on associate_service_detail_costplan=rate_plan_id");
			strQry.append(" where service_detail_patientid=" + patientId );
		

		if (service == 0) {
			if (!(doctorId.equals("-1")))
				strQry.append(" and service_detail_sdoctorid=" + doctorId);
			if (!(posId.equals("-1")))
				strQry.append(" and service_detail_posid=" + posId);
		}
			return strQry.toString();
		}
		
		public String patientServiceEditQry(String patientId, String serviceId, String copayCptId){
			StringBuffer strQry = new StringBuffer();
			strQry.append(" select service_detail_id as serviceid, service_detail_patientid as patientid, service_detail_submit_status as submit_status, claimstatus(service_detail_submit_status) as statusdesc ,to_mmddyyyy(service_detail_dos) as dosfrom,to_mmddyyyy(service_detail_dos_from) as dosto,to_mmddyyyy(service_detail_dop) as dop,");
			strQry.append(" cpt_cptcode as cptcode, service_detail_cptid as cptid, service_detail_comments as scomments, coalesce(service_detail_modifier1,'') as mod1, coalesce(service_detail_modifier2,'') as mod2, coalesce(service_detail_sdoctorid,-1) as sdoctorid, sd.emp_profile_doctorid||'-'||case when length(trim(sd.emp_profile_fullname)) > 20 then substring(trim(sd.emp_profile_fullname),0,20) || '..' else trim(sd.emp_profile_fullname) end  as sdoctor,");
			strQry.append(" bd.emp_profile_doctorid||'-'||case when length(trim(bd.emp_profile_fullname)) > 20 then substring(trim(bd.emp_profile_fullname),0,20) || '..' else trim(bd.emp_profile_fullname) end  as bdoctor, coalesce(service_detail_bdoctorid,-1) as bdoctorid, coalesce(service_detail_authid,-1) as authid, '' as authno, referring_doctor_referringdoctor as referral,coalesce(ref.authorization_referral_doctor_id,-1) as referralid,");
			strQry.append(" '(' || coalesce(pos_table_pos_code,-2) || ')' || '(' || coalesce(pos_table_place_of_service,'') || ')' || case when length(trim(pos_table_facility_comments)) > 20 then substring(trim(pos_table_facility_comments),0,20) || '..' else trim(pos_table_facility_comments) end  as pos, coalesce(service_detail_posid,-1) as posid, coalesce(service_detail_unit,1) as units, coalesce(service_detail_charges,0) as charges, coalesce(service_detail_copay,0) as copay,");
			strQry.append(" service_detail_reference as tif_ref, service_detail_dx1 as dx1, service_detail_dx2 as dx2, service_detail_dx3 as dx3, service_detail_dx4 as dx4, coalesce(service_detail_primaryins,-1) as priinsid,");
			strQry.append(" '('||coalesce(patient_ins_detail_patientinsuranceid,'')||')'||case when length(trim(ins_company_name)) > 20 then substring(trim(ins_company_name),0,20) || '..' ||' Type-'||	case when coalesce(patient_ins_detail_instype,-1)=1 then 'P' else case when coalesce(patient_ins_detail_instype,-1)=4 then 'CHDP' else case when coalesce(patient_ins_detail_instype,-1)=5 then 'WC' else case when coalesce(patient_ins_detail_instype,-1)=6 then 'IPA' else case when coalesce(patient_ins_detail_instype,-1)=7 then 'AUTO' else case when coalesce(patient_ins_detail_instype,-1)=8 then 'PIP' else '' end end end end end end    else trim(ins_company_name )||' Type-'||case when coalesce(patient_ins_detail_instype,-1)=1 then 'P' else case when coalesce(patient_ins_detail_instype,-1)=4 then 'CHDP' else case when coalesce(patient_ins_detail_instype,-1)=5 then 'WC' else case when coalesce(patient_ins_detail_instype,-1)=6 then 'IPA' else case when coalesce(patient_ins_detail_instype,-1)=7 then 'AUTO' else case when coalesce(patient_ins_detail_instype,-1)=8 then 'PIP' else '' end end end end end end end as primaryins, coalesce(service_detail_secondaryins,-1) as secinsid, '' as secondins, coalesce(service_detail_other_ins,-1) as otherinsid, '' as otherins,");
			strQry.append(" patient_registration_id as gaurantorid, coalesce(patient_registration_last_name,'') as gaurantorlname, coalesce(patient_registration_first_name,'') as gaurantorfname, coalesce(patient_registration_mid_initial,'') as gaurantormi,");
			strQry.append(" rate_plan_plan_name as costplan, coalesce(associate_service_detail_costplan,-1) as costplanid, coalesce(payment.payments,0) as payments, 9999 as ptpayments,coalesce(payment.howpaidid,-1) as howpaidid,");
			strQry.append(" coalesce(payment.howpaid,'') as howpaid, coalesce(payment.checkid,-1) as checkid, coalesce(payment.checkno,'') as checkno ,coalesce(service_detail_billing_reason,-1) as billingreason, ");
			strQry.append(" coalesce(associate_service_detail_med_notes,'') as mednotes ,coalesce(service_detail_modifier3,'') as mod3 ,coalesce(service_detail_modifier4,'') as mod4 ,coalesce(service_detail_type_of_service,-1) as typeofservice,coalesce(service_detail_rlu_claim,'') as rlu_claim, ");
			strQry.append(" coalesce(service_detail_primary_claimid,-1) as claim_p, coalesce(service_detail_secondary_claimid,-1) as claim_s, coalesce(service_detail_rdoctorid,-2) as rdoctorid, coalesce(associate_service_detail_dosage,'') as dosage ,coalesce(payment.totalpayments,0) as totalpay,cpt_cpttype as cpttype,coalesce(associate_service_detail_unknown3,-1) as patientCase,coalesce(associate_service_detail_special_dx,'') as SPDX,caseno as caseno,case_description as case_desc,coalesce(enctype.groupid,-1) as  enctype, coalesce(service_detail_other_ins,-1) as otherinsid,coalesce(associate_service_detail_unknown6,'') as rlu_claim_1,coalesce(associate_service_detail_unknown7,'') as rlu_claim_2,coalesce(est_pat_bal,0.00) as est_pat_pay,coalesce(service_detail_payment_group,-1) as paymentgroup,coalesce(service_detail_scan,false) as updatemed,coalesce(servicetype,-1) as visittype, coalesce(service_detail_dx5,'') as dx5, coalesce(service_detail_dx6,'') as dx6, coalesce(service_detail_dx7,'') as dx7, coalesce(service_detail_dx8,'') as dx8,coalesce(service_detail_second_primary,-1) as secondprimary,coalesce(service_detail_placedby,'') as placedby,coalesce(service_detail_modifiedby,'') as modifiedby ,");
			strQry.append(" coalesce(service_detail_dx9,'') as dx9, coalesce(service_detail_dx10,'') as dx10, coalesce(service_detail_dx11,'') as dx11, coalesce(service_detail_dx12,'') as dx12, coalesce(service_detail_dx13,'') as dx13, coalesce(service_detail_dx14,'') as dx14, coalesce(service_detail_dx15,'') as dx15, coalesce(service_detail_dx16,'') as dx16, coalesce(service_detail_dx17,'') as dx17, coalesce(service_detail_dx18,'') as dx18, coalesce(service_detail_dx19,'') as dx19,coalesce(service_detail_dx20,'') as dx20 ,service_detail_acn as acn,"); 
			strQry.append(" service_detail_anes_starttime as anes_starttime,service_detail_anes_endtime as anes_endtime,coalesce(service_detail_hemoglobincnt,'') as hemoglobincount,service_detail_dls as dls,service_detail_dfs as dfs,coalesce(service_detail_ndc,'') as ndc,  ");
			strQry.append(" coalesce(service_detail_drugdosagedetail,'') as drug_dosagedetails,coalesce(service_detail_msptype,'') as msptype,service_detail_hosp_admdate as hospadm_date,split_part(coalesce(service_detail_hosp_admtime,''),'~',1)  as hospadmittimehrs,split_part(coalesce(service_detail_hosp_admtime,''),'~',2)  as hospadmittimemins,split_part(coalesce(service_detail_hosp_admtime,''),'~',3)  as hospadmittimesecs,split_part(coalesce(service_detail_hosp_distime,''),'~',1)  as hospdistimehrs,split_part(coalesce(service_detail_hosp_distime,''),'~',2)  as hospdistimemins,split_part(coalesce(service_detail_hosp_distime,''),'~',3)  as hospdistimesecs,service_detail_hosp_disdate as hospdis_date,service_detail_hosp_lmpdate as lmpdate,service_detail_injury_date as injury_date,coalesce(service_detail_medrec_number,'') as medrec_number ");
			strQry.append(" ,coalesce(cpt_short_cut_desc,'') as cptdesc,coalesce(service_detail_dxsystem,'') as dxsystem,coalesce(service_detail_dx1desc,'') as dx1desc,coalesce(service_detail_dx2desc,'') as dx2desc,coalesce(service_detail_dx3desc,'') as dx3desc,coalesce(service_detail_dx4desc,'') as dx4desc ");
			strQry.append(" ,coalesce(service_detail_dx5desc,'') as dx5desc,coalesce(service_detail_dx6desc,'') as dx6desc,coalesce(service_detail_dx7desc,'') as dx7desc,coalesce(service_detail_dx8desc,'') as dx8desc,coalesce(service_detail_dx9desc,'') as dx9desc,coalesce(service_detail_dx10desc,'') as dx10desc,coalesce(service_detail_dx11desc,'') as dx11desc,coalesce(service_detail_dx12desc,'') as dx12desc,coalesce(service_detail_dx13desc,'') as dx13desc,coalesce(service_detail_dx14desc,'') as dx14desc,coalesce(service_detail_dx15desc,'') as dx15desc,coalesce(service_detail_dx16desc,'') as dx16desc,coalesce(service_detail_dx17desc,'') as dx17desc,coalesce(service_detail_dx18desc,'') as dx18desc,coalesce(service_detail_dx19desc,'') as dx19desc,coalesce(service_detail_dx20desc,'') as dx20desc ");
			strQry.append(" from service_detail left join associate_service_detail on associate_service_detail_service_id=service_detail_id");
			strQry.append(" inner join patient_registration on patient_registration_id=service_detail_patientid inner join cpt on cpt_id=service_detail_cptid");
			strQry.append(" inner join emp_profile sd on sd.emp_profile_empid=service_detail_sdoctorid");
			strQry.append(" inner join emp_profile bd on bd.emp_profile_empid=service_detail_bdoctorid");
			strQry.append(" left join (select non_service_detail_service_id, sum(coalesce(non_service_detail_amount,0)) as payments,max(non_service_detail_payment_method) as howpaidid, max(names_mapping_plan_name) as howpaid,  max(non_service_detail_check_id) as checkid, max(receipt_detail_reference_no) as checkno,sum(non_service_detail_amount) as totalpayments from non_service_detail");
			strQry.append(" left join names_mapping on names_mapping_plan_id=non_service_detail_payment_method left join receipt_detail on receipt_detail_id=non_service_detail_check_id where non_service_detail_payment_cpt_id=" + copayCptId + " and non_service_detail_patient_id=" + patientId + " group by non_service_detail_service_id )payment on service_detail_id=non_service_detail_service_id");
			strQry.append(" left join authorization_referral ref on ref.authorization_referral_id=service_detail_referralid and ref.authorization_referral_reference_type=1");
			strQry.append(" left join referring_doctor on referring_doctor_uniqueid=ref.authorization_referral_doctor_id");
			strQry.append(" left join pos_table on pos_table_relation_id=service_detail_posid");
			strQry.append(" left join patient_ins_detail id1 on service_detail_primaryins=id1.patient_ins_detail_id");
			strQry.append(" left join ins_comp_addr ica1 on ica1.ins_comp_addr_id=id1.patient_ins_detail_insaddressid");
			strQry.append(" left join ins_company ic1 on ic1.ins_company_id=ica1.ins_comp_addr_inscompany_id");
			
			strQry.append(" left join rate_plan on associate_service_detail_costplan=rate_plan_id");
			strQry.append(" left join case_tab on caseno=associate_service_detail_unknown3 ");
			strQry.append(" left join (select distinct groupid,plantype from patient_encounter_type)enctype ");
			strQry.append(" on enctype.plantype=rate_plan_id ");
			strQry.append(" where service_detail_patientid=" + patientId );
			strQry.append(" and service_detail_id=" + serviceId );
			strQry.append(" order by serviceid" );
			GlaceOutLoggingStream.console("EDIT >> "+strQry.toString());
						return strQry.toString();
		}
		
		public String patientServiceForEMR(String patientId, String dos,String pos,String sdoc, String copayCptId){
			StringBuffer strQry = new StringBuffer();
			strQry.append(" select service_detail_id as serviceid, service_detail_patientid as patientid, service_detail_submit_status as submit_status, claimstatus(service_detail_submit_status) as statusdesc ,to_mmddyyyy(service_detail_dos) as dosfrom,to_mmddyyyy(service_detail_dos_from) as dosto, to_mmddyyyy(service_detail_dop) as dop,");
			strQry.append(" cpt_cptcode as cptcode, service_detail_cptid as cptid, service_detail_comments as scomments, coalesce(service_detail_modifier1,'') as mod1, coalesce(service_detail_modifier2,'') as mod2, coalesce(service_detail_sdoctorid,-1) as sdoctorid, '' as sdoctor,");
			strQry.append(" '' as bdoctor, coalesce(service_detail_bdoctorid,-1) as bdoctorid, coalesce(service_detail_authid,-1) as authid, '' as authno, '' as referral,coalesce(ref.authorization_referral_doctor_id,-1) as referralid,");
			strQry.append(" '' as pos, coalesce(service_detail_posid,-1) as posid, coalesce(service_detail_unit,1) as units, coalesce(service_detail_charges,0) as charges, coalesce(service_detail_copay,0) as copay,");
			strQry.append(" service_detail_reference as tif_ref, service_detail_dx1 as dx1, service_detail_dx2 as dx2, service_detail_dx3 as dx3, service_detail_dx4 as dx4, coalesce(service_detail_primaryins,-1) as priinsid,");
			strQry.append(" '' as primaryins, coalesce(service_detail_secondaryins,-1) as secinsid, '' as secondins, coalesce(service_detail_other_ins,-1) as otherinsid, '' as otherins,");
			strQry.append(" patient_registration_id as gaurantorid, coalesce(patient_registration_last_name,'') as gaurantorlname, coalesce(patient_registration_first_name,'') as gaurantorfname, coalesce(patient_registration_mid_initial,'') as gaurantormi,");
			strQry.append(" rate_plan_plan_name as costplan, coalesce(associate_service_detail_costplan,-1) as costplanid, coalesce(payment.payments,0) as payments, 9999 as ptpayments,coalesce(payment.howpaidid,-1) as howpaidid,");
			strQry.append(" coalesce(payment.howpaid,'') as howpaid, coalesce(payment.checkid,-1) as checkid, coalesce(payment.checkno,'') as checkno ,coalesce(service_detail_billing_reason,-1) as billingreason, ");
			strQry.append(" coalesce(associate_service_detail_med_notes,'') as mednotes ,coalesce(service_detail_modifier3,'') as mod3 ,coalesce(service_detail_modifier4,'') as mod4 ,coalesce(service_detail_type_of_service,-1) as typeofservice,coalesce(service_detail_rlu_claim,'') as rlu_claim, ");
			strQry.append(" coalesce(service_detail_primary_claimid,-1) as claim_p, coalesce(service_detail_secondary_claimid,-1) as claim_s, coalesce(service_detail_rdoctorid,-2) as rdoctorid, coalesce(associate_service_detail_dosage,'') as dosage ,coalesce(payment.totalpayments,0) as totalpay,cpt_cpttype as cpttype,coalesce(associate_service_detail_unknown3,-1) as patientCase,coalesce(associate_service_detail_special_dx,'') as SPDX,caseno as caseno,case_description as case_desc,coalesce(enctype.groupid,-1) as  enctype, coalesce(service_detail_other_ins,-1) as otherinsid,coalesce(associate_service_detail_unknown6,'') as rlu_claim_1,coalesce(associate_service_detail_unknown7,'') as rlu_claim_2,coalesce(est_pat_bal,0.00) as est_pat_pay,coalesce(service_detail_payment_group,-1) as paymentgroup,coalesce(servicetype,-1) as visittype, coalesce(service_detail_dx5,'') as dx5, coalesce(service_detail_dx6,'') as dx6, coalesce(service_detail_dx7,'') as dx7, coalesce(service_detail_dx8,'') as dx8,coalesce(service_detail_second_primary,-1) as secondprimary ,");
			strQry.append(" coalesce(service_detail_dx9,'') as dx9, coalesce(service_detail_dx10,'') as dx10, coalesce(service_detail_dx11,'') as dx11, coalesce(service_detail_dx12,'') as dx12, coalesce(service_detail_dx13,'') as dx13, coalesce(service_detail_dx14,'') as dx14, coalesce(service_detail_dx15,'') as dx15, coalesce(service_detail_dx16,'') as dx16, coalesce(service_detail_dx17,'') as dx17, coalesce(service_detail_dx18,'') as dx18, coalesce(service_detail_dx19,'') as dx19,coalesce(service_detail_dx20,'') as dx20 ,service_detail_acn as acn,");
			strQry.append(" service_detail_anes_starttime as anes_starttime,service_detail_anes_endtime as anes_endtime,coalesce(service_detail_hemoglobincnt,'') as hemoglobincount,service_detail_dls as dls,service_detail_dfs as dfs,coalesce(service_detail_ndc,'') as ndc,  ");
			strQry.append(" coalesce(service_detail_drugdosagedetail,'') as drug_dosagedetails,coalesce(service_detail_msptype,'') as msptype,service_detail_hosp_admdate as hospadm_date,split_part(coalesce(service_detail_hosp_admtime,''),'~',1)  as hospadmittimehrs,split_part(coalesce(service_detail_hosp_admtime,''),'~',2)  as hospadmittimemins,split_part(coalesce(service_detail_hosp_admtime,''),'~',3)  as hospadmittimesecs,split_part(coalesce(service_detail_hosp_distime,''),'~',1)  as hospdistimehrs,split_part(coalesce(service_detail_hosp_distime,''),'~',2)  as hospdistimemins,split_part(coalesce(service_detail_hosp_distime,''),'~',3)  as hospdistimesecs,service_detail_hosp_disdate as hospdis_date,service_detail_hosp_lmpdate as lmpdate,service_detail_injury_date as injury_date,coalesce(service_detail_medrec_number,'') as medrec_number ");
			strQry.append(" ,coalesce(cpt_short_cut_desc,'') as cptdesc,coalesce(service_detail_dxsystem,'') as dxsystem,coalesce(service_detail_dx1desc,'') as dx1desc,coalesce(service_detail_dx2desc,'') as dx2desc,coalesce(service_detail_dx3desc,'') as dx3desc,coalesce(service_detail_dx4desc,'') as dx4desc ");
			strQry.append(" ,coalesce(service_detail_dx5desc,'') as dx5desc,coalesce(service_detail_dx6desc,'') as dx6desc,coalesce(service_detail_dx7desc,'') as dx7desc,coalesce(service_detail_dx8desc,'') as dx8desc,coalesce(service_detail_dx9desc,'') as dx9desc,coalesce(service_detail_dx10desc,'') as dx10desc,coalesce(service_detail_dx11desc,'') as dx11desc,coalesce(service_detail_dx12desc,'') as dx12desc,coalesce(service_detail_dx13desc,'') as dx13desc,coalesce(service_detail_dx14desc,'') as dx14desc,coalesce(service_detail_dx15desc,'') as dx15desc,coalesce(service_detail_dx16desc,'') as dx16desc,coalesce(service_detail_dx17desc,'') as dx17desc,coalesce(service_detail_dx18desc,'') as dx18desc,coalesce(service_detail_dx19desc,'') as dx19desc,coalesce(service_detail_dx20desc,'') as dx20desc ");
strQry.append(" ,coalesce(service_detail_service_status,1) as serviceStatus,coalesce(service_detail_service_invalidreason,'') as invalidstatusreason,coalesce(service_detail_medicalnecessity_desc,'') as medicaldesc,coalesce(service_detail_medicalnecessity_type,'') as medicaltype,coalesce(service_detail_medicalnecessity_dxcodes,'') as medicaldiagnosis ");
			strQry.append(" from service_detail left join associate_service_detail on associate_service_detail_service_id=service_detail_id");
			strQry.append(" inner join patient_registration on patient_registration_id=service_detail_patientid inner join cpt on cpt_id=service_detail_cptid and cpt_cpttype=1");
			strQry.append(" left join (select non_service_detail_service_id, sum(coalesce(non_service_detail_amount,0)) as payments,max(non_service_detail_payment_method) as howpaidid, max(names_mapping_plan_name) as howpaid,  max(non_service_detail_check_id) as checkid, max(receipt_detail_reference_no) as checkno,sum(non_service_detail_amount) as totalpayments from non_service_detail");
			strQry.append(" left join names_mapping on names_mapping_plan_id=non_service_detail_payment_method left join receipt_detail on receipt_detail_id=non_service_detail_check_id where non_service_detail_payment_cpt_id=" + copayCptId + " and non_service_detail_patient_id=" + patientId + " group by non_service_detail_service_id )payment on service_detail_id=non_service_detail_service_id");
			strQry.append(" left join authorization_referral ref on ref.authorization_referral_id=service_detail_referralid and ref.authorization_referral_reference_type=1");
			strQry.append(" left join rate_plan on associate_service_detail_costplan=rate_plan_id");
			strQry.append(" left join case_tab on caseno=associate_service_detail_unknown3 ");
			strQry.append(" left join (select distinct groupid,plantype from patient_encounter_type)enctype ");
			strQry.append(" on enctype.plantype=rate_plan_id ");
			strQry.append(" where service_detail_submit_status not in ('B','Y')  and service_detail_patientid=" + patientId );
		
			strQry.append(" and service_detail_sdoctorid=" + sdoc );
			if(dos.equals(""))
				strQry.append(" and 1=2" );
			else
			strQry.append(" and service_detail_dos='" + dos+"'::date" );
			strQry.append(" order by serviceid" );
			
			System.out.println("+++++++++++query executed+++++++++"+strQry);	

						return strQry.toString();
						
						
						//jarray =  dbUtil.executeQueryToJSONArray(queryString.toString(),true);

		}
		public String checkService(String patientId, String dos,String pos,String sdoc){
			StringBuffer strQry = new StringBuffer();
			strQry.append(" select cpt_cptcode as cptcode,to_mmddyyyy(service_detail_dos) as dosfrom,coalesce(service_detail_modifier1,'') as mod1, coalesce(service_detail_modifier2,'') as mod2, coalesce(service_detail_sdoctorid,-1) as sdoctorid ");
			strQry.append(" from service_detail ");
			strQry.append(" inner join cpt on cpt_id=service_detail_cptid and cpt_cpttype=1 ");
			strQry.append(" where service_detail_patientid=" + patientId );
			strQry.append(" and service_detail_sdoctorid=" + sdoc );
			strQry.append(" and service_detail_posid=" + pos );
			if(dos.equals(""))
				strQry.append(" and 1=2" );
			else
			strQry.append(" and service_detail_dos='" + dos+"'::date" );
			System.out.println("\n in mode 40++++++++++query executed++++++++++" +strQry);	

						return strQry.toString();
		}
		
		public String patientServiceEditQryByDos(String patientId, String dos,String copayCptId){
			StringBuffer strQry = new StringBuffer();
			strQry.append(" select service_detail_id as serviceid, service_detail_patientid as patientid, service_detail_submit_status as submit_status, claimstatus(service_detail_submit_status) as statusdesc ,to_mmddyyyy(service_detail_dos) as dosfrom,to_mmddyyyy(service_detail_dos_from) as dosto, to_mmddyyyy(service_detail_dop) as dop,");
			strQry.append(" cpt_cptcode as cptcode, service_detail_cptid as cptid, service_detail_comments as scomments, coalesce(service_detail_modifier1,'') as mod1, coalesce(service_detail_modifier2,'') as mod2, coalesce(service_detail_sdoctorid,-1) as sdoctorid, '' as sdoctor,");
			strQry.append(" '' as bdoctor, coalesce(service_detail_bdoctorid,-1) as bdoctorid, coalesce(service_detail_authid,-1) as authid, '' as authno, '' as referral,coalesce(ref.authorization_referral_doctor_id,-1) as referralid,");
			strQry.append(" '' as pos, coalesce(service_detail_posid,-1) as posid, coalesce(service_detail_unit,1) as units, coalesce(service_detail_charges,0) as charges, coalesce(service_detail_copay,0) as copay,");
			strQry.append(" service_detail_reference as tif_ref, service_detail_dx1 as dx1, service_detail_dx2 as dx2, service_detail_dx3 as dx3, service_detail_dx4 as dx4, coalesce(service_detail_primaryins,-1) as priinsid,");
			strQry.append(" '' as primaryins, coalesce(service_detail_secondaryins,-1) as secinsid, '' as secondins, coalesce(service_detail_other_ins,-1) as otherinsid, '' as otherins,");
			strQry.append(" patient_registration_id as gaurantorid, coalesce(patient_registration_last_name,'') as gaurantorlname, coalesce(patient_registration_first_name,'') as gaurantorfname, coalesce(patient_registration_mid_initial,'') as gaurantormi,");
			strQry.append(" rate_plan_plan_name as costplan, coalesce(associate_service_detail_costplan,-1) as costplanid, coalesce(payment.payments,0) as payments, 9999 as ptpayments,coalesce(payment.howpaidid,-1) as howpaidid,");
			strQry.append(" coalesce(payment.howpaid,'') as howpaid, coalesce(payment.checkid,-1) as checkid, coalesce(payment.checkno,'') as checkno ,coalesce(service_detail_billing_reason,-1) as billingreason, ");
			strQry.append(" coalesce(associate_service_detail_med_notes,'') as mednotes ,coalesce(service_detail_modifier3,'') as mod3 ,coalesce(service_detail_modifier4,'') as mod4 ,coalesce(service_detail_type_of_service,-1) as typeofservice,coalesce(service_detail_rlu_claim,'') as rlu_claim, ");
			strQry.append(" coalesce(service_detail_primary_claimid,-1) as claim_p, coalesce(service_detail_secondary_claimid,-1) as claim_s, coalesce(service_detail_rdoctorid,-2) as rdoctorid, coalesce(associate_service_detail_dosage,'') as dosage ,coalesce(payment.totalpayments,0) as totalpay,cpt_cpttype as cpttype,coalesce(associate_service_detail_unknown3,-1) as patientCase,coalesce(associate_service_detail_special_dx,'') as SPDX,caseno as caseno,case_description as case_desc,coalesce(enctype.groupid,-1) as  enctype, coalesce(service_detail_other_ins,-1) as otherinsid, coalesce(associate_service_detail_unknown6,'') as rlu_claim_1,coalesce(associate_service_detail_unknown7,'') as rlu_claim_2,coalesce(service_detail_payment_group,-1) as paymentgroup,coalesce(service_detail_scan,false) as updatemed,coalesce(servicetype,-1) as visittype , coalesce(service_detail_dx5,'') as dx5, coalesce(service_detail_dx6,'') as dx6, coalesce(service_detail_dx7,'') as dx7, coalesce(service_detail_dx8,'') as dx8,coalesce(service_detail_second_primary,-1) as secondprimary ,");
			strQry.append(" coalesce(service_detail_dx9,'') as dx9, coalesce(service_detail_dx10,'') as dx10, coalesce(service_detail_dx11,'') as dx11, coalesce(service_detail_dx12,'') as dx12, coalesce(service_detail_dx13,'') as dx13, coalesce(service_detail_dx14,'') as dx14, coalesce(service_detail_dx15,'') as dx15, coalesce(service_detail_dx16,'') as dx16, coalesce(service_detail_dx17,'') as dx17, coalesce(service_detail_dx18,'') as dx18, coalesce(service_detail_dx19,'') as dx19,coalesce(service_detail_dx20,'') as dx20 ,service_detail_acn as acn,");
			strQry.append(" service_detail_anes_starttime as anes_starttime,service_detail_anes_endtime as anes_endtime,coalesce(service_detail_hemoglobincnt,'') as hemoglobincount,service_detail_dls as dls,service_detail_dfs as dfs,coalesce(service_detail_ndc,'') as ndc,  ");
			strQry.append(" coalesce(service_detail_drugdosagedetail,'') as drug_dosagedetails,coalesce(service_detail_msptype,'') as msptype,service_detail_hosp_admdate as hospadm_date,split_part(coalesce(service_detail_hosp_admtime,''),'~',1)  as hospadmittimehrs,split_part(coalesce(service_detail_hosp_admtime,''),'~',2)  as hospadmittimemins,split_part(coalesce(service_detail_hosp_admtime,''),'~',3)  as hospadmittimesecs,split_part(coalesce(service_detail_hosp_distime,''),'~',1)  as hospdistimehrs,split_part(coalesce(service_detail_hosp_distime,''),'~',2)  as hospdistimemins,split_part(coalesce(service_detail_hosp_distime,''),'~',3)  as hospdistimesecs,service_detail_hosp_disdate as hospdis_date,service_detail_hosp_lmpdate as lmpdate,service_detail_injury_date as injury_date,coalesce(service_detail_medrec_number,'') as medrec_number ");
			strQry.append(" ,coalesce(cpt_short_cut_desc,'') as cptdesc,coalesce(service_detail_dxsystem,'') as dxsystem,coalesce(service_detail_dx1desc,'') as dx1desc,coalesce(service_detail_dx2desc,'') as dx2desc,coalesce(service_detail_dx3desc,'') as dx3desc,coalesce(service_detail_dx4desc,'') as dx4desc ");
			strQry.append(" ,coalesce(service_detail_dx5desc,'') as dx5desc,coalesce(service_detail_dx6desc,'') as dx6desc,coalesce(service_detail_dx7desc,'') as dx7desc,coalesce(service_detail_dx8desc,'') as dx8desc,coalesce(service_detail_dx9desc,'') as dx9desc,coalesce(service_detail_dx10desc,'') as dx10desc,coalesce(service_detail_dx11desc,'') as dx11desc,coalesce(service_detail_dx12desc,'') as dx12desc,coalesce(service_detail_dx13desc,'') as dx13desc,coalesce(service_detail_dx14desc,'') as dx14desc,coalesce(service_detail_dx15desc,'') as dx15desc,coalesce(service_detail_dx16desc,'') as dx16desc,coalesce(service_detail_dx17desc,'') as dx17desc,coalesce(service_detail_dx18desc,'') as dx18desc,coalesce(service_detail_dx19desc,'') as dx19desc,coalesce(service_detail_dx20desc,'') as dx20desc ");
			strQry.append(" from service_detail left join associate_service_detail on associate_service_detail_service_id=service_detail_id");
			strQry.append(" inner join patient_registration on patient_registration_id=service_detail_patientid inner join cpt on cpt_id=service_detail_cptid and cpt_cpttype=1");
			strQry.append(" left join (select non_service_detail_service_id, sum(coalesce(non_service_detail_amount,0)) as payments,max(non_service_detail_payment_method) as howpaidid, max(names_mapping_plan_name) as howpaid,  max(non_service_detail_check_id) as checkid, max(receipt_detail_reference_no) as checkno,sum(non_service_detail_amount) as totalpayments from non_service_detail");
			strQry.append(" left join names_mapping on names_mapping_plan_id=non_service_detail_payment_method left join receipt_detail on receipt_detail_id=non_service_detail_check_id where non_service_detail_payment_cpt_id=" + copayCptId + " and non_service_detail_patient_id=" + patientId + " group by non_service_detail_service_id )payment on service_detail_id=non_service_detail_service_id");
			strQry.append(" left join authorization_referral ref on ref.authorization_referral_id=service_detail_referralid and ref.authorization_referral_reference_type=1");
			strQry.append(" left join rate_plan on associate_service_detail_costplan=rate_plan_id");
			strQry.append(" left join case_tab on caseno=associate_service_detail_unknown3 ");
			strQry.append(" left join (select distinct groupid,plantype from patient_encounter_type)enctype ");
			strQry.append(" on enctype.plantype=rate_plan_id ");
			strQry.append(" where service_detail_patientid=" + patientId );
			strQry.append(" and service_detail_dos='").append(dos).append("' and service_detail_submit_status not like 'X'");
			strQry.append(" order by serviceid" );
						return strQry.toString();
		}
		
		public String defaultAdditionalServiceFielData(String patientId){
			
			StringBuffer strQry = new StringBuffer();
			
			 strQry.append(" select coalesce(encounter_date,now()::date),patient_registration_hosp_date_from as hospadm_date, patient_registration_hosp_date_to as hospdis_date,patient_registration_datefirstseen as dfs,msp.id as msptype,  ");
			 strQry.append(" (case when patient_registration_sex=2 and coalesce(patient_clinical_elements_value,'') similar to '((0?[1-9]|[12][0-9]|3[01])/(0?[1-9]|1[012])/((19|20)\\d\\d))|((0?[1-9]|1[012])/(0?[1-9]|[12][0-9]|3[01])/((19|20)\\d\\d))'=true then patient_clinical_elements_value else patient_registration_xray_date::text end)::date as lmpdate ");
			 strQry.append(" from patient_registration left join  patient_clinical_elements on patient_clinical_elements_patientid=patient_registration_id ");
			 strQry.append(" left join vitals_parameter on trim(vitals_parameter_gw_id) ='0000200200100055000' left join encounter on patient_clinical_elements_encounterid = encounter_id  ");
			 strQry.append(" left join units_of_measure on vitals_parameter_unit_of_measure_id = units_of_measure_id  left join patient_ins_detail on patient_ins_detail_patientid=patient_registration_id  and patient_ins_detail_instype=2 and patient_ins_detail_isactive is true   left join msptype msp on patient_ins_detail_msp_type=msp.id  ");
  			 strQry.append(" where patient_registration_id=" + patientId );
  			 strQry.append(" order by 1 desc limit 1 ");
  			 
			return strQry.toString();
		}
		
		public BillingServiceDetailModel getServiceDetailDetails(DataBaseUtils dbUtils,int patientId,int sericeId){
			BillingServiceDetailModel returnValue=new BillingServiceDetailModel();
			StringBuffer strQry = new StringBuffer();
			ResultSet rst;
			try {
				strQry.append("select service_detail_id as serviceId, service_detail_patientid as patientId,to_mmddyyyy(service_detail_dos) as dos,to_mmddyyyy(service_detail_dos_from) as dosFrom,to_mmddyyyy(service_detail_dop) as dop,service_detail_cptid as cptId,coalesce(service_detail_unit,1)  as units,coalesce(service_detail_charges,0.00) as charges,coalesce(service_detail_copay,0.00) as copay,coalesce(service_detail_modifier1,'') as modifier1,coalesce(service_detail_modifier2,'') as modifier2,coalesce(service_detail_modifier3,'') as modifier3,coalesce(service_detail_modifier4,'') as modifier4,coalesce(service_detail_billing_reason,-1) as billingReason,coalesce(service_detail_sdoctorid,-1) as sDoctorId,coalesce(service_detail_bdoctorid,-1) as bDoctorId, ");
				strQry.append(" coalesce(service_detail_rdoctorid,-2) as rDoctorId,coalesce(service_detail_referralid,-1) as referralId,coalesce(service_detail_posid,-1) as posId,coalesce(service_detail_submit_status,'') as submitStatus,coalesce(service_detail_comments,'') as serviceComments,coalesce(service_detail_primaryins,-1)  as primaryIns,coalesce(service_detail_secondaryins,-1) as secondaryIns,coalesce(service_detail_other_ins,-1) as otherIns,coalesce(service_detail_authid,-1) as authId,coalesce(service_detail_reference,'') as serviceReference,coalesce(service_detail_source,'') as source,coalesce(service_detail_acn,'') as acn,coalesce(service_detail_dx1,'') as dx1,coalesce(service_detail_dx2,'') as dx2,coalesce(service_detail_dx3,'') as dx3,coalesce(service_detail_dx4,'') as dx4,coalesce(service_detail_dx5,'') as dx5, ");
				strQry.append(" coalesce(service_detail_dx6,'') as dx6,coalesce(service_detail_dx7,'') as dx7,coalesce(service_detail_dx8,'') as dx8,coalesce(service_detail_dx9,'') as dx9,coalesce(service_detail_dx10,'') as dx10,coalesce(service_detail_dx11,'') as dx11,coalesce(service_detail_dx12,'') as dx12,coalesce(service_detail_dx13,'') as dx13,coalesce(service_detail_dx14,'') as dx14,coalesce(service_detail_dx15,'') as dx15,coalesce(service_detail_dx16,'') as dx16,coalesce(service_detail_dx17,'') as dx17,coalesce(service_detail_dx18,'') as dx18,coalesce(service_detail_dx19,'') as dx19,coalesce(service_detail_dx20,'') as dx20,coalesce(service_detail_dxsystem,'') as dxSystem,coalesce(service_detail_second_primary,-1) as secondPrimary,coalesce(service_detail_scan,false) as serviceScan,isblocked as isBlocked, ");
				strQry.append(" coalesce(prev_est_pat_pay,0.00) as prevEstPatPay,coalesce(servicetype,-1) as serviceType,coalesce(service_detail_hosp_admtime,'') as hospAdmTime,coalesce(service_detail_hosp_distime,'') as hospDisTime,coalesce(service_detail_type_of_service,-1) as typeofService,coalesce(service_detail_rlu_claim,'') as rluClaim,coalesce(service_detail_payment_group,-1) as paymentGroup,coalesce(service_detail_anes_timeline,'') as anesTimeline,coalesce(service_detail_anes_starttime,'') as anesSTime,coalesce(service_detail_anes_endtime,'') as anesETime,coalesce(service_detail_hemoglobincnt,'') as hemoglobinCount,coalesce(service_detail_dls,'') as dls,coalesce(service_detail_dfs,'') as dfs, ");
				strQry.append(" coalesce(service_detail_ndc,'') as ndc,coalesce(service_detail_drugdosagedetail,'') as drugDosageDetail,coalesce(service_detail_msptype,'') as mspType,coalesce(service_detail_hosp_admdate,'') as hospAdmDate,coalesce(service_detail_hosp_disdate,'') as hospDisDate,coalesce(service_detail_hosp_lmpdate,'') as hospLmpDate,coalesce(service_detail_injury_date,'') as injuryDate,coalesce(service_detail_medrec_number,'') as medrecNumber,coalesce(service_detail_dx1desc,'') as dx1desc,coalesce(service_detail_dx2desc,'') as dx2desc,coalesce(service_detail_dx3desc,'') as dx3desc,coalesce(service_detail_dx4desc,'') as dx4desc,coalesce(service_detail_dx5desc,'') as dx5desc,coalesce(service_detail_dx6desc,'') as dx6desc,coalesce(service_detail_dx7desc,'') as dx7desc, ");
				strQry.append(" coalesce(service_detail_dx8desc,'') as dx8desc,coalesce(service_detail_dx9desc,'') as dx9desc,coalesce(service_detail_dx10desc,'') as dx10desc,coalesce(service_detail_dx11desc,'') as dx11desc,coalesce(service_detail_dx12desc,'') as dx12desc,coalesce(service_detail_dx13desc,'') as dx13desc,coalesce(service_detail_dx14desc,'') as dx14desc,coalesce(service_detail_dx15desc,'') as dx15desc,coalesce(service_detail_dx16desc,'') as dx16desc,coalesce(service_detail_dx17desc,'') as dx17desc,coalesce(service_detail_dx18desc,'') as dx18desc,coalesce(service_detail_dx19desc,'') as dx19desc,coalesce(service_detail_dx20desc,'') as dx20desc,associate_service_detail_id as associateServiceId,coalesce(associate_service_detail_dosage,'') as dosage, ");
				strQry.append(" coalesce( associate_service_detail_special_dx,'') as specialDx,coalesce(associate_service_detail_costplan,-1) as costPlan,coalesce(associate_service_detail_med_notes,'') as medNotes,coalesce(associate_service_detail_unknown3,-1) as associateUnknown3,coalesce(associate_service_detail_unknown6,'') as associateUnknown6,coalesce(associate_service_detail_unknown7,'') as  associateUnknown7 from service_detail left join associate_service_detail on service_detail_id=associate_service_detail_service_id ");
				strQry.append(" where service_detail_id= "+sericeId+" and service_detail_patientid="+patientId);
				rst=dbUtils.executeQuery(strQry.toString());
				if(rst.next()){	
					returnValue.setServiceId(sericeId);
					returnValue.setPatientId(patientId);
					returnValue.setSubmitStatus(rst.getString("submitstatus"));
					returnValue.setDosFrom(rst.getString("dos"));
					returnValue.setDosTO(rst.getString("dosfrom"));
					returnValue.setDop(rst.getString("dop"));
					returnValue.setCptId(Integer.parseInt(rst.getString("cptid")));
					returnValue.setMod1(rst.getString("modifier1"));
					returnValue.setMod2(rst.getString("modifier2"));
					returnValue.setScomments(rst.getString("servicecomments"));
					returnValue.setSdoctorId(Integer.parseInt(rst.getString("sdoctorid")));
					returnValue.setBdoctorId(Integer.parseInt(rst.getString("bdoctorid")));
					returnValue.setRdoctorId(Integer.parseInt(rst.getString("rdoctorid")));
					returnValue.setAuthId(Integer.parseInt(rst.getString("authid")));
					returnValue.setReferralId(Integer.parseInt(rst.getString("referralId")));
					returnValue.setPosId(Integer.parseInt(rst.getString("posid")));
					returnValue.setUnits(Float.parseFloat(rst.getString("units")));
					returnValue.setCharges(Double.parseDouble(rst.getString("charges")));
					returnValue.setCopay(Double.parseDouble(rst.getString("copay")));
					returnValue.setTifRef(rst.getString("servicereference"));
					returnValue.setScreenName(rst.getString("source"));
					returnValue.setDx1(rst.getString("dx1"));
					returnValue.setDx2(rst.getString("dx2"));
					returnValue.setDx3(rst.getString("dx3"));
					returnValue.setDx4(rst.getString("dx4"));
					returnValue.setDx5(rst.getString("dx5"));
					returnValue.setDx6(rst.getString("dx6"));
					returnValue.setDx7(rst.getString("dx7"));
					returnValue.setDx8(rst.getString("dx8"));
					returnValue.setDx9(rst.getString("dx9"));
					returnValue.setDx10(rst.getString("dx10"));
					returnValue.setDx11(rst.getString("dx11"));
					returnValue.setDx12(rst.getString("dx12"));
					returnValue.setDx13(rst.getString("dx13"));
					returnValue.setDx14(rst.getString("dx14"));
					returnValue.setDx15(rst.getString("dx15"));
					returnValue.setDx16(rst.getString("dx16"));
					returnValue.setDx17(rst.getString("dx17"));
					returnValue.setDx18(rst.getString("dx18"));
					returnValue.setDx19(rst.getString("dx19"));
					returnValue.setDx20(rst.getString("dx20"));
					returnValue.setDx1Description(rst.getString("dx1desc"));
					returnValue.setDx2Description(rst.getString("dx2desc"));
					returnValue.setDx3Description(rst.getString("dx3desc"));
					returnValue.setDx4Description(rst.getString("dx4desc"));
					returnValue.setDx5Description(rst.getString("dx5desc"));
					returnValue.setDx6Description(rst.getString("dx6desc"));
					returnValue.setDx7Description(rst.getString("dx7desc"));
					returnValue.setDx8Description(rst.getString("dx8desc"));
					returnValue.setDx9Description(rst.getString("dx9desc"));
					returnValue.setDx10Description(rst.getString("dx10desc"));
					returnValue.setDx11Description(rst.getString("dx11desc"));
					returnValue.setDx12Description(rst.getString("dx12desc"));
					returnValue.setDx13Description(rst.getString("dx13desc"));
					returnValue.setDx14Description(rst.getString("dx14desc"));
					returnValue.setDx15Description(rst.getString("dx15desc"));
					returnValue.setDx16Description(rst.getString("dx16desc"));
					returnValue.setDx17Description(rst.getString("dx17desc"));
					returnValue.setDx18Description(rst.getString("dx18desc"));
					returnValue.setDx19Description(rst.getString("dx19desc"));
					returnValue.setDx20Description(rst.getString("dx20desc"));
					returnValue.setAcn(rst.getString("acn"));
					returnValue.setHospAdmTime(rst.getString("hospadmtime"));
					returnValue.setHospDisTime(rst.getString("hospdisTime"));
					returnValue.setPriInsId(Integer.parseInt(rst.getString("primaryins")));
					returnValue.setSecInsId(Integer.parseInt(rst.getString("secondaryins")));
					returnValue.setOtherInsId(Integer.parseInt(rst.getString("otherins")));
					returnValue.setBillingReason(Integer.parseInt(rst.getString("billingreason")));
					returnValue.setMod3(rst.getString("modifier3"));
					returnValue.setMod4(rst.getString("modifier4"));
					returnValue.setTypeOfService(Integer.parseInt(rst.getString("typeofservice")));
					returnValue.setRlu_claim(rst.getString("rluclaim"));
					returnValue.setAnes_timeline(rst.getString("anestimeline"));
					returnValue.setAnes_starttime(rst.getString("anesstime"));
					returnValue.setAnes_endtime(rst.getString("anesetime"));
					returnValue.setHemoglobincount(rst.getString("hemoglobincount"));
					returnValue.setDls(rst.getString("dls"));
					returnValue.setDfs(rst.getString("dfs"));
					returnValue.setNdc(rst.getString("ndc"));
					returnValue.setDrug_dosagedetails(rst.getString("drugdosagedetail"));
					returnValue.setMsptype(rst.getString("msptype"));
					returnValue.setHospadm_date(rst.getString("hospadmdate"));
					returnValue.setHospdis_date(rst.getString("hospdisdate"));
					returnValue.setLmpdate(rst.getString("hosplmpdate"));
					returnValue.setInjury_date(rst.getString("injurydate"));
					returnValue.setMedrec_number(rst.getString("medrecnumber"));
					returnValue.setDxCodeSystemId(rst.getString("dxsystem"));
					returnValue.setSecondPrimaryInsId(Integer.parseInt(rst.getString("secondprimary")));
					returnValue.setUploadMed(Boolean.parseBoolean(rst.getString("serviceScan")));
					returnValue.setPrevEstimatedPatPay(Double.parseDouble(rst.getString("prevestpatpay")));
					returnValue.setVisitType(Integer.parseInt(rst.getString("servicetype")));
					returnValue.setDosage(rst.getString("dosage"));
					returnValue.setSPDX(rst.getString("specialdx"));
					returnValue.setCostPlan(rst.getString("costplan"));
					returnValue.setMedNotes(rst.getString("mednotes"));
					returnValue.setPatientCase(Integer.parseInt(rst.getString("associateunknown3")));
					returnValue.setRlu_claim_1(rst.getString("associateunknown6"));
					returnValue.setRlu_claim_2(rst.getString("associateunknown7"));
				}
				rst.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
			return returnValue;
		}
		
		/**
		 * Get encounter date from encounterId
		 * @param request
		 * @param dbUtils
		 * @return
		 */
		private String getEncounterDate(HttpServletRequest request, DataBaseUtils dbUtils) {
			String dosDate = HUtil.Nz(request.getParameter("dosDate"), "-1").trim();
			try{
				
				if(dosDate.equals("-1") || dosDate.isEmpty()){
					Date date= new Date();
					dosDate= new SimpleDateFormat("MM/dd/yyyy").format(date); 
				} else {
					Date date= new SimpleDateFormat("MM/dd/yyyy").parse(dosDate);
					dosDate= new SimpleDateFormat("MM/dd/yyyy").format(date);					
				}
				dosDate=dosDate.replaceAll("/", "");
				return dosDate;
			}catch(Exception e){
				try{
					Date date= new Date();
					dosDate= new SimpleDateFormat("MM/dd/yyyy").format(date);
					dosDate=dosDate.replaceAll("/", "");
					return dosDate;
				}catch(Exception e1){
					return "";
				}
			}
		}
}